/*
 * Copyright 2021-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.jdbc.core.dialect;

import java.sql.SQLType;

import org.springframework.data.relational.core.dialect.Dialect;

/**
 * {@link org.springframework.data.relational.core.dialect.ArrayColumns} that offer JDBC specific functionality.
 *
 * @author Jens Schauder
 * @author Mikhail Polivakha
 * @since 2.3
 */
public interface JdbcDialect extends Dialect {

	/**
	 * Returns the JDBC specific array support object that describes how array-typed columns are supported by this
	 * dialect.
	 *
	 * @return the JDBC specific array support object that describes how array-typed columns are supported by this
	 *         dialect.
	 */
	default JdbcArrayColumns getArraySupport() {
		return JdbcArrayColumns.Unsupported.INSTANCE;
	}

	/**
	 * Returns the {@link JdbcArrayColumns array support} for the given {@link Dialect}. Defaults to
	 * {@link JdbcArrayColumns.Unsupported} iff the dialect is not an instance of {@code JdbcDialect}.
	 *
	 * @param dialect the dialect to check for array support.
	 * @return the {@link JdbcArrayColumns} instance that describes how array-typed columns are supported by the dialect.
	 * @since 4.0
	 */
	static JdbcArrayColumns getArraySupport(Dialect dialect) {
		return dialect instanceof JdbcDialect jdbcDialect ? jdbcDialect.getArraySupport()
				: JdbcArrayColumns.DefaultSupport.INSTANCE;
	}

	/**
	 * Creates a {@link SQLType} for the given name and vendor type number.
	 *
	 * @param name type name that represents a SQL data type.
	 * @param vendorTypeNumber vendor-specific type number for the data type.
	 * @return a new {@link SQLType} for the given name and vendor type number.
	 */
	default SQLType createSqlType(String name, int vendorTypeNumber) {
		return new CustomSQLType(name, "Spring", vendorTypeNumber);
	}

}
