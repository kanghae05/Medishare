/*
 * Copyright 2019-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.relational.core.sql;

/**
 * AST {@link Segment} for a condition.
 *
 * @author Mark Paluch
 * @author Jens Schauder
 * @since 1.1
 * @see Conditions
 */
public interface Condition extends Segment, Expression {

	/**
	 * Combine another {@link Condition} using {@code AND}.
	 *
	 * @param other the other {@link Condition}.
	 * @return the combined {@link Condition}.
	 */
	default Condition and(Condition other) {
		return new AndCondition(this, other);
	}

	/**
	 * Combine another {@link Condition} using {@code OR}.
	 *
	 * @param other the other {@link Condition}.
	 * @return the combined {@link Condition}.
	 */
	default Condition or(Condition other) {
		return new OrCondition(this, other);
	}

	/**
	 * Creates a {@link Condition} that negates this {@link Condition}.
	 *
	 * @return the negated {@link Condition}.
	 */
	default Condition not() {
		return new Not(this);
	}
}
