/*
 * Copyright 2026-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.jpa.repository.support;

import org.springframework.lang.Nullable;

/**
 * Utility to determine whether a query result exists.
 *
 * @author Mark Paluch
 * @since 3.5.11
 */
class ExistsUtil {

	/**
	 * Determine whether the given count is greater than zero.
	 */
	public static boolean exists(long count) {
		return count > 0;
	}

	/**
	 * Determine whether the given count is greater than zero.
	 */
	public static boolean exists(@Nullable Long singleResult) {
		return singleResult != null && exists(singleResult.longValue());
	}

}
