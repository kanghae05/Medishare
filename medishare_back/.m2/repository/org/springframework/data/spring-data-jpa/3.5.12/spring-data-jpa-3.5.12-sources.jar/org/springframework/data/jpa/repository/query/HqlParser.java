// Generated from org/springframework/data/jpa/repository/query/Hql.g4 by ANTLR 4.13.0
package org.springframework.data.jpa.repository.query;

/**
 * HQL per https://docs.jboss.org/hibernate/orm/6.1/userguide/html_single/Hibernate_User_Guide.html#query-language
 *
 * This is a mixture of Hibernate's BNF and missing bits of grammar. There are gaps and inconsistencies in the
 * BNF itself, explained by other fragments of their spec. Additionally, alternate labels are used to provide easier
 * management of complex rules in the generated Visitor. Finally, there are labels applied to rule elements (op=('+'|'-')
 * to simplify the processing.
 *
 * @author Greg Turnquist
 * @author Mark Paluch
 * @author Yannick Brandt
 * @since 3.1
 */

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
class HqlParser extends Parser {
	// Customization: Suppress version check
	// static { RuntimeMetaData.checkVersion("4.13.0", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, WS=22, COMMENT=23, ASTERISK=24, 
		ID=25, VERSION=26, VERSIONED=27, NATURALID=28, FK=29, ALL=30, AND=31, 
		ANY=32, AS=33, ASC=34, AVG=35, BETWEEN=36, BOTH=37, BREADTH=38, BY=39, 
		CASE=40, CAST=41, COLLATE=42, COLUMN=43, CONFLICT=44, CONSTRAINT=45, CONTAINS=46, 
		COUNT=47, CROSS=48, CUBE=49, CURRENT=50, CURRENT_DATE=51, CURRENT_INSTANT=52, 
		CURRENT_TIME=53, CURRENT_TIMESTAMP=54, CYCLE=55, DATE=56, DATETIME=57, 
		DAY=58, DEFAULT=59, DELETE=60, DEPTH=61, DESC=62, DISTINCT=63, DO=64, 
		ELEMENT=65, ELEMENTS=66, ELSE=67, EMPTY=68, END=69, ENTRY=70, EPOCH=71, 
		ERROR=72, ESCAPE=73, EVERY=74, EXCEPT=75, EXCLUDE=76, EXISTS=77, EXTRACT=78, 
		FETCH=79, FILTER=80, FIRST=81, FOLLOWING=82, FOR=83, FORMAT=84, FROM=85, 
		FULL=86, FUNCTION=87, GROUP=88, GROUPS=89, HAVING=90, HOUR=91, IGNORE=92, 
		ILIKE=93, IN=94, INCLUDES=95, INDEX=96, INDICES=97, INNER=98, INSERT=99, 
		INSTANT=100, INTERSECT=101, INTERSECTS=102, INTO=103, IS=104, JOIN=105, 
		KEY=106, KEYS=107, LAST=108, LATERAL=109, LEADING=110, LEFT=111, LIKE=112, 
		LIMIT=113, LIST=114, LISTAGG=115, LOCAL=116, LOCAL_DATE=117, LOCAL_DATETIME=118, 
		LOCAL_TIME=119, MAP=120, MATERIALIZED=121, MAX=122, MAXELEMENT=123, MAXINDEX=124, 
		MEMBER=125, MICROSECOND=126, MILLISECOND=127, MIN=128, MINELEMENT=129, 
		MININDEX=130, MINUTE=131, MONTH=132, NANOSECOND=133, NEW=134, NEXT=135, 
		NO=136, NOT=137, NOTHING=138, NULLS=139, OBJECT=140, OF=141, OFFSET=142, 
		OFFSET_DATETIME=143, ON=144, ONLY=145, OR=146, ORDER=147, OTHERS=148, 
		OUTER=149, OVER=150, OVERFLOW=151, OVERLAY=152, PAD=153, PARTITION=154, 
		PERCENT=155, PLACING=156, POSITION=157, PRECEDING=158, QUARTER=159, RANGE=160, 
		RESPECT=161, RIGHT=162, ROLLUP=163, ROW=164, ROWS=165, SEARCH=166, SECOND=167, 
		SELECT=168, SET=169, SIZE=170, SOME=171, SUBSTRING=172, SUM=173, THEN=174, 
		TIES=175, TIME=176, TIMESTAMP=177, TIMEZONE_HOUR=178, TIMEZONE_MINUTE=179, 
		TO=180, TRAILING=181, TREAT=182, TRIM=183, TRUNC=184, TRUNCATE=185, TYPE=186, 
		UNBOUNDED=187, UNION=188, UPDATE=189, USING=190, VALUE=191, VALUES=192, 
		WEEK=193, WHEN=194, WHERE=195, WITH=196, WITHIN=197, WITHOUT=198, YEAR=199, 
		ZONED=200, NULL=201, TRUE=202, FALSE=203, STRING_LITERAL=204, JAVA_STRING_LITERAL=205, 
		INTEGER_LITERAL=206, LONG_LITERAL=207, FLOAT_LITERAL=208, DOUBLE_LITERAL=209, 
		BIG_INTEGER_LITERAL=210, BIG_DECIMAL_LITERAL=211, HEX_LITERAL=212, BINARY_LITERAL=213, 
		TIMESTAMP_ESCAPE_START=214, DATE_ESCAPE_START=215, TIME_ESCAPE_START=216, 
		PLUS=217, MINUS=218, IDENTIFIER=219, QUOTED_IDENTIFIER=220;
	public static final int
		RULE_start = 0, RULE_ql_statement = 1, RULE_selectStatement = 2, RULE_queryExpression = 3, 
		RULE_withClause = 4, RULE_cte = 5, RULE_searchClause = 6, RULE_searchSpecifications = 7, 
		RULE_searchSpecification = 8, RULE_cycleClause = 9, RULE_cteAttributes = 10, 
		RULE_orderedQuery = 11, RULE_query = 12, RULE_queryOrder = 13, RULE_fromClause = 14, 
		RULE_entityWithJoins = 15, RULE_joinSpecifier = 16, RULE_fromRoot = 17, 
		RULE_join = 18, RULE_joinTarget = 19, RULE_updateStatement = 20, RULE_targetEntity = 21, 
		RULE_setClause = 22, RULE_assignment = 23, RULE_deleteStatement = 24, 
		RULE_insertStatement = 25, RULE_targetFields = 26, RULE_valuesList = 27, 
		RULE_values = 28, RULE_conflictClause = 29, RULE_conflictTarget = 30, 
		RULE_conflictAction = 31, RULE_instantiation = 32, RULE_groupedItem = 33, 
		RULE_sortedItem = 34, RULE_sortExpression = 35, RULE_sortDirection = 36, 
		RULE_nullsPrecedence = 37, RULE_limitClause = 38, RULE_offsetClause = 39, 
		RULE_fetchClause = 40, RULE_subquery = 41, RULE_selectClause = 42, RULE_selectionList = 43, 
		RULE_selection = 44, RULE_selectExpression = 45, RULE_mapEntrySelection = 46, 
		RULE_jpaSelectObjectSyntax = 47, RULE_whereClause = 48, RULE_joinType = 49, 
		RULE_crossJoin = 50, RULE_joinRestriction = 51, RULE_jpaCollectionJoin = 52, 
		RULE_groupByClause = 53, RULE_orderByClause = 54, RULE_havingClause = 55, 
		RULE_setOperator = 56, RULE_literal = 57, RULE_booleanLiteral = 58, RULE_numericLiteral = 59, 
		RULE_dateTimeLiteral = 60, RULE_localDateTimeLiteral = 61, RULE_zonedDateTimeLiteral = 62, 
		RULE_offsetDateTimeLiteral = 63, RULE_dateLiteral = 64, RULE_timeLiteral = 65, 
		RULE_dateTime = 66, RULE_localDateTime = 67, RULE_zonedDateTime = 68, 
		RULE_offsetDateTime = 69, RULE_offsetDateTimeWithMinutes = 70, RULE_jdbcTimestampLiteral = 71, 
		RULE_jdbcDateLiteral = 72, RULE_jdbcTimeLiteral = 73, RULE_genericTemporalLiteralText = 74, 
		RULE_arrayLiteral = 75, RULE_generalizedLiteral = 76, RULE_generalizedLiteralType = 77, 
		RULE_generalizedLiteralText = 78, RULE_date = 79, RULE_time = 80, RULE_offset = 81, 
		RULE_offsetWithMinutes = 82, RULE_year = 83, RULE_month = 84, RULE_day = 85, 
		RULE_hour = 86, RULE_minute = 87, RULE_second = 88, RULE_zoneId = 89, 
		RULE_extractField = 90, RULE_datetimeField = 91, RULE_dayField = 92, RULE_weekField = 93, 
		RULE_timeZoneField = 94, RULE_dateOrTimeField = 95, RULE_binaryLiteral = 96, 
		RULE_temporalLiteral = 97, RULE_expression = 98, RULE_primaryExpression = 99, 
		RULE_path = 100, RULE_generalPathFragment = 101, RULE_indexedPathAccessFragment = 102, 
		RULE_simplePath = 103, RULE_simplePathElement = 104, RULE_pathContinuation = 105, 
		RULE_entityTypeReference = 106, RULE_entityIdReference = 107, RULE_entityVersionReference = 108, 
		RULE_entityNaturalIdReference = 109, RULE_syntacticDomainPath = 110, RULE_slicedPathAccessFragment = 111, 
		RULE_treatedNavigablePath = 112, RULE_collectionValueNavigablePath = 113, 
		RULE_mapKeyNavigablePath = 114, RULE_toOneFkReference = 115, RULE_caseList = 116, 
		RULE_simpleCaseExpression = 117, RULE_searchedCaseExpression = 118, RULE_caseWhenExpressionClause = 119, 
		RULE_caseWhenPredicateClause = 120, RULE_function = 121, RULE_standardFunction = 122, 
		RULE_castFunction = 123, RULE_castTarget = 124, RULE_castTargetType = 125, 
		RULE_substringFunction = 126, RULE_substringFunctionStartArgument = 127, 
		RULE_substringFunctionLengthArgument = 128, RULE_trimFunction = 129, RULE_trimSpecification = 130, 
		RULE_trimCharacter = 131, RULE_padFunction = 132, RULE_padSpecification = 133, 
		RULE_padCharacter = 134, RULE_padLength = 135, RULE_positionFunction = 136, 
		RULE_positionFunctionPatternArgument = 137, RULE_positionFunctionStringArgument = 138, 
		RULE_overlayFunction = 139, RULE_overlayFunctionStringArgument = 140, 
		RULE_overlayFunctionReplacementArgument = 141, RULE_overlayFunctionStartArgument = 142, 
		RULE_overlayFunctionLengthArgument = 143, RULE_currentDateFunction = 144, 
		RULE_currentTimeFunction = 145, RULE_currentTimestampFunction = 146, RULE_instantFunction = 147, 
		RULE_localDateTimeFunction = 148, RULE_offsetDateTimeFunction = 149, RULE_localDateFunction = 150, 
		RULE_localTimeFunction = 151, RULE_formatFunction = 152, RULE_collation = 153, 
		RULE_collateFunction = 154, RULE_cube = 155, RULE_rollup = 156, RULE_format = 157, 
		RULE_extractFunction = 158, RULE_truncFunction = 159, RULE_jpaNonstandardFunction = 160, 
		RULE_jpaNonstandardFunctionName = 161, RULE_columnFunction = 162, RULE_genericFunction = 163, 
		RULE_genericFunctionName = 164, RULE_genericFunctionArguments = 165, RULE_collectionSizeFunction = 166, 
		RULE_collectionAggregateFunction = 167, RULE_collectionFunctionMisuse = 168, 
		RULE_aggregateFunction = 169, RULE_everyFunction = 170, RULE_anyFunction = 171, 
		RULE_everyAllQuantifier = 172, RULE_anySomeQuantifier = 173, RULE_listaggFunction = 174, 
		RULE_onOverflowClause = 175, RULE_withinGroupClause = 176, RULE_filterClause = 177, 
		RULE_nullsClause = 178, RULE_nthSideClause = 179, RULE_overClause = 180, 
		RULE_partitionClause = 181, RULE_frameClause = 182, RULE_frameStart = 183, 
		RULE_frameEnd = 184, RULE_frameExclusion = 185, RULE_predicate = 186, 
		RULE_expressionOrPredicate = 187, RULE_collectionQuantifier = 188, RULE_elementsValuesQuantifier = 189, 
		RULE_elementValueQuantifier = 190, RULE_indexKeyQuantifier = 191, RULE_indicesKeysQuantifier = 192, 
		RULE_relationalExpression = 193, RULE_betweenExpression = 194, RULE_stringPatternMatching = 195, 
		RULE_inExpression = 196, RULE_inList = 197, RULE_existsExpression = 198, 
		RULE_instantiationTarget = 199, RULE_instantiationArguments = 200, RULE_instantiationArgument = 201, 
		RULE_parameterOrIntegerLiteral = 202, RULE_parameterOrNumberLiteral = 203, 
		RULE_variable = 204, RULE_parameter = 205, RULE_entityName = 206, RULE_nakedIdentifier = 207, 
		RULE_identifier = 208;
	private static String[] makeRuleNames() {
		return new String[] {
			"start", "ql_statement", "selectStatement", "queryExpression", "withClause", 
			"cte", "searchClause", "searchSpecifications", "searchSpecification", 
			"cycleClause", "cteAttributes", "orderedQuery", "query", "queryOrder", 
			"fromClause", "entityWithJoins", "joinSpecifier", "fromRoot", "join", 
			"joinTarget", "updateStatement", "targetEntity", "setClause", "assignment", 
			"deleteStatement", "insertStatement", "targetFields", "valuesList", "values", 
			"conflictClause", "conflictTarget", "conflictAction", "instantiation", 
			"groupedItem", "sortedItem", "sortExpression", "sortDirection", "nullsPrecedence", 
			"limitClause", "offsetClause", "fetchClause", "subquery", "selectClause", 
			"selectionList", "selection", "selectExpression", "mapEntrySelection", 
			"jpaSelectObjectSyntax", "whereClause", "joinType", "crossJoin", "joinRestriction", 
			"jpaCollectionJoin", "groupByClause", "orderByClause", "havingClause", 
			"setOperator", "literal", "booleanLiteral", "numericLiteral", "dateTimeLiteral", 
			"localDateTimeLiteral", "zonedDateTimeLiteral", "offsetDateTimeLiteral", 
			"dateLiteral", "timeLiteral", "dateTime", "localDateTime", "zonedDateTime", 
			"offsetDateTime", "offsetDateTimeWithMinutes", "jdbcTimestampLiteral", 
			"jdbcDateLiteral", "jdbcTimeLiteral", "genericTemporalLiteralText", "arrayLiteral", 
			"generalizedLiteral", "generalizedLiteralType", "generalizedLiteralText", 
			"date", "time", "offset", "offsetWithMinutes", "year", "month", "day", 
			"hour", "minute", "second", "zoneId", "extractField", "datetimeField", 
			"dayField", "weekField", "timeZoneField", "dateOrTimeField", "binaryLiteral", 
			"temporalLiteral", "expression", "primaryExpression", "path", "generalPathFragment", 
			"indexedPathAccessFragment", "simplePath", "simplePathElement", "pathContinuation", 
			"entityTypeReference", "entityIdReference", "entityVersionReference", 
			"entityNaturalIdReference", "syntacticDomainPath", "slicedPathAccessFragment", 
			"treatedNavigablePath", "collectionValueNavigablePath", "mapKeyNavigablePath", 
			"toOneFkReference", "caseList", "simpleCaseExpression", "searchedCaseExpression", 
			"caseWhenExpressionClause", "caseWhenPredicateClause", "function", "standardFunction", 
			"castFunction", "castTarget", "castTargetType", "substringFunction", 
			"substringFunctionStartArgument", "substringFunctionLengthArgument", 
			"trimFunction", "trimSpecification", "trimCharacter", "padFunction", 
			"padSpecification", "padCharacter", "padLength", "positionFunction", 
			"positionFunctionPatternArgument", "positionFunctionStringArgument", 
			"overlayFunction", "overlayFunctionStringArgument", "overlayFunctionReplacementArgument", 
			"overlayFunctionStartArgument", "overlayFunctionLengthArgument", "currentDateFunction", 
			"currentTimeFunction", "currentTimestampFunction", "instantFunction", 
			"localDateTimeFunction", "offsetDateTimeFunction", "localDateFunction", 
			"localTimeFunction", "formatFunction", "collation", "collateFunction", 
			"cube", "rollup", "format", "extractFunction", "truncFunction", "jpaNonstandardFunction", 
			"jpaNonstandardFunctionName", "columnFunction", "genericFunction", "genericFunctionName", 
			"genericFunctionArguments", "collectionSizeFunction", "collectionAggregateFunction", 
			"collectionFunctionMisuse", "aggregateFunction", "everyFunction", "anyFunction", 
			"everyAllQuantifier", "anySomeQuantifier", "listaggFunction", "onOverflowClause", 
			"withinGroupClause", "filterClause", "nullsClause", "nthSideClause", 
			"overClause", "partitionClause", "frameClause", "frameStart", "frameEnd", 
			"frameExclusion", "predicate", "expressionOrPredicate", "collectionQuantifier", 
			"elementsValuesQuantifier", "elementValueQuantifier", "indexKeyQuantifier", 
			"indicesKeysQuantifier", "relationalExpression", "betweenExpression", 
			"stringPatternMatching", "inExpression", "inList", "existsExpression", 
			"instantiationTarget", "instantiationArguments", "instantiationArgument", 
			"parameterOrIntegerLiteral", "parameterOrNumberLiteral", "variable", 
			"parameter", "entityName", "nakedIdentifier", "identifier"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'('", "')'", "'='", "'%'", "'}'", "'['", "']'", "':'", 
			"'/'", "'{'", "'||'", "'.'", "'>'", "'>='", "'<'", "'<='", "'<>'", "'!='", 
			"'^='", "'?'", null, null, "'*'", null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, "'{ts'", "'{d'", "'{t'", "'+'", "'-'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, "WS", "COMMENT", 
			"ASTERISK", "ID", "VERSION", "VERSIONED", "NATURALID", "FK", "ALL", "AND", 
			"ANY", "AS", "ASC", "AVG", "BETWEEN", "BOTH", "BREADTH", "BY", "CASE", 
			"CAST", "COLLATE", "COLUMN", "CONFLICT", "CONSTRAINT", "CONTAINS", "COUNT", 
			"CROSS", "CUBE", "CURRENT", "CURRENT_DATE", "CURRENT_INSTANT", "CURRENT_TIME", 
			"CURRENT_TIMESTAMP", "CYCLE", "DATE", "DATETIME", "DAY", "DEFAULT", "DELETE", 
			"DEPTH", "DESC", "DISTINCT", "DO", "ELEMENT", "ELEMENTS", "ELSE", "EMPTY", 
			"END", "ENTRY", "EPOCH", "ERROR", "ESCAPE", "EVERY", "EXCEPT", "EXCLUDE", 
			"EXISTS", "EXTRACT", "FETCH", "FILTER", "FIRST", "FOLLOWING", "FOR", 
			"FORMAT", "FROM", "FULL", "FUNCTION", "GROUP", "GROUPS", "HAVING", "HOUR", 
			"IGNORE", "ILIKE", "IN", "INCLUDES", "INDEX", "INDICES", "INNER", "INSERT", 
			"INSTANT", "INTERSECT", "INTERSECTS", "INTO", "IS", "JOIN", "KEY", "KEYS", 
			"LAST", "LATERAL", "LEADING", "LEFT", "LIKE", "LIMIT", "LIST", "LISTAGG", 
			"LOCAL", "LOCAL_DATE", "LOCAL_DATETIME", "LOCAL_TIME", "MAP", "MATERIALIZED", 
			"MAX", "MAXELEMENT", "MAXINDEX", "MEMBER", "MICROSECOND", "MILLISECOND", 
			"MIN", "MINELEMENT", "MININDEX", "MINUTE", "MONTH", "NANOSECOND", "NEW", 
			"NEXT", "NO", "NOT", "NOTHING", "NULLS", "OBJECT", "OF", "OFFSET", "OFFSET_DATETIME", 
			"ON", "ONLY", "OR", "ORDER", "OTHERS", "OUTER", "OVER", "OVERFLOW", "OVERLAY", 
			"PAD", "PARTITION", "PERCENT", "PLACING", "POSITION", "PRECEDING", "QUARTER", 
			"RANGE", "RESPECT", "RIGHT", "ROLLUP", "ROW", "ROWS", "SEARCH", "SECOND", 
			"SELECT", "SET", "SIZE", "SOME", "SUBSTRING", "SUM", "THEN", "TIES", 
			"TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", 
			"TREAT", "TRIM", "TRUNC", "TRUNCATE", "TYPE", "UNBOUNDED", "UNION", "UPDATE", 
			"USING", "VALUE", "VALUES", "WEEK", "WHEN", "WHERE", "WITH", "WITHIN", 
			"WITHOUT", "YEAR", "ZONED", "NULL", "TRUE", "FALSE", "STRING_LITERAL", 
			"JAVA_STRING_LITERAL", "INTEGER_LITERAL", "LONG_LITERAL", "FLOAT_LITERAL", 
			"DOUBLE_LITERAL", "BIG_INTEGER_LITERAL", "BIG_DECIMAL_LITERAL", "HEX_LITERAL", 
			"BINARY_LITERAL", "TIMESTAMP_ESCAPE_START", "DATE_ESCAPE_START", "TIME_ESCAPE_START", 
			"PLUS", "MINUS", "IDENTIFIER", "QUOTED_IDENTIFIER"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Hql.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public HqlParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StartContext extends ParserRuleContext {
		public Ql_statementContext ql_statement() {
			return getRuleContext(Ql_statementContext.class,0);
		}
		public TerminalNode EOF() { return getToken(HqlParser.EOF, 0); }
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(418);
			ql_statement();
			setState(419);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Ql_statementContext extends ParserRuleContext {
		public SelectStatementContext selectStatement() {
			return getRuleContext(SelectStatementContext.class,0);
		}
		public UpdateStatementContext updateStatement() {
			return getRuleContext(UpdateStatementContext.class,0);
		}
		public DeleteStatementContext deleteStatement() {
			return getRuleContext(DeleteStatementContext.class,0);
		}
		public InsertStatementContext insertStatement() {
			return getRuleContext(InsertStatementContext.class,0);
		}
		public Ql_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ql_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterQl_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitQl_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitQl_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ql_statementContext ql_statement() throws RecognitionException {
		Ql_statementContext _localctx = new Ql_statementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_ql_statement);
		try {
			setState(425);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
			case FROM:
			case SELECT:
			case WITH:
				enterOuterAlt(_localctx, 1);
				{
				setState(421);
				selectStatement();
				}
				break;
			case UPDATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(422);
				updateStatement();
				}
				break;
			case DELETE:
				enterOuterAlt(_localctx, 3);
				{
				setState(423);
				deleteStatement();
				}
				break;
			case INSERT:
				enterOuterAlt(_localctx, 4);
				{
				setState(424);
				insertStatement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectStatementContext extends ParserRuleContext {
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public SelectStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectStatementContext selectStatement() throws RecognitionException {
		SelectStatementContext _localctx = new SelectStatementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_selectStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(427);
			queryExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QueryExpressionContext extends ParserRuleContext {
		public List<OrderedQueryContext> orderedQuery() {
			return getRuleContexts(OrderedQueryContext.class);
		}
		public OrderedQueryContext orderedQuery(int i) {
			return getRuleContext(OrderedQueryContext.class,i);
		}
		public WithClauseContext withClause() {
			return getRuleContext(WithClauseContext.class,0);
		}
		public List<SetOperatorContext> setOperator() {
			return getRuleContexts(SetOperatorContext.class);
		}
		public SetOperatorContext setOperator(int i) {
			return getRuleContext(SetOperatorContext.class,i);
		}
		public QueryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterQueryExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitQueryExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitQueryExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryExpressionContext queryExpression() throws RecognitionException {
		QueryExpressionContext _localctx = new QueryExpressionContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_queryExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(430);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WITH) {
				{
				setState(429);
				withClause();
				}
			}

			setState(432);
			orderedQuery();
			setState(438);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXCEPT || _la==INTERSECT || _la==UNION) {
				{
				{
				setState(433);
				setOperator();
				setState(434);
				orderedQuery();
				}
				}
				setState(440);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WithClauseContext extends ParserRuleContext {
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public List<CteContext> cte() {
			return getRuleContexts(CteContext.class);
		}
		public CteContext cte(int i) {
			return getRuleContext(CteContext.class,i);
		}
		public WithClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_withClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWithClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWithClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWithClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WithClauseContext withClause() throws RecognitionException {
		WithClauseContext _localctx = new WithClauseContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_withClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(441);
			match(WITH);
			setState(442);
			cte();
			setState(447);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(443);
				match(T__0);
				setState(444);
				cte();
				}
				}
				setState(449);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CteContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public TerminalNode MATERIALIZED() { return getToken(HqlParser.MATERIALIZED, 0); }
		public SearchClauseContext searchClause() {
			return getRuleContext(SearchClauseContext.class,0);
		}
		public CycleClauseContext cycleClause() {
			return getRuleContext(CycleClauseContext.class,0);
		}
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public CteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cte; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCte(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCte(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCte(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CteContext cte() throws RecognitionException {
		CteContext _localctx = new CteContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_cte);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(450);
			identifier();
			setState(451);
			match(AS);
			setState(456);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==MATERIALIZED || _la==NOT) {
				{
				setState(453);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(452);
					match(NOT);
					}
				}

				setState(455);
				match(MATERIALIZED);
				}
			}

			setState(458);
			match(T__1);
			setState(459);
			queryExpression();
			setState(460);
			match(T__2);
			setState(462);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==SEARCH) {
				{
				setState(461);
				searchClause();
				}
			}

			setState(465);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CYCLE) {
				{
				setState(464);
				cycleClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchClauseContext extends ParserRuleContext {
		public TerminalNode SEARCH() { return getToken(HqlParser.SEARCH, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public SearchSpecificationsContext searchSpecifications() {
			return getRuleContext(SearchSpecificationsContext.class,0);
		}
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode BREADTH() { return getToken(HqlParser.BREADTH, 0); }
		public TerminalNode DEPTH() { return getToken(HqlParser.DEPTH, 0); }
		public SearchClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchClauseContext searchClause() throws RecognitionException {
		SearchClauseContext _localctx = new SearchClauseContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_searchClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(467);
			match(SEARCH);
			setState(468);
			_la = _input.LA(1);
			if ( !(_la==BREADTH || _la==DEPTH) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(469);
			match(FIRST);
			setState(470);
			match(BY);
			setState(471);
			searchSpecifications();
			setState(472);
			match(SET);
			setState(473);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchSpecificationsContext extends ParserRuleContext {
		public List<SearchSpecificationContext> searchSpecification() {
			return getRuleContexts(SearchSpecificationContext.class);
		}
		public SearchSpecificationContext searchSpecification(int i) {
			return getRuleContext(SearchSpecificationContext.class,i);
		}
		public SearchSpecificationsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchSpecifications; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchSpecifications(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchSpecifications(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchSpecifications(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchSpecificationsContext searchSpecifications() throws RecognitionException {
		SearchSpecificationsContext _localctx = new SearchSpecificationsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_searchSpecifications);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(475);
			searchSpecification();
			setState(480);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(476);
				match(T__0);
				setState(477);
				searchSpecification();
				}
				}
				setState(482);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchSpecificationContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public SortDirectionContext sortDirection() {
			return getRuleContext(SortDirectionContext.class,0);
		}
		public NullsPrecedenceContext nullsPrecedence() {
			return getRuleContext(NullsPrecedenceContext.class,0);
		}
		public SearchSpecificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchSpecification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchSpecification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchSpecification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchSpecification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchSpecificationContext searchSpecification() throws RecognitionException {
		SearchSpecificationContext _localctx = new SearchSpecificationContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_searchSpecification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(483);
			identifier();
			setState(485);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(484);
				sortDirection();
				}
			}

			setState(488);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NULLS) {
				{
				setState(487);
				nullsPrecedence();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CycleClauseContext extends ParserRuleContext {
		public TerminalNode CYCLE() { return getToken(HqlParser.CYCLE, 0); }
		public CteAttributesContext cteAttributes() {
			return getRuleContext(CteAttributesContext.class,0);
		}
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode TO() { return getToken(HqlParser.TO, 0); }
		public List<LiteralContext> literal() {
			return getRuleContexts(LiteralContext.class);
		}
		public LiteralContext literal(int i) {
			return getRuleContext(LiteralContext.class,i);
		}
		public TerminalNode DEFAULT() { return getToken(HqlParser.DEFAULT, 0); }
		public TerminalNode USING() { return getToken(HqlParser.USING, 0); }
		public CycleClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cycleClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCycleClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCycleClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCycleClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CycleClauseContext cycleClause() throws RecognitionException {
		CycleClauseContext _localctx = new CycleClauseContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_cycleClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(490);
			match(CYCLE);
			setState(491);
			cteAttributes();
			setState(492);
			match(SET);
			setState(493);
			identifier();
			setState(499);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TO) {
				{
				setState(494);
				match(TO);
				setState(495);
				literal();
				setState(496);
				match(DEFAULT);
				setState(497);
				literal();
				}
			}

			setState(503);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==USING) {
				{
				setState(501);
				match(USING);
				setState(502);
				identifier();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CteAttributesContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public CteAttributesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cteAttributes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCteAttributes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCteAttributes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCteAttributes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CteAttributesContext cteAttributes() throws RecognitionException {
		CteAttributesContext _localctx = new CteAttributesContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_cteAttributes);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(505);
			identifier();
			setState(510);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(506);
				match(T__0);
				setState(507);
				identifier();
				}
				}
				setState(512);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrderedQueryContext extends ParserRuleContext {
		public QueryContext query() {
			return getRuleContext(QueryContext.class,0);
		}
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public QueryOrderContext queryOrder() {
			return getRuleContext(QueryOrderContext.class,0);
		}
		public LimitClauseContext limitClause() {
			return getRuleContext(LimitClauseContext.class,0);
		}
		public OffsetClauseContext offsetClause() {
			return getRuleContext(OffsetClauseContext.class,0);
		}
		public FetchClauseContext fetchClause() {
			return getRuleContext(FetchClauseContext.class,0);
		}
		public OrderedQueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderedQuery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOrderedQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOrderedQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOrderedQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrderedQueryContext orderedQuery() throws RecognitionException {
		OrderedQueryContext _localctx = new OrderedQueryContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_orderedQuery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(518);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FROM:
			case SELECT:
				{
				setState(513);
				query();
				}
				break;
			case T__1:
				{
				setState(514);
				match(T__1);
				setState(515);
				queryExpression();
				setState(516);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(521);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(520);
				queryOrder();
				}
			}

			setState(524);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LIMIT) {
				{
				setState(523);
				limitClause();
				}
			}

			setState(527);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==OFFSET) {
				{
				setState(526);
				offsetClause();
				}
			}

			setState(530);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FETCH) {
				{
				setState(529);
				fetchClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QueryContext extends ParserRuleContext {
		public QueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query; }
	 
		public QueryContext() { }
		public void copyFrom(QueryContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SelectQueryContext extends QueryContext {
		public SelectClauseContext selectClause() {
			return getRuleContext(SelectClauseContext.class,0);
		}
		public FromClauseContext fromClause() {
			return getRuleContext(FromClauseContext.class,0);
		}
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public GroupByClauseContext groupByClause() {
			return getRuleContext(GroupByClauseContext.class,0);
		}
		public HavingClauseContext havingClause() {
			return getRuleContext(HavingClauseContext.class,0);
		}
		public SelectQueryContext(QueryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectQuery(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FromQueryContext extends QueryContext {
		public FromClauseContext fromClause() {
			return getRuleContext(FromClauseContext.class,0);
		}
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public GroupByClauseContext groupByClause() {
			return getRuleContext(GroupByClauseContext.class,0);
		}
		public HavingClauseContext havingClause() {
			return getRuleContext(HavingClauseContext.class,0);
		}
		public SelectClauseContext selectClause() {
			return getRuleContext(SelectClauseContext.class,0);
		}
		public FromQueryContext(QueryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryContext query() throws RecognitionException {
		QueryContext _localctx = new QueryContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_query);
		int _la;
		try {
			setState(558);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SELECT:
				_localctx = new SelectQueryContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(532);
				selectClause();
				setState(534);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FROM) {
					{
					setState(533);
					fromClause();
					}
				}

				setState(537);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(536);
					whereClause();
					}
				}

				setState(540);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GROUP) {
					{
					setState(539);
					groupByClause();
					}
				}

				setState(543);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(542);
					havingClause();
					}
				}

				}
				break;
			case FROM:
				_localctx = new FromQueryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(545);
				fromClause();
				setState(547);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(546);
					whereClause();
					}
				}

				setState(550);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GROUP) {
					{
					setState(549);
					groupByClause();
					}
				}

				setState(553);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(552);
					havingClause();
					}
				}

				setState(556);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==SELECT) {
					{
					setState(555);
					selectClause();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QueryOrderContext extends ParserRuleContext {
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public QueryOrderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryOrder; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterQueryOrder(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitQueryOrder(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitQueryOrder(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryOrderContext queryOrder() throws RecognitionException {
		QueryOrderContext _localctx = new QueryOrderContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_queryOrder);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(560);
			orderByClause();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FromClauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public List<EntityWithJoinsContext> entityWithJoins() {
			return getRuleContexts(EntityWithJoinsContext.class);
		}
		public EntityWithJoinsContext entityWithJoins(int i) {
			return getRuleContext(EntityWithJoinsContext.class,i);
		}
		public FromClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fromClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FromClauseContext fromClause() throws RecognitionException {
		FromClauseContext _localctx = new FromClauseContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_fromClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(562);
			match(FROM);
			setState(563);
			entityWithJoins();
			setState(568);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(564);
				match(T__0);
				setState(565);
				entityWithJoins();
				}
				}
				setState(570);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityWithJoinsContext extends ParserRuleContext {
		public FromRootContext fromRoot() {
			return getRuleContext(FromRootContext.class,0);
		}
		public List<JoinSpecifierContext> joinSpecifier() {
			return getRuleContexts(JoinSpecifierContext.class);
		}
		public JoinSpecifierContext joinSpecifier(int i) {
			return getRuleContext(JoinSpecifierContext.class,i);
		}
		public EntityWithJoinsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityWithJoins; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityWithJoins(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityWithJoins(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityWithJoins(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityWithJoinsContext entityWithJoins() throws RecognitionException {
		EntityWithJoinsContext _localctx = new EntityWithJoinsContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_entityWithJoins);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(571);
			fromRoot();
			setState(575);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,29,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(572);
					joinSpecifier();
					}
					} 
				}
				setState(577);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,29,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinSpecifierContext extends ParserRuleContext {
		public JoinContext join() {
			return getRuleContext(JoinContext.class,0);
		}
		public CrossJoinContext crossJoin() {
			return getRuleContext(CrossJoinContext.class,0);
		}
		public JpaCollectionJoinContext jpaCollectionJoin() {
			return getRuleContext(JpaCollectionJoinContext.class,0);
		}
		public JoinSpecifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinSpecifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinSpecifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinSpecifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinSpecifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinSpecifierContext joinSpecifier() throws RecognitionException {
		JoinSpecifierContext _localctx = new JoinSpecifierContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_joinSpecifier);
		try {
			setState(581);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,30,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(578);
				join();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(579);
				crossJoin();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(580);
				jpaCollectionJoin();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FromRootContext extends ParserRuleContext {
		public EntityNameContext entityName() {
			return getRuleContext(EntityNameContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public FromRootContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fromRoot; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromRoot(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromRoot(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromRoot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FromRootContext fromRoot() throws RecognitionException {
		FromRootContext _localctx = new FromRootContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_fromRoot);
		int _la;
		try {
			setState(596);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,34,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(583);
				entityName();
				setState(585);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,31,_ctx) ) {
				case 1:
					{
					setState(584);
					variable();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(588);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LATERAL) {
					{
					setState(587);
					match(LATERAL);
					}
				}

				setState(590);
				match(T__1);
				setState(591);
				subquery();
				setState(592);
				match(T__2);
				setState(594);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
				case 1:
					{
					setState(593);
					variable();
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinContext extends ParserRuleContext {
		public JoinTypeContext joinType() {
			return getRuleContext(JoinTypeContext.class,0);
		}
		public TerminalNode JOIN() { return getToken(HqlParser.JOIN, 0); }
		public JoinTargetContext joinTarget() {
			return getRuleContext(JoinTargetContext.class,0);
		}
		public TerminalNode FETCH() { return getToken(HqlParser.FETCH, 0); }
		public JoinRestrictionContext joinRestriction() {
			return getRuleContext(JoinRestrictionContext.class,0);
		}
		public JoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinContext join() throws RecognitionException {
		JoinContext _localctx = new JoinContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_join);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(598);
			joinType();
			setState(599);
			match(JOIN);
			setState(601);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,35,_ctx) ) {
			case 1:
				{
				setState(600);
				match(FETCH);
				}
				break;
			}
			setState(603);
			joinTarget();
			setState(605);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,36,_ctx) ) {
			case 1:
				{
				setState(604);
				joinRestriction();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinTargetContext extends ParserRuleContext {
		public JoinTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinTarget; }
	 
		public JoinTargetContext() { }
		public void copyFrom(JoinTargetContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinPathContext extends JoinTargetContext {
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JoinPathContext(JoinTargetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinPath(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinSubqueryContext extends JoinTargetContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JoinSubqueryContext(JoinTargetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinSubquery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinTargetContext joinTarget() throws RecognitionException {
		JoinTargetContext _localctx = new JoinTargetContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_joinTarget);
		int _la;
		try {
			setState(620);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,40,_ctx) ) {
			case 1:
				_localctx = new JoinPathContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(607);
				path();
				setState(609);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
				case 1:
					{
					setState(608);
					variable();
					}
					break;
				}
				}
				break;
			case 2:
				_localctx = new JoinSubqueryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(612);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LATERAL) {
					{
					setState(611);
					match(LATERAL);
					}
				}

				setState(614);
				match(T__1);
				setState(615);
				subquery();
				setState(616);
				match(T__2);
				setState(618);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,39,_ctx) ) {
				case 1:
					{
					setState(617);
					variable();
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UpdateStatementContext extends ParserRuleContext {
		public TerminalNode UPDATE() { return getToken(HqlParser.UPDATE, 0); }
		public TargetEntityContext targetEntity() {
			return getRuleContext(TargetEntityContext.class,0);
		}
		public SetClauseContext setClause() {
			return getRuleContext(SetClauseContext.class,0);
		}
		public TerminalNode VERSIONED() { return getToken(HqlParser.VERSIONED, 0); }
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public UpdateStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_updateStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterUpdateStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitUpdateStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitUpdateStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UpdateStatementContext updateStatement() throws RecognitionException {
		UpdateStatementContext _localctx = new UpdateStatementContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_updateStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(622);
			match(UPDATE);
			setState(624);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
			case 1:
				{
				setState(623);
				match(VERSIONED);
				}
				break;
			}
			setState(626);
			targetEntity();
			setState(627);
			setClause();
			setState(629);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(628);
				whereClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TargetEntityContext extends ParserRuleContext {
		public EntityNameContext entityName() {
			return getRuleContext(EntityNameContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TargetEntityContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_targetEntity; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTargetEntity(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTargetEntity(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTargetEntity(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TargetEntityContext targetEntity() throws RecognitionException {
		TargetEntityContext _localctx = new TargetEntityContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_targetEntity);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(631);
			entityName();
			setState(633);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,43,_ctx) ) {
			case 1:
				{
				setState(632);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetClauseContext extends ParserRuleContext {
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public List<AssignmentContext> assignment() {
			return getRuleContexts(AssignmentContext.class);
		}
		public AssignmentContext assignment(int i) {
			return getRuleContext(AssignmentContext.class,i);
		}
		public SetClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSetClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSetClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSetClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetClauseContext setClause() throws RecognitionException {
		SetClauseContext _localctx = new SetClauseContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_setClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(635);
			match(SET);
			setState(636);
			assignment();
			setState(641);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(637);
				match(T__0);
				setState(638);
				assignment();
				}
				}
				setState(643);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AssignmentContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public AssignmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAssignment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAssignment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignmentContext assignment() throws RecognitionException {
		AssignmentContext _localctx = new AssignmentContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_assignment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(644);
			simplePath();
			setState(645);
			match(T__3);
			setState(646);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DeleteStatementContext extends ParserRuleContext {
		public TerminalNode DELETE() { return getToken(HqlParser.DELETE, 0); }
		public TargetEntityContext targetEntity() {
			return getRuleContext(TargetEntityContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public DeleteStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_deleteStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDeleteStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDeleteStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDeleteStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeleteStatementContext deleteStatement() throws RecognitionException {
		DeleteStatementContext _localctx = new DeleteStatementContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_deleteStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(648);
			match(DELETE);
			setState(650);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,45,_ctx) ) {
			case 1:
				{
				setState(649);
				match(FROM);
				}
				break;
			}
			setState(652);
			targetEntity();
			setState(654);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(653);
				whereClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InsertStatementContext extends ParserRuleContext {
		public TerminalNode INSERT() { return getToken(HqlParser.INSERT, 0); }
		public TargetEntityContext targetEntity() {
			return getRuleContext(TargetEntityContext.class,0);
		}
		public TargetFieldsContext targetFields() {
			return getRuleContext(TargetFieldsContext.class,0);
		}
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public ValuesListContext valuesList() {
			return getRuleContext(ValuesListContext.class,0);
		}
		public TerminalNode INTO() { return getToken(HqlParser.INTO, 0); }
		public ConflictClauseContext conflictClause() {
			return getRuleContext(ConflictClauseContext.class,0);
		}
		public InsertStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_insertStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInsertStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInsertStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInsertStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InsertStatementContext insertStatement() throws RecognitionException {
		InsertStatementContext _localctx = new InsertStatementContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_insertStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(656);
			match(INSERT);
			setState(658);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,47,_ctx) ) {
			case 1:
				{
				setState(657);
				match(INTO);
				}
				break;
			}
			setState(660);
			targetEntity();
			setState(661);
			targetFields();
			setState(664);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
			case FROM:
			case SELECT:
			case WITH:
				{
				setState(662);
				queryExpression();
				}
				break;
			case VALUES:
				{
				setState(663);
				valuesList();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(667);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(666);
				conflictClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TargetFieldsContext extends ParserRuleContext {
		public List<SimplePathContext> simplePath() {
			return getRuleContexts(SimplePathContext.class);
		}
		public SimplePathContext simplePath(int i) {
			return getRuleContext(SimplePathContext.class,i);
		}
		public TargetFieldsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_targetFields; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTargetFields(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTargetFields(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTargetFields(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TargetFieldsContext targetFields() throws RecognitionException {
		TargetFieldsContext _localctx = new TargetFieldsContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_targetFields);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(669);
			match(T__1);
			setState(670);
			simplePath();
			setState(675);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(671);
				match(T__0);
				setState(672);
				simplePath();
				}
				}
				setState(677);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(678);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValuesListContext extends ParserRuleContext {
		public TerminalNode VALUES() { return getToken(HqlParser.VALUES, 0); }
		public List<ValuesContext> values() {
			return getRuleContexts(ValuesContext.class);
		}
		public ValuesContext values(int i) {
			return getRuleContext(ValuesContext.class,i);
		}
		public ValuesListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valuesList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterValuesList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitValuesList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitValuesList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValuesListContext valuesList() throws RecognitionException {
		ValuesListContext _localctx = new ValuesListContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_valuesList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(680);
			match(VALUES);
			setState(681);
			values();
			setState(686);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(682);
				match(T__0);
				setState(683);
				values();
				}
				}
				setState(688);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValuesContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public ValuesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_values; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterValues(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitValues(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitValues(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValuesContext values() throws RecognitionException {
		ValuesContext _localctx = new ValuesContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_values);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(689);
			match(T__1);
			setState(690);
			expression(0);
			setState(695);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(691);
				match(T__0);
				setState(692);
				expression(0);
				}
				}
				setState(697);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(698);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConflictClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode CONFLICT() { return getToken(HqlParser.CONFLICT, 0); }
		public TerminalNode DO() { return getToken(HqlParser.DO, 0); }
		public ConflictActionContext conflictAction() {
			return getRuleContext(ConflictActionContext.class,0);
		}
		public ConflictTargetContext conflictTarget() {
			return getRuleContext(ConflictTargetContext.class,0);
		}
		public ConflictClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conflictClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterConflictClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitConflictClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitConflictClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConflictClauseContext conflictClause() throws RecognitionException {
		ConflictClauseContext _localctx = new ConflictClauseContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_conflictClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(700);
			match(ON);
			setState(701);
			match(CONFLICT);
			setState(703);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1 || _la==ON) {
				{
				setState(702);
				conflictTarget();
				}
			}

			setState(705);
			match(DO);
			setState(706);
			conflictAction();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConflictTargetContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode CONSTRAINT() { return getToken(HqlParser.CONSTRAINT, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public List<SimplePathContext> simplePath() {
			return getRuleContexts(SimplePathContext.class);
		}
		public SimplePathContext simplePath(int i) {
			return getRuleContext(SimplePathContext.class,i);
		}
		public ConflictTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conflictTarget; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterConflictTarget(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitConflictTarget(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitConflictTarget(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConflictTargetContext conflictTarget() throws RecognitionException {
		ConflictTargetContext _localctx = new ConflictTargetContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_conflictTarget);
		int _la;
		try {
			setState(722);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ON:
				enterOuterAlt(_localctx, 1);
				{
				setState(708);
				match(ON);
				setState(709);
				match(CONSTRAINT);
				setState(710);
				identifier();
				}
				break;
			case T__1:
				enterOuterAlt(_localctx, 2);
				{
				setState(711);
				match(T__1);
				setState(712);
				simplePath();
				setState(717);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(713);
					match(T__0);
					setState(714);
					simplePath();
					}
					}
					setState(719);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(720);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConflictActionContext extends ParserRuleContext {
		public TerminalNode NOTHING() { return getToken(HqlParser.NOTHING, 0); }
		public TerminalNode UPDATE() { return getToken(HqlParser.UPDATE, 0); }
		public SetClauseContext setClause() {
			return getRuleContext(SetClauseContext.class,0);
		}
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public ConflictActionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conflictAction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterConflictAction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitConflictAction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitConflictAction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConflictActionContext conflictAction() throws RecognitionException {
		ConflictActionContext _localctx = new ConflictActionContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_conflictAction);
		int _la;
		try {
			setState(730);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOTHING:
				enterOuterAlt(_localctx, 1);
				{
				setState(724);
				match(NOTHING);
				}
				break;
			case UPDATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(725);
				match(UPDATE);
				setState(726);
				setClause();
				setState(728);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(727);
					whereClause();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationContext extends ParserRuleContext {
		public TerminalNode NEW() { return getToken(HqlParser.NEW, 0); }
		public InstantiationTargetContext instantiationTarget() {
			return getRuleContext(InstantiationTargetContext.class,0);
		}
		public InstantiationArgumentsContext instantiationArguments() {
			return getRuleContext(InstantiationArgumentsContext.class,0);
		}
		public InstantiationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationContext instantiation() throws RecognitionException {
		InstantiationContext _localctx = new InstantiationContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_instantiation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(732);
			match(NEW);
			setState(733);
			instantiationTarget();
			setState(734);
			match(T__1);
			setState(735);
			instantiationArguments();
			setState(736);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GroupedItemContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public GroupedItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupedItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupedItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupedItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupedItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GroupedItemContext groupedItem() throws RecognitionException {
		GroupedItemContext _localctx = new GroupedItemContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_groupedItem);
		try {
			setState(741);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(738);
				identifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(739);
				match(INTEGER_LITERAL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(740);
				expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SortedItemContext extends ParserRuleContext {
		public SortExpressionContext sortExpression() {
			return getRuleContext(SortExpressionContext.class,0);
		}
		public SortDirectionContext sortDirection() {
			return getRuleContext(SortDirectionContext.class,0);
		}
		public NullsPrecedenceContext nullsPrecedence() {
			return getRuleContext(NullsPrecedenceContext.class,0);
		}
		public SortedItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sortedItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSortedItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSortedItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSortedItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SortedItemContext sortedItem() throws RecognitionException {
		SortedItemContext _localctx = new SortedItemContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_sortedItem);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(743);
			sortExpression();
			setState(745);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(744);
				sortDirection();
				}
			}

			setState(748);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NULLS) {
				{
				setState(747);
				nullsPrecedence();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SortExpressionContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SortExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sortExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSortExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSortExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSortExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SortExpressionContext sortExpression() throws RecognitionException {
		SortExpressionContext _localctx = new SortExpressionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_sortExpression);
		try {
			setState(753);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,61,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(750);
				identifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(751);
				match(INTEGER_LITERAL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(752);
				expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SortDirectionContext extends ParserRuleContext {
		public TerminalNode ASC() { return getToken(HqlParser.ASC, 0); }
		public TerminalNode DESC() { return getToken(HqlParser.DESC, 0); }
		public SortDirectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sortDirection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSortDirection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSortDirection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSortDirection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SortDirectionContext sortDirection() throws RecognitionException {
		SortDirectionContext _localctx = new SortDirectionContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_sortDirection);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(755);
			_la = _input.LA(1);
			if ( !(_la==ASC || _la==DESC) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NullsPrecedenceContext extends ParserRuleContext {
		public TerminalNode NULLS() { return getToken(HqlParser.NULLS, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(HqlParser.LAST, 0); }
		public NullsPrecedenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullsPrecedence; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNullsPrecedence(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNullsPrecedence(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNullsPrecedence(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NullsPrecedenceContext nullsPrecedence() throws RecognitionException {
		NullsPrecedenceContext _localctx = new NullsPrecedenceContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_nullsPrecedence);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(757);
			match(NULLS);
			setState(758);
			_la = _input.LA(1);
			if ( !(_la==FIRST || _la==LAST) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LimitClauseContext extends ParserRuleContext {
		public TerminalNode LIMIT() { return getToken(HqlParser.LIMIT, 0); }
		public ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() {
			return getRuleContext(ParameterOrIntegerLiteralContext.class,0);
		}
		public LimitClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_limitClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLimitClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLimitClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLimitClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LimitClauseContext limitClause() throws RecognitionException {
		LimitClauseContext _localctx = new LimitClauseContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_limitClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(760);
			match(LIMIT);
			setState(761);
			parameterOrIntegerLiteral();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetClauseContext extends ParserRuleContext {
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() {
			return getRuleContext(ParameterOrIntegerLiteralContext.class,0);
		}
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public OffsetClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetClauseContext offsetClause() throws RecognitionException {
		OffsetClauseContext _localctx = new OffsetClauseContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_offsetClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(763);
			match(OFFSET);
			setState(764);
			parameterOrIntegerLiteral();
			setState(766);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ROW || _la==ROWS) {
				{
				setState(765);
				_la = _input.LA(1);
				if ( !(_la==ROW || _la==ROWS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FetchClauseContext extends ParserRuleContext {
		public TerminalNode FETCH() { return getToken(HqlParser.FETCH, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode NEXT() { return getToken(HqlParser.NEXT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() {
			return getRuleContext(ParameterOrIntegerLiteralContext.class,0);
		}
		public ParameterOrNumberLiteralContext parameterOrNumberLiteral() {
			return getRuleContext(ParameterOrNumberLiteralContext.class,0);
		}
		public TerminalNode ONLY() { return getToken(HqlParser.ONLY, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode TIES() { return getToken(HqlParser.TIES, 0); }
		public FetchClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fetchClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFetchClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFetchClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFetchClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FetchClauseContext fetchClause() throws RecognitionException {
		FetchClauseContext _localctx = new FetchClauseContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_fetchClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(768);
			match(FETCH);
			setState(769);
			_la = _input.LA(1);
			if ( !(_la==FIRST || _la==NEXT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(774);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,63,_ctx) ) {
			case 1:
				{
				setState(770);
				parameterOrIntegerLiteral();
				}
				break;
			case 2:
				{
				setState(771);
				parameterOrNumberLiteral();
				setState(772);
				match(T__4);
				}
				break;
			}
			setState(776);
			_la = _input.LA(1);
			if ( !(_la==ROW || _la==ROWS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(780);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ONLY:
				{
				setState(777);
				match(ONLY);
				}
				break;
			case WITH:
				{
				setState(778);
				match(WITH);
				setState(779);
				match(TIES);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubqueryContext extends ParserRuleContext {
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public SubqueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subquery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubquery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubqueryContext subquery() throws RecognitionException {
		SubqueryContext _localctx = new SubqueryContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_subquery);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(782);
			queryExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectClauseContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(HqlParser.SELECT, 0); }
		public SelectionListContext selectionList() {
			return getRuleContext(SelectionListContext.class,0);
		}
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public SelectClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectClauseContext selectClause() throws RecognitionException {
		SelectClauseContext _localctx = new SelectClauseContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_selectClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(784);
			match(SELECT);
			setState(786);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,65,_ctx) ) {
			case 1:
				{
				setState(785);
				match(DISTINCT);
				}
				break;
			}
			setState(788);
			selectionList();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectionListContext extends ParserRuleContext {
		public List<SelectionContext> selection() {
			return getRuleContexts(SelectionContext.class);
		}
		public SelectionContext selection(int i) {
			return getRuleContext(SelectionContext.class,i);
		}
		public SelectionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectionList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectionList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectionList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectionList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectionListContext selectionList() throws RecognitionException {
		SelectionListContext _localctx = new SelectionListContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_selectionList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(790);
			selection();
			setState(795);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(791);
				match(T__0);
				setState(792);
				selection();
				}
				}
				setState(797);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectionContext extends ParserRuleContext {
		public SelectExpressionContext selectExpression() {
			return getRuleContext(SelectExpressionContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public SelectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectionContext selection() throws RecognitionException {
		SelectionContext _localctx = new SelectionContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_selection);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(798);
			selectExpression();
			setState(800);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,67,_ctx) ) {
			case 1:
				{
				setState(799);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectExpressionContext extends ParserRuleContext {
		public InstantiationContext instantiation() {
			return getRuleContext(InstantiationContext.class,0);
		}
		public MapEntrySelectionContext mapEntrySelection() {
			return getRuleContext(MapEntrySelectionContext.class,0);
		}
		public JpaSelectObjectSyntaxContext jpaSelectObjectSyntax() {
			return getRuleContext(JpaSelectObjectSyntaxContext.class,0);
		}
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public SelectExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectExpressionContext selectExpression() throws RecognitionException {
		SelectExpressionContext _localctx = new SelectExpressionContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_selectExpression);
		try {
			setState(806);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,68,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(802);
				instantiation();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(803);
				mapEntrySelection();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(804);
				jpaSelectObjectSyntax();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(805);
				expressionOrPredicate();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapEntrySelectionContext extends ParserRuleContext {
		public TerminalNode ENTRY() { return getToken(HqlParser.ENTRY, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public MapEntrySelectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapEntrySelection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMapEntrySelection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMapEntrySelection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMapEntrySelection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MapEntrySelectionContext mapEntrySelection() throws RecognitionException {
		MapEntrySelectionContext _localctx = new MapEntrySelectionContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_mapEntrySelection);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(808);
			match(ENTRY);
			setState(809);
			match(T__1);
			setState(810);
			path();
			setState(811);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaSelectObjectSyntaxContext extends ParserRuleContext {
		public TerminalNode OBJECT() { return getToken(HqlParser.OBJECT, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public JpaSelectObjectSyntaxContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaSelectObjectSyntax; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaSelectObjectSyntax(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaSelectObjectSyntax(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaSelectObjectSyntax(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaSelectObjectSyntaxContext jpaSelectObjectSyntax() throws RecognitionException {
		JpaSelectObjectSyntaxContext _localctx = new JpaSelectObjectSyntaxContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_jpaSelectObjectSyntax);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(813);
			match(OBJECT);
			setState(814);
			match(T__1);
			setState(815);
			identifier();
			setState(816);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WhereClauseContext extends ParserRuleContext {
		public TerminalNode WHERE() { return getToken(HqlParser.WHERE, 0); }
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public WhereClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whereClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWhereClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWhereClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWhereClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhereClauseContext whereClause() throws RecognitionException {
		WhereClauseContext _localctx = new WhereClauseContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_whereClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(818);
			match(WHERE);
			setState(819);
			predicate(0);
			setState(824);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(820);
				match(T__0);
				setState(821);
				predicate(0);
				}
				}
				setState(826);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinTypeContext extends ParserRuleContext {
		public TerminalNode INNER() { return getToken(HqlParser.INNER, 0); }
		public TerminalNode OUTER() { return getToken(HqlParser.OUTER, 0); }
		public TerminalNode LEFT() { return getToken(HqlParser.LEFT, 0); }
		public TerminalNode RIGHT() { return getToken(HqlParser.RIGHT, 0); }
		public TerminalNode FULL() { return getToken(HqlParser.FULL, 0); }
		public TerminalNode CROSS() { return getToken(HqlParser.CROSS, 0); }
		public JoinTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinTypeContext joinType() throws RecognitionException {
		JoinTypeContext _localctx = new JoinTypeContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_joinType);
		int _la;
		try {
			setState(837);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,73,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(828);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==INNER) {
					{
					setState(827);
					match(INNER);
					}
				}

				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(831);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FULL || _la==LEFT || _la==RIGHT) {
					{
					setState(830);
					_la = _input.LA(1);
					if ( !(_la==FULL || _la==LEFT || _la==RIGHT) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(834);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==OUTER) {
					{
					setState(833);
					match(OUTER);
					}
				}

				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(836);
				match(CROSS);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CrossJoinContext extends ParserRuleContext {
		public TerminalNode CROSS() { return getToken(HqlParser.CROSS, 0); }
		public TerminalNode JOIN() { return getToken(HqlParser.JOIN, 0); }
		public EntityNameContext entityName() {
			return getRuleContext(EntityNameContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public CrossJoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_crossJoin; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCrossJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCrossJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCrossJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CrossJoinContext crossJoin() throws RecognitionException {
		CrossJoinContext _localctx = new CrossJoinContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_crossJoin);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(839);
			match(CROSS);
			setState(840);
			match(JOIN);
			setState(841);
			entityName();
			setState(843);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,74,_ctx) ) {
			case 1:
				{
				setState(842);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinRestrictionContext extends ParserRuleContext {
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public JoinRestrictionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinRestriction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinRestriction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinRestriction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinRestriction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinRestrictionContext joinRestriction() throws RecognitionException {
		JoinRestrictionContext _localctx = new JoinRestrictionContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_joinRestriction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(845);
			_la = _input.LA(1);
			if ( !(_la==ON || _la==WITH) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(846);
			predicate(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaCollectionJoinContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JpaCollectionJoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaCollectionJoin; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaCollectionJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaCollectionJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaCollectionJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaCollectionJoinContext jpaCollectionJoin() throws RecognitionException {
		JpaCollectionJoinContext _localctx = new JpaCollectionJoinContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_jpaCollectionJoin);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(848);
			match(T__0);
			setState(849);
			match(IN);
			setState(850);
			match(T__1);
			setState(851);
			path();
			setState(852);
			match(T__2);
			setState(854);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,75,_ctx) ) {
			case 1:
				{
				setState(853);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GroupByClauseContext extends ParserRuleContext {
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public List<GroupedItemContext> groupedItem() {
			return getRuleContexts(GroupedItemContext.class);
		}
		public GroupedItemContext groupedItem(int i) {
			return getRuleContext(GroupedItemContext.class,i);
		}
		public GroupByClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupByClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupByClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupByClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupByClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GroupByClauseContext groupByClause() throws RecognitionException {
		GroupByClauseContext _localctx = new GroupByClauseContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_groupByClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(856);
			match(GROUP);
			setState(857);
			match(BY);
			setState(858);
			groupedItem();
			setState(863);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(859);
				match(T__0);
				setState(860);
				groupedItem();
				}
				}
				setState(865);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrderByClauseContext extends ParserRuleContext {
		public TerminalNode ORDER() { return getToken(HqlParser.ORDER, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public List<SortedItemContext> sortedItem() {
			return getRuleContexts(SortedItemContext.class);
		}
		public SortedItemContext sortedItem(int i) {
			return getRuleContext(SortedItemContext.class,i);
		}
		public OrderByClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderByClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOrderByClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOrderByClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOrderByClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrderByClauseContext orderByClause() throws RecognitionException {
		OrderByClauseContext _localctx = new OrderByClauseContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_orderByClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(866);
			match(ORDER);
			setState(867);
			match(BY);
			setState(868);
			sortedItem();
			setState(873);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(869);
				match(T__0);
				setState(870);
				sortedItem();
				}
				}
				setState(875);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HavingClauseContext extends ParserRuleContext {
		public TerminalNode HAVING() { return getToken(HqlParser.HAVING, 0); }
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public HavingClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_havingClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterHavingClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitHavingClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitHavingClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HavingClauseContext havingClause() throws RecognitionException {
		HavingClauseContext _localctx = new HavingClauseContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_havingClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(876);
			match(HAVING);
			setState(877);
			predicate(0);
			setState(882);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(878);
				match(T__0);
				setState(879);
				predicate(0);
				}
				}
				setState(884);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetOperatorContext extends ParserRuleContext {
		public TerminalNode UNION() { return getToken(HqlParser.UNION, 0); }
		public TerminalNode ALL() { return getToken(HqlParser.ALL, 0); }
		public TerminalNode INTERSECT() { return getToken(HqlParser.INTERSECT, 0); }
		public TerminalNode EXCEPT() { return getToken(HqlParser.EXCEPT, 0); }
		public SetOperatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setOperator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSetOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSetOperator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSetOperator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetOperatorContext setOperator() throws RecognitionException {
		SetOperatorContext _localctx = new SetOperatorContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_setOperator);
		int _la;
		try {
			setState(897);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case UNION:
				enterOuterAlt(_localctx, 1);
				{
				setState(885);
				match(UNION);
				setState(887);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(886);
					match(ALL);
					}
				}

				}
				break;
			case INTERSECT:
				enterOuterAlt(_localctx, 2);
				{
				setState(889);
				match(INTERSECT);
				setState(891);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(890);
					match(ALL);
					}
				}

				}
				break;
			case EXCEPT:
				enterOuterAlt(_localctx, 3);
				{
				setState(893);
				match(EXCEPT);
				setState(895);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(894);
					match(ALL);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LiteralContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public TerminalNode JAVA_STRING_LITERAL() { return getToken(HqlParser.JAVA_STRING_LITERAL, 0); }
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public BooleanLiteralContext booleanLiteral() {
			return getRuleContext(BooleanLiteralContext.class,0);
		}
		public NumericLiteralContext numericLiteral() {
			return getRuleContext(NumericLiteralContext.class,0);
		}
		public BinaryLiteralContext binaryLiteral() {
			return getRuleContext(BinaryLiteralContext.class,0);
		}
		public TemporalLiteralContext temporalLiteral() {
			return getRuleContext(TemporalLiteralContext.class,0);
		}
		public ArrayLiteralContext arrayLiteral() {
			return getRuleContext(ArrayLiteralContext.class,0);
		}
		public GeneralizedLiteralContext generalizedLiteral() {
			return getRuleContext(GeneralizedLiteralContext.class,0);
		}
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_literal);
		try {
			setState(908);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,83,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(899);
				match(STRING_LITERAL);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(900);
				match(JAVA_STRING_LITERAL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(901);
				match(NULL);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(902);
				booleanLiteral();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(903);
				numericLiteral();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(904);
				binaryLiteral();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(905);
				temporalLiteral();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(906);
				arrayLiteral();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(907);
				generalizedLiteral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BooleanLiteralContext extends ParserRuleContext {
		public TerminalNode TRUE() { return getToken(HqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(HqlParser.FALSE, 0); }
		public BooleanLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_booleanLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBooleanLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBooleanLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBooleanLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BooleanLiteralContext booleanLiteral() throws RecognitionException {
		BooleanLiteralContext _localctx = new BooleanLiteralContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_booleanLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(910);
			_la = _input.LA(1);
			if ( !(_la==TRUE || _la==FALSE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericLiteralContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public TerminalNode LONG_LITERAL() { return getToken(HqlParser.LONG_LITERAL, 0); }
		public TerminalNode BIG_INTEGER_LITERAL() { return getToken(HqlParser.BIG_INTEGER_LITERAL, 0); }
		public TerminalNode FLOAT_LITERAL() { return getToken(HqlParser.FLOAT_LITERAL, 0); }
		public TerminalNode DOUBLE_LITERAL() { return getToken(HqlParser.DOUBLE_LITERAL, 0); }
		public TerminalNode BIG_DECIMAL_LITERAL() { return getToken(HqlParser.BIG_DECIMAL_LITERAL, 0); }
		public TerminalNode HEX_LITERAL() { return getToken(HqlParser.HEX_LITERAL, 0); }
		public NumericLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNumericLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNumericLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNumericLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericLiteralContext numericLiteral() throws RecognitionException {
		NumericLiteralContext _localctx = new NumericLiteralContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_numericLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(912);
			_la = _input.LA(1);
			if ( !(((((_la - 206)) & ~0x3f) == 0 && ((1L << (_la - 206)) & 127L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateTimeLiteralContext extends ParserRuleContext {
		public LocalDateTimeLiteralContext localDateTimeLiteral() {
			return getRuleContext(LocalDateTimeLiteralContext.class,0);
		}
		public ZonedDateTimeLiteralContext zonedDateTimeLiteral() {
			return getRuleContext(ZonedDateTimeLiteralContext.class,0);
		}
		public OffsetDateTimeLiteralContext offsetDateTimeLiteral() {
			return getRuleContext(OffsetDateTimeLiteralContext.class,0);
		}
		public DateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateTimeLiteralContext dateTimeLiteral() throws RecognitionException {
		DateTimeLiteralContext _localctx = new DateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_dateTimeLiteral);
		try {
			setState(917);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,84,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(914);
				localDateTimeLiteral();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(915);
				zonedDateTimeLiteral();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(916);
				offsetDateTimeLiteral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateTimeLiteralContext extends ParserRuleContext {
		public LocalDateTimeContext localDateTime() {
			return getRuleContext(LocalDateTimeContext.class,0);
		}
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public LocalDateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateTimeLiteralContext localDateTimeLiteral() throws RecognitionException {
		LocalDateTimeLiteralContext _localctx = new LocalDateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_localDateTimeLiteral);
		int _la;
		try {
			setState(928);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(919);
				match(T__1);
				setState(920);
				localDateTime();
				setState(921);
				match(T__2);
				}
				break;
			case DATETIME:
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(924);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LOCAL) {
					{
					setState(923);
					match(LOCAL);
					}
				}

				setState(926);
				match(DATETIME);
				setState(927);
				localDateTime();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZonedDateTimeLiteralContext extends ParserRuleContext {
		public ZonedDateTimeContext zonedDateTime() {
			return getRuleContext(ZonedDateTimeContext.class,0);
		}
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public TerminalNode ZONED() { return getToken(HqlParser.ZONED, 0); }
		public ZonedDateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zonedDateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterZonedDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitZonedDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitZonedDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZonedDateTimeLiteralContext zonedDateTimeLiteral() throws RecognitionException {
		ZonedDateTimeLiteralContext _localctx = new ZonedDateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_zonedDateTimeLiteral);
		int _la;
		try {
			setState(939);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(930);
				match(T__1);
				setState(931);
				zonedDateTime();
				setState(932);
				match(T__2);
				}
				break;
			case DATETIME:
			case ZONED:
				enterOuterAlt(_localctx, 2);
				{
				setState(935);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ZONED) {
					{
					setState(934);
					match(ZONED);
					}
				}

				setState(937);
				match(DATETIME);
				setState(938);
				zonedDateTime();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeLiteralContext extends ParserRuleContext {
		public OffsetDateTimeContext offsetDateTime() {
			return getRuleContext(OffsetDateTimeContext.class,0);
		}
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public OffsetDateTimeWithMinutesContext offsetDateTimeWithMinutes() {
			return getRuleContext(OffsetDateTimeWithMinutesContext.class,0);
		}
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public OffsetDateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeLiteralContext offsetDateTimeLiteral() throws RecognitionException {
		OffsetDateTimeLiteralContext _localctx = new OffsetDateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_offsetDateTimeLiteral);
		int _la;
		try {
			setState(950);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(941);
				match(T__1);
				setState(942);
				offsetDateTime();
				setState(943);
				match(T__2);
				}
				break;
			case DATETIME:
			case OFFSET:
				enterOuterAlt(_localctx, 2);
				{
				setState(946);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==OFFSET) {
					{
					setState(945);
					match(OFFSET);
					}
				}

				setState(948);
				match(DATETIME);
				setState(949);
				offsetDateTimeWithMinutes();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateLiteralContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public DateLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateLiteralContext dateLiteral() throws RecognitionException {
		DateLiteralContext _localctx = new DateLiteralContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_dateLiteral);
		int _la;
		try {
			setState(961);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(952);
				match(T__1);
				setState(953);
				date();
				setState(954);
				match(T__2);
				}
				break;
			case DATE:
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(957);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LOCAL) {
					{
					setState(956);
					match(LOCAL);
					}
				}

				setState(959);
				match(DATE);
				setState(960);
				date();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeLiteralContext extends ParserRuleContext {
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeLiteralContext timeLiteral() throws RecognitionException {
		TimeLiteralContext _localctx = new TimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_timeLiteral);
		int _la;
		try {
			setState(972);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(963);
				match(T__1);
				setState(964);
				time();
				setState(965);
				match(T__2);
				}
				break;
			case LOCAL:
			case TIME:
				enterOuterAlt(_localctx, 2);
				{
				setState(968);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LOCAL) {
					{
					setState(967);
					match(LOCAL);
					}
				}

				setState(970);
				match(TIME);
				setState(971);
				time();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateTimeContext extends ParserRuleContext {
		public LocalDateTimeContext localDateTime() {
			return getRuleContext(LocalDateTimeContext.class,0);
		}
		public ZonedDateTimeContext zonedDateTime() {
			return getRuleContext(ZonedDateTimeContext.class,0);
		}
		public OffsetDateTimeContext offsetDateTime() {
			return getRuleContext(OffsetDateTimeContext.class,0);
		}
		public DateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateTimeContext dateTime() throws RecognitionException {
		DateTimeContext _localctx = new DateTimeContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_dateTime);
		try {
			setState(977);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,95,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(974);
				localDateTime();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(975);
				zonedDateTime();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(976);
				offsetDateTime();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateTimeContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public LocalDateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateTimeContext localDateTime() throws RecognitionException {
		LocalDateTimeContext _localctx = new LocalDateTimeContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_localDateTime);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(979);
			date();
			setState(980);
			time();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZonedDateTimeContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public ZoneIdContext zoneId() {
			return getRuleContext(ZoneIdContext.class,0);
		}
		public ZonedDateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zonedDateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterZonedDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitZonedDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitZonedDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZonedDateTimeContext zonedDateTime() throws RecognitionException {
		ZonedDateTimeContext _localctx = new ZonedDateTimeContext(_ctx, getState());
		enterRule(_localctx, 136, RULE_zonedDateTime);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(982);
			date();
			setState(983);
			time();
			setState(984);
			zoneId();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public OffsetContext offset() {
			return getRuleContext(OffsetContext.class,0);
		}
		public OffsetDateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeContext offsetDateTime() throws RecognitionException {
		OffsetDateTimeContext _localctx = new OffsetDateTimeContext(_ctx, getState());
		enterRule(_localctx, 138, RULE_offsetDateTime);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(986);
			date();
			setState(987);
			time();
			setState(988);
			offset();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeWithMinutesContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public OffsetWithMinutesContext offsetWithMinutes() {
			return getRuleContext(OffsetWithMinutesContext.class,0);
		}
		public OffsetDateTimeWithMinutesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTimeWithMinutes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTimeWithMinutes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTimeWithMinutes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTimeWithMinutes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeWithMinutesContext offsetDateTimeWithMinutes() throws RecognitionException {
		OffsetDateTimeWithMinutesContext _localctx = new OffsetDateTimeWithMinutesContext(_ctx, getState());
		enterRule(_localctx, 140, RULE_offsetDateTimeWithMinutes);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(990);
			date();
			setState(991);
			time();
			setState(992);
			offsetWithMinutes();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JdbcTimestampLiteralContext extends ParserRuleContext {
		public TerminalNode TIMESTAMP_ESCAPE_START() { return getToken(HqlParser.TIMESTAMP_ESCAPE_START, 0); }
		public DateTimeContext dateTime() {
			return getRuleContext(DateTimeContext.class,0);
		}
		public GenericTemporalLiteralTextContext genericTemporalLiteralText() {
			return getRuleContext(GenericTemporalLiteralTextContext.class,0);
		}
		public JdbcTimestampLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbcTimestampLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJdbcTimestampLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJdbcTimestampLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJdbcTimestampLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JdbcTimestampLiteralContext jdbcTimestampLiteral() throws RecognitionException {
		JdbcTimestampLiteralContext _localctx = new JdbcTimestampLiteralContext(_ctx, getState());
		enterRule(_localctx, 142, RULE_jdbcTimestampLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(994);
			match(TIMESTAMP_ESCAPE_START);
			setState(997);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				{
				setState(995);
				dateTime();
				}
				break;
			case STRING_LITERAL:
				{
				setState(996);
				genericTemporalLiteralText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(999);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JdbcDateLiteralContext extends ParserRuleContext {
		public TerminalNode DATE_ESCAPE_START() { return getToken(HqlParser.DATE_ESCAPE_START, 0); }
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public GenericTemporalLiteralTextContext genericTemporalLiteralText() {
			return getRuleContext(GenericTemporalLiteralTextContext.class,0);
		}
		public JdbcDateLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbcDateLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJdbcDateLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJdbcDateLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJdbcDateLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JdbcDateLiteralContext jdbcDateLiteral() throws RecognitionException {
		JdbcDateLiteralContext _localctx = new JdbcDateLiteralContext(_ctx, getState());
		enterRule(_localctx, 144, RULE_jdbcDateLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1001);
			match(DATE_ESCAPE_START);
			setState(1004);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				{
				setState(1002);
				date();
				}
				break;
			case STRING_LITERAL:
				{
				setState(1003);
				genericTemporalLiteralText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1006);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JdbcTimeLiteralContext extends ParserRuleContext {
		public TerminalNode TIME_ESCAPE_START() { return getToken(HqlParser.TIME_ESCAPE_START, 0); }
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public GenericTemporalLiteralTextContext genericTemporalLiteralText() {
			return getRuleContext(GenericTemporalLiteralTextContext.class,0);
		}
		public JdbcTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbcTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJdbcTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJdbcTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJdbcTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JdbcTimeLiteralContext jdbcTimeLiteral() throws RecognitionException {
		JdbcTimeLiteralContext _localctx = new JdbcTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 146, RULE_jdbcTimeLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1008);
			match(TIME_ESCAPE_START);
			setState(1011);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				{
				setState(1009);
				time();
				}
				break;
			case STRING_LITERAL:
				{
				setState(1010);
				genericTemporalLiteralText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1013);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericTemporalLiteralTextContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public GenericTemporalLiteralTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericTemporalLiteralText; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericTemporalLiteralText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericTemporalLiteralText(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericTemporalLiteralText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericTemporalLiteralTextContext genericTemporalLiteralText() throws RecognitionException {
		GenericTemporalLiteralTextContext _localctx = new GenericTemporalLiteralTextContext(_ctx, getState());
		enterRule(_localctx, 148, RULE_genericTemporalLiteralText);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1015);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ArrayLiteralContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public ArrayLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterArrayLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitArrayLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitArrayLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArrayLiteralContext arrayLiteral() throws RecognitionException {
		ArrayLiteralContext _localctx = new ArrayLiteralContext(_ctx, getState());
		enterRule(_localctx, 150, RULE_arrayLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1017);
			match(T__6);
			setState(1026);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -31454588L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -1L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 536870911L) != 0)) {
				{
				setState(1018);
				expression(0);
				setState(1023);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1019);
					match(T__0);
					setState(1020);
					expression(0);
					}
					}
					setState(1025);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(1028);
			match(T__7);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralizedLiteralContext extends ParserRuleContext {
		public GeneralizedLiteralTypeContext generalizedLiteralType() {
			return getRuleContext(GeneralizedLiteralTypeContext.class,0);
		}
		public GeneralizedLiteralTextContext generalizedLiteralText() {
			return getRuleContext(GeneralizedLiteralTextContext.class,0);
		}
		public GeneralizedLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalizedLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralizedLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralizedLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralizedLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralizedLiteralContext generalizedLiteral() throws RecognitionException {
		GeneralizedLiteralContext _localctx = new GeneralizedLiteralContext(_ctx, getState());
		enterRule(_localctx, 152, RULE_generalizedLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1030);
			match(T__1);
			setState(1031);
			generalizedLiteralType();
			setState(1032);
			match(T__8);
			setState(1033);
			generalizedLiteralText();
			setState(1034);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralizedLiteralTypeContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public GeneralizedLiteralTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalizedLiteralType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralizedLiteralType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralizedLiteralType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralizedLiteralType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralizedLiteralTypeContext generalizedLiteralType() throws RecognitionException {
		GeneralizedLiteralTypeContext _localctx = new GeneralizedLiteralTypeContext(_ctx, getState());
		enterRule(_localctx, 154, RULE_generalizedLiteralType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1036);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralizedLiteralTextContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public GeneralizedLiteralTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalizedLiteralText; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralizedLiteralText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralizedLiteralText(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralizedLiteralText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralizedLiteralTextContext generalizedLiteralText() throws RecognitionException {
		GeneralizedLiteralTextContext _localctx = new GeneralizedLiteralTextContext(_ctx, getState());
		enterRule(_localctx, 156, RULE_generalizedLiteralText);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1038);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateContext extends ParserRuleContext {
		public YearContext year() {
			return getRuleContext(YearContext.class,0);
		}
		public List<TerminalNode> MINUS() { return getTokens(HqlParser.MINUS); }
		public TerminalNode MINUS(int i) {
			return getToken(HqlParser.MINUS, i);
		}
		public MonthContext month() {
			return getRuleContext(MonthContext.class,0);
		}
		public DayContext day() {
			return getRuleContext(DayContext.class,0);
		}
		public DateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_date; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateContext date() throws RecognitionException {
		DateContext _localctx = new DateContext(_ctx, getState());
		enterRule(_localctx, 158, RULE_date);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1040);
			year();
			setState(1041);
			match(MINUS);
			setState(1042);
			month();
			setState(1043);
			match(MINUS);
			setState(1044);
			day();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeContext extends ParserRuleContext {
		public HourContext hour() {
			return getRuleContext(HourContext.class,0);
		}
		public MinuteContext minute() {
			return getRuleContext(MinuteContext.class,0);
		}
		public SecondContext second() {
			return getRuleContext(SecondContext.class,0);
		}
		public TimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_time; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeContext time() throws RecognitionException {
		TimeContext _localctx = new TimeContext(_ctx, getState());
		enterRule(_localctx, 160, RULE_time);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1046);
			hour();
			setState(1047);
			match(T__8);
			setState(1048);
			minute();
			setState(1051);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,101,_ctx) ) {
			case 1:
				{
				setState(1049);
				match(T__8);
				setState(1050);
				second();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetContext extends ParserRuleContext {
		public HourContext hour() {
			return getRuleContext(HourContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public MinuteContext minute() {
			return getRuleContext(MinuteContext.class,0);
		}
		public OffsetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offset; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffset(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetContext offset() throws RecognitionException {
		OffsetContext _localctx = new OffsetContext(_ctx, getState());
		enterRule(_localctx, 162, RULE_offset);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1053);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1054);
			hour();
			setState(1057);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__8) {
				{
				setState(1055);
				match(T__8);
				setState(1056);
				minute();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetWithMinutesContext extends ParserRuleContext {
		public HourContext hour() {
			return getRuleContext(HourContext.class,0);
		}
		public MinuteContext minute() {
			return getRuleContext(MinuteContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public OffsetWithMinutesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetWithMinutes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetWithMinutes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetWithMinutes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetWithMinutes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetWithMinutesContext offsetWithMinutes() throws RecognitionException {
		OffsetWithMinutesContext _localctx = new OffsetWithMinutesContext(_ctx, getState());
		enterRule(_localctx, 164, RULE_offsetWithMinutes);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1059);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1060);
			hour();
			setState(1061);
			match(T__8);
			setState(1062);
			minute();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class YearContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public YearContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_year; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterYear(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitYear(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitYear(this);
			else return visitor.visitChildren(this);
		}
	}

	public final YearContext year() throws RecognitionException {
		YearContext _localctx = new YearContext(_ctx, getState());
		enterRule(_localctx, 166, RULE_year);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1064);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MonthContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public MonthContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_month; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMonth(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMonth(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMonth(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MonthContext month() throws RecognitionException {
		MonthContext _localctx = new MonthContext(_ctx, getState());
		enterRule(_localctx, 168, RULE_month);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1066);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DayContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public DayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_day; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDay(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDay(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDay(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DayContext day() throws RecognitionException {
		DayContext _localctx = new DayContext(_ctx, getState());
		enterRule(_localctx, 170, RULE_day);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1068);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HourContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public HourContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hour; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterHour(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitHour(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitHour(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HourContext hour() throws RecognitionException {
		HourContext _localctx = new HourContext(_ctx, getState());
		enterRule(_localctx, 172, RULE_hour);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1070);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MinuteContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public MinuteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_minute; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMinute(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMinute(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMinute(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MinuteContext minute() throws RecognitionException {
		MinuteContext _localctx = new MinuteContext(_ctx, getState());
		enterRule(_localctx, 174, RULE_minute);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1072);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SecondContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public TerminalNode DOUBLE_LITERAL() { return getToken(HqlParser.DOUBLE_LITERAL, 0); }
		public SecondContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_second; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSecond(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSecond(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSecond(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SecondContext second() throws RecognitionException {
		SecondContext _localctx = new SecondContext(_ctx, getState());
		enterRule(_localctx, 176, RULE_second);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1074);
			_la = _input.LA(1);
			if ( !(_la==INTEGER_LITERAL || _la==DOUBLE_LITERAL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZoneIdContext extends ParserRuleContext {
		public List<TerminalNode> IDENTIFIER() { return getTokens(HqlParser.IDENTIFIER); }
		public TerminalNode IDENTIFIER(int i) {
			return getToken(HqlParser.IDENTIFIER, i);
		}
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public ZoneIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zoneId; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterZoneId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitZoneId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitZoneId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZoneIdContext zoneId() throws RecognitionException {
		ZoneIdContext _localctx = new ZoneIdContext(_ctx, getState());
		enterRule(_localctx, 178, RULE_zoneId);
		try {
			setState(1082);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1076);
				match(IDENTIFIER);
				setState(1079);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,103,_ctx) ) {
				case 1:
					{
					setState(1077);
					match(T__9);
					setState(1078);
					match(IDENTIFIER);
					}
					break;
				}
				}
				break;
			case STRING_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1081);
				match(STRING_LITERAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExtractFieldContext extends ParserRuleContext {
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public DayFieldContext dayField() {
			return getRuleContext(DayFieldContext.class,0);
		}
		public WeekFieldContext weekField() {
			return getRuleContext(WeekFieldContext.class,0);
		}
		public TimeZoneFieldContext timeZoneField() {
			return getRuleContext(TimeZoneFieldContext.class,0);
		}
		public DateOrTimeFieldContext dateOrTimeField() {
			return getRuleContext(DateOrTimeFieldContext.class,0);
		}
		public ExtractFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extractField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExtractField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExtractField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExtractField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExtractFieldContext extractField() throws RecognitionException {
		ExtractFieldContext _localctx = new ExtractFieldContext(_ctx, getState());
		enterRule(_localctx, 180, RULE_extractField);
		try {
			setState(1089);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,105,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1084);
				datetimeField();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1085);
				dayField();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1086);
				weekField();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1087);
				timeZoneField();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1088);
				dateOrTimeField();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DatetimeFieldContext extends ParserRuleContext {
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode QUARTER() { return getToken(HqlParser.QUARTER, 0); }
		public TerminalNode HOUR() { return getToken(HqlParser.HOUR, 0); }
		public TerminalNode MINUTE() { return getToken(HqlParser.MINUTE, 0); }
		public TerminalNode SECOND() { return getToken(HqlParser.SECOND, 0); }
		public TerminalNode NANOSECOND() { return getToken(HqlParser.NANOSECOND, 0); }
		public TerminalNode EPOCH() { return getToken(HqlParser.EPOCH, 0); }
		public DatetimeFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetimeField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDatetimeField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDatetimeField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDatetimeField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DatetimeFieldContext datetimeField() throws RecognitionException {
		DatetimeFieldContext _localctx = new DatetimeFieldContext(_ctx, getState());
		enterRule(_localctx, 182, RULE_datetimeField);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1091);
			_la = _input.LA(1);
			if ( !(_la==DAY || ((((_la - 71)) & ~0x3f) == 0 && ((1L << (_la - 71)) & 8070450532248977409L) != 0) || ((((_la - 159)) & ~0x3f) == 0 && ((1L << (_la - 159)) & 1116691497217L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DayFieldContext extends ParserRuleContext {
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public DayFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dayField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDayField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDayField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDayField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DayFieldContext dayField() throws RecognitionException {
		DayFieldContext _localctx = new DayFieldContext(_ctx, getState());
		enterRule(_localctx, 184, RULE_dayField);
		try {
			setState(1102);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,106,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1093);
				match(DAY);
				setState(1094);
				match(OF);
				setState(1095);
				match(MONTH);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1096);
				match(DAY);
				setState(1097);
				match(OF);
				setState(1098);
				match(WEEK);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1099);
				match(DAY);
				setState(1100);
				match(OF);
				setState(1101);
				match(YEAR);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WeekFieldContext extends ParserRuleContext {
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public WeekFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_weekField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWeekField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWeekField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWeekField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WeekFieldContext weekField() throws RecognitionException {
		WeekFieldContext _localctx = new WeekFieldContext(_ctx, getState());
		enterRule(_localctx, 186, RULE_weekField);
		try {
			setState(1110);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,107,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1104);
				match(WEEK);
				setState(1105);
				match(OF);
				setState(1106);
				match(MONTH);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1107);
				match(WEEK);
				setState(1108);
				match(OF);
				setState(1109);
				match(YEAR);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeZoneFieldContext extends ParserRuleContext {
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public TerminalNode HOUR() { return getToken(HqlParser.HOUR, 0); }
		public TerminalNode MINUTE() { return getToken(HqlParser.MINUTE, 0); }
		public TerminalNode TIMEZONE_HOUR() { return getToken(HqlParser.TIMEZONE_HOUR, 0); }
		public TerminalNode TIMEZONE_MINUTE() { return getToken(HqlParser.TIMEZONE_MINUTE, 0); }
		public TimeZoneFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeZoneField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTimeZoneField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTimeZoneField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTimeZoneField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeZoneFieldContext timeZoneField() throws RecognitionException {
		TimeZoneFieldContext _localctx = new TimeZoneFieldContext(_ctx, getState());
		enterRule(_localctx, 188, RULE_timeZoneField);
		int _la;
		try {
			setState(1118);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case OFFSET:
				enterOuterAlt(_localctx, 1);
				{
				setState(1112);
				match(OFFSET);
				setState(1114);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HOUR || _la==MINUTE) {
					{
					setState(1113);
					_la = _input.LA(1);
					if ( !(_la==HOUR || _la==MINUTE) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				}
				break;
			case TIMEZONE_HOUR:
				enterOuterAlt(_localctx, 2);
				{
				setState(1116);
				match(TIMEZONE_HOUR);
				}
				break;
			case TIMEZONE_MINUTE:
				enterOuterAlt(_localctx, 3);
				{
				setState(1117);
				match(TIMEZONE_MINUTE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateOrTimeFieldContext extends ParserRuleContext {
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public DateOrTimeFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateOrTimeField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateOrTimeField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateOrTimeField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateOrTimeField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateOrTimeFieldContext dateOrTimeField() throws RecognitionException {
		DateOrTimeFieldContext _localctx = new DateOrTimeFieldContext(_ctx, getState());
		enterRule(_localctx, 190, RULE_dateOrTimeField);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1120);
			_la = _input.LA(1);
			if ( !(_la==DATE || _la==TIME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BinaryLiteralContext extends ParserRuleContext {
		public TerminalNode BINARY_LITERAL() { return getToken(HqlParser.BINARY_LITERAL, 0); }
		public List<TerminalNode> HEX_LITERAL() { return getTokens(HqlParser.HEX_LITERAL); }
		public TerminalNode HEX_LITERAL(int i) {
			return getToken(HqlParser.HEX_LITERAL, i);
		}
		public BinaryLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBinaryLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBinaryLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBinaryLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BinaryLiteralContext binaryLiteral() throws RecognitionException {
		BinaryLiteralContext _localctx = new BinaryLiteralContext(_ctx, getState());
		enterRule(_localctx, 192, RULE_binaryLiteral);
		int _la;
		try {
			setState(1133);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BINARY_LITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1122);
				match(BINARY_LITERAL);
				}
				break;
			case T__10:
				enterOuterAlt(_localctx, 2);
				{
				setState(1123);
				match(T__10);
				setState(1124);
				match(HEX_LITERAL);
				setState(1129);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1125);
					match(T__0);
					setState(1126);
					match(HEX_LITERAL);
					}
					}
					setState(1131);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1132);
				match(T__5);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TemporalLiteralContext extends ParserRuleContext {
		public DateTimeLiteralContext dateTimeLiteral() {
			return getRuleContext(DateTimeLiteralContext.class,0);
		}
		public DateLiteralContext dateLiteral() {
			return getRuleContext(DateLiteralContext.class,0);
		}
		public TimeLiteralContext timeLiteral() {
			return getRuleContext(TimeLiteralContext.class,0);
		}
		public JdbcTimestampLiteralContext jdbcTimestampLiteral() {
			return getRuleContext(JdbcTimestampLiteralContext.class,0);
		}
		public JdbcDateLiteralContext jdbcDateLiteral() {
			return getRuleContext(JdbcDateLiteralContext.class,0);
		}
		public JdbcTimeLiteralContext jdbcTimeLiteral() {
			return getRuleContext(JdbcTimeLiteralContext.class,0);
		}
		public TemporalLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_temporalLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTemporalLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTemporalLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTemporalLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TemporalLiteralContext temporalLiteral() throws RecognitionException {
		TemporalLiteralContext _localctx = new TemporalLiteralContext(_ctx, getState());
		enterRule(_localctx, 194, RULE_temporalLiteral);
		try {
			setState(1141);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,112,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1135);
				dateTimeLiteral();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1136);
				dateLiteral();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1137);
				timeLiteral();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1138);
				jdbcTimestampLiteral();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1139);
				jdbcDateLiteral();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1140);
				jdbcTimeLiteral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AdditionExpressionContext extends ExpressionContext {
		public Token op;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public AdditionExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAdditionExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAdditionExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAdditionExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FromDurationExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public FromDurationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromDurationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromDurationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromDurationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PlainPrimaryExpressionContext extends ExpressionContext {
		public PrimaryExpressionContext primaryExpression() {
			return getRuleContext(PrimaryExpressionContext.class,0);
		}
		public PlainPrimaryExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPlainPrimaryExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPlainPrimaryExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPlainPrimaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TupleExpressionContext extends ExpressionContext {
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TupleExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTupleExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTupleExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTupleExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupedExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public GroupedExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupedExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupedExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SignedNumericLiteralContext extends ExpressionContext {
		public Token op;
		public NumericLiteralContext numericLiteral() {
			return getRuleContext(NumericLiteralContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public SignedNumericLiteralContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSignedNumericLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSignedNumericLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSignedNumericLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ToDurationExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public ToDurationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterToDurationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitToDurationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitToDurationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SubqueryExpressionContext extends ExpressionContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public SubqueryExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubqueryExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubqueryExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubqueryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DayOfMonthExpressionContext extends ExpressionContext {
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public DayOfMonthExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDayOfMonthExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDayOfMonthExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDayOfMonthExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DayOfWeekExpressionContext extends ExpressionContext {
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public DayOfWeekExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDayOfWeekExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDayOfWeekExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDayOfWeekExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class WeekOfYearExpressionContext extends ExpressionContext {
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public WeekOfYearExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWeekOfYearExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWeekOfYearExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWeekOfYearExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HqlConcatenationExpressionContext extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public HqlConcatenationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterHqlConcatenationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitHqlConcatenationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitHqlConcatenationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MultiplicationExpressionContext extends ExpressionContext {
		public Token op;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode ASTERISK() { return getToken(HqlParser.ASTERISK, 0); }
		public MultiplicationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMultiplicationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMultiplicationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMultiplicationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SignedExpressionContext extends ExpressionContext {
		public Token op;
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public SignedExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSignedExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSignedExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSignedExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		return expression(0);
	}

	private ExpressionContext expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExpressionContext _localctx = new ExpressionContext(_ctx, _parentState);
		ExpressionContext _prevctx = _localctx;
		int _startState = 196;
		enterRecursionRule(_localctx, 196, RULE_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1176);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,114,_ctx) ) {
			case 1:
				{
				_localctx = new GroupedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(1144);
				match(T__1);
				setState(1145);
				expression(0);
				setState(1146);
				match(T__2);
				}
				break;
			case 2:
				{
				_localctx = new TupleExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1148);
				match(T__1);
				setState(1149);
				expressionOrPredicate();
				setState(1152); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(1150);
					match(T__0);
					setState(1151);
					expressionOrPredicate();
					}
					}
					setState(1154); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__0 );
				setState(1156);
				match(T__2);
				}
				break;
			case 3:
				{
				_localctx = new SubqueryExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1158);
				match(T__1);
				setState(1159);
				subquery();
				setState(1160);
				match(T__2);
				}
				break;
			case 4:
				{
				_localctx = new PlainPrimaryExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1162);
				primaryExpression();
				}
				break;
			case 5:
				{
				_localctx = new SignedNumericLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1163);
				((SignedNumericLiteralContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					((SignedNumericLiteralContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1164);
				numericLiteral();
				}
				break;
			case 6:
				{
				_localctx = new SignedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1165);
				((SignedExpressionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					((SignedExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1166);
				expression(9);
				}
				break;
			case 7:
				{
				_localctx = new DayOfWeekExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1167);
				match(DAY);
				setState(1168);
				match(OF);
				setState(1169);
				match(WEEK);
				}
				break;
			case 8:
				{
				_localctx = new DayOfMonthExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1170);
				match(DAY);
				setState(1171);
				match(OF);
				setState(1172);
				match(MONTH);
				}
				break;
			case 9:
				{
				_localctx = new WeekOfYearExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1173);
				match(WEEK);
				setState(1174);
				match(OF);
				setState(1175);
				match(YEAR);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(1194);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,116,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(1192);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,115,_ctx) ) {
					case 1:
						{
						_localctx = new MultiplicationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1178);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(1179);
						((MultiplicationExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__9 || _la==ASTERISK) ) {
							((MultiplicationExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(1180);
						expression(7);
						}
						break;
					case 2:
						{
						_localctx = new AdditionExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1181);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(1182);
						((AdditionExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
							((AdditionExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(1183);
						expression(6);
						}
						break;
					case 3:
						{
						_localctx = new HqlConcatenationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1184);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(1185);
						match(T__11);
						setState(1186);
						expression(5);
						}
						break;
					case 4:
						{
						_localctx = new ToDurationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1187);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(1188);
						datetimeField();
						}
						break;
					case 5:
						{
						_localctx = new FromDurationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1189);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(1190);
						match(BY);
						setState(1191);
						datetimeField();
						}
						break;
					}
					} 
				}
				setState(1196);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,116,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PrimaryExpressionContext extends ParserRuleContext {
		public PrimaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_primaryExpression; }
	 
		public PrimaryExpressionContext() { }
		public void copyFrom(PrimaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FunctionExpressionContext extends PrimaryExpressionContext {
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public FunctionExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFunctionExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFunctionExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFunctionExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LiteralExpressionContext extends PrimaryExpressionContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLiteralExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLiteralExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLiteralExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ParameterExpressionContext extends PrimaryExpressionContext {
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public ParameterExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameterExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameterExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityTypeExpressionContext extends PrimaryExpressionContext {
		public EntityTypeReferenceContext entityTypeReference() {
			return getRuleContext(EntityTypeReferenceContext.class,0);
		}
		public EntityTypeExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityTypeExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityTypeExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityTypeExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityIdExpressionContext extends PrimaryExpressionContext {
		public EntityIdReferenceContext entityIdReference() {
			return getRuleContext(EntityIdReferenceContext.class,0);
		}
		public EntityIdExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityIdExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityIdExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityIdExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityVersionExpressionContext extends PrimaryExpressionContext {
		public EntityVersionReferenceContext entityVersionReference() {
			return getRuleContext(EntityVersionReferenceContext.class,0);
		}
		public EntityVersionExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityVersionExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityVersionExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityVersionExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GeneralPathExpressionContext extends PrimaryExpressionContext {
		public GeneralPathFragmentContext generalPathFragment() {
			return getRuleContext(GeneralPathFragmentContext.class,0);
		}
		public GeneralPathExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralPathExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralPathExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralPathExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityNaturalIdExpressionContext extends PrimaryExpressionContext {
		public EntityNaturalIdReferenceContext entityNaturalIdReference() {
			return getRuleContext(EntityNaturalIdReferenceContext.class,0);
		}
		public EntityNaturalIdExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityNaturalIdExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityNaturalIdExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityNaturalIdExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CaseExpressionContext extends PrimaryExpressionContext {
		public CaseListContext caseList() {
			return getRuleContext(CaseListContext.class,0);
		}
		public CaseExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SyntacticPathExpressionContext extends PrimaryExpressionContext {
		public SyntacticDomainPathContext syntacticDomainPath() {
			return getRuleContext(SyntacticDomainPathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public SyntacticPathExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSyntacticPathExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSyntacticPathExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSyntacticPathExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrimaryExpressionContext primaryExpression() throws RecognitionException {
		PrimaryExpressionContext _localctx = new PrimaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 198, RULE_primaryExpression);
		try {
			setState(1210);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,118,_ctx) ) {
			case 1:
				_localctx = new CaseExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1197);
				caseList();
				}
				break;
			case 2:
				_localctx = new LiteralExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1198);
				literal();
				}
				break;
			case 3:
				_localctx = new ParameterExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1199);
				parameter();
				}
				break;
			case 4:
				_localctx = new EntityTypeExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1200);
				entityTypeReference();
				}
				break;
			case 5:
				_localctx = new EntityIdExpressionContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(1201);
				entityIdReference();
				}
				break;
			case 6:
				_localctx = new EntityVersionExpressionContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(1202);
				entityVersionReference();
				}
				break;
			case 7:
				_localctx = new EntityNaturalIdExpressionContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(1203);
				entityNaturalIdReference();
				}
				break;
			case 8:
				_localctx = new SyntacticPathExpressionContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(1204);
				syntacticDomainPath();
				setState(1206);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,117,_ctx) ) {
				case 1:
					{
					setState(1205);
					pathContinuation();
					}
					break;
				}
				}
				break;
			case 9:
				_localctx = new FunctionExpressionContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(1208);
				function();
				}
				break;
			case 10:
				_localctx = new GeneralPathExpressionContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(1209);
				generalPathFragment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PathContext extends ParserRuleContext {
		public SyntacticDomainPathContext syntacticDomainPath() {
			return getRuleContext(SyntacticDomainPathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public GeneralPathFragmentContext generalPathFragment() {
			return getRuleContext(GeneralPathFragmentContext.class,0);
		}
		public PathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PathContext path() throws RecognitionException {
		PathContext _localctx = new PathContext(_ctx, getState());
		enterRule(_localctx, 200, RULE_path);
		try {
			setState(1217);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,120,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1212);
				syntacticDomainPath();
				setState(1214);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,119,_ctx) ) {
				case 1:
					{
					setState(1213);
					pathContinuation();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1216);
				generalPathFragment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralPathFragmentContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public IndexedPathAccessFragmentContext indexedPathAccessFragment() {
			return getRuleContext(IndexedPathAccessFragmentContext.class,0);
		}
		public GeneralPathFragmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalPathFragment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralPathFragment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralPathFragment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralPathFragment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralPathFragmentContext generalPathFragment() throws RecognitionException {
		GeneralPathFragmentContext _localctx = new GeneralPathFragmentContext(_ctx, getState());
		enterRule(_localctx, 202, RULE_generalPathFragment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1219);
			simplePath();
			setState(1221);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,121,_ctx) ) {
			case 1:
				{
				setState(1220);
				indexedPathAccessFragment();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IndexedPathAccessFragmentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public GeneralPathFragmentContext generalPathFragment() {
			return getRuleContext(GeneralPathFragmentContext.class,0);
		}
		public IndexedPathAccessFragmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_indexedPathAccessFragment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndexedPathAccessFragment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndexedPathAccessFragment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndexedPathAccessFragment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IndexedPathAccessFragmentContext indexedPathAccessFragment() throws RecognitionException {
		IndexedPathAccessFragmentContext _localctx = new IndexedPathAccessFragmentContext(_ctx, getState());
		enterRule(_localctx, 204, RULE_indexedPathAccessFragment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1223);
			match(T__6);
			setState(1224);
			expression(0);
			setState(1225);
			match(T__7);
			setState(1228);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,122,_ctx) ) {
			case 1:
				{
				setState(1226);
				match(T__12);
				setState(1227);
				generalPathFragment();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimplePathContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public List<SimplePathElementContext> simplePathElement() {
			return getRuleContexts(SimplePathElementContext.class);
		}
		public SimplePathElementContext simplePathElement(int i) {
			return getRuleContext(SimplePathElementContext.class,i);
		}
		public SimplePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simplePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimplePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimplePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimplePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimplePathContext simplePath() throws RecognitionException {
		SimplePathContext _localctx = new SimplePathContext(_ctx, getState());
		enterRule(_localctx, 206, RULE_simplePath);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1230);
			identifier();
			setState(1234);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,123,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1231);
					simplePathElement();
					}
					} 
				}
				setState(1236);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,123,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimplePathElementContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public SimplePathElementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simplePathElement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimplePathElement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimplePathElement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimplePathElement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimplePathElementContext simplePathElement() throws RecognitionException {
		SimplePathElementContext _localctx = new SimplePathElementContext(_ctx, getState());
		enterRule(_localctx, 208, RULE_simplePathElement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1237);
			match(T__12);
			setState(1238);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PathContinuationContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public PathContinuationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pathContinuation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPathContinuation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPathContinuation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPathContinuation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PathContinuationContext pathContinuation() throws RecognitionException {
		PathContinuationContext _localctx = new PathContinuationContext(_ctx, getState());
		enterRule(_localctx, 210, RULE_pathContinuation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1240);
			match(T__12);
			setState(1241);
			simplePath();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityTypeReferenceContext extends ParserRuleContext {
		public TerminalNode TYPE() { return getToken(HqlParser.TYPE, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public EntityTypeReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityTypeReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityTypeReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityTypeReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityTypeReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityTypeReferenceContext entityTypeReference() throws RecognitionException {
		EntityTypeReferenceContext _localctx = new EntityTypeReferenceContext(_ctx, getState());
		enterRule(_localctx, 212, RULE_entityTypeReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1243);
			match(TYPE);
			setState(1244);
			match(T__1);
			setState(1247);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ALL:
			case AND:
			case ANY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FULL:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INNER:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LEFT:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NANOSECOND:
			case NEW:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case OTHERS:
			case OUTER:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PARTITION:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNION:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case YEAR:
			case ZONED:
			case IDENTIFIER:
			case QUOTED_IDENTIFIER:
				{
				setState(1245);
				path();
				}
				break;
			case T__8:
			case T__20:
				{
				setState(1246);
				parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1249);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityIdReferenceContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(HqlParser.ID, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public EntityIdReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityIdReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityIdReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityIdReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityIdReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityIdReferenceContext entityIdReference() throws RecognitionException {
		EntityIdReferenceContext _localctx = new EntityIdReferenceContext(_ctx, getState());
		enterRule(_localctx, 214, RULE_entityIdReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1251);
			match(ID);
			setState(1252);
			match(T__1);
			setState(1253);
			path();
			setState(1254);
			match(T__2);
			setState(1256);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,125,_ctx) ) {
			case 1:
				{
				setState(1255);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityVersionReferenceContext extends ParserRuleContext {
		public TerminalNode VERSION() { return getToken(HqlParser.VERSION, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public EntityVersionReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityVersionReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityVersionReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityVersionReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityVersionReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityVersionReferenceContext entityVersionReference() throws RecognitionException {
		EntityVersionReferenceContext _localctx = new EntityVersionReferenceContext(_ctx, getState());
		enterRule(_localctx, 216, RULE_entityVersionReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1258);
			match(VERSION);
			setState(1259);
			match(T__1);
			setState(1260);
			path();
			setState(1261);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityNaturalIdReferenceContext extends ParserRuleContext {
		public TerminalNode NATURALID() { return getToken(HqlParser.NATURALID, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public EntityNaturalIdReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityNaturalIdReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityNaturalIdReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityNaturalIdReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityNaturalIdReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityNaturalIdReferenceContext entityNaturalIdReference() throws RecognitionException {
		EntityNaturalIdReferenceContext _localctx = new EntityNaturalIdReferenceContext(_ctx, getState());
		enterRule(_localctx, 218, RULE_entityNaturalIdReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1263);
			match(NATURALID);
			setState(1264);
			match(T__1);
			setState(1265);
			path();
			setState(1266);
			match(T__2);
			setState(1268);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,126,_ctx) ) {
			case 1:
				{
				setState(1267);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SyntacticDomainPathContext extends ParserRuleContext {
		public TreatedNavigablePathContext treatedNavigablePath() {
			return getRuleContext(TreatedNavigablePathContext.class,0);
		}
		public CollectionValueNavigablePathContext collectionValueNavigablePath() {
			return getRuleContext(CollectionValueNavigablePathContext.class,0);
		}
		public MapKeyNavigablePathContext mapKeyNavigablePath() {
			return getRuleContext(MapKeyNavigablePathContext.class,0);
		}
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public IndexedPathAccessFragmentContext indexedPathAccessFragment() {
			return getRuleContext(IndexedPathAccessFragmentContext.class,0);
		}
		public SlicedPathAccessFragmentContext slicedPathAccessFragment() {
			return getRuleContext(SlicedPathAccessFragmentContext.class,0);
		}
		public ToOneFkReferenceContext toOneFkReference() {
			return getRuleContext(ToOneFkReferenceContext.class,0);
		}
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public SyntacticDomainPathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_syntacticDomainPath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSyntacticDomainPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSyntacticDomainPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSyntacticDomainPath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SyntacticDomainPathContext syntacticDomainPath() throws RecognitionException {
		SyntacticDomainPathContext _localctx = new SyntacticDomainPathContext(_ctx, getState());
		enterRule(_localctx, 220, RULE_syntacticDomainPath);
		try {
			setState(1291);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,128,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1270);
				treatedNavigablePath();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1271);
				collectionValueNavigablePath();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1272);
				mapKeyNavigablePath();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1273);
				simplePath();
				setState(1274);
				indexedPathAccessFragment();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1276);
				simplePath();
				setState(1277);
				slicedPathAccessFragment();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1279);
				toOneFkReference();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1280);
				function();
				setState(1281);
				pathContinuation();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1283);
				function();
				setState(1284);
				indexedPathAccessFragment();
				setState(1286);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,127,_ctx) ) {
				case 1:
					{
					setState(1285);
					pathContinuation();
					}
					break;
				}
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1288);
				function();
				setState(1289);
				slicedPathAccessFragment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SlicedPathAccessFragmentContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public SlicedPathAccessFragmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_slicedPathAccessFragment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSlicedPathAccessFragment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSlicedPathAccessFragment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSlicedPathAccessFragment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SlicedPathAccessFragmentContext slicedPathAccessFragment() throws RecognitionException {
		SlicedPathAccessFragmentContext _localctx = new SlicedPathAccessFragmentContext(_ctx, getState());
		enterRule(_localctx, 222, RULE_slicedPathAccessFragment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1293);
			match(T__6);
			setState(1294);
			expression(0);
			setState(1295);
			match(T__8);
			setState(1296);
			expression(0);
			setState(1297);
			match(T__7);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TreatedNavigablePathContext extends ParserRuleContext {
		public TerminalNode TREAT() { return getToken(HqlParser.TREAT, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public TreatedNavigablePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_treatedNavigablePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTreatedNavigablePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTreatedNavigablePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTreatedNavigablePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TreatedNavigablePathContext treatedNavigablePath() throws RecognitionException {
		TreatedNavigablePathContext _localctx = new TreatedNavigablePathContext(_ctx, getState());
		enterRule(_localctx, 224, RULE_treatedNavigablePath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1299);
			match(TREAT);
			setState(1300);
			match(T__1);
			setState(1301);
			path();
			setState(1302);
			match(AS);
			setState(1303);
			simplePath();
			setState(1304);
			match(T__2);
			setState(1306);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,129,_ctx) ) {
			case 1:
				{
				setState(1305);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionValueNavigablePathContext extends ParserRuleContext {
		public ElementValueQuantifierContext elementValueQuantifier() {
			return getRuleContext(ElementValueQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public CollectionValueNavigablePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionValueNavigablePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionValueNavigablePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionValueNavigablePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionValueNavigablePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionValueNavigablePathContext collectionValueNavigablePath() throws RecognitionException {
		CollectionValueNavigablePathContext _localctx = new CollectionValueNavigablePathContext(_ctx, getState());
		enterRule(_localctx, 226, RULE_collectionValueNavigablePath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1308);
			elementValueQuantifier();
			setState(1309);
			match(T__1);
			setState(1310);
			path();
			setState(1311);
			match(T__2);
			setState(1313);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,130,_ctx) ) {
			case 1:
				{
				setState(1312);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapKeyNavigablePathContext extends ParserRuleContext {
		public IndexKeyQuantifierContext indexKeyQuantifier() {
			return getRuleContext(IndexKeyQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public MapKeyNavigablePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapKeyNavigablePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMapKeyNavigablePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMapKeyNavigablePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMapKeyNavigablePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MapKeyNavigablePathContext mapKeyNavigablePath() throws RecognitionException {
		MapKeyNavigablePathContext _localctx = new MapKeyNavigablePathContext(_ctx, getState());
		enterRule(_localctx, 228, RULE_mapKeyNavigablePath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1315);
			indexKeyQuantifier();
			setState(1316);
			match(T__1);
			setState(1317);
			path();
			setState(1318);
			match(T__2);
			setState(1320);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,131,_ctx) ) {
			case 1:
				{
				setState(1319);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ToOneFkReferenceContext extends ParserRuleContext {
		public TerminalNode FK() { return getToken(HqlParser.FK, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public ToOneFkReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_toOneFkReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterToOneFkReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitToOneFkReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitToOneFkReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ToOneFkReferenceContext toOneFkReference() throws RecognitionException {
		ToOneFkReferenceContext _localctx = new ToOneFkReferenceContext(_ctx, getState());
		enterRule(_localctx, 230, RULE_toOneFkReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1322);
			match(FK);
			setState(1323);
			match(T__1);
			setState(1324);
			path();
			setState(1325);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CaseListContext extends ParserRuleContext {
		public SimpleCaseExpressionContext simpleCaseExpression() {
			return getRuleContext(SimpleCaseExpressionContext.class,0);
		}
		public SearchedCaseExpressionContext searchedCaseExpression() {
			return getRuleContext(SearchedCaseExpressionContext.class,0);
		}
		public CaseListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caseList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseListContext caseList() throws RecognitionException {
		CaseListContext _localctx = new CaseListContext(_ctx, getState());
		enterRule(_localctx, 232, RULE_caseList);
		try {
			setState(1329);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,132,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1327);
				simpleCaseExpression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1328);
				searchedCaseExpression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimpleCaseExpressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(HqlParser.CASE, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode END() { return getToken(HqlParser.END, 0); }
		public List<CaseWhenExpressionClauseContext> caseWhenExpressionClause() {
			return getRuleContexts(CaseWhenExpressionClauseContext.class);
		}
		public CaseWhenExpressionClauseContext caseWhenExpressionClause(int i) {
			return getRuleContext(CaseWhenExpressionClauseContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(HqlParser.ELSE, 0); }
		public SimpleCaseExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleCaseExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimpleCaseExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimpleCaseExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimpleCaseExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimpleCaseExpressionContext simpleCaseExpression() throws RecognitionException {
		SimpleCaseExpressionContext _localctx = new SimpleCaseExpressionContext(_ctx, getState());
		enterRule(_localctx, 234, RULE_simpleCaseExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1331);
			match(CASE);
			setState(1332);
			expressionOrPredicate();
			setState(1334); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1333);
				caseWhenExpressionClause();
				}
				}
				setState(1336); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WHEN );
			setState(1340);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(1338);
				match(ELSE);
				setState(1339);
				expressionOrPredicate();
				}
			}

			setState(1342);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchedCaseExpressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(HqlParser.CASE, 0); }
		public TerminalNode END() { return getToken(HqlParser.END, 0); }
		public List<CaseWhenPredicateClauseContext> caseWhenPredicateClause() {
			return getRuleContexts(CaseWhenPredicateClauseContext.class);
		}
		public CaseWhenPredicateClauseContext caseWhenPredicateClause(int i) {
			return getRuleContext(CaseWhenPredicateClauseContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(HqlParser.ELSE, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public SearchedCaseExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchedCaseExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchedCaseExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchedCaseExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchedCaseExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchedCaseExpressionContext searchedCaseExpression() throws RecognitionException {
		SearchedCaseExpressionContext _localctx = new SearchedCaseExpressionContext(_ctx, getState());
		enterRule(_localctx, 236, RULE_searchedCaseExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1344);
			match(CASE);
			setState(1346); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1345);
				caseWhenPredicateClause();
				}
				}
				setState(1348); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WHEN );
			setState(1352);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(1350);
				match(ELSE);
				setState(1351);
				expressionOrPredicate();
				}
			}

			setState(1354);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CaseWhenExpressionClauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(HqlParser.WHEN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode THEN() { return getToken(HqlParser.THEN, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public CaseWhenExpressionClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caseWhenExpressionClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseWhenExpressionClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseWhenExpressionClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseWhenExpressionClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseWhenExpressionClauseContext caseWhenExpressionClause() throws RecognitionException {
		CaseWhenExpressionClauseContext _localctx = new CaseWhenExpressionClauseContext(_ctx, getState());
		enterRule(_localctx, 238, RULE_caseWhenExpressionClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1356);
			match(WHEN);
			setState(1357);
			expression(0);
			setState(1358);
			match(THEN);
			setState(1359);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CaseWhenPredicateClauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(HqlParser.WHEN, 0); }
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public TerminalNode THEN() { return getToken(HqlParser.THEN, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public CaseWhenPredicateClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caseWhenPredicateClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseWhenPredicateClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseWhenPredicateClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseWhenPredicateClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseWhenPredicateClauseContext caseWhenPredicateClause() throws RecognitionException {
		CaseWhenPredicateClauseContext _localctx = new CaseWhenPredicateClauseContext(_ctx, getState());
		enterRule(_localctx, 240, RULE_caseWhenPredicateClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1361);
			match(WHEN);
			setState(1362);
			predicate(0);
			setState(1363);
			match(THEN);
			setState(1364);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionContext extends ParserRuleContext {
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
	 
		public FunctionContext() { }
		public void copyFrom(FunctionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionAggregateFunctionInvocationContext extends FunctionContext {
		public CollectionAggregateFunctionContext collectionAggregateFunction() {
			return getRuleContext(CollectionAggregateFunctionContext.class,0);
		}
		public CollectionAggregateFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionAggregateFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionAggregateFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionAggregateFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AggregateFunctionInvocationContext extends FunctionContext {
		public AggregateFunctionContext aggregateFunction() {
			return getRuleContext(AggregateFunctionContext.class,0);
		}
		public AggregateFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAggregateFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAggregateFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAggregateFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionSizeFunctionInvocationContext extends FunctionContext {
		public CollectionSizeFunctionContext collectionSizeFunction() {
			return getRuleContext(CollectionSizeFunctionContext.class,0);
		}
		public CollectionSizeFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionSizeFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionSizeFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionSizeFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JpaNonstandardFunctionInvocationContext extends FunctionContext {
		public JpaNonstandardFunctionContext jpaNonstandardFunction() {
			return getRuleContext(JpaNonstandardFunctionContext.class,0);
		}
		public JpaNonstandardFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaNonstandardFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaNonstandardFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaNonstandardFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ColumnFunctionInvocationContext extends FunctionContext {
		public ColumnFunctionContext columnFunction() {
			return getRuleContext(ColumnFunctionContext.class,0);
		}
		public ColumnFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterColumnFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitColumnFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitColumnFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionFunctionMisuseInvocationContext extends FunctionContext {
		public CollectionFunctionMisuseContext collectionFunctionMisuse() {
			return getRuleContext(CollectionFunctionMisuseContext.class,0);
		}
		public CollectionFunctionMisuseInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionFunctionMisuseInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionFunctionMisuseInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionFunctionMisuseInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StandardFunctionInvocationContext extends FunctionContext {
		public StandardFunctionContext standardFunction() {
			return getRuleContext(StandardFunctionContext.class,0);
		}
		public StandardFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStandardFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStandardFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStandardFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionInvocationContext extends FunctionContext {
		public GenericFunctionContext genericFunction() {
			return getRuleContext(GenericFunctionContext.class,0);
		}
		public GenericFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 242, RULE_function);
		try {
			setState(1374);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,137,_ctx) ) {
			case 1:
				_localctx = new StandardFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1366);
				standardFunction();
				}
				break;
			case 2:
				_localctx = new AggregateFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1367);
				aggregateFunction();
				}
				break;
			case 3:
				_localctx = new CollectionSizeFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1368);
				collectionSizeFunction();
				}
				break;
			case 4:
				_localctx = new CollectionAggregateFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1369);
				collectionAggregateFunction();
				}
				break;
			case 5:
				_localctx = new CollectionFunctionMisuseInvocationContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(1370);
				collectionFunctionMisuse();
				}
				break;
			case 6:
				_localctx = new JpaNonstandardFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(1371);
				jpaNonstandardFunction();
				}
				break;
			case 7:
				_localctx = new ColumnFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(1372);
				columnFunction();
				}
				break;
			case 8:
				_localctx = new GenericFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(1373);
				genericFunction();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StandardFunctionContext extends ParserRuleContext {
		public CastFunctionContext castFunction() {
			return getRuleContext(CastFunctionContext.class,0);
		}
		public TreatedNavigablePathContext treatedNavigablePath() {
			return getRuleContext(TreatedNavigablePathContext.class,0);
		}
		public ExtractFunctionContext extractFunction() {
			return getRuleContext(ExtractFunctionContext.class,0);
		}
		public TruncFunctionContext truncFunction() {
			return getRuleContext(TruncFunctionContext.class,0);
		}
		public FormatFunctionContext formatFunction() {
			return getRuleContext(FormatFunctionContext.class,0);
		}
		public CollateFunctionContext collateFunction() {
			return getRuleContext(CollateFunctionContext.class,0);
		}
		public SubstringFunctionContext substringFunction() {
			return getRuleContext(SubstringFunctionContext.class,0);
		}
		public OverlayFunctionContext overlayFunction() {
			return getRuleContext(OverlayFunctionContext.class,0);
		}
		public TrimFunctionContext trimFunction() {
			return getRuleContext(TrimFunctionContext.class,0);
		}
		public PadFunctionContext padFunction() {
			return getRuleContext(PadFunctionContext.class,0);
		}
		public PositionFunctionContext positionFunction() {
			return getRuleContext(PositionFunctionContext.class,0);
		}
		public CurrentDateFunctionContext currentDateFunction() {
			return getRuleContext(CurrentDateFunctionContext.class,0);
		}
		public CurrentTimeFunctionContext currentTimeFunction() {
			return getRuleContext(CurrentTimeFunctionContext.class,0);
		}
		public CurrentTimestampFunctionContext currentTimestampFunction() {
			return getRuleContext(CurrentTimestampFunctionContext.class,0);
		}
		public InstantFunctionContext instantFunction() {
			return getRuleContext(InstantFunctionContext.class,0);
		}
		public LocalDateFunctionContext localDateFunction() {
			return getRuleContext(LocalDateFunctionContext.class,0);
		}
		public LocalTimeFunctionContext localTimeFunction() {
			return getRuleContext(LocalTimeFunctionContext.class,0);
		}
		public LocalDateTimeFunctionContext localDateTimeFunction() {
			return getRuleContext(LocalDateTimeFunctionContext.class,0);
		}
		public OffsetDateTimeFunctionContext offsetDateTimeFunction() {
			return getRuleContext(OffsetDateTimeFunctionContext.class,0);
		}
		public CubeContext cube() {
			return getRuleContext(CubeContext.class,0);
		}
		public RollupContext rollup() {
			return getRuleContext(RollupContext.class,0);
		}
		public StandardFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_standardFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStandardFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStandardFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStandardFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StandardFunctionContext standardFunction() throws RecognitionException {
		StandardFunctionContext _localctx = new StandardFunctionContext(_ctx, getState());
		enterRule(_localctx, 244, RULE_standardFunction);
		try {
			setState(1397);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,138,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1376);
				castFunction();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1377);
				treatedNavigablePath();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1378);
				extractFunction();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1379);
				truncFunction();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1380);
				formatFunction();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1381);
				collateFunction();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1382);
				substringFunction();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1383);
				overlayFunction();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1384);
				trimFunction();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(1385);
				padFunction();
				}
				break;
			case 11:
				enterOuterAlt(_localctx, 11);
				{
				setState(1386);
				positionFunction();
				}
				break;
			case 12:
				enterOuterAlt(_localctx, 12);
				{
				setState(1387);
				currentDateFunction();
				}
				break;
			case 13:
				enterOuterAlt(_localctx, 13);
				{
				setState(1388);
				currentTimeFunction();
				}
				break;
			case 14:
				enterOuterAlt(_localctx, 14);
				{
				setState(1389);
				currentTimestampFunction();
				}
				break;
			case 15:
				enterOuterAlt(_localctx, 15);
				{
				setState(1390);
				instantFunction();
				}
				break;
			case 16:
				enterOuterAlt(_localctx, 16);
				{
				setState(1391);
				localDateFunction();
				}
				break;
			case 17:
				enterOuterAlt(_localctx, 17);
				{
				setState(1392);
				localTimeFunction();
				}
				break;
			case 18:
				enterOuterAlt(_localctx, 18);
				{
				setState(1393);
				localDateTimeFunction();
				}
				break;
			case 19:
				enterOuterAlt(_localctx, 19);
				{
				setState(1394);
				offsetDateTimeFunction();
				}
				break;
			case 20:
				enterOuterAlt(_localctx, 20);
				{
				setState(1395);
				cube();
				}
				break;
			case 21:
				enterOuterAlt(_localctx, 21);
				{
				setState(1396);
				rollup();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CastFunctionContext extends ParserRuleContext {
		public TerminalNode CAST() { return getToken(HqlParser.CAST, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public CastFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_castFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCastFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCastFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCastFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CastFunctionContext castFunction() throws RecognitionException {
		CastFunctionContext _localctx = new CastFunctionContext(_ctx, getState());
		enterRule(_localctx, 246, RULE_castFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1399);
			match(CAST);
			setState(1400);
			match(T__1);
			setState(1401);
			expression(0);
			setState(1402);
			match(AS);
			setState(1403);
			castTarget();
			setState(1404);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CastTargetContext extends ParserRuleContext {
		public CastTargetTypeContext castTargetType() {
			return getRuleContext(CastTargetTypeContext.class,0);
		}
		public List<TerminalNode> INTEGER_LITERAL() { return getTokens(HqlParser.INTEGER_LITERAL); }
		public TerminalNode INTEGER_LITERAL(int i) {
			return getToken(HqlParser.INTEGER_LITERAL, i);
		}
		public CastTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_castTarget; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCastTarget(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCastTarget(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCastTarget(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CastTargetContext castTarget() throws RecognitionException {
		CastTargetContext _localctx = new CastTargetContext(_ctx, getState());
		enterRule(_localctx, 248, RULE_castTarget);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1406);
			castTargetType();
			setState(1414);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(1407);
				match(T__1);
				setState(1408);
				match(INTEGER_LITERAL);
				setState(1411);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1409);
					match(T__0);
					setState(1410);
					match(INTEGER_LITERAL);
					}
				}

				setState(1413);
				match(T__2);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CastTargetTypeContext extends ParserRuleContext {
		public String fullTargetName;
		public IdentifierContext i;
		public IdentifierContext c;
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public CastTargetTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_castTargetType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCastTargetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCastTargetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCastTargetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CastTargetTypeContext castTargetType() throws RecognitionException {
		CastTargetTypeContext _localctx = new CastTargetTypeContext(_ctx, getState());
		enterRule(_localctx, 250, RULE_castTargetType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(1416);
			((CastTargetTypeContext)_localctx).i = identifier();
			 ((CastTargetTypeContext)_localctx).fullTargetName =  _localctx.i.getText(); 
			}
			setState(1425);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__12) {
				{
				{
				setState(1419);
				match(T__12);
				setState(1420);
				((CastTargetTypeContext)_localctx).c = identifier();
				 _localctx.fullTargetName += ("." + _localctx.c.getText() ); 
				}
				}
				setState(1427);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubstringFunctionContext extends ParserRuleContext {
		public TerminalNode SUBSTRING() { return getToken(HqlParser.SUBSTRING, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SubstringFunctionStartArgumentContext substringFunctionStartArgument() {
			return getRuleContext(SubstringFunctionStartArgumentContext.class,0);
		}
		public SubstringFunctionLengthArgumentContext substringFunctionLengthArgument() {
			return getRuleContext(SubstringFunctionLengthArgumentContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public SubstringFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_substringFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubstringFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubstringFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubstringFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubstringFunctionContext substringFunction() throws RecognitionException {
		SubstringFunctionContext _localctx = new SubstringFunctionContext(_ctx, getState());
		enterRule(_localctx, 252, RULE_substringFunction);
		int _la;
		try {
			setState(1450);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,144,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1428);
				match(SUBSTRING);
				setState(1429);
				match(T__1);
				setState(1430);
				expression(0);
				setState(1431);
				match(T__0);
				setState(1432);
				substringFunctionStartArgument();
				setState(1435);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1433);
					match(T__0);
					setState(1434);
					substringFunctionLengthArgument();
					}
				}

				setState(1437);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1439);
				match(SUBSTRING);
				setState(1440);
				match(T__1);
				setState(1441);
				expression(0);
				setState(1442);
				match(FROM);
				setState(1443);
				substringFunctionStartArgument();
				setState(1446);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FOR) {
					{
					setState(1444);
					match(FOR);
					setState(1445);
					substringFunctionLengthArgument();
					}
				}

				setState(1448);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubstringFunctionStartArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SubstringFunctionStartArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_substringFunctionStartArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubstringFunctionStartArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubstringFunctionStartArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubstringFunctionStartArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubstringFunctionStartArgumentContext substringFunctionStartArgument() throws RecognitionException {
		SubstringFunctionStartArgumentContext _localctx = new SubstringFunctionStartArgumentContext(_ctx, getState());
		enterRule(_localctx, 254, RULE_substringFunctionStartArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1452);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubstringFunctionLengthArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SubstringFunctionLengthArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_substringFunctionLengthArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubstringFunctionLengthArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubstringFunctionLengthArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubstringFunctionLengthArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubstringFunctionLengthArgumentContext substringFunctionLengthArgument() throws RecognitionException {
		SubstringFunctionLengthArgumentContext _localctx = new SubstringFunctionLengthArgumentContext(_ctx, getState());
		enterRule(_localctx, 256, RULE_substringFunctionLengthArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1454);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrimFunctionContext extends ParserRuleContext {
		public TerminalNode TRIM() { return getToken(HqlParser.TRIM, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TrimSpecificationContext trimSpecification() {
			return getRuleContext(TrimSpecificationContext.class,0);
		}
		public TrimCharacterContext trimCharacter() {
			return getRuleContext(TrimCharacterContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TrimFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trimFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTrimFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTrimFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTrimFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TrimFunctionContext trimFunction() throws RecognitionException {
		TrimFunctionContext _localctx = new TrimFunctionContext(_ctx, getState());
		enterRule(_localctx, 258, RULE_trimFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1456);
			match(TRIM);
			setState(1457);
			match(T__1);
			setState(1459);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,145,_ctx) ) {
			case 1:
				{
				setState(1458);
				trimSpecification();
				}
				break;
			}
			setState(1462);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,146,_ctx) ) {
			case 1:
				{
				setState(1461);
				trimCharacter();
				}
				break;
			}
			setState(1465);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,147,_ctx) ) {
			case 1:
				{
				setState(1464);
				match(FROM);
				}
				break;
			}
			setState(1467);
			expression(0);
			setState(1468);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrimSpecificationContext extends ParserRuleContext {
		public TerminalNode LEADING() { return getToken(HqlParser.LEADING, 0); }
		public TerminalNode TRAILING() { return getToken(HqlParser.TRAILING, 0); }
		public TerminalNode BOTH() { return getToken(HqlParser.BOTH, 0); }
		public TrimSpecificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trimSpecification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTrimSpecification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTrimSpecification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTrimSpecification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TrimSpecificationContext trimSpecification() throws RecognitionException {
		TrimSpecificationContext _localctx = new TrimSpecificationContext(_ctx, getState());
		enterRule(_localctx, 260, RULE_trimSpecification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1470);
			_la = _input.LA(1);
			if ( !(_la==BOTH || _la==LEADING || _la==TRAILING) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrimCharacterContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public TrimCharacterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trimCharacter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTrimCharacter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTrimCharacter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTrimCharacter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TrimCharacterContext trimCharacter() throws RecognitionException {
		TrimCharacterContext _localctx = new TrimCharacterContext(_ctx, getState());
		enterRule(_localctx, 262, RULE_trimCharacter);
		try {
			setState(1474);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING_LITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1472);
				match(STRING_LITERAL);
				}
				break;
			case T__8:
			case T__20:
				enterOuterAlt(_localctx, 2);
				{
				setState(1473);
				parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadFunctionContext extends ParserRuleContext {
		public TerminalNode PAD() { return getToken(HqlParser.PAD, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public PadLengthContext padLength() {
			return getRuleContext(PadLengthContext.class,0);
		}
		public PadSpecificationContext padSpecification() {
			return getRuleContext(PadSpecificationContext.class,0);
		}
		public PadCharacterContext padCharacter() {
			return getRuleContext(PadCharacterContext.class,0);
		}
		public PadFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadFunctionContext padFunction() throws RecognitionException {
		PadFunctionContext _localctx = new PadFunctionContext(_ctx, getState());
		enterRule(_localctx, 264, RULE_padFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1476);
			match(PAD);
			setState(1477);
			match(T__1);
			setState(1478);
			expression(0);
			setState(1479);
			match(WITH);
			setState(1480);
			padLength();
			setState(1481);
			padSpecification();
			setState(1483);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==STRING_LITERAL) {
				{
				setState(1482);
				padCharacter();
				}
			}

			setState(1485);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadSpecificationContext extends ParserRuleContext {
		public TerminalNode LEADING() { return getToken(HqlParser.LEADING, 0); }
		public TerminalNode TRAILING() { return getToken(HqlParser.TRAILING, 0); }
		public PadSpecificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padSpecification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadSpecification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadSpecification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadSpecification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadSpecificationContext padSpecification() throws RecognitionException {
		PadSpecificationContext _localctx = new PadSpecificationContext(_ctx, getState());
		enterRule(_localctx, 266, RULE_padSpecification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1487);
			_la = _input.LA(1);
			if ( !(_la==LEADING || _la==TRAILING) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadCharacterContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public PadCharacterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padCharacter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadCharacter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadCharacter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadCharacter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadCharacterContext padCharacter() throws RecognitionException {
		PadCharacterContext _localctx = new PadCharacterContext(_ctx, getState());
		enterRule(_localctx, 268, RULE_padCharacter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1489);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadLengthContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PadLengthContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padLength; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadLength(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadLength(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadLength(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadLengthContext padLength() throws RecognitionException {
		PadLengthContext _localctx = new PadLengthContext(_ctx, getState());
		enterRule(_localctx, 270, RULE_padLength);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1491);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionFunctionContext extends ParserRuleContext {
		public TerminalNode POSITION() { return getToken(HqlParser.POSITION, 0); }
		public PositionFunctionPatternArgumentContext positionFunctionPatternArgument() {
			return getRuleContext(PositionFunctionPatternArgumentContext.class,0);
		}
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public PositionFunctionStringArgumentContext positionFunctionStringArgument() {
			return getRuleContext(PositionFunctionStringArgumentContext.class,0);
		}
		public PositionFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPositionFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPositionFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPositionFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionFunctionContext positionFunction() throws RecognitionException {
		PositionFunctionContext _localctx = new PositionFunctionContext(_ctx, getState());
		enterRule(_localctx, 272, RULE_positionFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1493);
			match(POSITION);
			setState(1494);
			match(T__1);
			setState(1495);
			positionFunctionPatternArgument();
			setState(1496);
			match(IN);
			setState(1497);
			positionFunctionStringArgument();
			setState(1498);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionFunctionPatternArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositionFunctionPatternArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionFunctionPatternArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPositionFunctionPatternArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPositionFunctionPatternArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPositionFunctionPatternArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionFunctionPatternArgumentContext positionFunctionPatternArgument() throws RecognitionException {
		PositionFunctionPatternArgumentContext _localctx = new PositionFunctionPatternArgumentContext(_ctx, getState());
		enterRule(_localctx, 274, RULE_positionFunctionPatternArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1500);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionFunctionStringArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositionFunctionStringArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionFunctionStringArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPositionFunctionStringArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPositionFunctionStringArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPositionFunctionStringArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionFunctionStringArgumentContext positionFunctionStringArgument() throws RecognitionException {
		PositionFunctionStringArgumentContext _localctx = new PositionFunctionStringArgumentContext(_ctx, getState());
		enterRule(_localctx, 276, RULE_positionFunctionStringArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1502);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionContext extends ParserRuleContext {
		public TerminalNode OVERLAY() { return getToken(HqlParser.OVERLAY, 0); }
		public OverlayFunctionStringArgumentContext overlayFunctionStringArgument() {
			return getRuleContext(OverlayFunctionStringArgumentContext.class,0);
		}
		public TerminalNode PLACING() { return getToken(HqlParser.PLACING, 0); }
		public OverlayFunctionReplacementArgumentContext overlayFunctionReplacementArgument() {
			return getRuleContext(OverlayFunctionReplacementArgumentContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public OverlayFunctionStartArgumentContext overlayFunctionStartArgument() {
			return getRuleContext(OverlayFunctionStartArgumentContext.class,0);
		}
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public OverlayFunctionLengthArgumentContext overlayFunctionLengthArgument() {
			return getRuleContext(OverlayFunctionLengthArgumentContext.class,0);
		}
		public OverlayFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionContext overlayFunction() throws RecognitionException {
		OverlayFunctionContext _localctx = new OverlayFunctionContext(_ctx, getState());
		enterRule(_localctx, 278, RULE_overlayFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1504);
			match(OVERLAY);
			setState(1505);
			match(T__1);
			setState(1506);
			overlayFunctionStringArgument();
			setState(1507);
			match(PLACING);
			setState(1508);
			overlayFunctionReplacementArgument();
			setState(1509);
			match(FROM);
			setState(1510);
			overlayFunctionStartArgument();
			setState(1513);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FOR) {
				{
				setState(1511);
				match(FOR);
				setState(1512);
				overlayFunctionLengthArgument();
				}
			}

			setState(1515);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionStringArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionStringArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionStringArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionStringArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionStringArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionStringArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionStringArgumentContext overlayFunctionStringArgument() throws RecognitionException {
		OverlayFunctionStringArgumentContext _localctx = new OverlayFunctionStringArgumentContext(_ctx, getState());
		enterRule(_localctx, 280, RULE_overlayFunctionStringArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1517);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionReplacementArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionReplacementArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionReplacementArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionReplacementArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionReplacementArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionReplacementArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionReplacementArgumentContext overlayFunctionReplacementArgument() throws RecognitionException {
		OverlayFunctionReplacementArgumentContext _localctx = new OverlayFunctionReplacementArgumentContext(_ctx, getState());
		enterRule(_localctx, 282, RULE_overlayFunctionReplacementArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1519);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionStartArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionStartArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionStartArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionStartArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionStartArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionStartArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionStartArgumentContext overlayFunctionStartArgument() throws RecognitionException {
		OverlayFunctionStartArgumentContext _localctx = new OverlayFunctionStartArgumentContext(_ctx, getState());
		enterRule(_localctx, 284, RULE_overlayFunctionStartArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1521);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionLengthArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionLengthArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionLengthArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionLengthArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionLengthArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionLengthArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionLengthArgumentContext overlayFunctionLengthArgument() throws RecognitionException {
		OverlayFunctionLengthArgumentContext _localctx = new OverlayFunctionLengthArgumentContext(_ctx, getState());
		enterRule(_localctx, 286, RULE_overlayFunctionLengthArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1523);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CurrentDateFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_DATE() { return getToken(HqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public CurrentDateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_currentDateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCurrentDateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCurrentDateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCurrentDateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CurrentDateFunctionContext currentDateFunction() throws RecognitionException {
		CurrentDateFunctionContext _localctx = new CurrentDateFunctionContext(_ctx, getState());
		enterRule(_localctx, 288, RULE_currentDateFunction);
		try {
			setState(1532);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_DATE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1525);
				match(CURRENT_DATE);
				setState(1528);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,151,_ctx) ) {
				case 1:
					{
					setState(1526);
					match(T__1);
					setState(1527);
					match(T__2);
					}
					break;
				}
				}
				break;
			case CURRENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1530);
				match(CURRENT);
				setState(1531);
				match(DATE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CurrentTimeFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_TIME() { return getToken(HqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public CurrentTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_currentTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCurrentTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCurrentTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCurrentTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CurrentTimeFunctionContext currentTimeFunction() throws RecognitionException {
		CurrentTimeFunctionContext _localctx = new CurrentTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 290, RULE_currentTimeFunction);
		try {
			setState(1541);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_TIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1534);
				match(CURRENT_TIME);
				setState(1537);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,153,_ctx) ) {
				case 1:
					{
					setState(1535);
					match(T__1);
					setState(1536);
					match(T__2);
					}
					break;
				}
				}
				break;
			case CURRENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1539);
				match(CURRENT);
				setState(1540);
				match(TIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CurrentTimestampFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(HqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode TIMESTAMP() { return getToken(HqlParser.TIMESTAMP, 0); }
		public CurrentTimestampFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_currentTimestampFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCurrentTimestampFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCurrentTimestampFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCurrentTimestampFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CurrentTimestampFunctionContext currentTimestampFunction() throws RecognitionException {
		CurrentTimestampFunctionContext _localctx = new CurrentTimestampFunctionContext(_ctx, getState());
		enterRule(_localctx, 292, RULE_currentTimestampFunction);
		try {
			setState(1550);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_TIMESTAMP:
				enterOuterAlt(_localctx, 1);
				{
				setState(1543);
				match(CURRENT_TIMESTAMP);
				setState(1546);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,155,_ctx) ) {
				case 1:
					{
					setState(1544);
					match(T__1);
					setState(1545);
					match(T__2);
					}
					break;
				}
				}
				break;
			case CURRENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1548);
				match(CURRENT);
				setState(1549);
				match(TIMESTAMP);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_INSTANT() { return getToken(HqlParser.CURRENT_INSTANT, 0); }
		public TerminalNode INSTANT() { return getToken(HqlParser.INSTANT, 0); }
		public InstantFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantFunctionContext instantFunction() throws RecognitionException {
		InstantFunctionContext _localctx = new InstantFunctionContext(_ctx, getState());
		enterRule(_localctx, 294, RULE_instantFunction);
		try {
			setState(1558);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_INSTANT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1552);
				match(CURRENT_INSTANT);
				setState(1555);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,157,_ctx) ) {
				case 1:
					{
					setState(1553);
					match(T__1);
					setState(1554);
					match(T__2);
					}
					break;
				}
				}
				break;
			case INSTANT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1557);
				match(INSTANT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateTimeFunctionContext extends ParserRuleContext {
		public TerminalNode LOCAL_DATETIME() { return getToken(HqlParser.LOCAL_DATETIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public LocalDateTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateTimeFunctionContext localDateTimeFunction() throws RecognitionException {
		LocalDateTimeFunctionContext _localctx = new LocalDateTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 296, RULE_localDateTimeFunction);
		try {
			setState(1567);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOCAL_DATETIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1560);
				match(LOCAL_DATETIME);
				setState(1563);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,159,_ctx) ) {
				case 1:
					{
					setState(1561);
					match(T__1);
					setState(1562);
					match(T__2);
					}
					break;
				}
				}
				break;
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1565);
				match(LOCAL);
				setState(1566);
				match(DATETIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeFunctionContext extends ParserRuleContext {
		public TerminalNode OFFSET_DATETIME() { return getToken(HqlParser.OFFSET_DATETIME, 0); }
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public OffsetDateTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeFunctionContext offsetDateTimeFunction() throws RecognitionException {
		OffsetDateTimeFunctionContext _localctx = new OffsetDateTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 298, RULE_offsetDateTimeFunction);
		try {
			setState(1576);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case OFFSET_DATETIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1569);
				match(OFFSET_DATETIME);
				setState(1572);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,161,_ctx) ) {
				case 1:
					{
					setState(1570);
					match(T__1);
					setState(1571);
					match(T__2);
					}
					break;
				}
				}
				break;
			case OFFSET:
				enterOuterAlt(_localctx, 2);
				{
				setState(1574);
				match(OFFSET);
				setState(1575);
				match(DATETIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateFunctionContext extends ParserRuleContext {
		public TerminalNode LOCAL_DATE() { return getToken(HqlParser.LOCAL_DATE, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public LocalDateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateFunctionContext localDateFunction() throws RecognitionException {
		LocalDateFunctionContext _localctx = new LocalDateFunctionContext(_ctx, getState());
		enterRule(_localctx, 300, RULE_localDateFunction);
		try {
			setState(1585);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOCAL_DATE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1578);
				match(LOCAL_DATE);
				setState(1581);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,163,_ctx) ) {
				case 1:
					{
					setState(1579);
					match(T__1);
					setState(1580);
					match(T__2);
					}
					break;
				}
				}
				break;
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1583);
				match(LOCAL);
				setState(1584);
				match(DATE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalTimeFunctionContext extends ParserRuleContext {
		public TerminalNode LOCAL_TIME() { return getToken(HqlParser.LOCAL_TIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public LocalTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalTimeFunctionContext localTimeFunction() throws RecognitionException {
		LocalTimeFunctionContext _localctx = new LocalTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 302, RULE_localTimeFunction);
		try {
			setState(1594);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOCAL_TIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1587);
				match(LOCAL_TIME);
				setState(1590);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,165,_ctx) ) {
				case 1:
					{
					setState(1588);
					match(T__1);
					setState(1589);
					match(T__2);
					}
					break;
				}
				}
				break;
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1592);
				match(LOCAL);
				setState(1593);
				match(TIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormatFunctionContext extends ParserRuleContext {
		public TerminalNode FORMAT() { return getToken(HqlParser.FORMAT, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public FormatContext format() {
			return getRuleContext(FormatContext.class,0);
		}
		public FormatFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formatFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFormatFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFormatFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFormatFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormatFunctionContext formatFunction() throws RecognitionException {
		FormatFunctionContext _localctx = new FormatFunctionContext(_ctx, getState());
		enterRule(_localctx, 304, RULE_formatFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1596);
			match(FORMAT);
			setState(1597);
			match(T__1);
			setState(1598);
			expression(0);
			setState(1599);
			match(AS);
			setState(1600);
			format();
			setState(1601);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollationContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public CollationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollationContext collation() throws RecognitionException {
		CollationContext _localctx = new CollationContext(_ctx, getState());
		enterRule(_localctx, 306, RULE_collation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1603);
			simplePath();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollateFunctionContext extends ParserRuleContext {
		public TerminalNode COLLATE() { return getToken(HqlParser.COLLATE, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CollationContext collation() {
			return getRuleContext(CollationContext.class,0);
		}
		public CollateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollateFunctionContext collateFunction() throws RecognitionException {
		CollateFunctionContext _localctx = new CollateFunctionContext(_ctx, getState());
		enterRule(_localctx, 308, RULE_collateFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1605);
			match(COLLATE);
			setState(1606);
			match(T__1);
			setState(1607);
			expression(0);
			setState(1608);
			match(AS);
			setState(1609);
			collation();
			setState(1610);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CubeContext extends ParserRuleContext {
		public TerminalNode CUBE() { return getToken(HqlParser.CUBE, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public CubeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cube; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCube(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCube(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCube(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CubeContext cube() throws RecognitionException {
		CubeContext _localctx = new CubeContext(_ctx, getState());
		enterRule(_localctx, 310, RULE_cube);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1612);
			match(CUBE);
			setState(1613);
			match(T__1);
			setState(1614);
			expressionOrPredicate();
			setState(1619);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1615);
				match(T__0);
				setState(1616);
				expressionOrPredicate();
				}
				}
				setState(1621);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1622);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RollupContext extends ParserRuleContext {
		public TerminalNode ROLLUP() { return getToken(HqlParser.ROLLUP, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public RollupContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rollup; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRollup(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRollup(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRollup(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RollupContext rollup() throws RecognitionException {
		RollupContext _localctx = new RollupContext(_ctx, getState());
		enterRule(_localctx, 312, RULE_rollup);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1624);
			match(ROLLUP);
			setState(1625);
			match(T__1);
			setState(1626);
			expressionOrPredicate();
			setState(1631);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1627);
				match(T__0);
				setState(1628);
				expressionOrPredicate();
				}
				}
				setState(1633);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1634);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormatContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public FormatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_format; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFormat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFormat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFormat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormatContext format() throws RecognitionException {
		FormatContext _localctx = new FormatContext(_ctx, getState());
		enterRule(_localctx, 314, RULE_format);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1636);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExtractFunctionContext extends ParserRuleContext {
		public TerminalNode EXTRACT() { return getToken(HqlParser.EXTRACT, 0); }
		public ExtractFieldContext extractField() {
			return getRuleContext(ExtractFieldContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public ExtractFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extractFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExtractFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExtractFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExtractFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExtractFunctionContext extractFunction() throws RecognitionException {
		ExtractFunctionContext _localctx = new ExtractFunctionContext(_ctx, getState());
		enterRule(_localctx, 316, RULE_extractFunction);
		try {
			setState(1650);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXTRACT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1638);
				match(EXTRACT);
				setState(1639);
				match(T__1);
				setState(1640);
				extractField();
				setState(1641);
				match(FROM);
				setState(1642);
				expression(0);
				setState(1643);
				match(T__2);
				}
				break;
			case DAY:
			case EPOCH:
			case HOUR:
			case MINUTE:
			case MONTH:
			case NANOSECOND:
			case QUARTER:
			case SECOND:
			case WEEK:
			case YEAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(1645);
				datetimeField();
				setState(1646);
				match(T__1);
				setState(1647);
				expression(0);
				setState(1648);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TruncFunctionContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode TRUNC() { return getToken(HqlParser.TRUNC, 0); }
		public TerminalNode TRUNCATE() { return getToken(HqlParser.TRUNCATE, 0); }
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public TruncFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_truncFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTruncFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTruncFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTruncFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TruncFunctionContext truncFunction() throws RecognitionException {
		TruncFunctionContext _localctx = new TruncFunctionContext(_ctx, getState());
		enterRule(_localctx, 318, RULE_truncFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1652);
			_la = _input.LA(1);
			if ( !(_la==TRUNC || _la==TRUNCATE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1653);
			match(T__1);
			setState(1654);
			expression(0);
			setState(1660);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(1655);
				match(T__0);
				setState(1658);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,170,_ctx) ) {
				case 1:
					{
					setState(1656);
					datetimeField();
					}
					break;
				case 2:
					{
					setState(1657);
					expression(0);
					}
					break;
				}
				}
			}

			setState(1662);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaNonstandardFunctionContext extends ParserRuleContext {
		public TerminalNode FUNCTION() { return getToken(HqlParser.FUNCTION, 0); }
		public JpaNonstandardFunctionNameContext jpaNonstandardFunctionName() {
			return getRuleContext(JpaNonstandardFunctionNameContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public GenericFunctionArgumentsContext genericFunctionArguments() {
			return getRuleContext(GenericFunctionArgumentsContext.class,0);
		}
		public JpaNonstandardFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaNonstandardFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaNonstandardFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaNonstandardFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaNonstandardFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaNonstandardFunctionContext jpaNonstandardFunction() throws RecognitionException {
		JpaNonstandardFunctionContext _localctx = new JpaNonstandardFunctionContext(_ctx, getState());
		enterRule(_localctx, 320, RULE_jpaNonstandardFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1664);
			match(FUNCTION);
			setState(1665);
			match(T__1);
			setState(1666);
			jpaNonstandardFunctionName();
			setState(1669);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1667);
				match(AS);
				setState(1668);
				castTarget();
				}
			}

			setState(1673);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(1671);
				match(T__0);
				setState(1672);
				genericFunctionArguments();
				}
			}

			setState(1675);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaNonstandardFunctionNameContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public JpaNonstandardFunctionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaNonstandardFunctionName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaNonstandardFunctionName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaNonstandardFunctionName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaNonstandardFunctionName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaNonstandardFunctionNameContext jpaNonstandardFunctionName() throws RecognitionException {
		JpaNonstandardFunctionNameContext _localctx = new JpaNonstandardFunctionNameContext(_ctx, getState());
		enterRule(_localctx, 322, RULE_jpaNonstandardFunctionName);
		try {
			setState(1679);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING_LITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1677);
				match(STRING_LITERAL);
				}
				break;
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ALL:
			case AND:
			case ANY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FULL:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INNER:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LEFT:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NANOSECOND:
			case NEW:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case OTHERS:
			case OUTER:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PARTITION:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNION:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case YEAR:
			case ZONED:
			case IDENTIFIER:
			case QUOTED_IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(1678);
				identifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColumnFunctionContext extends ParserRuleContext {
		public TerminalNode COLUMN() { return getToken(HqlParser.COLUMN, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public JpaNonstandardFunctionNameContext jpaNonstandardFunctionName() {
			return getRuleContext(JpaNonstandardFunctionNameContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public ColumnFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_columnFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterColumnFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitColumnFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitColumnFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ColumnFunctionContext columnFunction() throws RecognitionException {
		ColumnFunctionContext _localctx = new ColumnFunctionContext(_ctx, getState());
		enterRule(_localctx, 324, RULE_columnFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1681);
			match(COLUMN);
			setState(1682);
			match(T__1);
			setState(1683);
			path();
			setState(1684);
			match(T__12);
			setState(1685);
			jpaNonstandardFunctionName();
			setState(1688);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1686);
				match(AS);
				setState(1687);
				castTarget();
				}
			}

			setState(1690);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionContext extends ParserRuleContext {
		public GenericFunctionNameContext genericFunctionName() {
			return getRuleContext(GenericFunctionNameContext.class,0);
		}
		public GenericFunctionArgumentsContext genericFunctionArguments() {
			return getRuleContext(GenericFunctionArgumentsContext.class,0);
		}
		public TerminalNode ASTERISK() { return getToken(HqlParser.ASTERISK, 0); }
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public NthSideClauseContext nthSideClause() {
			return getRuleContext(NthSideClauseContext.class,0);
		}
		public NullsClauseContext nullsClause() {
			return getRuleContext(NullsClauseContext.class,0);
		}
		public WithinGroupClauseContext withinGroupClause() {
			return getRuleContext(WithinGroupClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public GenericFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericFunctionContext genericFunction() throws RecognitionException {
		GenericFunctionContext _localctx = new GenericFunctionContext(_ctx, getState());
		enterRule(_localctx, 326, RULE_genericFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1692);
			genericFunctionName();
			setState(1693);
			match(T__1);
			setState(1696);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
			case T__6:
			case T__8:
			case T__10:
			case T__20:
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ALL:
			case AND:
			case ANY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FULL:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INNER:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LEFT:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NANOSECOND:
			case NEW:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case OTHERS:
			case OUTER:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PARTITION:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNION:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case YEAR:
			case ZONED:
			case NULL:
			case TRUE:
			case FALSE:
			case STRING_LITERAL:
			case JAVA_STRING_LITERAL:
			case INTEGER_LITERAL:
			case LONG_LITERAL:
			case FLOAT_LITERAL:
			case DOUBLE_LITERAL:
			case BIG_INTEGER_LITERAL:
			case BIG_DECIMAL_LITERAL:
			case HEX_LITERAL:
			case BINARY_LITERAL:
			case TIMESTAMP_ESCAPE_START:
			case DATE_ESCAPE_START:
			case TIME_ESCAPE_START:
			case PLUS:
			case MINUS:
			case IDENTIFIER:
			case QUOTED_IDENTIFIER:
				{
				setState(1694);
				genericFunctionArguments();
				}
				break;
			case ASTERISK:
				{
				setState(1695);
				match(ASTERISK);
				}
				break;
			case T__2:
				break;
			default:
				break;
			}
			setState(1698);
			match(T__2);
			setState(1700);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,177,_ctx) ) {
			case 1:
				{
				setState(1699);
				pathContinuation();
				}
				break;
			}
			setState(1703);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,178,_ctx) ) {
			case 1:
				{
				setState(1702);
				nthSideClause();
				}
				break;
			}
			setState(1706);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,179,_ctx) ) {
			case 1:
				{
				setState(1705);
				nullsClause();
				}
				break;
			}
			setState(1709);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,180,_ctx) ) {
			case 1:
				{
				setState(1708);
				withinGroupClause();
				}
				break;
			}
			setState(1712);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,181,_ctx) ) {
			case 1:
				{
				setState(1711);
				filterClause();
				}
				break;
			}
			setState(1715);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,182,_ctx) ) {
			case 1:
				{
				setState(1714);
				overClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionNameContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public GenericFunctionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericFunctionName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunctionName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunctionName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunctionName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericFunctionNameContext genericFunctionName() throws RecognitionException {
		GenericFunctionNameContext _localctx = new GenericFunctionNameContext(_ctx, getState());
		enterRule(_localctx, 328, RULE_genericFunctionName);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1717);
			simplePath();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionArgumentsContext extends ParserRuleContext {
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public GenericFunctionArgumentsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericFunctionArguments; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunctionArguments(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunctionArguments(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunctionArguments(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericFunctionArgumentsContext genericFunctionArguments() throws RecognitionException {
		GenericFunctionArgumentsContext _localctx = new GenericFunctionArgumentsContext(_ctx, getState());
		enterRule(_localctx, 330, RULE_genericFunctionArguments);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1723);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,183,_ctx) ) {
			case 1:
				{
				setState(1719);
				match(DISTINCT);
				}
				break;
			case 2:
				{
				setState(1720);
				datetimeField();
				setState(1721);
				match(T__0);
				}
				break;
			}
			setState(1725);
			expressionOrPredicate();
			setState(1730);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1726);
				match(T__0);
				setState(1727);
				expressionOrPredicate();
				}
				}
				setState(1732);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionSizeFunctionContext extends ParserRuleContext {
		public TerminalNode SIZE() { return getToken(HqlParser.SIZE, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public CollectionSizeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionSizeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionSizeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionSizeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionSizeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionSizeFunctionContext collectionSizeFunction() throws RecognitionException {
		CollectionSizeFunctionContext _localctx = new CollectionSizeFunctionContext(_ctx, getState());
		enterRule(_localctx, 332, RULE_collectionSizeFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1733);
			match(SIZE);
			setState(1734);
			match(T__1);
			setState(1735);
			path();
			setState(1736);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionAggregateFunctionContext extends ParserRuleContext {
		public CollectionAggregateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionAggregateFunction; }
	 
		public CollectionAggregateFunctionContext() { }
		public void copyFrom(CollectionAggregateFunctionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IndexAggregateFunctionContext extends CollectionAggregateFunctionContext {
		public IndicesKeysQuantifierContext indicesKeysQuantifier() {
			return getRuleContext(IndicesKeysQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode MAX() { return getToken(HqlParser.MAX, 0); }
		public TerminalNode MIN() { return getToken(HqlParser.MIN, 0); }
		public TerminalNode SUM() { return getToken(HqlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(HqlParser.AVG, 0); }
		public TerminalNode MAXINDEX() { return getToken(HqlParser.MAXINDEX, 0); }
		public TerminalNode MININDEX() { return getToken(HqlParser.MININDEX, 0); }
		public IndexAggregateFunctionContext(CollectionAggregateFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndexAggregateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndexAggregateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndexAggregateFunction(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ElementAggregateFunctionContext extends CollectionAggregateFunctionContext {
		public ElementsValuesQuantifierContext elementsValuesQuantifier() {
			return getRuleContext(ElementsValuesQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode MAX() { return getToken(HqlParser.MAX, 0); }
		public TerminalNode MIN() { return getToken(HqlParser.MIN, 0); }
		public TerminalNode SUM() { return getToken(HqlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(HqlParser.AVG, 0); }
		public TerminalNode MAXELEMENT() { return getToken(HqlParser.MAXELEMENT, 0); }
		public TerminalNode MINELEMENT() { return getToken(HqlParser.MINELEMENT, 0); }
		public ElementAggregateFunctionContext(CollectionAggregateFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterElementAggregateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitElementAggregateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitElementAggregateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionAggregateFunctionContext collectionAggregateFunction() throws RecognitionException {
		CollectionAggregateFunctionContext _localctx = new CollectionAggregateFunctionContext(_ctx, getState());
		enterRule(_localctx, 334, RULE_collectionAggregateFunction);
		int _la;
		try {
			setState(1764);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,185,_ctx) ) {
			case 1:
				_localctx = new ElementAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1738);
				_la = _input.LA(1);
				if ( !(_la==AVG || ((((_la - 122)) & ~0x3f) == 0 && ((1L << (_la - 122)) & 2251799813685313L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1739);
				match(T__1);
				setState(1740);
				elementsValuesQuantifier();
				setState(1741);
				match(T__1);
				setState(1742);
				path();
				setState(1743);
				match(T__2);
				setState(1744);
				match(T__2);
				}
				break;
			case 2:
				_localctx = new IndexAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1746);
				_la = _input.LA(1);
				if ( !(_la==AVG || ((((_la - 122)) & ~0x3f) == 0 && ((1L << (_la - 122)) & 2251799813685313L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1747);
				match(T__1);
				setState(1748);
				indicesKeysQuantifier();
				setState(1749);
				match(T__1);
				setState(1750);
				path();
				setState(1751);
				match(T__2);
				setState(1752);
				match(T__2);
				}
				break;
			case 3:
				_localctx = new ElementAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1754);
				_la = _input.LA(1);
				if ( !(_la==MAXELEMENT || _la==MINELEMENT) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1755);
				match(T__1);
				setState(1756);
				path();
				setState(1757);
				match(T__2);
				}
				break;
			case 4:
				_localctx = new IndexAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1759);
				_la = _input.LA(1);
				if ( !(_la==MAXINDEX || _la==MININDEX) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1760);
				match(T__1);
				setState(1761);
				path();
				setState(1762);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionFunctionMisuseContext extends ParserRuleContext {
		public ElementsValuesQuantifierContext elementsValuesQuantifier() {
			return getRuleContext(ElementsValuesQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public IndicesKeysQuantifierContext indicesKeysQuantifier() {
			return getRuleContext(IndicesKeysQuantifierContext.class,0);
		}
		public CollectionFunctionMisuseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionFunctionMisuse; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionFunctionMisuse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionFunctionMisuse(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionFunctionMisuse(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionFunctionMisuseContext collectionFunctionMisuse() throws RecognitionException {
		CollectionFunctionMisuseContext _localctx = new CollectionFunctionMisuseContext(_ctx, getState());
		enterRule(_localctx, 336, RULE_collectionFunctionMisuse);
		try {
			setState(1776);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ELEMENTS:
			case VALUES:
				enterOuterAlt(_localctx, 1);
				{
				setState(1766);
				elementsValuesQuantifier();
				setState(1767);
				match(T__1);
				setState(1768);
				path();
				setState(1769);
				match(T__2);
				}
				break;
			case INDICES:
			case KEYS:
				enterOuterAlt(_localctx, 2);
				{
				setState(1771);
				indicesKeysQuantifier();
				setState(1772);
				match(T__1);
				setState(1773);
				path();
				setState(1774);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggregateFunctionContext extends ParserRuleContext {
		public EveryFunctionContext everyFunction() {
			return getRuleContext(EveryFunctionContext.class,0);
		}
		public AnyFunctionContext anyFunction() {
			return getRuleContext(AnyFunctionContext.class,0);
		}
		public ListaggFunctionContext listaggFunction() {
			return getRuleContext(ListaggFunctionContext.class,0);
		}
		public AggregateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggregateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAggregateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAggregateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAggregateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggregateFunctionContext aggregateFunction() throws RecognitionException {
		AggregateFunctionContext _localctx = new AggregateFunctionContext(_ctx, getState());
		enterRule(_localctx, 338, RULE_aggregateFunction);
		try {
			setState(1781);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ALL:
			case EVERY:
				enterOuterAlt(_localctx, 1);
				{
				setState(1778);
				everyFunction();
				}
				break;
			case ANY:
			case SOME:
				enterOuterAlt(_localctx, 2);
				{
				setState(1779);
				anyFunction();
				}
				break;
			case LISTAGG:
				enterOuterAlt(_localctx, 3);
				{
				setState(1780);
				listaggFunction();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EveryFunctionContext extends ParserRuleContext {
		public EveryAllQuantifierContext everyAllQuantifier() {
			return getRuleContext(EveryAllQuantifierContext.class,0);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public CollectionQuantifierContext collectionQuantifier() {
			return getRuleContext(CollectionQuantifierContext.class,0);
		}
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public EveryFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_everyFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEveryFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEveryFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEveryFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EveryFunctionContext everyFunction() throws RecognitionException {
		EveryFunctionContext _localctx = new EveryFunctionContext(_ctx, getState());
		enterRule(_localctx, 340, RULE_everyFunction);
		try {
			setState(1804);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,190,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1783);
				everyAllQuantifier();
				setState(1784);
				match(T__1);
				setState(1785);
				predicate(0);
				setState(1786);
				match(T__2);
				setState(1788);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,188,_ctx) ) {
				case 1:
					{
					setState(1787);
					filterClause();
					}
					break;
				}
				setState(1791);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,189,_ctx) ) {
				case 1:
					{
					setState(1790);
					overClause();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1793);
				everyAllQuantifier();
				setState(1794);
				match(T__1);
				setState(1795);
				subquery();
				setState(1796);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1798);
				everyAllQuantifier();
				setState(1799);
				collectionQuantifier();
				setState(1800);
				match(T__1);
				setState(1801);
				simplePath();
				setState(1802);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnyFunctionContext extends ParserRuleContext {
		public AnySomeQuantifierContext anySomeQuantifier() {
			return getRuleContext(AnySomeQuantifierContext.class,0);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public CollectionQuantifierContext collectionQuantifier() {
			return getRuleContext(CollectionQuantifierContext.class,0);
		}
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public AnyFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anyFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAnyFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAnyFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAnyFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnyFunctionContext anyFunction() throws RecognitionException {
		AnyFunctionContext _localctx = new AnyFunctionContext(_ctx, getState());
		enterRule(_localctx, 342, RULE_anyFunction);
		try {
			setState(1827);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,193,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1806);
				anySomeQuantifier();
				setState(1807);
				match(T__1);
				setState(1808);
				predicate(0);
				setState(1809);
				match(T__2);
				setState(1811);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,191,_ctx) ) {
				case 1:
					{
					setState(1810);
					filterClause();
					}
					break;
				}
				setState(1814);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,192,_ctx) ) {
				case 1:
					{
					setState(1813);
					overClause();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1816);
				anySomeQuantifier();
				setState(1817);
				match(T__1);
				setState(1818);
				subquery();
				setState(1819);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1821);
				anySomeQuantifier();
				setState(1822);
				collectionQuantifier();
				setState(1823);
				match(T__1);
				setState(1824);
				simplePath();
				setState(1825);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EveryAllQuantifierContext extends ParserRuleContext {
		public TerminalNode EVERY() { return getToken(HqlParser.EVERY, 0); }
		public TerminalNode ALL() { return getToken(HqlParser.ALL, 0); }
		public EveryAllQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_everyAllQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEveryAllQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEveryAllQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEveryAllQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EveryAllQuantifierContext everyAllQuantifier() throws RecognitionException {
		EveryAllQuantifierContext _localctx = new EveryAllQuantifierContext(_ctx, getState());
		enterRule(_localctx, 344, RULE_everyAllQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1829);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==EVERY) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnySomeQuantifierContext extends ParserRuleContext {
		public TerminalNode ANY() { return getToken(HqlParser.ANY, 0); }
		public TerminalNode SOME() { return getToken(HqlParser.SOME, 0); }
		public AnySomeQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anySomeQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAnySomeQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAnySomeQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAnySomeQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnySomeQuantifierContext anySomeQuantifier() throws RecognitionException {
		AnySomeQuantifierContext _localctx = new AnySomeQuantifierContext(_ctx, getState());
		enterRule(_localctx, 346, RULE_anySomeQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1831);
			_la = _input.LA(1);
			if ( !(_la==ANY || _la==SOME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ListaggFunctionContext extends ParserRuleContext {
		public TerminalNode LISTAGG() { return getToken(HqlParser.LISTAGG, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public OnOverflowClauseContext onOverflowClause() {
			return getRuleContext(OnOverflowClauseContext.class,0);
		}
		public WithinGroupClauseContext withinGroupClause() {
			return getRuleContext(WithinGroupClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public ListaggFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_listaggFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterListaggFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitListaggFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitListaggFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ListaggFunctionContext listaggFunction() throws RecognitionException {
		ListaggFunctionContext _localctx = new ListaggFunctionContext(_ctx, getState());
		enterRule(_localctx, 348, RULE_listaggFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1833);
			match(LISTAGG);
			setState(1834);
			match(T__1);
			setState(1836);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,194,_ctx) ) {
			case 1:
				{
				setState(1835);
				match(DISTINCT);
				}
				break;
			}
			setState(1838);
			expressionOrPredicate();
			setState(1839);
			match(T__0);
			setState(1840);
			expressionOrPredicate();
			setState(1842);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(1841);
				onOverflowClause();
				}
			}

			setState(1844);
			match(T__2);
			setState(1846);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,196,_ctx) ) {
			case 1:
				{
				setState(1845);
				withinGroupClause();
				}
				break;
			}
			setState(1849);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,197,_ctx) ) {
			case 1:
				{
				setState(1848);
				filterClause();
				}
				break;
			}
			setState(1852);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,198,_ctx) ) {
			case 1:
				{
				setState(1851);
				overClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OnOverflowClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode OVERFLOW() { return getToken(HqlParser.OVERFLOW, 0); }
		public TerminalNode ERROR() { return getToken(HqlParser.ERROR, 0); }
		public TerminalNode TRUNCATE() { return getToken(HqlParser.TRUNCATE, 0); }
		public TerminalNode COUNT() { return getToken(HqlParser.COUNT, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode WITHOUT() { return getToken(HqlParser.WITHOUT, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OnOverflowClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_onOverflowClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOnOverflowClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOnOverflowClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOnOverflowClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OnOverflowClauseContext onOverflowClause() throws RecognitionException {
		OnOverflowClauseContext _localctx = new OnOverflowClauseContext(_ctx, getState());
		enterRule(_localctx, 350, RULE_onOverflowClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1854);
			match(ON);
			setState(1855);
			match(OVERFLOW);
			setState(1863);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ERROR:
				{
				setState(1856);
				match(ERROR);
				}
				break;
			case TRUNCATE:
				{
				setState(1857);
				match(TRUNCATE);
				setState(1859);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,199,_ctx) ) {
				case 1:
					{
					setState(1858);
					expression(0);
					}
					break;
				}
				setState(1861);
				_la = _input.LA(1);
				if ( !(_la==WITH || _la==WITHOUT) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1862);
				match(COUNT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WithinGroupClauseContext extends ParserRuleContext {
		public TerminalNode WITHIN() { return getToken(HqlParser.WITHIN, 0); }
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public WithinGroupClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_withinGroupClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWithinGroupClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWithinGroupClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWithinGroupClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WithinGroupClauseContext withinGroupClause() throws RecognitionException {
		WithinGroupClauseContext _localctx = new WithinGroupClauseContext(_ctx, getState());
		enterRule(_localctx, 352, RULE_withinGroupClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1865);
			match(WITHIN);
			setState(1866);
			match(GROUP);
			setState(1867);
			match(T__1);
			setState(1868);
			orderByClause();
			setState(1869);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FilterClauseContext extends ParserRuleContext {
		public TerminalNode FILTER() { return getToken(HqlParser.FILTER, 0); }
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public FilterClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_filterClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFilterClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFilterClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFilterClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FilterClauseContext filterClause() throws RecognitionException {
		FilterClauseContext _localctx = new FilterClauseContext(_ctx, getState());
		enterRule(_localctx, 354, RULE_filterClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1871);
			match(FILTER);
			setState(1872);
			match(T__1);
			setState(1873);
			whereClause();
			setState(1874);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NullsClauseContext extends ParserRuleContext {
		public TerminalNode RESPECT() { return getToken(HqlParser.RESPECT, 0); }
		public TerminalNode NULLS() { return getToken(HqlParser.NULLS, 0); }
		public TerminalNode IGNORE() { return getToken(HqlParser.IGNORE, 0); }
		public NullsClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullsClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNullsClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNullsClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNullsClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NullsClauseContext nullsClause() throws RecognitionException {
		NullsClauseContext _localctx = new NullsClauseContext(_ctx, getState());
		enterRule(_localctx, 356, RULE_nullsClause);
		try {
			setState(1880);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RESPECT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1876);
				match(RESPECT);
				setState(1877);
				match(NULLS);
				}
				break;
			case IGNORE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1878);
				match(IGNORE);
				setState(1879);
				match(NULLS);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NthSideClauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(HqlParser.LAST, 0); }
		public NthSideClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nthSideClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNthSideClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNthSideClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNthSideClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NthSideClauseContext nthSideClause() throws RecognitionException {
		NthSideClauseContext _localctx = new NthSideClauseContext(_ctx, getState());
		enterRule(_localctx, 358, RULE_nthSideClause);
		try {
			setState(1886);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,202,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1882);
				match(FROM);
				setState(1883);
				match(FIRST);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1884);
				match(FROM);
				setState(1885);
				match(LAST);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverClauseContext extends ParserRuleContext {
		public TerminalNode OVER() { return getToken(HqlParser.OVER, 0); }
		public PartitionClauseContext partitionClause() {
			return getRuleContext(PartitionClauseContext.class,0);
		}
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public FrameClauseContext frameClause() {
			return getRuleContext(FrameClauseContext.class,0);
		}
		public OverClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverClauseContext overClause() throws RecognitionException {
		OverClauseContext _localctx = new OverClauseContext(_ctx, getState());
		enterRule(_localctx, 360, RULE_overClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1888);
			match(OVER);
			setState(1889);
			match(T__1);
			setState(1891);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PARTITION) {
				{
				setState(1890);
				partitionClause();
				}
			}

			setState(1894);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(1893);
				orderByClause();
				}
			}

			setState(1897);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUPS || _la==RANGE || _la==ROWS) {
				{
				setState(1896);
				frameClause();
				}
			}

			setState(1899);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PartitionClauseContext extends ParserRuleContext {
		public TerminalNode PARTITION() { return getToken(HqlParser.PARTITION, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public PartitionClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_partitionClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPartitionClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPartitionClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPartitionClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PartitionClauseContext partitionClause() throws RecognitionException {
		PartitionClauseContext _localctx = new PartitionClauseContext(_ctx, getState());
		enterRule(_localctx, 362, RULE_partitionClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1901);
			match(PARTITION);
			setState(1902);
			match(BY);
			setState(1903);
			expression(0);
			setState(1908);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1904);
				match(T__0);
				setState(1905);
				expression(0);
				}
				}
				setState(1910);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameClauseContext extends ParserRuleContext {
		public FrameStartContext frameStart() {
			return getRuleContext(FrameStartContext.class,0);
		}
		public TerminalNode RANGE() { return getToken(HqlParser.RANGE, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public TerminalNode GROUPS() { return getToken(HqlParser.GROUPS, 0); }
		public FrameExclusionContext frameExclusion() {
			return getRuleContext(FrameExclusionContext.class,0);
		}
		public TerminalNode BETWEEN() { return getToken(HqlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public FrameEndContext frameEnd() {
			return getRuleContext(FrameEndContext.class,0);
		}
		public FrameClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameClauseContext frameClause() throws RecognitionException {
		FrameClauseContext _localctx = new FrameClauseContext(_ctx, getState());
		enterRule(_localctx, 364, RULE_frameClause);
		int _la;
		try {
			setState(1924);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,209,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1911);
				_la = _input.LA(1);
				if ( !(_la==GROUPS || _la==RANGE || _la==ROWS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1912);
				frameStart();
				setState(1914);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXCLUDE) {
					{
					setState(1913);
					frameExclusion();
					}
				}

				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1916);
				_la = _input.LA(1);
				if ( !(_la==GROUPS || _la==RANGE || _la==ROWS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1917);
				match(BETWEEN);
				setState(1918);
				frameStart();
				setState(1919);
				match(AND);
				setState(1920);
				frameEnd();
				setState(1922);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXCLUDE) {
					{
					setState(1921);
					frameExclusion();
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameStartContext extends ParserRuleContext {
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode UNBOUNDED() { return getToken(HqlParser.UNBOUNDED, 0); }
		public TerminalNode PRECEDING() { return getToken(HqlParser.PRECEDING, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode FOLLOWING() { return getToken(HqlParser.FOLLOWING, 0); }
		public FrameStartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameStart; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameStartContext frameStart() throws RecognitionException {
		FrameStartContext _localctx = new FrameStartContext(_ctx, getState());
		enterRule(_localctx, 366, RULE_frameStart);
		try {
			setState(1936);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,210,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1926);
				match(CURRENT);
				setState(1927);
				match(ROW);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1928);
				match(UNBOUNDED);
				setState(1929);
				match(PRECEDING);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1930);
				expression(0);
				setState(1931);
				match(PRECEDING);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1933);
				expression(0);
				setState(1934);
				match(FOLLOWING);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameEndContext extends ParserRuleContext {
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode UNBOUNDED() { return getToken(HqlParser.UNBOUNDED, 0); }
		public TerminalNode FOLLOWING() { return getToken(HqlParser.FOLLOWING, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode PRECEDING() { return getToken(HqlParser.PRECEDING, 0); }
		public FrameEndContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameEnd; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameEnd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameEnd(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameEnd(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameEndContext frameEnd() throws RecognitionException {
		FrameEndContext _localctx = new FrameEndContext(_ctx, getState());
		enterRule(_localctx, 368, RULE_frameEnd);
		try {
			setState(1948);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,211,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1938);
				match(CURRENT);
				setState(1939);
				match(ROW);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1940);
				match(UNBOUNDED);
				setState(1941);
				match(FOLLOWING);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1942);
				expression(0);
				setState(1943);
				match(PRECEDING);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1945);
				expression(0);
				setState(1946);
				match(FOLLOWING);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameExclusionContext extends ParserRuleContext {
		public TerminalNode EXCLUDE() { return getToken(HqlParser.EXCLUDE, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public TerminalNode TIES() { return getToken(HqlParser.TIES, 0); }
		public TerminalNode NO() { return getToken(HqlParser.NO, 0); }
		public TerminalNode OTHERS() { return getToken(HqlParser.OTHERS, 0); }
		public FrameExclusionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameExclusion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameExclusion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameExclusion(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameExclusion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameExclusionContext frameExclusion() throws RecognitionException {
		FrameExclusionContext _localctx = new FrameExclusionContext(_ctx, getState());
		enterRule(_localctx, 370, RULE_frameExclusion);
		try {
			setState(1960);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,212,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1950);
				match(EXCLUDE);
				setState(1951);
				match(CURRENT);
				setState(1952);
				match(ROW);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1953);
				match(EXCLUDE);
				setState(1954);
				match(GROUP);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1955);
				match(EXCLUDE);
				setState(1956);
				match(TIES);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1957);
				match(EXCLUDE);
				setState(1958);
				match(NO);
				setState(1959);
				match(OTHERS);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PredicateContext extends ParserRuleContext {
		public PredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_predicate; }
	 
		public PredicateContext() { }
		public void copyFrom(PredicateContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IsDistinctFromPredicateContext extends PredicateContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode IS() { return getToken(HqlParser.IS, 0); }
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public IsDistinctFromPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIsDistinctFromPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIsDistinctFromPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIsDistinctFromPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ContainsPredicateContext extends PredicateContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode CONTAINS() { return getToken(HqlParser.CONTAINS, 0); }
		public TerminalNode INCLUDES() { return getToken(HqlParser.INCLUDES, 0); }
		public TerminalNode INTERSECTS() { return getToken(HqlParser.INTERSECTS, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public ContainsPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterContainsPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitContainsPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitContainsPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IsBooleanPredicateContext extends PredicateContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode IS() { return getToken(HqlParser.IS, 0); }
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public TerminalNode EMPTY() { return getToken(HqlParser.EMPTY, 0); }
		public TerminalNode TRUE() { return getToken(HqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(HqlParser.FALSE, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public IsBooleanPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIsBooleanPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIsBooleanPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIsBooleanPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BetweenPredicateContext extends PredicateContext {
		public BetweenExpressionContext betweenExpression() {
			return getRuleContext(BetweenExpressionContext.class,0);
		}
		public BetweenPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBetweenPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBetweenPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBetweenPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RelationalPredicateContext extends PredicateContext {
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public RelationalPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRelationalPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRelationalPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRelationalPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExistsPredicateContext extends PredicateContext {
		public ExistsExpressionContext existsExpression() {
			return getRuleContext(ExistsExpressionContext.class,0);
		}
		public ExistsPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExistsPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExistsPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExistsPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AndPredicateContext extends PredicateContext {
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public AndPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAndPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAndPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAndPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupedPredicateContext extends PredicateContext {
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public GroupedPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupedPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupedPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupedPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LikePredicateContext extends PredicateContext {
		public StringPatternMatchingContext stringPatternMatching() {
			return getRuleContext(StringPatternMatchingContext.class,0);
		}
		public LikePredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLikePredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLikePredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLikePredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InPredicateContext extends PredicateContext {
		public InExpressionContext inExpression() {
			return getRuleContext(InExpressionContext.class,0);
		}
		public InPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotPredicateContext extends PredicateContext {
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public NotPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNotPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNotPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNotPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionPredicateContext extends PredicateContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ExpressionPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExpressionPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExpressionPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExpressionPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OrPredicateContext extends PredicateContext {
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public TerminalNode OR() { return getToken(HqlParser.OR, 0); }
		public OrPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOrPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOrPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOrPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MemberOfPredicateContext extends PredicateContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode MEMBER() { return getToken(HqlParser.MEMBER, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public MemberOfPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMemberOfPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMemberOfPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMemberOfPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PredicateContext predicate() throws RecognitionException {
		return predicate(0);
	}

	private PredicateContext predicate(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		PredicateContext _localctx = new PredicateContext(_ctx, _parentState);
		PredicateContext _prevctx = _localctx;
		int _startState = 372;
		enterRecursionRule(_localctx, 372, RULE_predicate, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(2008);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,218,_ctx) ) {
			case 1:
				{
				_localctx = new GroupedPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(1963);
				match(T__1);
				setState(1964);
				predicate(0);
				setState(1965);
				match(T__2);
				}
				break;
			case 2:
				{
				_localctx = new IsBooleanPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1967);
				expression(0);
				setState(1968);
				match(IS);
				setState(1970);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(1969);
					match(NOT);
					}
				}

				setState(1972);
				_la = _input.LA(1);
				if ( !(_la==EMPTY || ((((_la - 201)) & ~0x3f) == 0 && ((1L << (_la - 201)) & 7L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case 3:
				{
				_localctx = new IsDistinctFromPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1974);
				expression(0);
				setState(1975);
				match(IS);
				setState(1977);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(1976);
					match(NOT);
					}
				}

				setState(1979);
				match(DISTINCT);
				setState(1980);
				match(FROM);
				setState(1981);
				expression(0);
				}
				break;
			case 4:
				{
				_localctx = new MemberOfPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1983);
				expression(0);
				setState(1985);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(1984);
					match(NOT);
					}
				}

				setState(1987);
				match(MEMBER);
				setState(1989);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,216,_ctx) ) {
				case 1:
					{
					setState(1988);
					match(OF);
					}
					break;
				}
				setState(1991);
				path();
				}
				break;
			case 5:
				{
				_localctx = new InPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1993);
				inExpression();
				}
				break;
			case 6:
				{
				_localctx = new BetweenPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1994);
				betweenExpression();
				}
				break;
			case 7:
				{
				_localctx = new ContainsPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1995);
				expression(0);
				setState(1997);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(1996);
					match(NOT);
					}
				}

				setState(1999);
				_la = _input.LA(1);
				if ( !(((((_la - 46)) & ~0x3f) == 0 && ((1L << (_la - 46)) & 72620543991349249L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2000);
				expression(0);
				}
				break;
			case 8:
				{
				_localctx = new RelationalPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2002);
				relationalExpression();
				}
				break;
			case 9:
				{
				_localctx = new LikePredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2003);
				stringPatternMatching();
				}
				break;
			case 10:
				{
				_localctx = new ExistsPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2004);
				existsExpression();
				}
				break;
			case 11:
				{
				_localctx = new NotPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2005);
				match(NOT);
				setState(2006);
				predicate(4);
				}
				break;
			case 12:
				{
				_localctx = new ExpressionPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2007);
				expression(0);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(2018);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,220,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(2016);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,219,_ctx) ) {
					case 1:
						{
						_localctx = new AndPredicateContext(new PredicateContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_predicate);
						setState(2010);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(2011);
						match(AND);
						setState(2012);
						predicate(4);
						}
						break;
					case 2:
						{
						_localctx = new OrPredicateContext(new PredicateContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_predicate);
						setState(2013);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(2014);
						match(OR);
						setState(2015);
						predicate(3);
						}
						break;
					}
					} 
				}
				setState(2020);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,220,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionOrPredicateContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public ExpressionOrPredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionOrPredicate; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExpressionOrPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExpressionOrPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExpressionOrPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionOrPredicateContext expressionOrPredicate() throws RecognitionException {
		ExpressionOrPredicateContext _localctx = new ExpressionOrPredicateContext(_ctx, getState());
		enterRule(_localctx, 374, RULE_expressionOrPredicate);
		try {
			setState(2023);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,221,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2021);
				expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2022);
				predicate(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionQuantifierContext extends ParserRuleContext {
		public ElementsValuesQuantifierContext elementsValuesQuantifier() {
			return getRuleContext(ElementsValuesQuantifierContext.class,0);
		}
		public IndicesKeysQuantifierContext indicesKeysQuantifier() {
			return getRuleContext(IndicesKeysQuantifierContext.class,0);
		}
		public CollectionQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionQuantifierContext collectionQuantifier() throws RecognitionException {
		CollectionQuantifierContext _localctx = new CollectionQuantifierContext(_ctx, getState());
		enterRule(_localctx, 376, RULE_collectionQuantifier);
		try {
			setState(2027);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ELEMENTS:
			case VALUES:
				enterOuterAlt(_localctx, 1);
				{
				setState(2025);
				elementsValuesQuantifier();
				}
				break;
			case INDICES:
			case KEYS:
				enterOuterAlt(_localctx, 2);
				{
				setState(2026);
				indicesKeysQuantifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElementsValuesQuantifierContext extends ParserRuleContext {
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode VALUES() { return getToken(HqlParser.VALUES, 0); }
		public ElementsValuesQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elementsValuesQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterElementsValuesQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitElementsValuesQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitElementsValuesQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementsValuesQuantifierContext elementsValuesQuantifier() throws RecognitionException {
		ElementsValuesQuantifierContext _localctx = new ElementsValuesQuantifierContext(_ctx, getState());
		enterRule(_localctx, 378, RULE_elementsValuesQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2029);
			_la = _input.LA(1);
			if ( !(_la==ELEMENTS || _la==VALUES) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElementValueQuantifierContext extends ParserRuleContext {
		public TerminalNode ELEMENT() { return getToken(HqlParser.ELEMENT, 0); }
		public TerminalNode VALUE() { return getToken(HqlParser.VALUE, 0); }
		public ElementValueQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elementValueQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterElementValueQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitElementValueQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitElementValueQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementValueQuantifierContext elementValueQuantifier() throws RecognitionException {
		ElementValueQuantifierContext _localctx = new ElementValueQuantifierContext(_ctx, getState());
		enterRule(_localctx, 380, RULE_elementValueQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2031);
			_la = _input.LA(1);
			if ( !(_la==ELEMENT || _la==VALUE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IndexKeyQuantifierContext extends ParserRuleContext {
		public TerminalNode INDEX() { return getToken(HqlParser.INDEX, 0); }
		public TerminalNode KEY() { return getToken(HqlParser.KEY, 0); }
		public IndexKeyQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_indexKeyQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndexKeyQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndexKeyQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndexKeyQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IndexKeyQuantifierContext indexKeyQuantifier() throws RecognitionException {
		IndexKeyQuantifierContext _localctx = new IndexKeyQuantifierContext(_ctx, getState());
		enterRule(_localctx, 382, RULE_indexKeyQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2033);
			_la = _input.LA(1);
			if ( !(_la==INDEX || _la==KEY) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IndicesKeysQuantifierContext extends ParserRuleContext {
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public TerminalNode KEYS() { return getToken(HqlParser.KEYS, 0); }
		public IndicesKeysQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_indicesKeysQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndicesKeysQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndicesKeysQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndicesKeysQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IndicesKeysQuantifierContext indicesKeysQuantifier() throws RecognitionException {
		IndicesKeysQuantifierContext _localctx = new IndicesKeysQuantifierContext(_ctx, getState());
		enterRule(_localctx, 384, RULE_indicesKeysQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2035);
			_la = _input.LA(1);
			if ( !(_la==INDICES || _la==KEYS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RelationalExpressionContext extends ParserRuleContext {
		public Token op;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public RelationalExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relationalExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRelationalExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRelationalExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRelationalExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RelationalExpressionContext relationalExpression() throws RecognitionException {
		RelationalExpressionContext _localctx = new RelationalExpressionContext(_ctx, getState());
		enterRule(_localctx, 386, RULE_relationalExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2037);
			expression(0);
			setState(2038);
			((RelationalExpressionContext)_localctx).op = _input.LT(1);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 2080784L) != 0)) ) {
				((RelationalExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2039);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BetweenExpressionContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode BETWEEN() { return getToken(HqlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public BetweenExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_betweenExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBetweenExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBetweenExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBetweenExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BetweenExpressionContext betweenExpression() throws RecognitionException {
		BetweenExpressionContext _localctx = new BetweenExpressionContext(_ctx, getState());
		enterRule(_localctx, 388, RULE_betweenExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2041);
			expression(0);
			setState(2043);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(2042);
				match(NOT);
				}
			}

			setState(2045);
			match(BETWEEN);
			setState(2046);
			expression(0);
			setState(2047);
			match(AND);
			setState(2048);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StringPatternMatchingContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode LIKE() { return getToken(HqlParser.LIKE, 0); }
		public TerminalNode ILIKE() { return getToken(HqlParser.ILIKE, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public TerminalNode ESCAPE() { return getToken(HqlParser.ESCAPE, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public TerminalNode JAVA_STRING_LITERAL() { return getToken(HqlParser.JAVA_STRING_LITERAL, 0); }
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public StringPatternMatchingContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringPatternMatching; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStringPatternMatching(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStringPatternMatching(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStringPatternMatching(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringPatternMatchingContext stringPatternMatching() throws RecognitionException {
		StringPatternMatchingContext _localctx = new StringPatternMatchingContext(_ctx, getState());
		enterRule(_localctx, 390, RULE_stringPatternMatching);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2050);
			expression(0);
			setState(2052);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(2051);
				match(NOT);
				}
			}

			setState(2054);
			_la = _input.LA(1);
			if ( !(_la==ILIKE || _la==LIKE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2055);
			expression(0);
			setState(2062);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,226,_ctx) ) {
			case 1:
				{
				setState(2056);
				match(ESCAPE);
				setState(2060);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case STRING_LITERAL:
					{
					setState(2057);
					match(STRING_LITERAL);
					}
					break;
				case JAVA_STRING_LITERAL:
					{
					setState(2058);
					match(JAVA_STRING_LITERAL);
					}
					break;
				case T__8:
				case T__20:
					{
					setState(2059);
					parameter();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InExpressionContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public InListContext inList() {
			return getRuleContext(InListContext.class,0);
		}
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public InExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InExpressionContext inExpression() throws RecognitionException {
		InExpressionContext _localctx = new InExpressionContext(_ctx, getState());
		enterRule(_localctx, 392, RULE_inExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2064);
			expression(0);
			setState(2066);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(2065);
				match(NOT);
				}
			}

			setState(2068);
			match(IN);
			setState(2069);
			inList();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InListContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public InListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InListContext inList() throws RecognitionException {
		InListContext _localctx = new InListContext(_ctx, getState());
		enterRule(_localctx, 394, RULE_inList);
		int _la;
		try {
			setState(2093);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,230,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2071);
				_la = _input.LA(1);
				if ( !(_la==ELEMENTS || _la==INDICES) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2072);
				match(T__1);
				setState(2073);
				simplePath();
				setState(2074);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2076);
				match(T__1);
				setState(2077);
				subquery();
				setState(2078);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2080);
				parameter();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2081);
				match(T__1);
				setState(2090);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -31454588L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -1L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 536870911L) != 0)) {
					{
					setState(2082);
					expressionOrPredicate();
					setState(2087);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__0) {
						{
						{
						setState(2083);
						match(T__0);
						setState(2084);
						expressionOrPredicate();
						}
						}
						setState(2089);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(2092);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExistsExpressionContext extends ParserRuleContext {
		public TerminalNode EXISTS() { return getToken(HqlParser.EXISTS, 0); }
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ExistsExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_existsExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExistsExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExistsExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExistsExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExistsExpressionContext existsExpression() throws RecognitionException {
		ExistsExpressionContext _localctx = new ExistsExpressionContext(_ctx, getState());
		enterRule(_localctx, 396, RULE_existsExpression);
		int _la;
		try {
			setState(2103);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,231,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2095);
				match(EXISTS);
				setState(2096);
				_la = _input.LA(1);
				if ( !(_la==ELEMENTS || _la==INDICES) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2097);
				match(T__1);
				setState(2098);
				simplePath();
				setState(2099);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2101);
				match(EXISTS);
				setState(2102);
				expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationTargetContext extends ParserRuleContext {
		public TerminalNode LIST() { return getToken(HqlParser.LIST, 0); }
		public TerminalNode MAP() { return getToken(HqlParser.MAP, 0); }
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public InstantiationTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiationTarget; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiationTarget(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiationTarget(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiationTarget(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationTargetContext instantiationTarget() throws RecognitionException {
		InstantiationTargetContext _localctx = new InstantiationTargetContext(_ctx, getState());
		enterRule(_localctx, 398, RULE_instantiationTarget);
		try {
			setState(2108);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,232,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2105);
				match(LIST);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2106);
				match(MAP);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2107);
				simplePath();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationArgumentsContext extends ParserRuleContext {
		public List<InstantiationArgumentContext> instantiationArgument() {
			return getRuleContexts(InstantiationArgumentContext.class);
		}
		public InstantiationArgumentContext instantiationArgument(int i) {
			return getRuleContext(InstantiationArgumentContext.class,i);
		}
		public InstantiationArgumentsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiationArguments; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiationArguments(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiationArguments(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiationArguments(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationArgumentsContext instantiationArguments() throws RecognitionException {
		InstantiationArgumentsContext _localctx = new InstantiationArgumentsContext(_ctx, getState());
		enterRule(_localctx, 400, RULE_instantiationArguments);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2110);
			instantiationArgument();
			setState(2115);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2111);
				match(T__0);
				setState(2112);
				instantiationArgument();
				}
				}
				setState(2117);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationArgumentContext extends ParserRuleContext {
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public InstantiationContext instantiation() {
			return getRuleContext(InstantiationContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public InstantiationArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiationArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiationArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiationArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiationArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationArgumentContext instantiationArgument() throws RecognitionException {
		InstantiationArgumentContext _localctx = new InstantiationArgumentContext(_ctx, getState());
		enterRule(_localctx, 402, RULE_instantiationArgument);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2120);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,234,_ctx) ) {
			case 1:
				{
				setState(2118);
				expressionOrPredicate();
				}
				break;
			case 2:
				{
				setState(2119);
				instantiation();
				}
				break;
			}
			setState(2123);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -33554432L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -140754672418817L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -2097153L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 402653695L) != 0)) {
				{
				setState(2122);
				variable();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterOrIntegerLiteralContext extends ParserRuleContext {
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ParameterOrIntegerLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterOrIntegerLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameterOrIntegerLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameterOrIntegerLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameterOrIntegerLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() throws RecognitionException {
		ParameterOrIntegerLiteralContext _localctx = new ParameterOrIntegerLiteralContext(_ctx, getState());
		enterRule(_localctx, 404, RULE_parameterOrIntegerLiteral);
		try {
			setState(2127);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__8:
			case T__20:
				enterOuterAlt(_localctx, 1);
				{
				setState(2125);
				parameter();
				}
				break;
			case INTEGER_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(2126);
				match(INTEGER_LITERAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterOrNumberLiteralContext extends ParserRuleContext {
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public NumericLiteralContext numericLiteral() {
			return getRuleContext(NumericLiteralContext.class,0);
		}
		public ParameterOrNumberLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterOrNumberLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameterOrNumberLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameterOrNumberLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameterOrNumberLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterOrNumberLiteralContext parameterOrNumberLiteral() throws RecognitionException {
		ParameterOrNumberLiteralContext _localctx = new ParameterOrNumberLiteralContext(_ctx, getState());
		enterRule(_localctx, 406, RULE_parameterOrNumberLiteral);
		try {
			setState(2131);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__8:
			case T__20:
				enterOuterAlt(_localctx, 1);
				{
				setState(2129);
				parameter();
				}
				break;
			case INTEGER_LITERAL:
			case LONG_LITERAL:
			case FLOAT_LITERAL:
			case DOUBLE_LITERAL:
			case BIG_INTEGER_LITERAL:
			case BIG_DECIMAL_LITERAL:
			case HEX_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(2130);
				numericLiteral();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VariableContext extends ParserRuleContext {
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public NakedIdentifierContext nakedIdentifier() {
			return getRuleContext(NakedIdentifierContext.class,0);
		}
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitVariable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 408, RULE_variable);
		try {
			setState(2136);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,238,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2133);
				match(AS);
				setState(2134);
				identifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2135);
				nakedIdentifier();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterContext extends ParserRuleContext {
		public Token prefix;
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterContext parameter() throws RecognitionException {
		ParameterContext _localctx = new ParameterContext(_ctx, getState());
		enterRule(_localctx, 410, RULE_parameter);
		try {
			setState(2144);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__8:
				enterOuterAlt(_localctx, 1);
				{
				setState(2138);
				((ParameterContext)_localctx).prefix = match(T__8);
				setState(2139);
				identifier();
				}
				break;
			case T__20:
				enterOuterAlt(_localctx, 2);
				{
				setState(2140);
				((ParameterContext)_localctx).prefix = match(T__20);
				setState(2142);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,239,_ctx) ) {
				case 1:
					{
					setState(2141);
					match(INTEGER_LITERAL);
					}
					break;
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityNameContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public EntityNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityNameContext entityName() throws RecognitionException {
		EntityNameContext _localctx = new EntityNameContext(_ctx, getState());
		enterRule(_localctx, 412, RULE_entityName);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2146);
			identifier();
			setState(2151);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__12) {
				{
				{
				setState(2147);
				match(T__12);
				setState(2148);
				identifier();
				}
				}
				setState(2153);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NakedIdentifierContext extends ParserRuleContext {
		public Token f;
		public TerminalNode IDENTIFIER() { return getToken(HqlParser.IDENTIFIER, 0); }
		public TerminalNode QUOTED_IDENTIFIER() { return getToken(HqlParser.QUOTED_IDENTIFIER, 0); }
		public TerminalNode ALL() { return getToken(HqlParser.ALL, 0); }
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public TerminalNode ANY() { return getToken(HqlParser.ANY, 0); }
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public TerminalNode ASC() { return getToken(HqlParser.ASC, 0); }
		public TerminalNode AVG() { return getToken(HqlParser.AVG, 0); }
		public TerminalNode BETWEEN() { return getToken(HqlParser.BETWEEN, 0); }
		public TerminalNode BOTH() { return getToken(HqlParser.BOTH, 0); }
		public TerminalNode BREADTH() { return getToken(HqlParser.BREADTH, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public TerminalNode CASE() { return getToken(HqlParser.CASE, 0); }
		public TerminalNode CAST() { return getToken(HqlParser.CAST, 0); }
		public TerminalNode COLLATE() { return getToken(HqlParser.COLLATE, 0); }
		public TerminalNode COLUMN() { return getToken(HqlParser.COLUMN, 0); }
		public TerminalNode CONFLICT() { return getToken(HqlParser.CONFLICT, 0); }
		public TerminalNode CONSTRAINT() { return getToken(HqlParser.CONSTRAINT, 0); }
		public TerminalNode CONTAINS() { return getToken(HqlParser.CONTAINS, 0); }
		public TerminalNode COUNT() { return getToken(HqlParser.COUNT, 0); }
		public TerminalNode CROSS() { return getToken(HqlParser.CROSS, 0); }
		public TerminalNode CUBE() { return getToken(HqlParser.CUBE, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode CURRENT_DATE() { return getToken(HqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT_INSTANT() { return getToken(HqlParser.CURRENT_INSTANT, 0); }
		public TerminalNode CURRENT_TIME() { return getToken(HqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(HqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode CYCLE() { return getToken(HqlParser.CYCLE, 0); }
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode DEFAULT() { return getToken(HqlParser.DEFAULT, 0); }
		public TerminalNode DELETE() { return getToken(HqlParser.DELETE, 0); }
		public TerminalNode DEPTH() { return getToken(HqlParser.DEPTH, 0); }
		public TerminalNode DESC() { return getToken(HqlParser.DESC, 0); }
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public TerminalNode DO() { return getToken(HqlParser.DO, 0); }
		public TerminalNode ELEMENT() { return getToken(HqlParser.ELEMENT, 0); }
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode ELSE() { return getToken(HqlParser.ELSE, 0); }
		public TerminalNode EMPTY() { return getToken(HqlParser.EMPTY, 0); }
		public TerminalNode END() { return getToken(HqlParser.END, 0); }
		public TerminalNode ENTRY() { return getToken(HqlParser.ENTRY, 0); }
		public TerminalNode EPOCH() { return getToken(HqlParser.EPOCH, 0); }
		public TerminalNode ERROR() { return getToken(HqlParser.ERROR, 0); }
		public TerminalNode ESCAPE() { return getToken(HqlParser.ESCAPE, 0); }
		public TerminalNode EVERY() { return getToken(HqlParser.EVERY, 0); }
		public TerminalNode EXCEPT() { return getToken(HqlParser.EXCEPT, 0); }
		public TerminalNode EXCLUDE() { return getToken(HqlParser.EXCLUDE, 0); }
		public TerminalNode EXISTS() { return getToken(HqlParser.EXISTS, 0); }
		public TerminalNode EXTRACT() { return getToken(HqlParser.EXTRACT, 0); }
		public TerminalNode FETCH() { return getToken(HqlParser.FETCH, 0); }
		public TerminalNode FILTER() { return getToken(HqlParser.FILTER, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode FK() { return getToken(HqlParser.FK, 0); }
		public TerminalNode FOLLOWING() { return getToken(HqlParser.FOLLOWING, 0); }
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public TerminalNode FORMAT() { return getToken(HqlParser.FORMAT, 0); }
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode FUNCTION() { return getToken(HqlParser.FUNCTION, 0); }
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public TerminalNode GROUPS() { return getToken(HqlParser.GROUPS, 0); }
		public TerminalNode HAVING() { return getToken(HqlParser.HAVING, 0); }
		public TerminalNode HOUR() { return getToken(HqlParser.HOUR, 0); }
		public TerminalNode ID() { return getToken(HqlParser.ID, 0); }
		public TerminalNode IGNORE() { return getToken(HqlParser.IGNORE, 0); }
		public TerminalNode ILIKE() { return getToken(HqlParser.ILIKE, 0); }
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public TerminalNode INDEX() { return getToken(HqlParser.INDEX, 0); }
		public TerminalNode INCLUDES() { return getToken(HqlParser.INCLUDES, 0); }
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public TerminalNode INSERT() { return getToken(HqlParser.INSERT, 0); }
		public TerminalNode INSTANT() { return getToken(HqlParser.INSTANT, 0); }
		public TerminalNode INTERSECT() { return getToken(HqlParser.INTERSECT, 0); }
		public TerminalNode INTERSECTS() { return getToken(HqlParser.INTERSECTS, 0); }
		public TerminalNode INTO() { return getToken(HqlParser.INTO, 0); }
		public TerminalNode IS() { return getToken(HqlParser.IS, 0); }
		public TerminalNode JOIN() { return getToken(HqlParser.JOIN, 0); }
		public TerminalNode KEY() { return getToken(HqlParser.KEY, 0); }
		public TerminalNode KEYS() { return getToken(HqlParser.KEYS, 0); }
		public TerminalNode LAST() { return getToken(HqlParser.LAST, 0); }
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public TerminalNode LEADING() { return getToken(HqlParser.LEADING, 0); }
		public TerminalNode LIKE() { return getToken(HqlParser.LIKE, 0); }
		public TerminalNode LIMIT() { return getToken(HqlParser.LIMIT, 0); }
		public TerminalNode LIST() { return getToken(HqlParser.LIST, 0); }
		public TerminalNode LISTAGG() { return getToken(HqlParser.LISTAGG, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode LOCAL_DATE() { return getToken(HqlParser.LOCAL_DATE, 0); }
		public TerminalNode LOCAL_DATETIME() { return getToken(HqlParser.LOCAL_DATETIME, 0); }
		public TerminalNode LOCAL_TIME() { return getToken(HqlParser.LOCAL_TIME, 0); }
		public TerminalNode MAP() { return getToken(HqlParser.MAP, 0); }
		public TerminalNode MATERIALIZED() { return getToken(HqlParser.MATERIALIZED, 0); }
		public TerminalNode MAX() { return getToken(HqlParser.MAX, 0); }
		public TerminalNode MAXELEMENT() { return getToken(HqlParser.MAXELEMENT, 0); }
		public TerminalNode MAXINDEX() { return getToken(HqlParser.MAXINDEX, 0); }
		public TerminalNode MEMBER() { return getToken(HqlParser.MEMBER, 0); }
		public TerminalNode MICROSECOND() { return getToken(HqlParser.MICROSECOND, 0); }
		public TerminalNode MILLISECOND() { return getToken(HqlParser.MILLISECOND, 0); }
		public TerminalNode MIN() { return getToken(HqlParser.MIN, 0); }
		public TerminalNode MINELEMENT() { return getToken(HqlParser.MINELEMENT, 0); }
		public TerminalNode MININDEX() { return getToken(HqlParser.MININDEX, 0); }
		public TerminalNode MINUTE() { return getToken(HqlParser.MINUTE, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode NANOSECOND() { return getToken(HqlParser.NANOSECOND, 0); }
		public TerminalNode NATURALID() { return getToken(HqlParser.NATURALID, 0); }
		public TerminalNode NEW() { return getToken(HqlParser.NEW, 0); }
		public TerminalNode NEXT() { return getToken(HqlParser.NEXT, 0); }
		public TerminalNode NO() { return getToken(HqlParser.NO, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public TerminalNode NOTHING() { return getToken(HqlParser.NOTHING, 0); }
		public TerminalNode NULLS() { return getToken(HqlParser.NULLS, 0); }
		public TerminalNode OBJECT() { return getToken(HqlParser.OBJECT, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public TerminalNode OFFSET_DATETIME() { return getToken(HqlParser.OFFSET_DATETIME, 0); }
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode ONLY() { return getToken(HqlParser.ONLY, 0); }
		public TerminalNode OR() { return getToken(HqlParser.OR, 0); }
		public TerminalNode ORDER() { return getToken(HqlParser.ORDER, 0); }
		public TerminalNode OTHERS() { return getToken(HqlParser.OTHERS, 0); }
		public TerminalNode OVER() { return getToken(HqlParser.OVER, 0); }
		public TerminalNode OVERFLOW() { return getToken(HqlParser.OVERFLOW, 0); }
		public TerminalNode OVERLAY() { return getToken(HqlParser.OVERLAY, 0); }
		public TerminalNode PAD() { return getToken(HqlParser.PAD, 0); }
		public TerminalNode PARTITION() { return getToken(HqlParser.PARTITION, 0); }
		public TerminalNode PERCENT() { return getToken(HqlParser.PERCENT, 0); }
		public TerminalNode PLACING() { return getToken(HqlParser.PLACING, 0); }
		public TerminalNode POSITION() { return getToken(HqlParser.POSITION, 0); }
		public TerminalNode PRECEDING() { return getToken(HqlParser.PRECEDING, 0); }
		public TerminalNode QUARTER() { return getToken(HqlParser.QUARTER, 0); }
		public TerminalNode RANGE() { return getToken(HqlParser.RANGE, 0); }
		public TerminalNode RESPECT() { return getToken(HqlParser.RESPECT, 0); }
		public TerminalNode RIGHT() { return getToken(HqlParser.RIGHT, 0); }
		public TerminalNode ROLLUP() { return getToken(HqlParser.ROLLUP, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public TerminalNode SEARCH() { return getToken(HqlParser.SEARCH, 0); }
		public TerminalNode SECOND() { return getToken(HqlParser.SECOND, 0); }
		public TerminalNode SELECT() { return getToken(HqlParser.SELECT, 0); }
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public TerminalNode SIZE() { return getToken(HqlParser.SIZE, 0); }
		public TerminalNode SOME() { return getToken(HqlParser.SOME, 0); }
		public TerminalNode SUBSTRING() { return getToken(HqlParser.SUBSTRING, 0); }
		public TerminalNode SUM() { return getToken(HqlParser.SUM, 0); }
		public TerminalNode THEN() { return getToken(HqlParser.THEN, 0); }
		public TerminalNode TIES() { return getToken(HqlParser.TIES, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public TerminalNode TIMESTAMP() { return getToken(HqlParser.TIMESTAMP, 0); }
		public TerminalNode TIMEZONE_HOUR() { return getToken(HqlParser.TIMEZONE_HOUR, 0); }
		public TerminalNode TIMEZONE_MINUTE() { return getToken(HqlParser.TIMEZONE_MINUTE, 0); }
		public TerminalNode TO() { return getToken(HqlParser.TO, 0); }
		public TerminalNode TRAILING() { return getToken(HqlParser.TRAILING, 0); }
		public TerminalNode TREAT() { return getToken(HqlParser.TREAT, 0); }
		public TerminalNode TRIM() { return getToken(HqlParser.TRIM, 0); }
		public TerminalNode TRUNC() { return getToken(HqlParser.TRUNC, 0); }
		public TerminalNode TRUNCATE() { return getToken(HqlParser.TRUNCATE, 0); }
		public TerminalNode TYPE() { return getToken(HqlParser.TYPE, 0); }
		public TerminalNode UNBOUNDED() { return getToken(HqlParser.UNBOUNDED, 0); }
		public TerminalNode UNION() { return getToken(HqlParser.UNION, 0); }
		public TerminalNode UPDATE() { return getToken(HqlParser.UPDATE, 0); }
		public TerminalNode USING() { return getToken(HqlParser.USING, 0); }
		public TerminalNode VALUE() { return getToken(HqlParser.VALUE, 0); }
		public TerminalNode VALUES() { return getToken(HqlParser.VALUES, 0); }
		public TerminalNode VERSION() { return getToken(HqlParser.VERSION, 0); }
		public TerminalNode VERSIONED() { return getToken(HqlParser.VERSIONED, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode WHEN() { return getToken(HqlParser.WHEN, 0); }
		public TerminalNode WHERE() { return getToken(HqlParser.WHERE, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode WITHIN() { return getToken(HqlParser.WITHIN, 0); }
		public TerminalNode WITHOUT() { return getToken(HqlParser.WITHOUT, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public TerminalNode ZONED() { return getToken(HqlParser.ZONED, 0); }
		public NakedIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nakedIdentifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNakedIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNakedIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNakedIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NakedIdentifierContext nakedIdentifier() throws RecognitionException {
		NakedIdentifierContext _localctx = new NakedIdentifierContext(_ctx, getState());
		enterRule(_localctx, 414, RULE_nakedIdentifier);
		int _la;
		try {
			setState(2157);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(2154);
				match(IDENTIFIER);
				}
				break;
			case QUOTED_IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(2155);
				match(QUOTED_IDENTIFIER);
				}
				break;
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ALL:
			case AND:
			case ANY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NANOSECOND:
			case NEW:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case OTHERS:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PARTITION:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNION:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case YEAR:
			case ZONED:
				enterOuterAlt(_localctx, 3);
				{
				setState(2156);
				((NakedIdentifierContext)_localctx).f = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 25)) & ~0x3f) == 0 && ((1L << (_la - 25)) & -2305843009213693953L) != 0) || ((((_la - 89)) & ~0x3f) == 0 && ((1L << (_la - 89)) & -1152921504611041793L) != 0) || ((((_la - 153)) & ~0x3f) == 0 && ((1L << (_la - 153)) & 281474976710655L) != 0)) ) {
					((NakedIdentifierContext)_localctx).f = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierContext extends ParserRuleContext {
		public NakedIdentifierContext nakedIdentifier() {
			return getRuleContext(NakedIdentifierContext.class,0);
		}
		public TerminalNode FULL() { return getToken(HqlParser.FULL, 0); }
		public TerminalNode INNER() { return getToken(HqlParser.INNER, 0); }
		public TerminalNode LEFT() { return getToken(HqlParser.LEFT, 0); }
		public TerminalNode OUTER() { return getToken(HqlParser.OUTER, 0); }
		public TerminalNode RIGHT() { return getToken(HqlParser.RIGHT, 0); }
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 416, RULE_identifier);
		try {
			setState(2165);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,243,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2159);
				nakedIdentifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2160);
				match(FULL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2161);
				match(INNER);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2162);
				match(LEFT);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(2163);
				match(OUTER);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(2164);
				match(RIGHT);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 98:
			return expression_sempred((ExpressionContext)_localctx, predIndex);
		case 186:
			return predicate_sempred((PredicateContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expression_sempred(ExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 6);
		case 1:
			return precpred(_ctx, 5);
		case 2:
			return precpred(_ctx, 4);
		case 3:
			return precpred(_ctx, 8);
		case 4:
			return precpred(_ctx, 7);
		}
		return true;
	}
	private boolean predicate_sempred(PredicateContext _localctx, int predIndex) {
		switch (predIndex) {
		case 5:
			return precpred(_ctx, 3);
		case 6:
			return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u00dc\u0878\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007"+
		"\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007"+
		"\u0015\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007"+
		"\u0018\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007"+
		"\u001b\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007"+
		"\u001e\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007"+
		"\"\u0002#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007"+
		"\'\u0002(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007"+
		",\u0002-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u0007"+
		"1\u00022\u00072\u00023\u00073\u00024\u00074\u00025\u00075\u00026\u0007"+
		"6\u00027\u00077\u00028\u00078\u00029\u00079\u0002:\u0007:\u0002;\u0007"+
		";\u0002<\u0007<\u0002=\u0007=\u0002>\u0007>\u0002?\u0007?\u0002@\u0007"+
		"@\u0002A\u0007A\u0002B\u0007B\u0002C\u0007C\u0002D\u0007D\u0002E\u0007"+
		"E\u0002F\u0007F\u0002G\u0007G\u0002H\u0007H\u0002I\u0007I\u0002J\u0007"+
		"J\u0002K\u0007K\u0002L\u0007L\u0002M\u0007M\u0002N\u0007N\u0002O\u0007"+
		"O\u0002P\u0007P\u0002Q\u0007Q\u0002R\u0007R\u0002S\u0007S\u0002T\u0007"+
		"T\u0002U\u0007U\u0002V\u0007V\u0002W\u0007W\u0002X\u0007X\u0002Y\u0007"+
		"Y\u0002Z\u0007Z\u0002[\u0007[\u0002\\\u0007\\\u0002]\u0007]\u0002^\u0007"+
		"^\u0002_\u0007_\u0002`\u0007`\u0002a\u0007a\u0002b\u0007b\u0002c\u0007"+
		"c\u0002d\u0007d\u0002e\u0007e\u0002f\u0007f\u0002g\u0007g\u0002h\u0007"+
		"h\u0002i\u0007i\u0002j\u0007j\u0002k\u0007k\u0002l\u0007l\u0002m\u0007"+
		"m\u0002n\u0007n\u0002o\u0007o\u0002p\u0007p\u0002q\u0007q\u0002r\u0007"+
		"r\u0002s\u0007s\u0002t\u0007t\u0002u\u0007u\u0002v\u0007v\u0002w\u0007"+
		"w\u0002x\u0007x\u0002y\u0007y\u0002z\u0007z\u0002{\u0007{\u0002|\u0007"+
		"|\u0002}\u0007}\u0002~\u0007~\u0002\u007f\u0007\u007f\u0002\u0080\u0007"+
		"\u0080\u0002\u0081\u0007\u0081\u0002\u0082\u0007\u0082\u0002\u0083\u0007"+
		"\u0083\u0002\u0084\u0007\u0084\u0002\u0085\u0007\u0085\u0002\u0086\u0007"+
		"\u0086\u0002\u0087\u0007\u0087\u0002\u0088\u0007\u0088\u0002\u0089\u0007"+
		"\u0089\u0002\u008a\u0007\u008a\u0002\u008b\u0007\u008b\u0002\u008c\u0007"+
		"\u008c\u0002\u008d\u0007\u008d\u0002\u008e\u0007\u008e\u0002\u008f\u0007"+
		"\u008f\u0002\u0090\u0007\u0090\u0002\u0091\u0007\u0091\u0002\u0092\u0007"+
		"\u0092\u0002\u0093\u0007\u0093\u0002\u0094\u0007\u0094\u0002\u0095\u0007"+
		"\u0095\u0002\u0096\u0007\u0096\u0002\u0097\u0007\u0097\u0002\u0098\u0007"+
		"\u0098\u0002\u0099\u0007\u0099\u0002\u009a\u0007\u009a\u0002\u009b\u0007"+
		"\u009b\u0002\u009c\u0007\u009c\u0002\u009d\u0007\u009d\u0002\u009e\u0007"+
		"\u009e\u0002\u009f\u0007\u009f\u0002\u00a0\u0007\u00a0\u0002\u00a1\u0007"+
		"\u00a1\u0002\u00a2\u0007\u00a2\u0002\u00a3\u0007\u00a3\u0002\u00a4\u0007"+
		"\u00a4\u0002\u00a5\u0007\u00a5\u0002\u00a6\u0007\u00a6\u0002\u00a7\u0007"+
		"\u00a7\u0002\u00a8\u0007\u00a8\u0002\u00a9\u0007\u00a9\u0002\u00aa\u0007"+
		"\u00aa\u0002\u00ab\u0007\u00ab\u0002\u00ac\u0007\u00ac\u0002\u00ad\u0007"+
		"\u00ad\u0002\u00ae\u0007\u00ae\u0002\u00af\u0007\u00af\u0002\u00b0\u0007"+
		"\u00b0\u0002\u00b1\u0007\u00b1\u0002\u00b2\u0007\u00b2\u0002\u00b3\u0007"+
		"\u00b3\u0002\u00b4\u0007\u00b4\u0002\u00b5\u0007\u00b5\u0002\u00b6\u0007"+
		"\u00b6\u0002\u00b7\u0007\u00b7\u0002\u00b8\u0007\u00b8\u0002\u00b9\u0007"+
		"\u00b9\u0002\u00ba\u0007\u00ba\u0002\u00bb\u0007\u00bb\u0002\u00bc\u0007"+
		"\u00bc\u0002\u00bd\u0007\u00bd\u0002\u00be\u0007\u00be\u0002\u00bf\u0007"+
		"\u00bf\u0002\u00c0\u0007\u00c0\u0002\u00c1\u0007\u00c1\u0002\u00c2\u0007"+
		"\u00c2\u0002\u00c3\u0007\u00c3\u0002\u00c4\u0007\u00c4\u0002\u00c5\u0007"+
		"\u00c5\u0002\u00c6\u0007\u00c6\u0002\u00c7\u0007\u00c7\u0002\u00c8\u0007"+
		"\u00c8\u0002\u00c9\u0007\u00c9\u0002\u00ca\u0007\u00ca\u0002\u00cb\u0007"+
		"\u00cb\u0002\u00cc\u0007\u00cc\u0002\u00cd\u0007\u00cd\u0002\u00ce\u0007"+
		"\u00ce\u0002\u00cf\u0007\u00cf\u0002\u00d0\u0007\u00d0\u0001\u0000\u0001"+
		"\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0003"+
		"\u0001\u01aa\b\u0001\u0001\u0002\u0001\u0002\u0001\u0003\u0003\u0003\u01af"+
		"\b\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0005\u0003\u01b5"+
		"\b\u0003\n\u0003\f\u0003\u01b8\t\u0003\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0005\u0004\u01be\b\u0004\n\u0004\f\u0004\u01c1\t\u0004\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0003\u0005\u01c6\b\u0005\u0001\u0005\u0003"+
		"\u0005\u01c9\b\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003"+
		"\u0005\u01cf\b\u0005\u0001\u0005\u0003\u0005\u01d2\b\u0005\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0005\u0007\u01df\b\u0007"+
		"\n\u0007\f\u0007\u01e2\t\u0007\u0001\b\u0001\b\u0003\b\u01e6\b\b\u0001"+
		"\b\u0003\b\u01e9\b\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0003\t\u01f4\b\t\u0001\t\u0001\t\u0003\t\u01f8\b\t"+
		"\u0001\n\u0001\n\u0001\n\u0005\n\u01fd\b\n\n\n\f\n\u0200\t\n\u0001\u000b"+
		"\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0003\u000b\u0207\b\u000b"+
		"\u0001\u000b\u0003\u000b\u020a\b\u000b\u0001\u000b\u0003\u000b\u020d\b"+
		"\u000b\u0001\u000b\u0003\u000b\u0210\b\u000b\u0001\u000b\u0003\u000b\u0213"+
		"\b\u000b\u0001\f\u0001\f\u0003\f\u0217\b\f\u0001\f\u0003\f\u021a\b\f\u0001"+
		"\f\u0003\f\u021d\b\f\u0001\f\u0003\f\u0220\b\f\u0001\f\u0001\f\u0003\f"+
		"\u0224\b\f\u0001\f\u0003\f\u0227\b\f\u0001\f\u0003\f\u022a\b\f\u0001\f"+
		"\u0003\f\u022d\b\f\u0003\f\u022f\b\f\u0001\r\u0001\r\u0001\u000e\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0005\u000e\u0237\b\u000e\n\u000e\f\u000e"+
		"\u023a\t\u000e\u0001\u000f\u0001\u000f\u0005\u000f\u023e\b\u000f\n\u000f"+
		"\f\u000f\u0241\t\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0003\u0010"+
		"\u0246\b\u0010\u0001\u0011\u0001\u0011\u0003\u0011\u024a\b\u0011\u0001"+
		"\u0011\u0003\u0011\u024d\b\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001"+
		"\u0011\u0003\u0011\u0253\b\u0011\u0003\u0011\u0255\b\u0011\u0001\u0012"+
		"\u0001\u0012\u0001\u0012\u0003\u0012\u025a\b\u0012\u0001\u0012\u0001\u0012"+
		"\u0003\u0012\u025e\b\u0012\u0001\u0013\u0001\u0013\u0003\u0013\u0262\b"+
		"\u0013\u0001\u0013\u0003\u0013\u0265\b\u0013\u0001\u0013\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0003\u0013\u026b\b\u0013\u0003\u0013\u026d\b\u0013"+
		"\u0001\u0014\u0001\u0014\u0003\u0014\u0271\b\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0014\u0003\u0014\u0276\b\u0014\u0001\u0015\u0001\u0015\u0003\u0015"+
		"\u027a\b\u0015\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0005\u0016"+
		"\u0280\b\u0016\n\u0016\f\u0016\u0283\t\u0016\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0018\u0001\u0018\u0003\u0018\u028b\b\u0018\u0001"+
		"\u0018\u0001\u0018\u0003\u0018\u028f\b\u0018\u0001\u0019\u0001\u0019\u0003"+
		"\u0019\u0293\b\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0003"+
		"\u0019\u0299\b\u0019\u0001\u0019\u0003\u0019\u029c\b\u0019\u0001\u001a"+
		"\u0001\u001a\u0001\u001a\u0001\u001a\u0005\u001a\u02a2\b\u001a\n\u001a"+
		"\f\u001a\u02a5\t\u001a\u0001\u001a\u0001\u001a\u0001\u001b\u0001\u001b"+
		"\u0001\u001b\u0001\u001b\u0005\u001b\u02ad\b\u001b\n\u001b\f\u001b\u02b0"+
		"\t\u001b\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001c\u0005\u001c\u02b6"+
		"\b\u001c\n\u001c\f\u001c\u02b9\t\u001c\u0001\u001c\u0001\u001c\u0001\u001d"+
		"\u0001\u001d\u0001\u001d\u0003\u001d\u02c0\b\u001d\u0001\u001d\u0001\u001d"+
		"\u0001\u001d\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001e"+
		"\u0001\u001e\u0001\u001e\u0005\u001e\u02cc\b\u001e\n\u001e\f\u001e\u02cf"+
		"\t\u001e\u0001\u001e\u0001\u001e\u0003\u001e\u02d3\b\u001e\u0001\u001f"+
		"\u0001\u001f\u0001\u001f\u0001\u001f\u0003\u001f\u02d9\b\u001f\u0003\u001f"+
		"\u02db\b\u001f\u0001 \u0001 \u0001 \u0001 \u0001 \u0001 \u0001!\u0001"+
		"!\u0001!\u0003!\u02e6\b!\u0001\"\u0001\"\u0003\"\u02ea\b\"\u0001\"\u0003"+
		"\"\u02ed\b\"\u0001#\u0001#\u0001#\u0003#\u02f2\b#\u0001$\u0001$\u0001"+
		"%\u0001%\u0001%\u0001&\u0001&\u0001&\u0001\'\u0001\'\u0001\'\u0003\'\u02ff"+
		"\b\'\u0001(\u0001(\u0001(\u0001(\u0001(\u0001(\u0003(\u0307\b(\u0001("+
		"\u0001(\u0001(\u0001(\u0003(\u030d\b(\u0001)\u0001)\u0001*\u0001*\u0003"+
		"*\u0313\b*\u0001*\u0001*\u0001+\u0001+\u0001+\u0005+\u031a\b+\n+\f+\u031d"+
		"\t+\u0001,\u0001,\u0003,\u0321\b,\u0001-\u0001-\u0001-\u0001-\u0003-\u0327"+
		"\b-\u0001.\u0001.\u0001.\u0001.\u0001.\u0001/\u0001/\u0001/\u0001/\u0001"+
		"/\u00010\u00010\u00010\u00010\u00050\u0337\b0\n0\f0\u033a\t0\u00011\u0003"+
		"1\u033d\b1\u00011\u00031\u0340\b1\u00011\u00031\u0343\b1\u00011\u0003"+
		"1\u0346\b1\u00012\u00012\u00012\u00012\u00032\u034c\b2\u00013\u00013\u0001"+
		"3\u00014\u00014\u00014\u00014\u00014\u00014\u00034\u0357\b4\u00015\u0001"+
		"5\u00015\u00015\u00015\u00055\u035e\b5\n5\f5\u0361\t5\u00016\u00016\u0001"+
		"6\u00016\u00016\u00056\u0368\b6\n6\f6\u036b\t6\u00017\u00017\u00017\u0001"+
		"7\u00057\u0371\b7\n7\f7\u0374\t7\u00018\u00018\u00038\u0378\b8\u00018"+
		"\u00018\u00038\u037c\b8\u00018\u00018\u00038\u0380\b8\u00038\u0382\b8"+
		"\u00019\u00019\u00019\u00019\u00019\u00019\u00019\u00019\u00019\u0003"+
		"9\u038d\b9\u0001:\u0001:\u0001;\u0001;\u0001<\u0001<\u0001<\u0003<\u0396"+
		"\b<\u0001=\u0001=\u0001=\u0001=\u0001=\u0003=\u039d\b=\u0001=\u0001=\u0003"+
		"=\u03a1\b=\u0001>\u0001>\u0001>\u0001>\u0001>\u0003>\u03a8\b>\u0001>\u0001"+
		">\u0003>\u03ac\b>\u0001?\u0001?\u0001?\u0001?\u0001?\u0003?\u03b3\b?\u0001"+
		"?\u0001?\u0003?\u03b7\b?\u0001@\u0001@\u0001@\u0001@\u0001@\u0003@\u03be"+
		"\b@\u0001@\u0001@\u0003@\u03c2\b@\u0001A\u0001A\u0001A\u0001A\u0001A\u0003"+
		"A\u03c9\bA\u0001A\u0001A\u0003A\u03cd\bA\u0001B\u0001B\u0001B\u0003B\u03d2"+
		"\bB\u0001C\u0001C\u0001C\u0001D\u0001D\u0001D\u0001D\u0001E\u0001E\u0001"+
		"E\u0001E\u0001F\u0001F\u0001F\u0001F\u0001G\u0001G\u0001G\u0003G\u03e6"+
		"\bG\u0001G\u0001G\u0001H\u0001H\u0001H\u0003H\u03ed\bH\u0001H\u0001H\u0001"+
		"I\u0001I\u0001I\u0003I\u03f4\bI\u0001I\u0001I\u0001J\u0001J\u0001K\u0001"+
		"K\u0001K\u0001K\u0005K\u03fe\bK\nK\fK\u0401\tK\u0003K\u0403\bK\u0001K"+
		"\u0001K\u0001L\u0001L\u0001L\u0001L\u0001L\u0001L\u0001M\u0001M\u0001"+
		"N\u0001N\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001P\u0001P\u0001"+
		"P\u0001P\u0001P\u0003P\u041c\bP\u0001Q\u0001Q\u0001Q\u0001Q\u0003Q\u0422"+
		"\bQ\u0001R\u0001R\u0001R\u0001R\u0001R\u0001S\u0001S\u0001T\u0001T\u0001"+
		"U\u0001U\u0001V\u0001V\u0001W\u0001W\u0001X\u0001X\u0001Y\u0001Y\u0001"+
		"Y\u0003Y\u0438\bY\u0001Y\u0003Y\u043b\bY\u0001Z\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0003Z\u0442\bZ\u0001[\u0001[\u0001\\\u0001\\\u0001\\\u0001\\\u0001"+
		"\\\u0001\\\u0001\\\u0001\\\u0001\\\u0003\\\u044f\b\\\u0001]\u0001]\u0001"+
		"]\u0001]\u0001]\u0001]\u0003]\u0457\b]\u0001^\u0001^\u0003^\u045b\b^\u0001"+
		"^\u0001^\u0003^\u045f\b^\u0001_\u0001_\u0001`\u0001`\u0001`\u0001`\u0001"+
		"`\u0005`\u0468\b`\n`\f`\u046b\t`\u0001`\u0003`\u046e\b`\u0001a\u0001a"+
		"\u0001a\u0001a\u0001a\u0001a\u0003a\u0476\ba\u0001b\u0001b\u0001b\u0001"+
		"b\u0001b\u0001b\u0001b\u0001b\u0001b\u0004b\u0481\bb\u000bb\fb\u0482\u0001"+
		"b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001"+
		"b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0003"+
		"b\u0499\bb\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001"+
		"b\u0001b\u0001b\u0001b\u0001b\u0001b\u0005b\u04a9\bb\nb\fb\u04ac\tb\u0001"+
		"c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0003c\u04b7"+
		"\bc\u0001c\u0001c\u0003c\u04bb\bc\u0001d\u0001d\u0003d\u04bf\bd\u0001"+
		"d\u0003d\u04c2\bd\u0001e\u0001e\u0003e\u04c6\be\u0001f\u0001f\u0001f\u0001"+
		"f\u0001f\u0003f\u04cd\bf\u0001g\u0001g\u0005g\u04d1\bg\ng\fg\u04d4\tg"+
		"\u0001h\u0001h\u0001h\u0001i\u0001i\u0001i\u0001j\u0001j\u0001j\u0001"+
		"j\u0003j\u04e0\bj\u0001j\u0001j\u0001k\u0001k\u0001k\u0001k\u0001k\u0003"+
		"k\u04e9\bk\u0001l\u0001l\u0001l\u0001l\u0001l\u0001m\u0001m\u0001m\u0001"+
		"m\u0001m\u0003m\u04f5\bm\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001"+
		"n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0003"+
		"n\u0507\bn\u0001n\u0001n\u0001n\u0003n\u050c\bn\u0001o\u0001o\u0001o\u0001"+
		"o\u0001o\u0001o\u0001p\u0001p\u0001p\u0001p\u0001p\u0001p\u0001p\u0003"+
		"p\u051b\bp\u0001q\u0001q\u0001q\u0001q\u0001q\u0003q\u0522\bq\u0001r\u0001"+
		"r\u0001r\u0001r\u0001r\u0003r\u0529\br\u0001s\u0001s\u0001s\u0001s\u0001"+
		"s\u0001t\u0001t\u0003t\u0532\bt\u0001u\u0001u\u0001u\u0004u\u0537\bu\u000b"+
		"u\fu\u0538\u0001u\u0001u\u0003u\u053d\bu\u0001u\u0001u\u0001v\u0001v\u0004"+
		"v\u0543\bv\u000bv\fv\u0544\u0001v\u0001v\u0003v\u0549\bv\u0001v\u0001"+
		"v\u0001w\u0001w\u0001w\u0001w\u0001w\u0001x\u0001x\u0001x\u0001x\u0001"+
		"x\u0001y\u0001y\u0001y\u0001y\u0001y\u0001y\u0001y\u0001y\u0003y\u055f"+
		"\by\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001"+
		"z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001z\u0001"+
		"z\u0001z\u0003z\u0576\bz\u0001{\u0001{\u0001{\u0001{\u0001{\u0001{\u0001"+
		"{\u0001|\u0001|\u0001|\u0001|\u0001|\u0003|\u0584\b|\u0001|\u0003|\u0587"+
		"\b|\u0001}\u0001}\u0001}\u0001}\u0001}\u0001}\u0001}\u0005}\u0590\b}\n"+
		"}\f}\u0593\t}\u0001~\u0001~\u0001~\u0001~\u0001~\u0001~\u0001~\u0003~"+
		"\u059c\b~\u0001~\u0001~\u0001~\u0001~\u0001~\u0001~\u0001~\u0001~\u0001"+
		"~\u0003~\u05a7\b~\u0001~\u0001~\u0003~\u05ab\b~\u0001\u007f\u0001\u007f"+
		"\u0001\u0080\u0001\u0080\u0001\u0081\u0001\u0081\u0001\u0081\u0003\u0081"+
		"\u05b4\b\u0081\u0001\u0081\u0003\u0081\u05b7\b\u0081\u0001\u0081\u0003"+
		"\u0081\u05ba\b\u0081\u0001\u0081\u0001\u0081\u0001\u0081\u0001\u0082\u0001"+
		"\u0082\u0001\u0083\u0001\u0083\u0003\u0083\u05c3\b\u0083\u0001\u0084\u0001"+
		"\u0084\u0001\u0084\u0001\u0084\u0001\u0084\u0001\u0084\u0001\u0084\u0003"+
		"\u0084\u05cc\b\u0084\u0001\u0084\u0001\u0084\u0001\u0085\u0001\u0085\u0001"+
		"\u0086\u0001\u0086\u0001\u0087\u0001\u0087\u0001\u0088\u0001\u0088\u0001"+
		"\u0088\u0001\u0088\u0001\u0088\u0001\u0088\u0001\u0088\u0001\u0089\u0001"+
		"\u0089\u0001\u008a\u0001\u008a\u0001\u008b\u0001\u008b\u0001\u008b\u0001"+
		"\u008b\u0001\u008b\u0001\u008b\u0001\u008b\u0001\u008b\u0001\u008b\u0003"+
		"\u008b\u05ea\b\u008b\u0001\u008b\u0001\u008b\u0001\u008c\u0001\u008c\u0001"+
		"\u008d\u0001\u008d\u0001\u008e\u0001\u008e\u0001\u008f\u0001\u008f\u0001"+
		"\u0090\u0001\u0090\u0001\u0090\u0003\u0090\u05f9\b\u0090\u0001\u0090\u0001"+
		"\u0090\u0003\u0090\u05fd\b\u0090\u0001\u0091\u0001\u0091\u0001\u0091\u0003"+
		"\u0091\u0602\b\u0091\u0001\u0091\u0001\u0091\u0003\u0091\u0606\b\u0091"+
		"\u0001\u0092\u0001\u0092\u0001\u0092\u0003\u0092\u060b\b\u0092\u0001\u0092"+
		"\u0001\u0092\u0003\u0092\u060f\b\u0092\u0001\u0093\u0001\u0093\u0001\u0093"+
		"\u0003\u0093\u0614\b\u0093\u0001\u0093\u0003\u0093\u0617\b\u0093\u0001"+
		"\u0094\u0001\u0094\u0001\u0094\u0003\u0094\u061c\b\u0094\u0001\u0094\u0001"+
		"\u0094\u0003\u0094\u0620\b\u0094\u0001\u0095\u0001\u0095\u0001\u0095\u0003"+
		"\u0095\u0625\b\u0095\u0001\u0095\u0001\u0095\u0003\u0095\u0629\b\u0095"+
		"\u0001\u0096\u0001\u0096\u0001\u0096\u0003\u0096\u062e\b\u0096\u0001\u0096"+
		"\u0001\u0096\u0003\u0096\u0632\b\u0096\u0001\u0097\u0001\u0097\u0001\u0097"+
		"\u0003\u0097\u0637\b\u0097\u0001\u0097\u0001\u0097\u0003\u0097\u063b\b"+
		"\u0097\u0001\u0098\u0001\u0098\u0001\u0098\u0001\u0098\u0001\u0098\u0001"+
		"\u0098\u0001\u0098\u0001\u0099\u0001\u0099\u0001\u009a\u0001\u009a\u0001"+
		"\u009a\u0001\u009a\u0001\u009a\u0001\u009a\u0001\u009a\u0001\u009b\u0001"+
		"\u009b\u0001\u009b\u0001\u009b\u0001\u009b\u0005\u009b\u0652\b\u009b\n"+
		"\u009b\f\u009b\u0655\t\u009b\u0001\u009b\u0001\u009b\u0001\u009c\u0001"+
		"\u009c\u0001\u009c\u0001\u009c\u0001\u009c\u0005\u009c\u065e\b\u009c\n"+
		"\u009c\f\u009c\u0661\t\u009c\u0001\u009c\u0001\u009c\u0001\u009d\u0001"+
		"\u009d\u0001\u009e\u0001\u009e\u0001\u009e\u0001\u009e\u0001\u009e\u0001"+
		"\u009e\u0001\u009e\u0001\u009e\u0001\u009e\u0001\u009e\u0001\u009e\u0001"+
		"\u009e\u0003\u009e\u0673\b\u009e\u0001\u009f\u0001\u009f\u0001\u009f\u0001"+
		"\u009f\u0001\u009f\u0001\u009f\u0003\u009f\u067b\b\u009f\u0003\u009f\u067d"+
		"\b\u009f\u0001\u009f\u0001\u009f\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001"+
		"\u00a0\u0001\u00a0\u0003\u00a0\u0686\b\u00a0\u0001\u00a0\u0001\u00a0\u0003"+
		"\u00a0\u068a\b\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a1\u0001\u00a1\u0003"+
		"\u00a1\u0690\b\u00a1\u0001\u00a2\u0001\u00a2\u0001\u00a2\u0001\u00a2\u0001"+
		"\u00a2\u0001\u00a2\u0001\u00a2\u0003\u00a2\u0699\b\u00a2\u0001\u00a2\u0001"+
		"\u00a2\u0001\u00a3\u0001\u00a3\u0001\u00a3\u0001\u00a3\u0003\u00a3\u06a1"+
		"\b\u00a3\u0001\u00a3\u0001\u00a3\u0003\u00a3\u06a5\b\u00a3\u0001\u00a3"+
		"\u0003\u00a3\u06a8\b\u00a3\u0001\u00a3\u0003\u00a3\u06ab\b\u00a3\u0001"+
		"\u00a3\u0003\u00a3\u06ae\b\u00a3\u0001\u00a3\u0003\u00a3\u06b1\b\u00a3"+
		"\u0001\u00a3\u0003\u00a3\u06b4\b\u00a3\u0001\u00a4\u0001\u00a4\u0001\u00a5"+
		"\u0001\u00a5\u0001\u00a5\u0001\u00a5\u0003\u00a5\u06bc\b\u00a5\u0001\u00a5"+
		"\u0001\u00a5\u0001\u00a5\u0005\u00a5\u06c1\b\u00a5\n\u00a5\f\u00a5\u06c4"+
		"\t\u00a5\u0001\u00a6\u0001\u00a6\u0001\u00a6\u0001\u00a6\u0001\u00a6\u0001"+
		"\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001"+
		"\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001"+
		"\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001"+
		"\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0001"+
		"\u00a7\u0001\u00a7\u0003\u00a7\u06e5\b\u00a7\u0001\u00a8\u0001\u00a8\u0001"+
		"\u00a8\u0001\u00a8\u0001\u00a8\u0001\u00a8\u0001\u00a8\u0001\u00a8\u0001"+
		"\u00a8\u0001\u00a8\u0003\u00a8\u06f1\b\u00a8\u0001\u00a9\u0001\u00a9\u0001"+
		"\u00a9\u0003\u00a9\u06f6\b\u00a9\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001"+
		"\u00aa\u0001\u00aa\u0003\u00aa\u06fd\b\u00aa\u0001\u00aa\u0003\u00aa\u0700"+
		"\b\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001"+
		"\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0003"+
		"\u00aa\u070d\b\u00aa\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001"+
		"\u00ab\u0003\u00ab\u0714\b\u00ab\u0001\u00ab\u0003\u00ab\u0717\b\u00ab"+
		"\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001\u00ab"+
		"\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0001\u00ab\u0003\u00ab"+
		"\u0724\b\u00ab\u0001\u00ac\u0001\u00ac\u0001\u00ad\u0001\u00ad\u0001\u00ae"+
		"\u0001\u00ae\u0001\u00ae\u0003\u00ae\u072d\b\u00ae\u0001\u00ae\u0001\u00ae"+
		"\u0001\u00ae\u0001\u00ae\u0003\u00ae\u0733\b\u00ae\u0001\u00ae\u0001\u00ae"+
		"\u0003\u00ae\u0737\b\u00ae\u0001\u00ae\u0003\u00ae\u073a\b\u00ae\u0001"+
		"\u00ae\u0003\u00ae\u073d\b\u00ae\u0001\u00af\u0001\u00af\u0001\u00af\u0001"+
		"\u00af\u0001\u00af\u0003\u00af\u0744\b\u00af\u0001\u00af\u0001\u00af\u0003"+
		"\u00af\u0748\b\u00af\u0001\u00b0\u0001\u00b0\u0001\u00b0\u0001\u00b0\u0001"+
		"\u00b0\u0001\u00b0\u0001\u00b1\u0001\u00b1\u0001\u00b1\u0001\u00b1\u0001"+
		"\u00b1\u0001\u00b2\u0001\u00b2\u0001\u00b2\u0001\u00b2\u0003\u00b2\u0759"+
		"\b\u00b2\u0001\u00b3\u0001\u00b3\u0001\u00b3\u0001\u00b3\u0003\u00b3\u075f"+
		"\b\u00b3\u0001\u00b4\u0001\u00b4\u0001\u00b4\u0003\u00b4\u0764\b\u00b4"+
		"\u0001\u00b4\u0003\u00b4\u0767\b\u00b4\u0001\u00b4\u0003\u00b4\u076a\b"+
		"\u00b4\u0001\u00b4\u0001\u00b4\u0001\u00b5\u0001\u00b5\u0001\u00b5\u0001"+
		"\u00b5\u0001\u00b5\u0005\u00b5\u0773\b\u00b5\n\u00b5\f\u00b5\u0776\t\u00b5"+
		"\u0001\u00b6\u0001\u00b6\u0001\u00b6\u0003\u00b6\u077b\b\u00b6\u0001\u00b6"+
		"\u0001\u00b6\u0001\u00b6\u0001\u00b6\u0001\u00b6\u0001\u00b6\u0003\u00b6"+
		"\u0783\b\u00b6\u0003\u00b6\u0785\b\u00b6\u0001\u00b7\u0001\u00b7\u0001"+
		"\u00b7\u0001\u00b7\u0001\u00b7\u0001\u00b7\u0001\u00b7\u0001\u00b7\u0001"+
		"\u00b7\u0001\u00b7\u0003\u00b7\u0791\b\u00b7\u0001\u00b8\u0001\u00b8\u0001"+
		"\u00b8\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0001"+
		"\u00b8\u0001\u00b8\u0003\u00b8\u079d\b\u00b8\u0001\u00b9\u0001\u00b9\u0001"+
		"\u00b9\u0001\u00b9\u0001\u00b9\u0001\u00b9\u0001\u00b9\u0001\u00b9\u0001"+
		"\u00b9\u0001\u00b9\u0003\u00b9\u07a9\b\u00b9\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0003"+
		"\u00ba\u07b3\b\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0003\u00ba\u07ba\b\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0001\u00ba\u0003\u00ba\u07c2\b\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0003\u00ba\u07c6\b\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0001\u00ba\u0003\u00ba\u07ce\b\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0003\u00ba\u07d9\b\u00ba\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0005\u00ba\u07e1\b\u00ba\n"+
		"\u00ba\f\u00ba\u07e4\t\u00ba\u0001\u00bb\u0001\u00bb\u0003\u00bb\u07e8"+
		"\b\u00bb\u0001\u00bc\u0001\u00bc\u0003\u00bc\u07ec\b\u00bc\u0001\u00bd"+
		"\u0001\u00bd\u0001\u00be\u0001\u00be\u0001\u00bf\u0001\u00bf\u0001\u00c0"+
		"\u0001\u00c0\u0001\u00c1\u0001\u00c1\u0001\u00c1\u0001\u00c1\u0001\u00c2"+
		"\u0001\u00c2\u0003\u00c2\u07fc\b\u00c2\u0001\u00c2\u0001\u00c2\u0001\u00c2"+
		"\u0001\u00c2\u0001\u00c2\u0001\u00c3\u0001\u00c3\u0003\u00c3\u0805\b\u00c3"+
		"\u0001\u00c3\u0001\u00c3\u0001\u00c3\u0001\u00c3\u0001\u00c3\u0001\u00c3"+
		"\u0003\u00c3\u080d\b\u00c3\u0003\u00c3\u080f\b\u00c3\u0001\u00c4\u0001"+
		"\u00c4\u0003\u00c4\u0813\b\u00c4\u0001\u00c4\u0001\u00c4\u0001\u00c4\u0001"+
		"\u00c5\u0001\u00c5\u0001\u00c5\u0001\u00c5\u0001\u00c5\u0001\u00c5\u0001"+
		"\u00c5\u0001\u00c5\u0001\u00c5\u0001\u00c5\u0001\u00c5\u0001\u00c5\u0001"+
		"\u00c5\u0001\u00c5\u0005\u00c5\u0826\b\u00c5\n\u00c5\f\u00c5\u0829\t\u00c5"+
		"\u0003\u00c5\u082b\b\u00c5\u0001\u00c5\u0003\u00c5\u082e\b\u00c5\u0001"+
		"\u00c6\u0001\u00c6\u0001\u00c6\u0001\u00c6\u0001\u00c6\u0001\u00c6\u0001"+
		"\u00c6\u0001\u00c6\u0003\u00c6\u0838\b\u00c6\u0001\u00c7\u0001\u00c7\u0001"+
		"\u00c7\u0003\u00c7\u083d\b\u00c7\u0001\u00c8\u0001\u00c8\u0001\u00c8\u0005"+
		"\u00c8\u0842\b\u00c8\n\u00c8\f\u00c8\u0845\t\u00c8\u0001\u00c9\u0001\u00c9"+
		"\u0003\u00c9\u0849\b\u00c9\u0001\u00c9\u0003\u00c9\u084c\b\u00c9\u0001"+
		"\u00ca\u0001\u00ca\u0003\u00ca\u0850\b\u00ca\u0001\u00cb\u0001\u00cb\u0003"+
		"\u00cb\u0854\b\u00cb\u0001\u00cc\u0001\u00cc\u0001\u00cc\u0003\u00cc\u0859"+
		"\b\u00cc\u0001\u00cd\u0001\u00cd\u0001\u00cd\u0001\u00cd\u0003\u00cd\u085f"+
		"\b\u00cd\u0003\u00cd\u0861\b\u00cd\u0001\u00ce\u0001\u00ce\u0001\u00ce"+
		"\u0005\u00ce\u0866\b\u00ce\n\u00ce\f\u00ce\u0869\t\u00ce\u0001\u00cf\u0001"+
		"\u00cf\u0001\u00cf\u0003\u00cf\u086e\b\u00cf\u0001\u00d0\u0001\u00d0\u0001"+
		"\u00d0\u0001\u00d0\u0001\u00d0\u0001\u00d0\u0003\u00d0\u0876\b\u00d0\u0001"+
		"\u00d0\u0000\u0002\u00c4\u0174\u00d1\u0000\u0002\u0004\u0006\b\n\f\u000e"+
		"\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@BDF"+
		"HJLNPRTVXZ\\^`bdfhjlnprtvxz|~\u0080\u0082\u0084\u0086\u0088\u008a\u008c"+
		"\u008e\u0090\u0092\u0094\u0096\u0098\u009a\u009c\u009e\u00a0\u00a2\u00a4"+
		"\u00a6\u00a8\u00aa\u00ac\u00ae\u00b0\u00b2\u00b4\u00b6\u00b8\u00ba\u00bc"+
		"\u00be\u00c0\u00c2\u00c4\u00c6\u00c8\u00ca\u00cc\u00ce\u00d0\u00d2\u00d4"+
		"\u00d6\u00d8\u00da\u00dc\u00de\u00e0\u00e2\u00e4\u00e6\u00e8\u00ea\u00ec"+
		"\u00ee\u00f0\u00f2\u00f4\u00f6\u00f8\u00fa\u00fc\u00fe\u0100\u0102\u0104"+
		"\u0106\u0108\u010a\u010c\u010e\u0110\u0112\u0114\u0116\u0118\u011a\u011c"+
		"\u011e\u0120\u0122\u0124\u0126\u0128\u012a\u012c\u012e\u0130\u0132\u0134"+
		"\u0136\u0138\u013a\u013c\u013e\u0140\u0142\u0144\u0146\u0148\u014a\u014c"+
		"\u014e\u0150\u0152\u0154\u0156\u0158\u015a\u015c\u015e\u0160\u0162\u0164"+
		"\u0166\u0168\u016a\u016c\u016e\u0170\u0172\u0174\u0176\u0178\u017a\u017c"+
		"\u017e\u0180\u0182\u0184\u0186\u0188\u018a\u018c\u018e\u0190\u0192\u0194"+
		"\u0196\u0198\u019a\u019c\u019e\u01a0\u0000#\u0002\u0000&&==\u0002\u0000"+
		"\"\">>\u0002\u0000QQll\u0001\u0000\u00a4\u00a5\u0002\u0000QQ\u0087\u0087"+
		"\u0003\u0000VVoo\u00a2\u00a2\u0002\u0000\u0090\u0090\u00c4\u00c4\u0001"+
		"\u0000\u00ca\u00cb\u0001\u0000\u00ce\u00d4\u0001\u0000\u00d9\u00da\u0002"+
		"\u0000\u00ce\u00ce\u00d1\u00d1\b\u0000::GG[[\u0083\u0085\u009f\u009f\u00a7"+
		"\u00a7\u00c1\u00c1\u00c7\u00c7\u0002\u0000[[\u0083\u0083\u0002\u00008"+
		"8\u00b0\u00b0\u0002\u0000\n\n\u0018\u0018\u0003\u0000%%nn\u00b5\u00b5"+
		"\u0002\u0000nn\u00b5\u00b5\u0001\u0000\u00b8\u00b9\u0004\u0000##zz\u0080"+
		"\u0080\u00ad\u00ad\u0002\u0000{{\u0081\u0081\u0002\u0000||\u0082\u0082"+
		"\u0002\u0000\u001e\u001eJJ\u0002\u0000  \u00ab\u00ab\u0002\u0000\u00c4"+
		"\u00c4\u00c6\u00c6\u0003\u0000YY\u00a0\u00a0\u00a5\u00a5\u0002\u0000D"+
		"D\u00c9\u00cb\u0003\u0000..__ff\u0002\u0000BB\u00c0\u00c0\u0002\u0000"+
		"AA\u00bf\u00bf\u0002\u0000``jj\u0002\u0000aakk\u0002\u0000\u0004\u0004"+
		"\u000e\u0014\u0002\u0000]]pp\u0002\u0000BBaa\u0005\u0000\u0019UWacnp\u0094"+
		"\u0096\u00c8\u0907\u0000\u01a2\u0001\u0000\u0000\u0000\u0002\u01a9\u0001"+
		"\u0000\u0000\u0000\u0004\u01ab\u0001\u0000\u0000\u0000\u0006\u01ae\u0001"+
		"\u0000\u0000\u0000\b\u01b9\u0001\u0000\u0000\u0000\n\u01c2\u0001\u0000"+
		"\u0000\u0000\f\u01d3\u0001\u0000\u0000\u0000\u000e\u01db\u0001\u0000\u0000"+
		"\u0000\u0010\u01e3\u0001\u0000\u0000\u0000\u0012\u01ea\u0001\u0000\u0000"+
		"\u0000\u0014\u01f9\u0001\u0000\u0000\u0000\u0016\u0206\u0001\u0000\u0000"+
		"\u0000\u0018\u022e\u0001\u0000\u0000\u0000\u001a\u0230\u0001\u0000\u0000"+
		"\u0000\u001c\u0232\u0001\u0000\u0000\u0000\u001e\u023b\u0001\u0000\u0000"+
		"\u0000 \u0245\u0001\u0000\u0000\u0000\"\u0254\u0001\u0000\u0000\u0000"+
		"$\u0256\u0001\u0000\u0000\u0000&\u026c\u0001\u0000\u0000\u0000(\u026e"+
		"\u0001\u0000\u0000\u0000*\u0277\u0001\u0000\u0000\u0000,\u027b\u0001\u0000"+
		"\u0000\u0000.\u0284\u0001\u0000\u0000\u00000\u0288\u0001\u0000\u0000\u0000"+
		"2\u0290\u0001\u0000\u0000\u00004\u029d\u0001\u0000\u0000\u00006\u02a8"+
		"\u0001\u0000\u0000\u00008\u02b1\u0001\u0000\u0000\u0000:\u02bc\u0001\u0000"+
		"\u0000\u0000<\u02d2\u0001\u0000\u0000\u0000>\u02da\u0001\u0000\u0000\u0000"+
		"@\u02dc\u0001\u0000\u0000\u0000B\u02e5\u0001\u0000\u0000\u0000D\u02e7"+
		"\u0001\u0000\u0000\u0000F\u02f1\u0001\u0000\u0000\u0000H\u02f3\u0001\u0000"+
		"\u0000\u0000J\u02f5\u0001\u0000\u0000\u0000L\u02f8\u0001\u0000\u0000\u0000"+
		"N\u02fb\u0001\u0000\u0000\u0000P\u0300\u0001\u0000\u0000\u0000R\u030e"+
		"\u0001\u0000\u0000\u0000T\u0310\u0001\u0000\u0000\u0000V\u0316\u0001\u0000"+
		"\u0000\u0000X\u031e\u0001\u0000\u0000\u0000Z\u0326\u0001\u0000\u0000\u0000"+
		"\\\u0328\u0001\u0000\u0000\u0000^\u032d\u0001\u0000\u0000\u0000`\u0332"+
		"\u0001\u0000\u0000\u0000b\u0345\u0001\u0000\u0000\u0000d\u0347\u0001\u0000"+
		"\u0000\u0000f\u034d\u0001\u0000\u0000\u0000h\u0350\u0001\u0000\u0000\u0000"+
		"j\u0358\u0001\u0000\u0000\u0000l\u0362\u0001\u0000\u0000\u0000n\u036c"+
		"\u0001\u0000\u0000\u0000p\u0381\u0001\u0000\u0000\u0000r\u038c\u0001\u0000"+
		"\u0000\u0000t\u038e\u0001\u0000\u0000\u0000v\u0390\u0001\u0000\u0000\u0000"+
		"x\u0395\u0001\u0000\u0000\u0000z\u03a0\u0001\u0000\u0000\u0000|\u03ab"+
		"\u0001\u0000\u0000\u0000~\u03b6\u0001\u0000\u0000\u0000\u0080\u03c1\u0001"+
		"\u0000\u0000\u0000\u0082\u03cc\u0001\u0000\u0000\u0000\u0084\u03d1\u0001"+
		"\u0000\u0000\u0000\u0086\u03d3\u0001\u0000\u0000\u0000\u0088\u03d6\u0001"+
		"\u0000\u0000\u0000\u008a\u03da\u0001\u0000\u0000\u0000\u008c\u03de\u0001"+
		"\u0000\u0000\u0000\u008e\u03e2\u0001\u0000\u0000\u0000\u0090\u03e9\u0001"+
		"\u0000\u0000\u0000\u0092\u03f0\u0001\u0000\u0000\u0000\u0094\u03f7\u0001"+
		"\u0000\u0000\u0000\u0096\u03f9\u0001\u0000\u0000\u0000\u0098\u0406\u0001"+
		"\u0000\u0000\u0000\u009a\u040c\u0001\u0000\u0000\u0000\u009c\u040e\u0001"+
		"\u0000\u0000\u0000\u009e\u0410\u0001\u0000\u0000\u0000\u00a0\u0416\u0001"+
		"\u0000\u0000\u0000\u00a2\u041d\u0001\u0000\u0000\u0000\u00a4\u0423\u0001"+
		"\u0000\u0000\u0000\u00a6\u0428\u0001\u0000\u0000\u0000\u00a8\u042a\u0001"+
		"\u0000\u0000\u0000\u00aa\u042c\u0001\u0000\u0000\u0000\u00ac\u042e\u0001"+
		"\u0000\u0000\u0000\u00ae\u0430\u0001\u0000\u0000\u0000\u00b0\u0432\u0001"+
		"\u0000\u0000\u0000\u00b2\u043a\u0001\u0000\u0000\u0000\u00b4\u0441\u0001"+
		"\u0000\u0000\u0000\u00b6\u0443\u0001\u0000\u0000\u0000\u00b8\u044e\u0001"+
		"\u0000\u0000\u0000\u00ba\u0456\u0001\u0000\u0000\u0000\u00bc\u045e\u0001"+
		"\u0000\u0000\u0000\u00be\u0460\u0001\u0000\u0000\u0000\u00c0\u046d\u0001"+
		"\u0000\u0000\u0000\u00c2\u0475\u0001\u0000\u0000\u0000\u00c4\u0498\u0001"+
		"\u0000\u0000\u0000\u00c6\u04ba\u0001\u0000\u0000\u0000\u00c8\u04c1\u0001"+
		"\u0000\u0000\u0000\u00ca\u04c3\u0001\u0000\u0000\u0000\u00cc\u04c7\u0001"+
		"\u0000\u0000\u0000\u00ce\u04ce\u0001\u0000\u0000\u0000\u00d0\u04d5\u0001"+
		"\u0000\u0000\u0000\u00d2\u04d8\u0001\u0000\u0000\u0000\u00d4\u04db\u0001"+
		"\u0000\u0000\u0000\u00d6\u04e3\u0001\u0000\u0000\u0000\u00d8\u04ea\u0001"+
		"\u0000\u0000\u0000\u00da\u04ef\u0001\u0000\u0000\u0000\u00dc\u050b\u0001"+
		"\u0000\u0000\u0000\u00de\u050d\u0001\u0000\u0000\u0000\u00e0\u0513\u0001"+
		"\u0000\u0000\u0000\u00e2\u051c\u0001\u0000\u0000\u0000\u00e4\u0523\u0001"+
		"\u0000\u0000\u0000\u00e6\u052a\u0001\u0000\u0000\u0000\u00e8\u0531\u0001"+
		"\u0000\u0000\u0000\u00ea\u0533\u0001\u0000\u0000\u0000\u00ec\u0540\u0001"+
		"\u0000\u0000\u0000\u00ee\u054c\u0001\u0000\u0000\u0000\u00f0\u0551\u0001"+
		"\u0000\u0000\u0000\u00f2\u055e\u0001\u0000\u0000\u0000\u00f4\u0575\u0001"+
		"\u0000\u0000\u0000\u00f6\u0577\u0001\u0000\u0000\u0000\u00f8\u057e\u0001"+
		"\u0000\u0000\u0000\u00fa\u0588\u0001\u0000\u0000\u0000\u00fc\u05aa\u0001"+
		"\u0000\u0000\u0000\u00fe\u05ac\u0001\u0000\u0000\u0000\u0100\u05ae\u0001"+
		"\u0000\u0000\u0000\u0102\u05b0\u0001\u0000\u0000\u0000\u0104\u05be\u0001"+
		"\u0000\u0000\u0000\u0106\u05c2\u0001\u0000\u0000\u0000\u0108\u05c4\u0001"+
		"\u0000\u0000\u0000\u010a\u05cf\u0001\u0000\u0000\u0000\u010c\u05d1\u0001"+
		"\u0000\u0000\u0000\u010e\u05d3\u0001\u0000\u0000\u0000\u0110\u05d5\u0001"+
		"\u0000\u0000\u0000\u0112\u05dc\u0001\u0000\u0000\u0000\u0114\u05de\u0001"+
		"\u0000\u0000\u0000\u0116\u05e0\u0001\u0000\u0000\u0000\u0118\u05ed\u0001"+
		"\u0000\u0000\u0000\u011a\u05ef\u0001\u0000\u0000\u0000\u011c\u05f1\u0001"+
		"\u0000\u0000\u0000\u011e\u05f3\u0001\u0000\u0000\u0000\u0120\u05fc\u0001"+
		"\u0000\u0000\u0000\u0122\u0605\u0001\u0000\u0000\u0000\u0124\u060e\u0001"+
		"\u0000\u0000\u0000\u0126\u0616\u0001\u0000\u0000\u0000\u0128\u061f\u0001"+
		"\u0000\u0000\u0000\u012a\u0628\u0001\u0000\u0000\u0000\u012c\u0631\u0001"+
		"\u0000\u0000\u0000\u012e\u063a\u0001\u0000\u0000\u0000\u0130\u063c\u0001"+
		"\u0000\u0000\u0000\u0132\u0643\u0001\u0000\u0000\u0000\u0134\u0645\u0001"+
		"\u0000\u0000\u0000\u0136\u064c\u0001\u0000\u0000\u0000\u0138\u0658\u0001"+
		"\u0000\u0000\u0000\u013a\u0664\u0001\u0000\u0000\u0000\u013c\u0672\u0001"+
		"\u0000\u0000\u0000\u013e\u0674\u0001\u0000\u0000\u0000\u0140\u0680\u0001"+
		"\u0000\u0000\u0000\u0142\u068f\u0001\u0000\u0000\u0000\u0144\u0691\u0001"+
		"\u0000\u0000\u0000\u0146\u069c\u0001\u0000\u0000\u0000\u0148\u06b5\u0001"+
		"\u0000\u0000\u0000\u014a\u06bb\u0001\u0000\u0000\u0000\u014c\u06c5\u0001"+
		"\u0000\u0000\u0000\u014e\u06e4\u0001\u0000\u0000\u0000\u0150\u06f0\u0001"+
		"\u0000\u0000\u0000\u0152\u06f5\u0001\u0000\u0000\u0000\u0154\u070c\u0001"+
		"\u0000\u0000\u0000\u0156\u0723\u0001\u0000\u0000\u0000\u0158\u0725\u0001"+
		"\u0000\u0000\u0000\u015a\u0727\u0001\u0000\u0000\u0000\u015c\u0729\u0001"+
		"\u0000\u0000\u0000\u015e\u073e\u0001\u0000\u0000\u0000\u0160\u0749\u0001"+
		"\u0000\u0000\u0000\u0162\u074f\u0001\u0000\u0000\u0000\u0164\u0758\u0001"+
		"\u0000\u0000\u0000\u0166\u075e\u0001\u0000\u0000\u0000\u0168\u0760\u0001"+
		"\u0000\u0000\u0000\u016a\u076d\u0001\u0000\u0000\u0000\u016c\u0784\u0001"+
		"\u0000\u0000\u0000\u016e\u0790\u0001\u0000\u0000\u0000\u0170\u079c\u0001"+
		"\u0000\u0000\u0000\u0172\u07a8\u0001\u0000\u0000\u0000\u0174\u07d8\u0001"+
		"\u0000\u0000\u0000\u0176\u07e7\u0001\u0000\u0000\u0000\u0178\u07eb\u0001"+
		"\u0000\u0000\u0000\u017a\u07ed\u0001\u0000\u0000\u0000\u017c\u07ef\u0001"+
		"\u0000\u0000\u0000\u017e\u07f1\u0001\u0000\u0000\u0000\u0180\u07f3\u0001"+
		"\u0000\u0000\u0000\u0182\u07f5\u0001\u0000\u0000\u0000\u0184\u07f9\u0001"+
		"\u0000\u0000\u0000\u0186\u0802\u0001\u0000\u0000\u0000\u0188\u0810\u0001"+
		"\u0000\u0000\u0000\u018a\u082d\u0001\u0000\u0000\u0000\u018c\u0837\u0001"+
		"\u0000\u0000\u0000\u018e\u083c\u0001\u0000\u0000\u0000\u0190\u083e\u0001"+
		"\u0000\u0000\u0000\u0192\u0848\u0001\u0000\u0000\u0000\u0194\u084f\u0001"+
		"\u0000\u0000\u0000\u0196\u0853\u0001\u0000\u0000\u0000\u0198\u0858\u0001"+
		"\u0000\u0000\u0000\u019a\u0860\u0001\u0000\u0000\u0000\u019c\u0862\u0001"+
		"\u0000\u0000\u0000\u019e\u086d\u0001\u0000\u0000\u0000\u01a0\u0875\u0001"+
		"\u0000\u0000\u0000\u01a2\u01a3\u0003\u0002\u0001\u0000\u01a3\u01a4\u0005"+
		"\u0000\u0000\u0001\u01a4\u0001\u0001\u0000\u0000\u0000\u01a5\u01aa\u0003"+
		"\u0004\u0002\u0000\u01a6\u01aa\u0003(\u0014\u0000\u01a7\u01aa\u00030\u0018"+
		"\u0000\u01a8\u01aa\u00032\u0019\u0000\u01a9\u01a5\u0001\u0000\u0000\u0000"+
		"\u01a9\u01a6\u0001\u0000\u0000\u0000\u01a9\u01a7\u0001\u0000\u0000\u0000"+
		"\u01a9\u01a8\u0001\u0000\u0000\u0000\u01aa\u0003\u0001\u0000\u0000\u0000"+
		"\u01ab\u01ac\u0003\u0006\u0003\u0000\u01ac\u0005\u0001\u0000\u0000\u0000"+
		"\u01ad\u01af\u0003\b\u0004\u0000\u01ae\u01ad\u0001\u0000\u0000\u0000\u01ae"+
		"\u01af\u0001\u0000\u0000\u0000\u01af\u01b0\u0001\u0000\u0000\u0000\u01b0"+
		"\u01b6\u0003\u0016\u000b\u0000\u01b1\u01b2\u0003p8\u0000\u01b2\u01b3\u0003"+
		"\u0016\u000b\u0000\u01b3\u01b5\u0001\u0000\u0000\u0000\u01b4\u01b1\u0001"+
		"\u0000\u0000\u0000\u01b5\u01b8\u0001\u0000\u0000\u0000\u01b6\u01b4\u0001"+
		"\u0000\u0000\u0000\u01b6\u01b7\u0001\u0000\u0000\u0000\u01b7\u0007\u0001"+
		"\u0000\u0000\u0000\u01b8\u01b6\u0001\u0000\u0000\u0000\u01b9\u01ba\u0005"+
		"\u00c4\u0000\u0000\u01ba\u01bf\u0003\n\u0005\u0000\u01bb\u01bc\u0005\u0001"+
		"\u0000\u0000\u01bc\u01be\u0003\n\u0005\u0000\u01bd\u01bb\u0001\u0000\u0000"+
		"\u0000\u01be\u01c1\u0001\u0000\u0000\u0000\u01bf\u01bd\u0001\u0000\u0000"+
		"\u0000\u01bf\u01c0\u0001\u0000\u0000\u0000\u01c0\t\u0001\u0000\u0000\u0000"+
		"\u01c1\u01bf\u0001\u0000\u0000\u0000\u01c2\u01c3\u0003\u01a0\u00d0\u0000"+
		"\u01c3\u01c8\u0005!\u0000\u0000\u01c4\u01c6\u0005\u0089\u0000\u0000\u01c5"+
		"\u01c4\u0001\u0000\u0000\u0000\u01c5\u01c6\u0001\u0000\u0000\u0000\u01c6"+
		"\u01c7\u0001\u0000\u0000\u0000\u01c7\u01c9\u0005y\u0000\u0000\u01c8\u01c5"+
		"\u0001\u0000\u0000\u0000\u01c8\u01c9\u0001\u0000\u0000\u0000\u01c9\u01ca"+
		"\u0001\u0000\u0000\u0000\u01ca\u01cb\u0005\u0002\u0000\u0000\u01cb\u01cc"+
		"\u0003\u0006\u0003\u0000\u01cc\u01ce\u0005\u0003\u0000\u0000\u01cd\u01cf"+
		"\u0003\f\u0006\u0000\u01ce\u01cd\u0001\u0000\u0000\u0000\u01ce\u01cf\u0001"+
		"\u0000\u0000\u0000\u01cf\u01d1\u0001\u0000\u0000\u0000\u01d0\u01d2\u0003"+
		"\u0012\t\u0000\u01d1\u01d0\u0001\u0000\u0000\u0000\u01d1\u01d2\u0001\u0000"+
		"\u0000\u0000\u01d2\u000b\u0001\u0000\u0000\u0000\u01d3\u01d4\u0005\u00a6"+
		"\u0000\u0000\u01d4\u01d5\u0007\u0000\u0000\u0000\u01d5\u01d6\u0005Q\u0000"+
		"\u0000\u01d6\u01d7\u0005\'\u0000\u0000\u01d7\u01d8\u0003\u000e\u0007\u0000"+
		"\u01d8\u01d9\u0005\u00a9\u0000\u0000\u01d9\u01da\u0003\u01a0\u00d0\u0000"+
		"\u01da\r\u0001\u0000\u0000\u0000\u01db\u01e0\u0003\u0010\b\u0000\u01dc"+
		"\u01dd\u0005\u0001\u0000\u0000\u01dd\u01df\u0003\u0010\b\u0000\u01de\u01dc"+
		"\u0001\u0000\u0000\u0000\u01df\u01e2\u0001\u0000\u0000\u0000\u01e0\u01de"+
		"\u0001\u0000\u0000\u0000\u01e0\u01e1\u0001\u0000\u0000\u0000\u01e1\u000f"+
		"\u0001\u0000\u0000\u0000\u01e2\u01e0\u0001\u0000\u0000\u0000\u01e3\u01e5"+
		"\u0003\u01a0\u00d0\u0000\u01e4\u01e6\u0003H$\u0000\u01e5\u01e4\u0001\u0000"+
		"\u0000\u0000\u01e5\u01e6\u0001\u0000\u0000\u0000\u01e6\u01e8\u0001\u0000"+
		"\u0000\u0000\u01e7\u01e9\u0003J%\u0000\u01e8\u01e7\u0001\u0000\u0000\u0000"+
		"\u01e8\u01e9\u0001\u0000\u0000\u0000\u01e9\u0011\u0001\u0000\u0000\u0000"+
		"\u01ea\u01eb\u00057\u0000\u0000\u01eb\u01ec\u0003\u0014\n\u0000\u01ec"+
		"\u01ed\u0005\u00a9\u0000\u0000\u01ed\u01f3\u0003\u01a0\u00d0\u0000\u01ee"+
		"\u01ef\u0005\u00b4\u0000\u0000\u01ef\u01f0\u0003r9\u0000\u01f0\u01f1\u0005"+
		";\u0000\u0000\u01f1\u01f2\u0003r9\u0000\u01f2\u01f4\u0001\u0000\u0000"+
		"\u0000\u01f3\u01ee\u0001\u0000\u0000\u0000\u01f3\u01f4\u0001\u0000\u0000"+
		"\u0000\u01f4\u01f7\u0001\u0000\u0000\u0000\u01f5\u01f6\u0005\u00be\u0000"+
		"\u0000\u01f6\u01f8\u0003\u01a0\u00d0\u0000\u01f7\u01f5\u0001\u0000\u0000"+
		"\u0000\u01f7\u01f8\u0001\u0000\u0000\u0000\u01f8\u0013\u0001\u0000\u0000"+
		"\u0000\u01f9\u01fe\u0003\u01a0\u00d0\u0000\u01fa\u01fb\u0005\u0001\u0000"+
		"\u0000\u01fb\u01fd\u0003\u01a0\u00d0\u0000\u01fc\u01fa\u0001\u0000\u0000"+
		"\u0000\u01fd\u0200\u0001\u0000\u0000\u0000\u01fe\u01fc\u0001\u0000\u0000"+
		"\u0000\u01fe\u01ff\u0001\u0000\u0000\u0000\u01ff\u0015\u0001\u0000\u0000"+
		"\u0000\u0200\u01fe\u0001\u0000\u0000\u0000\u0201\u0207\u0003\u0018\f\u0000"+
		"\u0202\u0203\u0005\u0002\u0000\u0000\u0203\u0204\u0003\u0006\u0003\u0000"+
		"\u0204\u0205\u0005\u0003\u0000\u0000\u0205\u0207\u0001\u0000\u0000\u0000"+
		"\u0206\u0201\u0001\u0000\u0000\u0000\u0206\u0202\u0001\u0000\u0000\u0000"+
		"\u0207\u0209\u0001\u0000\u0000\u0000\u0208\u020a\u0003\u001a\r\u0000\u0209"+
		"\u0208\u0001\u0000\u0000\u0000\u0209\u020a\u0001\u0000\u0000\u0000\u020a"+
		"\u020c\u0001\u0000\u0000\u0000\u020b\u020d\u0003L&\u0000\u020c\u020b\u0001"+
		"\u0000\u0000\u0000\u020c\u020d\u0001\u0000\u0000\u0000\u020d\u020f\u0001"+
		"\u0000\u0000\u0000\u020e\u0210\u0003N\'\u0000\u020f\u020e\u0001\u0000"+
		"\u0000\u0000\u020f\u0210\u0001\u0000\u0000\u0000\u0210\u0212\u0001\u0000"+
		"\u0000\u0000\u0211\u0213\u0003P(\u0000\u0212\u0211\u0001\u0000\u0000\u0000"+
		"\u0212\u0213\u0001\u0000\u0000\u0000\u0213\u0017\u0001\u0000\u0000\u0000"+
		"\u0214\u0216\u0003T*\u0000\u0215\u0217\u0003\u001c\u000e\u0000\u0216\u0215"+
		"\u0001\u0000\u0000\u0000\u0216\u0217\u0001\u0000\u0000\u0000\u0217\u0219"+
		"\u0001\u0000\u0000\u0000\u0218\u021a\u0003`0\u0000\u0219\u0218\u0001\u0000"+
		"\u0000\u0000\u0219\u021a\u0001\u0000\u0000\u0000\u021a\u021c\u0001\u0000"+
		"\u0000\u0000\u021b\u021d\u0003j5\u0000\u021c\u021b\u0001\u0000\u0000\u0000"+
		"\u021c\u021d\u0001\u0000\u0000\u0000\u021d\u021f\u0001\u0000\u0000\u0000"+
		"\u021e\u0220\u0003n7\u0000\u021f\u021e\u0001\u0000\u0000\u0000\u021f\u0220"+
		"\u0001\u0000\u0000\u0000\u0220\u022f\u0001\u0000\u0000\u0000\u0221\u0223"+
		"\u0003\u001c\u000e\u0000\u0222\u0224\u0003`0\u0000\u0223\u0222\u0001\u0000"+
		"\u0000\u0000\u0223\u0224\u0001\u0000\u0000\u0000\u0224\u0226\u0001\u0000"+
		"\u0000\u0000\u0225\u0227\u0003j5\u0000\u0226\u0225\u0001\u0000\u0000\u0000"+
		"\u0226\u0227\u0001\u0000\u0000\u0000\u0227\u0229\u0001\u0000\u0000\u0000"+
		"\u0228\u022a\u0003n7\u0000\u0229\u0228\u0001\u0000\u0000\u0000\u0229\u022a"+
		"\u0001\u0000\u0000\u0000\u022a\u022c\u0001\u0000\u0000\u0000\u022b\u022d"+
		"\u0003T*\u0000\u022c\u022b\u0001\u0000\u0000\u0000\u022c\u022d\u0001\u0000"+
		"\u0000\u0000\u022d\u022f\u0001\u0000\u0000\u0000\u022e\u0214\u0001\u0000"+
		"\u0000\u0000\u022e\u0221\u0001\u0000\u0000\u0000\u022f\u0019\u0001\u0000"+
		"\u0000\u0000\u0230\u0231\u0003l6\u0000\u0231\u001b\u0001\u0000\u0000\u0000"+
		"\u0232\u0233\u0005U\u0000\u0000\u0233\u0238\u0003\u001e\u000f\u0000\u0234"+
		"\u0235\u0005\u0001\u0000\u0000\u0235\u0237\u0003\u001e\u000f\u0000\u0236"+
		"\u0234\u0001\u0000\u0000\u0000\u0237\u023a\u0001\u0000\u0000\u0000\u0238"+
		"\u0236\u0001\u0000\u0000\u0000\u0238\u0239\u0001\u0000\u0000\u0000\u0239"+
		"\u001d\u0001\u0000\u0000\u0000\u023a\u0238\u0001\u0000\u0000\u0000\u023b"+
		"\u023f\u0003\"\u0011\u0000\u023c\u023e\u0003 \u0010\u0000\u023d\u023c"+
		"\u0001\u0000\u0000\u0000\u023e\u0241\u0001\u0000\u0000\u0000\u023f\u023d"+
		"\u0001\u0000\u0000\u0000\u023f\u0240\u0001\u0000\u0000\u0000\u0240\u001f"+
		"\u0001\u0000\u0000\u0000\u0241\u023f\u0001\u0000\u0000\u0000\u0242\u0246"+
		"\u0003$\u0012\u0000\u0243\u0246\u0003d2\u0000\u0244\u0246\u0003h4\u0000"+
		"\u0245\u0242\u0001\u0000\u0000\u0000\u0245\u0243\u0001\u0000\u0000\u0000"+
		"\u0245\u0244\u0001\u0000\u0000\u0000\u0246!\u0001\u0000\u0000\u0000\u0247"+
		"\u0249\u0003\u019c\u00ce\u0000\u0248\u024a\u0003\u0198\u00cc\u0000\u0249"+
		"\u0248\u0001\u0000\u0000\u0000\u0249\u024a\u0001\u0000\u0000\u0000\u024a"+
		"\u0255\u0001\u0000\u0000\u0000\u024b\u024d\u0005m\u0000\u0000\u024c\u024b"+
		"\u0001\u0000\u0000\u0000\u024c\u024d\u0001\u0000\u0000\u0000\u024d\u024e"+
		"\u0001\u0000\u0000\u0000\u024e\u024f\u0005\u0002\u0000\u0000\u024f\u0250"+
		"\u0003R)\u0000\u0250\u0252\u0005\u0003\u0000\u0000\u0251\u0253\u0003\u0198"+
		"\u00cc\u0000\u0252\u0251\u0001\u0000\u0000\u0000\u0252\u0253\u0001\u0000"+
		"\u0000\u0000\u0253\u0255\u0001\u0000\u0000\u0000\u0254\u0247\u0001\u0000"+
		"\u0000\u0000\u0254\u024c\u0001\u0000\u0000\u0000\u0255#\u0001\u0000\u0000"+
		"\u0000\u0256\u0257\u0003b1\u0000\u0257\u0259\u0005i\u0000\u0000\u0258"+
		"\u025a\u0005O\u0000\u0000\u0259\u0258\u0001\u0000\u0000\u0000\u0259\u025a"+
		"\u0001\u0000\u0000\u0000\u025a\u025b\u0001\u0000\u0000\u0000\u025b\u025d"+
		"\u0003&\u0013\u0000\u025c\u025e\u0003f3\u0000\u025d\u025c\u0001\u0000"+
		"\u0000\u0000\u025d\u025e\u0001\u0000\u0000\u0000\u025e%\u0001\u0000\u0000"+
		"\u0000\u025f\u0261\u0003\u00c8d\u0000\u0260\u0262\u0003\u0198\u00cc\u0000"+
		"\u0261\u0260\u0001\u0000\u0000\u0000\u0261\u0262\u0001\u0000\u0000\u0000"+
		"\u0262\u026d\u0001\u0000\u0000\u0000\u0263\u0265\u0005m\u0000\u0000\u0264"+
		"\u0263\u0001\u0000\u0000\u0000\u0264\u0265\u0001\u0000\u0000\u0000\u0265"+
		"\u0266\u0001\u0000\u0000\u0000\u0266\u0267\u0005\u0002\u0000\u0000\u0267"+
		"\u0268\u0003R)\u0000\u0268\u026a\u0005\u0003\u0000\u0000\u0269\u026b\u0003"+
		"\u0198\u00cc\u0000\u026a\u0269\u0001\u0000\u0000\u0000\u026a\u026b\u0001"+
		"\u0000\u0000\u0000\u026b\u026d\u0001\u0000\u0000\u0000\u026c\u025f\u0001"+
		"\u0000\u0000\u0000\u026c\u0264\u0001\u0000\u0000\u0000\u026d\'\u0001\u0000"+
		"\u0000\u0000\u026e\u0270\u0005\u00bd\u0000\u0000\u026f\u0271\u0005\u001b"+
		"\u0000\u0000\u0270\u026f\u0001\u0000\u0000\u0000\u0270\u0271\u0001\u0000"+
		"\u0000\u0000\u0271\u0272\u0001\u0000\u0000\u0000\u0272\u0273\u0003*\u0015"+
		"\u0000\u0273\u0275\u0003,\u0016\u0000\u0274\u0276\u0003`0\u0000\u0275"+
		"\u0274\u0001\u0000\u0000\u0000\u0275\u0276\u0001\u0000\u0000\u0000\u0276"+
		")\u0001\u0000\u0000\u0000\u0277\u0279\u0003\u019c\u00ce\u0000\u0278\u027a"+
		"\u0003\u0198\u00cc\u0000\u0279\u0278\u0001\u0000\u0000\u0000\u0279\u027a"+
		"\u0001\u0000\u0000\u0000\u027a+\u0001\u0000\u0000\u0000\u027b\u027c\u0005"+
		"\u00a9\u0000\u0000\u027c\u0281\u0003.\u0017\u0000\u027d\u027e\u0005\u0001"+
		"\u0000\u0000\u027e\u0280\u0003.\u0017\u0000\u027f\u027d\u0001\u0000\u0000"+
		"\u0000\u0280\u0283\u0001\u0000\u0000\u0000\u0281\u027f\u0001\u0000\u0000"+
		"\u0000\u0281\u0282\u0001\u0000\u0000\u0000\u0282-\u0001\u0000\u0000\u0000"+
		"\u0283\u0281\u0001\u0000\u0000\u0000\u0284\u0285\u0003\u00ceg\u0000\u0285"+
		"\u0286\u0005\u0004\u0000\u0000\u0286\u0287\u0003\u0176\u00bb\u0000\u0287"+
		"/\u0001\u0000\u0000\u0000\u0288\u028a\u0005<\u0000\u0000\u0289\u028b\u0005"+
		"U\u0000\u0000\u028a\u0289\u0001\u0000\u0000\u0000\u028a\u028b\u0001\u0000"+
		"\u0000\u0000\u028b\u028c\u0001\u0000\u0000\u0000\u028c\u028e\u0003*\u0015"+
		"\u0000\u028d\u028f\u0003`0\u0000\u028e\u028d\u0001\u0000\u0000\u0000\u028e"+
		"\u028f\u0001\u0000\u0000\u0000\u028f1\u0001\u0000\u0000\u0000\u0290\u0292"+
		"\u0005c\u0000\u0000\u0291\u0293\u0005g\u0000\u0000\u0292\u0291\u0001\u0000"+
		"\u0000\u0000\u0292\u0293\u0001\u0000\u0000\u0000\u0293\u0294\u0001\u0000"+
		"\u0000\u0000\u0294\u0295\u0003*\u0015\u0000\u0295\u0298\u00034\u001a\u0000"+
		"\u0296\u0299\u0003\u0006\u0003\u0000\u0297\u0299\u00036\u001b\u0000\u0298"+
		"\u0296\u0001\u0000\u0000\u0000\u0298\u0297\u0001\u0000\u0000\u0000\u0299"+
		"\u029b\u0001\u0000\u0000\u0000\u029a\u029c\u0003:\u001d\u0000\u029b\u029a"+
		"\u0001\u0000\u0000\u0000\u029b\u029c\u0001\u0000\u0000\u0000\u029c3\u0001"+
		"\u0000\u0000\u0000\u029d\u029e\u0005\u0002\u0000\u0000\u029e\u02a3\u0003"+
		"\u00ceg\u0000\u029f\u02a0\u0005\u0001\u0000\u0000\u02a0\u02a2\u0003\u00ce"+
		"g\u0000\u02a1\u029f\u0001\u0000\u0000\u0000\u02a2\u02a5\u0001\u0000\u0000"+
		"\u0000\u02a3\u02a1\u0001\u0000\u0000\u0000\u02a3\u02a4\u0001\u0000\u0000"+
		"\u0000\u02a4\u02a6\u0001\u0000\u0000\u0000\u02a5\u02a3\u0001\u0000\u0000"+
		"\u0000\u02a6\u02a7\u0005\u0003\u0000\u0000\u02a75\u0001\u0000\u0000\u0000"+
		"\u02a8\u02a9\u0005\u00c0\u0000\u0000\u02a9\u02ae\u00038\u001c\u0000\u02aa"+
		"\u02ab\u0005\u0001\u0000\u0000\u02ab\u02ad\u00038\u001c\u0000\u02ac\u02aa"+
		"\u0001\u0000\u0000\u0000\u02ad\u02b0\u0001\u0000\u0000\u0000\u02ae\u02ac"+
		"\u0001\u0000\u0000\u0000\u02ae\u02af\u0001\u0000\u0000\u0000\u02af7\u0001"+
		"\u0000\u0000\u0000\u02b0\u02ae\u0001\u0000\u0000\u0000\u02b1\u02b2\u0005"+
		"\u0002\u0000\u0000\u02b2\u02b7\u0003\u00c4b\u0000\u02b3\u02b4\u0005\u0001"+
		"\u0000\u0000\u02b4\u02b6\u0003\u00c4b\u0000\u02b5\u02b3\u0001\u0000\u0000"+
		"\u0000\u02b6\u02b9\u0001\u0000\u0000\u0000\u02b7\u02b5\u0001\u0000\u0000"+
		"\u0000\u02b7\u02b8\u0001\u0000\u0000\u0000\u02b8\u02ba\u0001\u0000\u0000"+
		"\u0000\u02b9\u02b7\u0001\u0000\u0000\u0000\u02ba\u02bb\u0005\u0003\u0000"+
		"\u0000\u02bb9\u0001\u0000\u0000\u0000\u02bc\u02bd\u0005\u0090\u0000\u0000"+
		"\u02bd\u02bf\u0005,\u0000\u0000\u02be\u02c0\u0003<\u001e\u0000\u02bf\u02be"+
		"\u0001\u0000\u0000\u0000\u02bf\u02c0\u0001\u0000\u0000\u0000\u02c0\u02c1"+
		"\u0001\u0000\u0000\u0000\u02c1\u02c2\u0005@\u0000\u0000\u02c2\u02c3\u0003"+
		">\u001f\u0000\u02c3;\u0001\u0000\u0000\u0000\u02c4\u02c5\u0005\u0090\u0000"+
		"\u0000\u02c5\u02c6\u0005-\u0000\u0000\u02c6\u02d3\u0003\u01a0\u00d0\u0000"+
		"\u02c7\u02c8\u0005\u0002\u0000\u0000\u02c8\u02cd\u0003\u00ceg\u0000\u02c9"+
		"\u02ca\u0005\u0001\u0000\u0000\u02ca\u02cc\u0003\u00ceg\u0000\u02cb\u02c9"+
		"\u0001\u0000\u0000\u0000\u02cc\u02cf\u0001\u0000\u0000\u0000\u02cd\u02cb"+
		"\u0001\u0000\u0000\u0000\u02cd\u02ce\u0001\u0000\u0000\u0000\u02ce\u02d0"+
		"\u0001\u0000\u0000\u0000\u02cf\u02cd\u0001\u0000\u0000\u0000\u02d0\u02d1"+
		"\u0005\u0003\u0000\u0000\u02d1\u02d3\u0001\u0000\u0000\u0000\u02d2\u02c4"+
		"\u0001\u0000\u0000\u0000\u02d2\u02c7\u0001\u0000\u0000\u0000\u02d3=\u0001"+
		"\u0000\u0000\u0000\u02d4\u02db\u0005\u008a\u0000\u0000\u02d5\u02d6\u0005"+
		"\u00bd\u0000\u0000\u02d6\u02d8\u0003,\u0016\u0000\u02d7\u02d9\u0003`0"+
		"\u0000\u02d8\u02d7\u0001\u0000\u0000\u0000\u02d8\u02d9\u0001\u0000\u0000"+
		"\u0000\u02d9\u02db\u0001\u0000\u0000\u0000\u02da\u02d4\u0001\u0000\u0000"+
		"\u0000\u02da\u02d5\u0001\u0000\u0000\u0000\u02db?\u0001\u0000\u0000\u0000"+
		"\u02dc\u02dd\u0005\u0086\u0000\u0000\u02dd\u02de\u0003\u018e\u00c7\u0000"+
		"\u02de\u02df\u0005\u0002\u0000\u0000\u02df\u02e0\u0003\u0190\u00c8\u0000"+
		"\u02e0\u02e1\u0005\u0003\u0000\u0000\u02e1A\u0001\u0000\u0000\u0000\u02e2"+
		"\u02e6\u0003\u01a0\u00d0\u0000\u02e3\u02e6\u0005\u00ce\u0000\u0000\u02e4"+
		"\u02e6\u0003\u00c4b\u0000\u02e5\u02e2\u0001\u0000\u0000\u0000\u02e5\u02e3"+
		"\u0001\u0000\u0000\u0000\u02e5\u02e4\u0001\u0000\u0000\u0000\u02e6C\u0001"+
		"\u0000\u0000\u0000\u02e7\u02e9\u0003F#\u0000\u02e8\u02ea\u0003H$\u0000"+
		"\u02e9\u02e8\u0001\u0000\u0000\u0000\u02e9\u02ea\u0001\u0000\u0000\u0000"+
		"\u02ea\u02ec\u0001\u0000\u0000\u0000\u02eb\u02ed\u0003J%\u0000\u02ec\u02eb"+
		"\u0001\u0000\u0000\u0000\u02ec\u02ed\u0001\u0000\u0000\u0000\u02edE\u0001"+
		"\u0000\u0000\u0000\u02ee\u02f2\u0003\u01a0\u00d0\u0000\u02ef\u02f2\u0005"+
		"\u00ce\u0000\u0000\u02f0\u02f2\u0003\u00c4b\u0000\u02f1\u02ee\u0001\u0000"+
		"\u0000\u0000\u02f1\u02ef\u0001\u0000\u0000\u0000\u02f1\u02f0\u0001\u0000"+
		"\u0000\u0000\u02f2G\u0001\u0000\u0000\u0000\u02f3\u02f4\u0007\u0001\u0000"+
		"\u0000\u02f4I\u0001\u0000\u0000\u0000\u02f5\u02f6\u0005\u008b\u0000\u0000"+
		"\u02f6\u02f7\u0007\u0002\u0000\u0000\u02f7K\u0001\u0000\u0000\u0000\u02f8"+
		"\u02f9\u0005q\u0000\u0000\u02f9\u02fa\u0003\u0194\u00ca\u0000\u02faM\u0001"+
		"\u0000\u0000\u0000\u02fb\u02fc\u0005\u008e\u0000\u0000\u02fc\u02fe\u0003"+
		"\u0194\u00ca\u0000\u02fd\u02ff\u0007\u0003\u0000\u0000\u02fe\u02fd\u0001"+
		"\u0000\u0000\u0000\u02fe\u02ff\u0001\u0000\u0000\u0000\u02ffO\u0001\u0000"+
		"\u0000\u0000\u0300\u0301\u0005O\u0000\u0000\u0301\u0306\u0007\u0004\u0000"+
		"\u0000\u0302\u0307\u0003\u0194\u00ca\u0000\u0303\u0304\u0003\u0196\u00cb"+
		"\u0000\u0304\u0305\u0005\u0005\u0000\u0000\u0305\u0307\u0001\u0000\u0000"+
		"\u0000\u0306\u0302\u0001\u0000\u0000\u0000\u0306\u0303\u0001\u0000\u0000"+
		"\u0000\u0307\u0308\u0001\u0000\u0000\u0000\u0308\u030c\u0007\u0003\u0000"+
		"\u0000\u0309\u030d\u0005\u0091\u0000\u0000\u030a\u030b\u0005\u00c4\u0000"+
		"\u0000\u030b\u030d\u0005\u00af\u0000\u0000\u030c\u0309\u0001\u0000\u0000"+
		"\u0000\u030c\u030a\u0001\u0000\u0000\u0000\u030dQ\u0001\u0000\u0000\u0000"+
		"\u030e\u030f\u0003\u0006\u0003\u0000\u030fS\u0001\u0000\u0000\u0000\u0310"+
		"\u0312\u0005\u00a8\u0000\u0000\u0311\u0313\u0005?\u0000\u0000\u0312\u0311"+
		"\u0001\u0000\u0000\u0000\u0312\u0313\u0001\u0000\u0000\u0000\u0313\u0314"+
		"\u0001\u0000\u0000\u0000\u0314\u0315\u0003V+\u0000\u0315U\u0001\u0000"+
		"\u0000\u0000\u0316\u031b\u0003X,\u0000\u0317\u0318\u0005\u0001\u0000\u0000"+
		"\u0318\u031a\u0003X,\u0000\u0319\u0317\u0001\u0000\u0000\u0000\u031a\u031d"+
		"\u0001\u0000\u0000\u0000\u031b\u0319\u0001\u0000\u0000\u0000\u031b\u031c"+
		"\u0001\u0000\u0000\u0000\u031cW\u0001\u0000\u0000\u0000\u031d\u031b\u0001"+
		"\u0000\u0000\u0000\u031e\u0320\u0003Z-\u0000\u031f\u0321\u0003\u0198\u00cc"+
		"\u0000\u0320\u031f\u0001\u0000\u0000\u0000\u0320\u0321\u0001\u0000\u0000"+
		"\u0000\u0321Y\u0001\u0000\u0000\u0000\u0322\u0327\u0003@ \u0000\u0323"+
		"\u0327\u0003\\.\u0000\u0324\u0327\u0003^/\u0000\u0325\u0327\u0003\u0176"+
		"\u00bb\u0000\u0326\u0322\u0001\u0000\u0000\u0000\u0326\u0323\u0001\u0000"+
		"\u0000\u0000\u0326\u0324\u0001\u0000\u0000\u0000\u0326\u0325\u0001\u0000"+
		"\u0000\u0000\u0327[\u0001\u0000\u0000\u0000\u0328\u0329\u0005F\u0000\u0000"+
		"\u0329\u032a\u0005\u0002\u0000\u0000\u032a\u032b\u0003\u00c8d\u0000\u032b"+
		"\u032c\u0005\u0003\u0000\u0000\u032c]\u0001\u0000\u0000\u0000\u032d\u032e"+
		"\u0005\u008c\u0000\u0000\u032e\u032f\u0005\u0002\u0000\u0000\u032f\u0330"+
		"\u0003\u01a0\u00d0\u0000\u0330\u0331\u0005\u0003\u0000\u0000\u0331_\u0001"+
		"\u0000\u0000\u0000\u0332\u0333\u0005\u00c3\u0000\u0000\u0333\u0338\u0003"+
		"\u0174\u00ba\u0000\u0334\u0335\u0005\u0001\u0000\u0000\u0335\u0337\u0003"+
		"\u0174\u00ba\u0000\u0336\u0334\u0001\u0000\u0000\u0000\u0337\u033a\u0001"+
		"\u0000\u0000\u0000\u0338\u0336\u0001\u0000\u0000\u0000\u0338\u0339\u0001"+
		"\u0000\u0000\u0000\u0339a\u0001\u0000\u0000\u0000\u033a\u0338\u0001\u0000"+
		"\u0000\u0000\u033b\u033d\u0005b\u0000\u0000\u033c\u033b\u0001\u0000\u0000"+
		"\u0000\u033c\u033d\u0001\u0000\u0000\u0000\u033d\u0346\u0001\u0000\u0000"+
		"\u0000\u033e\u0340\u0007\u0005\u0000\u0000\u033f\u033e\u0001\u0000\u0000"+
		"\u0000\u033f\u0340\u0001\u0000\u0000\u0000\u0340\u0342\u0001\u0000\u0000"+
		"\u0000\u0341\u0343\u0005\u0095\u0000\u0000\u0342\u0341\u0001\u0000\u0000"+
		"\u0000\u0342\u0343\u0001\u0000\u0000\u0000\u0343\u0346\u0001\u0000\u0000"+
		"\u0000\u0344\u0346\u00050\u0000\u0000\u0345\u033c\u0001\u0000\u0000\u0000"+
		"\u0345\u033f\u0001\u0000\u0000\u0000\u0345\u0344\u0001\u0000\u0000\u0000"+
		"\u0346c\u0001\u0000\u0000\u0000\u0347\u0348\u00050\u0000\u0000\u0348\u0349"+
		"\u0005i\u0000\u0000\u0349\u034b\u0003\u019c\u00ce\u0000\u034a\u034c\u0003"+
		"\u0198\u00cc\u0000\u034b\u034a\u0001\u0000\u0000\u0000\u034b\u034c\u0001"+
		"\u0000\u0000\u0000\u034ce\u0001\u0000\u0000\u0000\u034d\u034e\u0007\u0006"+
		"\u0000\u0000\u034e\u034f\u0003\u0174\u00ba\u0000\u034fg\u0001\u0000\u0000"+
		"\u0000\u0350\u0351\u0005\u0001\u0000\u0000\u0351\u0352\u0005^\u0000\u0000"+
		"\u0352\u0353\u0005\u0002\u0000\u0000\u0353\u0354\u0003\u00c8d\u0000\u0354"+
		"\u0356\u0005\u0003\u0000\u0000\u0355\u0357\u0003\u0198\u00cc\u0000\u0356"+
		"\u0355\u0001\u0000\u0000\u0000\u0356\u0357\u0001\u0000\u0000\u0000\u0357"+
		"i\u0001\u0000\u0000\u0000\u0358\u0359\u0005X\u0000\u0000\u0359\u035a\u0005"+
		"\'\u0000\u0000\u035a\u035f\u0003B!\u0000\u035b\u035c\u0005\u0001\u0000"+
		"\u0000\u035c\u035e\u0003B!\u0000\u035d\u035b\u0001\u0000\u0000\u0000\u035e"+
		"\u0361\u0001\u0000\u0000\u0000\u035f\u035d\u0001\u0000\u0000\u0000\u035f"+
		"\u0360\u0001\u0000\u0000\u0000\u0360k\u0001\u0000\u0000\u0000\u0361\u035f"+
		"\u0001\u0000\u0000\u0000\u0362\u0363\u0005\u0093\u0000\u0000\u0363\u0364"+
		"\u0005\'\u0000\u0000\u0364\u0369\u0003D\"\u0000\u0365\u0366\u0005\u0001"+
		"\u0000\u0000\u0366\u0368\u0003D\"\u0000\u0367\u0365\u0001\u0000\u0000"+
		"\u0000\u0368\u036b\u0001\u0000\u0000\u0000\u0369\u0367\u0001\u0000\u0000"+
		"\u0000\u0369\u036a\u0001\u0000\u0000\u0000\u036am\u0001\u0000\u0000\u0000"+
		"\u036b\u0369\u0001\u0000\u0000\u0000\u036c\u036d\u0005Z\u0000\u0000\u036d"+
		"\u0372\u0003\u0174\u00ba\u0000\u036e\u036f\u0005\u0001\u0000\u0000\u036f"+
		"\u0371\u0003\u0174\u00ba\u0000\u0370\u036e\u0001\u0000\u0000\u0000\u0371"+
		"\u0374\u0001\u0000\u0000\u0000\u0372\u0370\u0001\u0000\u0000\u0000\u0372"+
		"\u0373\u0001\u0000\u0000\u0000\u0373o\u0001\u0000\u0000\u0000\u0374\u0372"+
		"\u0001\u0000\u0000\u0000\u0375\u0377\u0005\u00bc\u0000\u0000\u0376\u0378"+
		"\u0005\u001e\u0000\u0000\u0377\u0376\u0001\u0000\u0000\u0000\u0377\u0378"+
		"\u0001\u0000\u0000\u0000\u0378\u0382\u0001\u0000\u0000\u0000\u0379\u037b"+
		"\u0005e\u0000\u0000\u037a\u037c\u0005\u001e\u0000\u0000\u037b\u037a\u0001"+
		"\u0000\u0000\u0000\u037b\u037c\u0001\u0000\u0000\u0000\u037c\u0382\u0001"+
		"\u0000\u0000\u0000\u037d\u037f\u0005K\u0000\u0000\u037e\u0380\u0005\u001e"+
		"\u0000\u0000\u037f\u037e\u0001\u0000\u0000\u0000\u037f\u0380\u0001\u0000"+
		"\u0000\u0000\u0380\u0382\u0001\u0000\u0000\u0000\u0381\u0375\u0001\u0000"+
		"\u0000\u0000\u0381\u0379\u0001\u0000\u0000\u0000\u0381\u037d\u0001\u0000"+
		"\u0000\u0000\u0382q\u0001\u0000\u0000\u0000\u0383\u038d\u0005\u00cc\u0000"+
		"\u0000\u0384\u038d\u0005\u00cd\u0000\u0000\u0385\u038d\u0005\u00c9\u0000"+
		"\u0000\u0386\u038d\u0003t:\u0000\u0387\u038d\u0003v;\u0000\u0388\u038d"+
		"\u0003\u00c0`\u0000\u0389\u038d\u0003\u00c2a\u0000\u038a\u038d\u0003\u0096"+
		"K\u0000\u038b\u038d\u0003\u0098L\u0000\u038c\u0383\u0001\u0000\u0000\u0000"+
		"\u038c\u0384\u0001\u0000\u0000\u0000\u038c\u0385\u0001\u0000\u0000\u0000"+
		"\u038c\u0386\u0001\u0000\u0000\u0000\u038c\u0387\u0001\u0000\u0000\u0000"+
		"\u038c\u0388\u0001\u0000\u0000\u0000\u038c\u0389\u0001\u0000\u0000\u0000"+
		"\u038c\u038a\u0001\u0000\u0000\u0000\u038c\u038b\u0001\u0000\u0000\u0000"+
		"\u038ds\u0001\u0000\u0000\u0000\u038e\u038f\u0007\u0007\u0000\u0000\u038f"+
		"u\u0001\u0000\u0000\u0000\u0390\u0391\u0007\b\u0000\u0000\u0391w\u0001"+
		"\u0000\u0000\u0000\u0392\u0396\u0003z=\u0000\u0393\u0396\u0003|>\u0000"+
		"\u0394\u0396\u0003~?\u0000\u0395\u0392\u0001\u0000\u0000\u0000\u0395\u0393"+
		"\u0001\u0000\u0000\u0000\u0395\u0394\u0001\u0000\u0000\u0000\u0396y\u0001"+
		"\u0000\u0000\u0000\u0397\u0398\u0005\u0002\u0000\u0000\u0398\u0399\u0003"+
		"\u0086C\u0000\u0399\u039a\u0005\u0003\u0000\u0000\u039a\u03a1\u0001\u0000"+
		"\u0000\u0000\u039b\u039d\u0005t\u0000\u0000\u039c\u039b\u0001\u0000\u0000"+
		"\u0000\u039c\u039d\u0001\u0000\u0000\u0000\u039d\u039e\u0001\u0000\u0000"+
		"\u0000\u039e\u039f\u00059\u0000\u0000\u039f\u03a1\u0003\u0086C\u0000\u03a0"+
		"\u0397\u0001\u0000\u0000\u0000\u03a0\u039c\u0001\u0000\u0000\u0000\u03a1"+
		"{\u0001\u0000\u0000\u0000\u03a2\u03a3\u0005\u0002\u0000\u0000\u03a3\u03a4"+
		"\u0003\u0088D\u0000\u03a4\u03a5\u0005\u0003\u0000\u0000\u03a5\u03ac\u0001"+
		"\u0000\u0000\u0000\u03a6\u03a8\u0005\u00c8\u0000\u0000\u03a7\u03a6\u0001"+
		"\u0000\u0000\u0000\u03a7\u03a8\u0001\u0000\u0000\u0000\u03a8\u03a9\u0001"+
		"\u0000\u0000\u0000\u03a9\u03aa\u00059\u0000\u0000\u03aa\u03ac\u0003\u0088"+
		"D\u0000\u03ab\u03a2\u0001\u0000\u0000\u0000\u03ab\u03a7\u0001\u0000\u0000"+
		"\u0000\u03ac}\u0001\u0000\u0000\u0000\u03ad\u03ae\u0005\u0002\u0000\u0000"+
		"\u03ae\u03af\u0003\u008aE\u0000\u03af\u03b0\u0005\u0003\u0000\u0000\u03b0"+
		"\u03b7\u0001\u0000\u0000\u0000\u03b1\u03b3\u0005\u008e\u0000\u0000\u03b2"+
		"\u03b1\u0001\u0000\u0000\u0000\u03b2\u03b3\u0001\u0000\u0000\u0000\u03b3"+
		"\u03b4\u0001\u0000\u0000\u0000\u03b4\u03b5\u00059\u0000\u0000\u03b5\u03b7"+
		"\u0003\u008cF\u0000\u03b6\u03ad\u0001\u0000\u0000\u0000\u03b6\u03b2\u0001"+
		"\u0000\u0000\u0000\u03b7\u007f\u0001\u0000\u0000\u0000\u03b8\u03b9\u0005"+
		"\u0002\u0000\u0000\u03b9\u03ba\u0003\u009eO\u0000\u03ba\u03bb\u0005\u0003"+
		"\u0000\u0000\u03bb\u03c2\u0001\u0000\u0000\u0000\u03bc\u03be\u0005t\u0000"+
		"\u0000\u03bd\u03bc\u0001\u0000\u0000\u0000\u03bd\u03be\u0001\u0000\u0000"+
		"\u0000\u03be\u03bf\u0001\u0000\u0000\u0000\u03bf\u03c0\u00058\u0000\u0000"+
		"\u03c0\u03c2\u0003\u009eO\u0000\u03c1\u03b8\u0001\u0000\u0000\u0000\u03c1"+
		"\u03bd\u0001\u0000\u0000\u0000\u03c2\u0081\u0001\u0000\u0000\u0000\u03c3"+
		"\u03c4\u0005\u0002\u0000\u0000\u03c4\u03c5\u0003\u00a0P\u0000\u03c5\u03c6"+
		"\u0005\u0003\u0000\u0000\u03c6\u03cd\u0001\u0000\u0000\u0000\u03c7\u03c9"+
		"\u0005t\u0000\u0000\u03c8\u03c7\u0001\u0000\u0000\u0000\u03c8\u03c9\u0001"+
		"\u0000\u0000\u0000\u03c9\u03ca\u0001\u0000\u0000\u0000\u03ca\u03cb\u0005"+
		"\u00b0\u0000\u0000\u03cb\u03cd\u0003\u00a0P\u0000\u03cc\u03c3\u0001\u0000"+
		"\u0000\u0000\u03cc\u03c8\u0001\u0000\u0000\u0000\u03cd\u0083\u0001\u0000"+
		"\u0000\u0000\u03ce\u03d2\u0003\u0086C\u0000\u03cf\u03d2\u0003\u0088D\u0000"+
		"\u03d0\u03d2\u0003\u008aE\u0000\u03d1\u03ce\u0001\u0000\u0000\u0000\u03d1"+
		"\u03cf\u0001\u0000\u0000\u0000\u03d1\u03d0\u0001\u0000\u0000\u0000\u03d2"+
		"\u0085\u0001\u0000\u0000\u0000\u03d3\u03d4\u0003\u009eO\u0000\u03d4\u03d5"+
		"\u0003\u00a0P\u0000\u03d5\u0087\u0001\u0000\u0000\u0000\u03d6\u03d7\u0003"+
		"\u009eO\u0000\u03d7\u03d8\u0003\u00a0P\u0000\u03d8\u03d9\u0003\u00b2Y"+
		"\u0000\u03d9\u0089\u0001\u0000\u0000\u0000\u03da\u03db\u0003\u009eO\u0000"+
		"\u03db\u03dc\u0003\u00a0P\u0000\u03dc\u03dd\u0003\u00a2Q\u0000\u03dd\u008b"+
		"\u0001\u0000\u0000\u0000\u03de\u03df\u0003\u009eO\u0000\u03df\u03e0\u0003"+
		"\u00a0P\u0000\u03e0\u03e1\u0003\u00a4R\u0000\u03e1\u008d\u0001\u0000\u0000"+
		"\u0000\u03e2\u03e5\u0005\u00d6\u0000\u0000\u03e3\u03e6\u0003\u0084B\u0000"+
		"\u03e4\u03e6\u0003\u0094J\u0000\u03e5\u03e3\u0001\u0000\u0000\u0000\u03e5"+
		"\u03e4\u0001\u0000\u0000\u0000\u03e6\u03e7\u0001\u0000\u0000\u0000\u03e7"+
		"\u03e8\u0005\u0006\u0000\u0000\u03e8\u008f\u0001\u0000\u0000\u0000\u03e9"+
		"\u03ec\u0005\u00d7\u0000\u0000\u03ea\u03ed\u0003\u009eO\u0000\u03eb\u03ed"+
		"\u0003\u0094J\u0000\u03ec\u03ea\u0001\u0000\u0000\u0000\u03ec\u03eb\u0001"+
		"\u0000\u0000\u0000\u03ed\u03ee\u0001\u0000\u0000\u0000\u03ee\u03ef\u0005"+
		"\u0006\u0000\u0000\u03ef\u0091\u0001\u0000\u0000\u0000\u03f0\u03f3\u0005"+
		"\u00d8\u0000\u0000\u03f1\u03f4\u0003\u00a0P\u0000\u03f2\u03f4\u0003\u0094"+
		"J\u0000\u03f3\u03f1\u0001\u0000\u0000\u0000\u03f3\u03f2\u0001\u0000\u0000"+
		"\u0000\u03f4\u03f5\u0001\u0000\u0000\u0000\u03f5\u03f6\u0005\u0006\u0000"+
		"\u0000\u03f6\u0093\u0001\u0000\u0000\u0000\u03f7\u03f8\u0005\u00cc\u0000"+
		"\u0000\u03f8\u0095\u0001\u0000\u0000\u0000\u03f9\u0402\u0005\u0007\u0000"+
		"\u0000\u03fa\u03ff\u0003\u00c4b\u0000\u03fb\u03fc\u0005\u0001\u0000\u0000"+
		"\u03fc\u03fe\u0003\u00c4b\u0000\u03fd\u03fb\u0001\u0000\u0000\u0000\u03fe"+
		"\u0401\u0001\u0000\u0000\u0000\u03ff\u03fd\u0001\u0000\u0000\u0000\u03ff"+
		"\u0400\u0001\u0000\u0000\u0000\u0400\u0403\u0001\u0000\u0000\u0000\u0401"+
		"\u03ff\u0001\u0000\u0000\u0000\u0402\u03fa\u0001\u0000\u0000\u0000\u0402"+
		"\u0403\u0001\u0000\u0000\u0000\u0403\u0404\u0001\u0000\u0000\u0000\u0404"+
		"\u0405\u0005\b\u0000\u0000\u0405\u0097\u0001\u0000\u0000\u0000\u0406\u0407"+
		"\u0005\u0002\u0000\u0000\u0407\u0408\u0003\u009aM\u0000\u0408\u0409\u0005"+
		"\t\u0000\u0000\u0409\u040a\u0003\u009cN\u0000\u040a\u040b\u0005\u0003"+
		"\u0000\u0000\u040b\u0099\u0001\u0000\u0000\u0000\u040c\u040d\u0005\u00cc"+
		"\u0000\u0000\u040d\u009b\u0001\u0000\u0000\u0000\u040e\u040f\u0005\u00cc"+
		"\u0000\u0000\u040f\u009d\u0001\u0000\u0000\u0000\u0410\u0411\u0003\u00a6"+
		"S\u0000\u0411\u0412\u0005\u00da\u0000\u0000\u0412\u0413\u0003\u00a8T\u0000"+
		"\u0413\u0414\u0005\u00da\u0000\u0000\u0414\u0415\u0003\u00aaU\u0000\u0415"+
		"\u009f\u0001\u0000\u0000\u0000\u0416\u0417\u0003\u00acV\u0000\u0417\u0418"+
		"\u0005\t\u0000\u0000\u0418\u041b\u0003\u00aeW\u0000\u0419\u041a\u0005"+
		"\t\u0000\u0000\u041a\u041c\u0003\u00b0X\u0000\u041b\u0419\u0001\u0000"+
		"\u0000\u0000\u041b\u041c\u0001\u0000\u0000\u0000\u041c\u00a1\u0001\u0000"+
		"\u0000\u0000\u041d\u041e\u0007\t\u0000\u0000\u041e\u0421\u0003\u00acV"+
		"\u0000\u041f\u0420\u0005\t\u0000\u0000\u0420\u0422\u0003\u00aeW\u0000"+
		"\u0421\u041f\u0001\u0000\u0000\u0000\u0421\u0422\u0001\u0000\u0000\u0000"+
		"\u0422\u00a3\u0001\u0000\u0000\u0000\u0423\u0424\u0007\t\u0000\u0000\u0424"+
		"\u0425\u0003\u00acV\u0000\u0425\u0426\u0005\t\u0000\u0000\u0426\u0427"+
		"\u0003\u00aeW\u0000\u0427\u00a5\u0001\u0000\u0000\u0000\u0428\u0429\u0005"+
		"\u00ce\u0000\u0000\u0429\u00a7\u0001\u0000\u0000\u0000\u042a\u042b\u0005"+
		"\u00ce\u0000\u0000\u042b\u00a9\u0001\u0000\u0000\u0000\u042c\u042d\u0005"+
		"\u00ce\u0000\u0000\u042d\u00ab\u0001\u0000\u0000\u0000\u042e\u042f\u0005"+
		"\u00ce\u0000\u0000\u042f\u00ad\u0001\u0000\u0000\u0000\u0430\u0431\u0005"+
		"\u00ce\u0000\u0000\u0431\u00af\u0001\u0000\u0000\u0000\u0432\u0433\u0007"+
		"\n\u0000\u0000\u0433\u00b1\u0001\u0000\u0000\u0000\u0434\u0437\u0005\u00db"+
		"\u0000\u0000\u0435\u0436\u0005\n\u0000\u0000\u0436\u0438\u0005\u00db\u0000"+
		"\u0000\u0437\u0435\u0001\u0000\u0000\u0000\u0437\u0438\u0001\u0000\u0000"+
		"\u0000\u0438\u043b\u0001\u0000\u0000\u0000\u0439\u043b\u0005\u00cc\u0000"+
		"\u0000\u043a\u0434\u0001\u0000\u0000\u0000\u043a\u0439\u0001\u0000\u0000"+
		"\u0000\u043b\u00b3\u0001\u0000\u0000\u0000\u043c\u0442\u0003\u00b6[\u0000"+
		"\u043d\u0442\u0003\u00b8\\\u0000\u043e\u0442\u0003\u00ba]\u0000\u043f"+
		"\u0442\u0003\u00bc^\u0000\u0440\u0442\u0003\u00be_\u0000\u0441\u043c\u0001"+
		"\u0000\u0000\u0000\u0441\u043d\u0001\u0000\u0000\u0000\u0441\u043e\u0001"+
		"\u0000\u0000\u0000\u0441\u043f\u0001\u0000\u0000\u0000\u0441\u0440\u0001"+
		"\u0000\u0000\u0000\u0442\u00b5\u0001\u0000\u0000\u0000\u0443\u0444\u0007"+
		"\u000b\u0000\u0000\u0444\u00b7\u0001\u0000\u0000\u0000\u0445\u0446\u0005"+
		":\u0000\u0000\u0446\u0447\u0005\u008d\u0000\u0000\u0447\u044f\u0005\u0084"+
		"\u0000\u0000\u0448\u0449\u0005:\u0000\u0000\u0449\u044a\u0005\u008d\u0000"+
		"\u0000\u044a\u044f\u0005\u00c1\u0000\u0000\u044b\u044c\u0005:\u0000\u0000"+
		"\u044c\u044d\u0005\u008d\u0000\u0000\u044d\u044f\u0005\u00c7\u0000\u0000"+
		"\u044e\u0445\u0001\u0000\u0000\u0000\u044e\u0448\u0001\u0000\u0000\u0000"+
		"\u044e\u044b\u0001\u0000\u0000\u0000\u044f\u00b9\u0001\u0000\u0000\u0000"+
		"\u0450\u0451\u0005\u00c1\u0000\u0000\u0451\u0452\u0005\u008d\u0000\u0000"+
		"\u0452\u0457\u0005\u0084\u0000\u0000\u0453\u0454\u0005\u00c1\u0000\u0000"+
		"\u0454\u0455\u0005\u008d\u0000\u0000\u0455\u0457\u0005\u00c7\u0000\u0000"+
		"\u0456\u0450\u0001\u0000\u0000\u0000\u0456\u0453\u0001\u0000\u0000\u0000"+
		"\u0457\u00bb\u0001\u0000\u0000\u0000\u0458\u045a\u0005\u008e\u0000\u0000"+
		"\u0459\u045b\u0007\f\u0000\u0000\u045a\u0459\u0001\u0000\u0000\u0000\u045a"+
		"\u045b\u0001\u0000\u0000\u0000\u045b\u045f\u0001\u0000\u0000\u0000\u045c"+
		"\u045f\u0005\u00b2\u0000\u0000\u045d\u045f\u0005\u00b3\u0000\u0000\u045e"+
		"\u0458\u0001\u0000\u0000\u0000\u045e\u045c\u0001\u0000\u0000\u0000\u045e"+
		"\u045d\u0001\u0000\u0000\u0000\u045f\u00bd\u0001\u0000\u0000\u0000\u0460"+
		"\u0461\u0007\r\u0000\u0000\u0461\u00bf\u0001\u0000\u0000\u0000\u0462\u046e"+
		"\u0005\u00d5\u0000\u0000\u0463\u0464\u0005\u000b\u0000\u0000\u0464\u0469"+
		"\u0005\u00d4\u0000\u0000\u0465\u0466\u0005\u0001\u0000\u0000\u0466\u0468"+
		"\u0005\u00d4\u0000\u0000\u0467\u0465\u0001\u0000\u0000\u0000\u0468\u046b"+
		"\u0001\u0000\u0000\u0000\u0469\u0467\u0001\u0000\u0000\u0000\u0469\u046a"+
		"\u0001\u0000\u0000\u0000\u046a\u046c\u0001\u0000\u0000\u0000\u046b\u0469"+
		"\u0001\u0000\u0000\u0000\u046c\u046e\u0005\u0006\u0000\u0000\u046d\u0462"+
		"\u0001\u0000\u0000\u0000\u046d\u0463\u0001\u0000\u0000\u0000\u046e\u00c1"+
		"\u0001\u0000\u0000\u0000\u046f\u0476\u0003x<\u0000\u0470\u0476\u0003\u0080"+
		"@\u0000\u0471\u0476\u0003\u0082A\u0000\u0472\u0476\u0003\u008eG\u0000"+
		"\u0473\u0476\u0003\u0090H\u0000\u0474\u0476\u0003\u0092I\u0000\u0475\u046f"+
		"\u0001\u0000\u0000\u0000\u0475\u0470\u0001\u0000\u0000\u0000\u0475\u0471"+
		"\u0001\u0000\u0000\u0000\u0475\u0472\u0001\u0000\u0000\u0000\u0475\u0473"+
		"\u0001\u0000\u0000\u0000\u0475\u0474\u0001\u0000\u0000\u0000\u0476\u00c3"+
		"\u0001\u0000\u0000\u0000\u0477\u0478\u0006b\uffff\uffff\u0000\u0478\u0479"+
		"\u0005\u0002\u0000\u0000\u0479\u047a\u0003\u00c4b\u0000\u047a\u047b\u0005"+
		"\u0003\u0000\u0000\u047b\u0499\u0001\u0000\u0000\u0000\u047c\u047d\u0005"+
		"\u0002\u0000\u0000\u047d\u0480\u0003\u0176\u00bb\u0000\u047e\u047f\u0005"+
		"\u0001\u0000\u0000\u047f\u0481\u0003\u0176\u00bb\u0000\u0480\u047e\u0001"+
		"\u0000\u0000\u0000\u0481\u0482\u0001\u0000\u0000\u0000\u0482\u0480\u0001"+
		"\u0000\u0000\u0000\u0482\u0483\u0001\u0000\u0000\u0000\u0483\u0484\u0001"+
		"\u0000\u0000\u0000\u0484\u0485\u0005\u0003\u0000\u0000\u0485\u0499\u0001"+
		"\u0000\u0000\u0000\u0486\u0487\u0005\u0002\u0000\u0000\u0487\u0488\u0003"+
		"R)\u0000\u0488\u0489\u0005\u0003\u0000\u0000\u0489\u0499\u0001\u0000\u0000"+
		"\u0000\u048a\u0499\u0003\u00c6c\u0000\u048b\u048c\u0007\t\u0000\u0000"+
		"\u048c\u0499\u0003v;\u0000\u048d\u048e\u0007\t\u0000\u0000\u048e\u0499"+
		"\u0003\u00c4b\t\u048f\u0490\u0005:\u0000\u0000\u0490\u0491\u0005\u008d"+
		"\u0000\u0000\u0491\u0499\u0005\u00c1\u0000\u0000\u0492\u0493\u0005:\u0000"+
		"\u0000\u0493\u0494\u0005\u008d\u0000\u0000\u0494\u0499\u0005\u0084\u0000"+
		"\u0000\u0495\u0496\u0005\u00c1\u0000\u0000\u0496\u0497\u0005\u008d\u0000"+
		"\u0000\u0497\u0499\u0005\u00c7\u0000\u0000\u0498\u0477\u0001\u0000\u0000"+
		"\u0000\u0498\u047c\u0001\u0000\u0000\u0000\u0498\u0486\u0001\u0000\u0000"+
		"\u0000\u0498\u048a\u0001\u0000\u0000\u0000\u0498\u048b\u0001\u0000\u0000"+
		"\u0000\u0498\u048d\u0001\u0000\u0000\u0000\u0498\u048f\u0001\u0000\u0000"+
		"\u0000\u0498\u0492\u0001\u0000\u0000\u0000\u0498\u0495\u0001\u0000\u0000"+
		"\u0000\u0499\u04aa\u0001\u0000\u0000\u0000\u049a\u049b\n\u0006\u0000\u0000"+
		"\u049b\u049c\u0007\u000e\u0000\u0000\u049c\u04a9\u0003\u00c4b\u0007\u049d"+
		"\u049e\n\u0005\u0000\u0000\u049e\u049f\u0007\t\u0000\u0000\u049f\u04a9"+
		"\u0003\u00c4b\u0006\u04a0\u04a1\n\u0004\u0000\u0000\u04a1\u04a2\u0005"+
		"\f\u0000\u0000\u04a2\u04a9\u0003\u00c4b\u0005\u04a3\u04a4\n\b\u0000\u0000"+
		"\u04a4\u04a9\u0003\u00b6[\u0000\u04a5\u04a6\n\u0007\u0000\u0000\u04a6"+
		"\u04a7\u0005\'\u0000\u0000\u04a7\u04a9\u0003\u00b6[\u0000\u04a8\u049a"+
		"\u0001\u0000\u0000\u0000\u04a8\u049d\u0001\u0000\u0000\u0000\u04a8\u04a0"+
		"\u0001\u0000\u0000\u0000\u04a8\u04a3\u0001\u0000\u0000\u0000\u04a8\u04a5"+
		"\u0001\u0000\u0000\u0000\u04a9\u04ac\u0001\u0000\u0000\u0000\u04aa\u04a8"+
		"\u0001\u0000\u0000\u0000\u04aa\u04ab\u0001\u0000\u0000\u0000\u04ab\u00c5"+
		"\u0001\u0000\u0000\u0000\u04ac\u04aa\u0001\u0000\u0000\u0000\u04ad\u04bb"+
		"\u0003\u00e8t\u0000\u04ae\u04bb\u0003r9\u0000\u04af\u04bb\u0003\u019a"+
		"\u00cd\u0000\u04b0\u04bb\u0003\u00d4j\u0000\u04b1\u04bb\u0003\u00d6k\u0000"+
		"\u04b2\u04bb\u0003\u00d8l\u0000\u04b3\u04bb\u0003\u00dam\u0000\u04b4\u04b6"+
		"\u0003\u00dcn\u0000\u04b5\u04b7\u0003\u00d2i\u0000\u04b6\u04b5\u0001\u0000"+
		"\u0000\u0000\u04b6\u04b7\u0001\u0000\u0000\u0000\u04b7\u04bb\u0001\u0000"+
		"\u0000\u0000\u04b8\u04bb\u0003\u00f2y\u0000\u04b9\u04bb\u0003\u00cae\u0000"+
		"\u04ba\u04ad\u0001\u0000\u0000\u0000\u04ba\u04ae\u0001\u0000\u0000\u0000"+
		"\u04ba\u04af\u0001\u0000\u0000\u0000\u04ba\u04b0\u0001\u0000\u0000\u0000"+
		"\u04ba\u04b1\u0001\u0000\u0000\u0000\u04ba\u04b2\u0001\u0000\u0000\u0000"+
		"\u04ba\u04b3\u0001\u0000\u0000\u0000\u04ba\u04b4\u0001\u0000\u0000\u0000"+
		"\u04ba\u04b8\u0001\u0000\u0000\u0000\u04ba\u04b9\u0001\u0000\u0000\u0000"+
		"\u04bb\u00c7\u0001\u0000\u0000\u0000\u04bc\u04be\u0003\u00dcn\u0000\u04bd"+
		"\u04bf\u0003\u00d2i\u0000\u04be\u04bd\u0001\u0000\u0000\u0000\u04be\u04bf"+
		"\u0001\u0000\u0000\u0000\u04bf\u04c2\u0001\u0000\u0000\u0000\u04c0\u04c2"+
		"\u0003\u00cae\u0000\u04c1\u04bc\u0001\u0000\u0000\u0000\u04c1\u04c0\u0001"+
		"\u0000\u0000\u0000\u04c2\u00c9\u0001\u0000\u0000\u0000\u04c3\u04c5\u0003"+
		"\u00ceg\u0000\u04c4\u04c6\u0003\u00ccf\u0000\u04c5\u04c4\u0001\u0000\u0000"+
		"\u0000\u04c5\u04c6\u0001\u0000\u0000\u0000\u04c6\u00cb\u0001\u0000\u0000"+
		"\u0000\u04c7\u04c8\u0005\u0007\u0000\u0000\u04c8\u04c9\u0003\u00c4b\u0000"+
		"\u04c9\u04cc\u0005\b\u0000\u0000\u04ca\u04cb\u0005\r\u0000\u0000\u04cb"+
		"\u04cd\u0003\u00cae\u0000\u04cc\u04ca\u0001\u0000\u0000\u0000\u04cc\u04cd"+
		"\u0001\u0000\u0000\u0000\u04cd\u00cd\u0001\u0000\u0000\u0000\u04ce\u04d2"+
		"\u0003\u01a0\u00d0\u0000\u04cf\u04d1\u0003\u00d0h\u0000\u04d0\u04cf\u0001"+
		"\u0000\u0000\u0000\u04d1\u04d4\u0001\u0000\u0000\u0000\u04d2\u04d0\u0001"+
		"\u0000\u0000\u0000\u04d2\u04d3\u0001\u0000\u0000\u0000\u04d3\u00cf\u0001"+
		"\u0000\u0000\u0000\u04d4\u04d2\u0001\u0000\u0000\u0000\u04d5\u04d6\u0005"+
		"\r\u0000\u0000\u04d6\u04d7\u0003\u01a0\u00d0\u0000\u04d7\u00d1\u0001\u0000"+
		"\u0000\u0000\u04d8\u04d9\u0005\r\u0000\u0000\u04d9\u04da\u0003\u00ceg"+
		"\u0000\u04da\u00d3\u0001\u0000\u0000\u0000\u04db\u04dc\u0005\u00ba\u0000"+
		"\u0000\u04dc\u04df\u0005\u0002\u0000\u0000\u04dd\u04e0\u0003\u00c8d\u0000"+
		"\u04de\u04e0\u0003\u019a\u00cd\u0000\u04df\u04dd\u0001\u0000\u0000\u0000"+
		"\u04df\u04de\u0001\u0000\u0000\u0000\u04e0\u04e1\u0001\u0000\u0000\u0000"+
		"\u04e1\u04e2\u0005\u0003\u0000\u0000\u04e2\u00d5\u0001\u0000\u0000\u0000"+
		"\u04e3\u04e4\u0005\u0019\u0000\u0000\u04e4\u04e5\u0005\u0002\u0000\u0000"+
		"\u04e5\u04e6\u0003\u00c8d\u0000\u04e6\u04e8\u0005\u0003\u0000\u0000\u04e7"+
		"\u04e9\u0003\u00d2i\u0000\u04e8\u04e7\u0001\u0000\u0000\u0000\u04e8\u04e9"+
		"\u0001\u0000\u0000\u0000\u04e9\u00d7\u0001\u0000\u0000\u0000\u04ea\u04eb"+
		"\u0005\u001a\u0000\u0000\u04eb\u04ec\u0005\u0002\u0000\u0000\u04ec\u04ed"+
		"\u0003\u00c8d\u0000\u04ed\u04ee\u0005\u0003\u0000\u0000\u04ee\u00d9\u0001"+
		"\u0000\u0000\u0000\u04ef\u04f0\u0005\u001c\u0000\u0000\u04f0\u04f1\u0005"+
		"\u0002\u0000\u0000\u04f1\u04f2\u0003\u00c8d\u0000\u04f2\u04f4\u0005\u0003"+
		"\u0000\u0000\u04f3\u04f5\u0003\u00d2i\u0000\u04f4\u04f3\u0001\u0000\u0000"+
		"\u0000\u04f4\u04f5\u0001\u0000\u0000\u0000\u04f5\u00db\u0001\u0000\u0000"+
		"\u0000\u04f6\u050c\u0003\u00e0p\u0000\u04f7\u050c\u0003\u00e2q\u0000\u04f8"+
		"\u050c\u0003\u00e4r\u0000\u04f9\u04fa\u0003\u00ceg\u0000\u04fa\u04fb\u0003"+
		"\u00ccf\u0000\u04fb\u050c\u0001\u0000\u0000\u0000\u04fc\u04fd\u0003\u00ce"+
		"g\u0000\u04fd\u04fe\u0003\u00deo\u0000\u04fe\u050c\u0001\u0000\u0000\u0000"+
		"\u04ff\u050c\u0003\u00e6s\u0000\u0500\u0501\u0003\u00f2y\u0000\u0501\u0502"+
		"\u0003\u00d2i\u0000\u0502\u050c\u0001\u0000\u0000\u0000\u0503\u0504\u0003"+
		"\u00f2y\u0000\u0504\u0506\u0003\u00ccf\u0000\u0505\u0507\u0003\u00d2i"+
		"\u0000\u0506\u0505\u0001\u0000\u0000\u0000\u0506\u0507\u0001\u0000\u0000"+
		"\u0000\u0507\u050c\u0001\u0000\u0000\u0000\u0508\u0509\u0003\u00f2y\u0000"+
		"\u0509\u050a\u0003\u00deo\u0000\u050a\u050c\u0001\u0000\u0000\u0000\u050b"+
		"\u04f6\u0001\u0000\u0000\u0000\u050b\u04f7\u0001\u0000\u0000\u0000\u050b"+
		"\u04f8\u0001\u0000\u0000\u0000\u050b\u04f9\u0001\u0000\u0000\u0000\u050b"+
		"\u04fc\u0001\u0000\u0000\u0000\u050b\u04ff\u0001\u0000\u0000\u0000\u050b"+
		"\u0500\u0001\u0000\u0000\u0000\u050b\u0503\u0001\u0000\u0000\u0000\u050b"+
		"\u0508\u0001\u0000\u0000\u0000\u050c\u00dd\u0001\u0000\u0000\u0000\u050d"+
		"\u050e\u0005\u0007\u0000\u0000\u050e\u050f\u0003\u00c4b\u0000\u050f\u0510"+
		"\u0005\t\u0000\u0000\u0510\u0511\u0003\u00c4b\u0000\u0511\u0512\u0005"+
		"\b\u0000\u0000\u0512\u00df\u0001\u0000\u0000\u0000\u0513\u0514\u0005\u00b6"+
		"\u0000\u0000\u0514\u0515\u0005\u0002\u0000\u0000\u0515\u0516\u0003\u00c8"+
		"d\u0000\u0516\u0517\u0005!\u0000\u0000\u0517\u0518\u0003\u00ceg\u0000"+
		"\u0518\u051a\u0005\u0003\u0000\u0000\u0519\u051b\u0003\u00d2i\u0000\u051a"+
		"\u0519\u0001\u0000\u0000\u0000\u051a\u051b\u0001\u0000\u0000\u0000\u051b"+
		"\u00e1\u0001\u0000\u0000\u0000\u051c\u051d\u0003\u017c\u00be\u0000\u051d"+
		"\u051e\u0005\u0002\u0000\u0000\u051e\u051f\u0003\u00c8d\u0000\u051f\u0521"+
		"\u0005\u0003\u0000\u0000\u0520\u0522\u0003\u00d2i\u0000\u0521\u0520\u0001"+
		"\u0000\u0000\u0000\u0521\u0522\u0001\u0000\u0000\u0000\u0522\u00e3\u0001"+
		"\u0000\u0000\u0000\u0523\u0524\u0003\u017e\u00bf\u0000\u0524\u0525\u0005"+
		"\u0002\u0000\u0000\u0525\u0526\u0003\u00c8d\u0000\u0526\u0528\u0005\u0003"+
		"\u0000\u0000\u0527\u0529\u0003\u00d2i\u0000\u0528\u0527\u0001\u0000\u0000"+
		"\u0000\u0528\u0529\u0001\u0000\u0000\u0000\u0529\u00e5\u0001\u0000\u0000"+
		"\u0000\u052a\u052b\u0005\u001d\u0000\u0000\u052b\u052c\u0005\u0002\u0000"+
		"\u0000\u052c\u052d\u0003\u00c8d\u0000\u052d\u052e\u0005\u0003\u0000\u0000"+
		"\u052e\u00e7\u0001\u0000\u0000\u0000\u052f\u0532\u0003\u00eau\u0000\u0530"+
		"\u0532\u0003\u00ecv\u0000\u0531\u052f\u0001\u0000\u0000\u0000\u0531\u0530"+
		"\u0001\u0000\u0000\u0000\u0532\u00e9\u0001\u0000\u0000\u0000\u0533\u0534"+
		"\u0005(\u0000\u0000\u0534\u0536\u0003\u0176\u00bb\u0000\u0535\u0537\u0003"+
		"\u00eew\u0000\u0536\u0535\u0001\u0000\u0000\u0000\u0537\u0538\u0001\u0000"+
		"\u0000\u0000\u0538\u0536\u0001\u0000\u0000\u0000\u0538\u0539\u0001\u0000"+
		"\u0000\u0000\u0539\u053c\u0001\u0000\u0000\u0000\u053a\u053b\u0005C\u0000"+
		"\u0000\u053b\u053d\u0003\u0176\u00bb\u0000\u053c\u053a\u0001\u0000\u0000"+
		"\u0000\u053c\u053d\u0001\u0000\u0000\u0000\u053d\u053e\u0001\u0000\u0000"+
		"\u0000\u053e\u053f\u0005E\u0000\u0000\u053f\u00eb\u0001\u0000\u0000\u0000"+
		"\u0540\u0542\u0005(\u0000\u0000\u0541\u0543\u0003\u00f0x\u0000\u0542\u0541"+
		"\u0001\u0000\u0000\u0000\u0543\u0544\u0001\u0000\u0000\u0000\u0544\u0542"+
		"\u0001\u0000\u0000\u0000\u0544\u0545\u0001\u0000\u0000\u0000\u0545\u0548"+
		"\u0001\u0000\u0000\u0000\u0546\u0547\u0005C\u0000\u0000\u0547\u0549\u0003"+
		"\u0176\u00bb\u0000\u0548\u0546\u0001\u0000\u0000\u0000\u0548\u0549\u0001"+
		"\u0000\u0000\u0000\u0549\u054a\u0001\u0000\u0000\u0000\u054a\u054b\u0005"+
		"E\u0000\u0000\u054b\u00ed\u0001\u0000\u0000\u0000\u054c\u054d\u0005\u00c2"+
		"\u0000\u0000\u054d\u054e\u0003\u00c4b\u0000\u054e\u054f\u0005\u00ae\u0000"+
		"\u0000\u054f\u0550\u0003\u0176\u00bb\u0000\u0550\u00ef\u0001\u0000\u0000"+
		"\u0000\u0551\u0552\u0005\u00c2\u0000\u0000\u0552\u0553\u0003\u0174\u00ba"+
		"\u0000\u0553\u0554\u0005\u00ae\u0000\u0000\u0554\u0555\u0003\u0176\u00bb"+
		"\u0000\u0555\u00f1\u0001\u0000\u0000\u0000\u0556\u055f\u0003\u00f4z\u0000"+
		"\u0557\u055f\u0003\u0152\u00a9\u0000\u0558\u055f\u0003\u014c\u00a6\u0000"+
		"\u0559\u055f\u0003\u014e\u00a7\u0000\u055a\u055f\u0003\u0150\u00a8\u0000"+
		"\u055b\u055f\u0003\u0140\u00a0\u0000\u055c\u055f\u0003\u0144\u00a2\u0000"+
		"\u055d\u055f\u0003\u0146\u00a3\u0000\u055e\u0556\u0001\u0000\u0000\u0000"+
		"\u055e\u0557\u0001\u0000\u0000\u0000\u055e\u0558\u0001\u0000\u0000\u0000"+
		"\u055e\u0559\u0001\u0000\u0000\u0000\u055e\u055a\u0001\u0000\u0000\u0000"+
		"\u055e\u055b\u0001\u0000\u0000\u0000\u055e\u055c\u0001\u0000\u0000\u0000"+
		"\u055e\u055d\u0001\u0000\u0000\u0000\u055f\u00f3\u0001\u0000\u0000\u0000"+
		"\u0560\u0576\u0003\u00f6{\u0000\u0561\u0576\u0003\u00e0p\u0000\u0562\u0576"+
		"\u0003\u013c\u009e\u0000\u0563\u0576\u0003\u013e\u009f\u0000\u0564\u0576"+
		"\u0003\u0130\u0098\u0000\u0565\u0576\u0003\u0134\u009a\u0000\u0566\u0576"+
		"\u0003\u00fc~\u0000\u0567\u0576\u0003\u0116\u008b\u0000\u0568\u0576\u0003"+
		"\u0102\u0081\u0000\u0569\u0576\u0003\u0108\u0084\u0000\u056a\u0576\u0003"+
		"\u0110\u0088\u0000\u056b\u0576\u0003\u0120\u0090\u0000\u056c\u0576\u0003"+
		"\u0122\u0091\u0000\u056d\u0576\u0003\u0124\u0092\u0000\u056e\u0576\u0003"+
		"\u0126\u0093\u0000\u056f\u0576\u0003\u012c\u0096\u0000\u0570\u0576\u0003"+
		"\u012e\u0097\u0000\u0571\u0576\u0003\u0128\u0094\u0000\u0572\u0576\u0003"+
		"\u012a\u0095\u0000\u0573\u0576\u0003\u0136\u009b\u0000\u0574\u0576\u0003"+
		"\u0138\u009c\u0000\u0575\u0560\u0001\u0000\u0000\u0000\u0575\u0561\u0001"+
		"\u0000\u0000\u0000\u0575\u0562\u0001\u0000\u0000\u0000\u0575\u0563\u0001"+
		"\u0000\u0000\u0000\u0575\u0564\u0001\u0000\u0000\u0000\u0575\u0565\u0001"+
		"\u0000\u0000\u0000\u0575\u0566\u0001\u0000\u0000\u0000\u0575\u0567\u0001"+
		"\u0000\u0000\u0000\u0575\u0568\u0001\u0000\u0000\u0000\u0575\u0569\u0001"+
		"\u0000\u0000\u0000\u0575\u056a\u0001\u0000\u0000\u0000\u0575\u056b\u0001"+
		"\u0000\u0000\u0000\u0575\u056c\u0001\u0000\u0000\u0000\u0575\u056d\u0001"+
		"\u0000\u0000\u0000\u0575\u056e\u0001\u0000\u0000\u0000\u0575\u056f\u0001"+
		"\u0000\u0000\u0000\u0575\u0570\u0001\u0000\u0000\u0000\u0575\u0571\u0001"+
		"\u0000\u0000\u0000\u0575\u0572\u0001\u0000\u0000\u0000\u0575\u0573\u0001"+
		"\u0000\u0000\u0000\u0575\u0574\u0001\u0000\u0000\u0000\u0576\u00f5\u0001"+
		"\u0000\u0000\u0000\u0577\u0578\u0005)\u0000\u0000\u0578\u0579\u0005\u0002"+
		"\u0000\u0000\u0579\u057a\u0003\u00c4b\u0000\u057a\u057b\u0005!\u0000\u0000"+
		"\u057b\u057c\u0003\u00f8|\u0000\u057c\u057d\u0005\u0003\u0000\u0000\u057d"+
		"\u00f7\u0001\u0000\u0000\u0000\u057e\u0586\u0003\u00fa}\u0000\u057f\u0580"+
		"\u0005\u0002\u0000\u0000\u0580\u0583\u0005\u00ce\u0000\u0000\u0581\u0582"+
		"\u0005\u0001\u0000\u0000\u0582\u0584\u0005\u00ce\u0000\u0000\u0583\u0581"+
		"\u0001\u0000\u0000\u0000\u0583\u0584\u0001\u0000\u0000\u0000\u0584\u0585"+
		"\u0001\u0000\u0000\u0000\u0585\u0587\u0005\u0003\u0000\u0000\u0586\u057f"+
		"\u0001\u0000\u0000\u0000\u0586\u0587\u0001\u0000\u0000\u0000\u0587\u00f9"+
		"\u0001\u0000\u0000\u0000\u0588\u0589\u0003\u01a0\u00d0\u0000\u0589\u058a"+
		"\u0006}\uffff\uffff\u0000\u058a\u0591\u0001\u0000\u0000\u0000\u058b\u058c"+
		"\u0005\r\u0000\u0000\u058c\u058d\u0003\u01a0\u00d0\u0000\u058d\u058e\u0006"+
		"}\uffff\uffff\u0000\u058e\u0590\u0001\u0000\u0000\u0000\u058f\u058b\u0001"+
		"\u0000\u0000\u0000\u0590\u0593\u0001\u0000\u0000\u0000\u0591\u058f\u0001"+
		"\u0000\u0000\u0000\u0591\u0592\u0001\u0000\u0000\u0000\u0592\u00fb\u0001"+
		"\u0000\u0000\u0000\u0593\u0591\u0001\u0000\u0000\u0000\u0594\u0595\u0005"+
		"\u00ac\u0000\u0000\u0595\u0596\u0005\u0002\u0000\u0000\u0596\u0597\u0003"+
		"\u00c4b\u0000\u0597\u0598\u0005\u0001\u0000\u0000\u0598\u059b\u0003\u00fe"+
		"\u007f\u0000\u0599\u059a\u0005\u0001\u0000\u0000\u059a\u059c\u0003\u0100"+
		"\u0080\u0000\u059b\u0599\u0001\u0000\u0000\u0000\u059b\u059c\u0001\u0000"+
		"\u0000\u0000\u059c\u059d\u0001\u0000\u0000\u0000\u059d\u059e\u0005\u0003"+
		"\u0000\u0000\u059e\u05ab\u0001\u0000\u0000\u0000\u059f\u05a0\u0005\u00ac"+
		"\u0000\u0000\u05a0\u05a1\u0005\u0002\u0000\u0000\u05a1\u05a2\u0003\u00c4"+
		"b\u0000\u05a2\u05a3\u0005U\u0000\u0000\u05a3\u05a6\u0003\u00fe\u007f\u0000"+
		"\u05a4\u05a5\u0005S\u0000\u0000\u05a5\u05a7\u0003\u0100\u0080\u0000\u05a6"+
		"\u05a4\u0001\u0000\u0000\u0000\u05a6\u05a7\u0001\u0000\u0000\u0000\u05a7"+
		"\u05a8\u0001\u0000\u0000\u0000\u05a8\u05a9\u0005\u0003\u0000\u0000\u05a9"+
		"\u05ab\u0001\u0000\u0000\u0000\u05aa\u0594\u0001\u0000\u0000\u0000\u05aa"+
		"\u059f\u0001\u0000\u0000\u0000\u05ab\u00fd\u0001\u0000\u0000\u0000\u05ac"+
		"\u05ad\u0003\u00c4b\u0000\u05ad\u00ff\u0001\u0000\u0000\u0000\u05ae\u05af"+
		"\u0003\u00c4b\u0000\u05af\u0101\u0001\u0000\u0000\u0000\u05b0\u05b1\u0005"+
		"\u00b7\u0000\u0000\u05b1\u05b3\u0005\u0002\u0000\u0000\u05b2\u05b4\u0003"+
		"\u0104\u0082\u0000\u05b3\u05b2\u0001\u0000\u0000\u0000\u05b3\u05b4\u0001"+
		"\u0000\u0000\u0000\u05b4\u05b6\u0001\u0000\u0000\u0000\u05b5\u05b7\u0003"+
		"\u0106\u0083\u0000\u05b6\u05b5\u0001\u0000\u0000\u0000\u05b6\u05b7\u0001"+
		"\u0000\u0000\u0000\u05b7\u05b9\u0001\u0000\u0000\u0000\u05b8\u05ba\u0005"+
		"U\u0000\u0000\u05b9\u05b8\u0001\u0000\u0000\u0000\u05b9\u05ba\u0001\u0000"+
		"\u0000\u0000\u05ba\u05bb\u0001\u0000\u0000\u0000\u05bb\u05bc\u0003\u00c4"+
		"b\u0000\u05bc\u05bd\u0005\u0003\u0000\u0000\u05bd\u0103\u0001\u0000\u0000"+
		"\u0000\u05be\u05bf\u0007\u000f\u0000\u0000\u05bf\u0105\u0001\u0000\u0000"+
		"\u0000\u05c0\u05c3\u0005\u00cc\u0000\u0000\u05c1\u05c3\u0003\u019a\u00cd"+
		"\u0000\u05c2\u05c0\u0001\u0000\u0000\u0000\u05c2\u05c1\u0001\u0000\u0000"+
		"\u0000\u05c3\u0107\u0001\u0000\u0000\u0000\u05c4\u05c5\u0005\u0099\u0000"+
		"\u0000\u05c5\u05c6\u0005\u0002\u0000\u0000\u05c6\u05c7\u0003\u00c4b\u0000"+
		"\u05c7\u05c8\u0005\u00c4\u0000\u0000\u05c8\u05c9\u0003\u010e\u0087\u0000"+
		"\u05c9\u05cb\u0003\u010a\u0085\u0000\u05ca\u05cc\u0003\u010c\u0086\u0000"+
		"\u05cb\u05ca\u0001\u0000\u0000\u0000\u05cb\u05cc\u0001\u0000\u0000\u0000"+
		"\u05cc\u05cd\u0001\u0000\u0000\u0000\u05cd\u05ce\u0005\u0003\u0000\u0000"+
		"\u05ce\u0109\u0001\u0000\u0000\u0000\u05cf\u05d0\u0007\u0010\u0000\u0000"+
		"\u05d0\u010b\u0001\u0000\u0000\u0000\u05d1\u05d2\u0005\u00cc\u0000\u0000"+
		"\u05d2\u010d\u0001\u0000\u0000\u0000\u05d3\u05d4\u0003\u00c4b\u0000\u05d4"+
		"\u010f\u0001\u0000\u0000\u0000\u05d5\u05d6\u0005\u009d\u0000\u0000\u05d6"+
		"\u05d7\u0005\u0002\u0000\u0000\u05d7\u05d8\u0003\u0112\u0089\u0000\u05d8"+
		"\u05d9\u0005^\u0000\u0000\u05d9\u05da\u0003\u0114\u008a\u0000\u05da\u05db"+
		"\u0005\u0003\u0000\u0000\u05db\u0111\u0001\u0000\u0000\u0000\u05dc\u05dd"+
		"\u0003\u00c4b\u0000\u05dd\u0113\u0001\u0000\u0000\u0000\u05de\u05df\u0003"+
		"\u00c4b\u0000\u05df\u0115\u0001\u0000\u0000\u0000\u05e0\u05e1\u0005\u0098"+
		"\u0000\u0000\u05e1\u05e2\u0005\u0002\u0000\u0000\u05e2\u05e3\u0003\u0118"+
		"\u008c\u0000\u05e3\u05e4\u0005\u009c\u0000\u0000\u05e4\u05e5\u0003\u011a"+
		"\u008d\u0000\u05e5\u05e6\u0005U\u0000\u0000\u05e6\u05e9\u0003\u011c\u008e"+
		"\u0000\u05e7\u05e8\u0005S\u0000\u0000\u05e8\u05ea\u0003\u011e\u008f\u0000"+
		"\u05e9\u05e7\u0001\u0000\u0000\u0000\u05e9\u05ea\u0001\u0000\u0000\u0000"+
		"\u05ea\u05eb\u0001\u0000\u0000\u0000\u05eb\u05ec\u0005\u0003\u0000\u0000"+
		"\u05ec\u0117\u0001\u0000\u0000\u0000\u05ed\u05ee\u0003\u00c4b\u0000\u05ee"+
		"\u0119\u0001\u0000\u0000\u0000\u05ef\u05f0\u0003\u00c4b\u0000\u05f0\u011b"+
		"\u0001\u0000\u0000\u0000\u05f1\u05f2\u0003\u00c4b\u0000\u05f2\u011d\u0001"+
		"\u0000\u0000\u0000\u05f3\u05f4\u0003\u00c4b\u0000\u05f4\u011f\u0001\u0000"+
		"\u0000\u0000\u05f5\u05f8\u00053\u0000\u0000\u05f6\u05f7\u0005\u0002\u0000"+
		"\u0000\u05f7\u05f9\u0005\u0003\u0000\u0000\u05f8\u05f6\u0001\u0000\u0000"+
		"\u0000\u05f8\u05f9\u0001\u0000\u0000\u0000\u05f9\u05fd\u0001\u0000\u0000"+
		"\u0000\u05fa\u05fb\u00052\u0000\u0000\u05fb\u05fd\u00058\u0000\u0000\u05fc"+
		"\u05f5\u0001\u0000\u0000\u0000\u05fc\u05fa\u0001\u0000\u0000\u0000\u05fd"+
		"\u0121\u0001\u0000\u0000\u0000\u05fe\u0601\u00055\u0000\u0000\u05ff\u0600"+
		"\u0005\u0002\u0000\u0000\u0600\u0602\u0005\u0003\u0000\u0000\u0601\u05ff"+
		"\u0001\u0000\u0000\u0000\u0601\u0602\u0001\u0000\u0000\u0000\u0602\u0606"+
		"\u0001\u0000\u0000\u0000\u0603\u0604\u00052\u0000\u0000\u0604\u0606\u0005"+
		"\u00b0\u0000\u0000\u0605\u05fe\u0001\u0000\u0000\u0000\u0605\u0603\u0001"+
		"\u0000\u0000\u0000\u0606\u0123\u0001\u0000\u0000\u0000\u0607\u060a\u0005"+
		"6\u0000\u0000\u0608\u0609\u0005\u0002\u0000\u0000\u0609\u060b\u0005\u0003"+
		"\u0000\u0000\u060a\u0608\u0001\u0000\u0000\u0000\u060a\u060b\u0001\u0000"+
		"\u0000\u0000\u060b\u060f\u0001\u0000\u0000\u0000\u060c\u060d\u00052\u0000"+
		"\u0000\u060d\u060f\u0005\u00b1\u0000\u0000\u060e\u0607\u0001\u0000\u0000"+
		"\u0000\u060e\u060c\u0001\u0000\u0000\u0000\u060f\u0125\u0001\u0000\u0000"+
		"\u0000\u0610\u0613\u00054\u0000\u0000\u0611\u0612\u0005\u0002\u0000\u0000"+
		"\u0612\u0614\u0005\u0003\u0000\u0000\u0613\u0611\u0001\u0000\u0000\u0000"+
		"\u0613\u0614\u0001\u0000\u0000\u0000\u0614\u0617\u0001\u0000\u0000\u0000"+
		"\u0615\u0617\u0005d\u0000\u0000\u0616\u0610\u0001\u0000\u0000\u0000\u0616"+
		"\u0615\u0001\u0000\u0000\u0000\u0617\u0127\u0001\u0000\u0000\u0000\u0618"+
		"\u061b\u0005v\u0000\u0000\u0619\u061a\u0005\u0002\u0000\u0000\u061a\u061c"+
		"\u0005\u0003\u0000\u0000\u061b\u0619\u0001\u0000\u0000\u0000\u061b\u061c"+
		"\u0001\u0000\u0000\u0000\u061c\u0620\u0001\u0000\u0000\u0000\u061d\u061e"+
		"\u0005t\u0000\u0000\u061e\u0620\u00059\u0000\u0000\u061f\u0618\u0001\u0000"+
		"\u0000\u0000\u061f\u061d\u0001\u0000\u0000\u0000\u0620\u0129\u0001\u0000"+
		"\u0000\u0000\u0621\u0624\u0005\u008f\u0000\u0000\u0622\u0623\u0005\u0002"+
		"\u0000\u0000\u0623\u0625\u0005\u0003\u0000\u0000\u0624\u0622\u0001\u0000"+
		"\u0000\u0000\u0624\u0625\u0001\u0000\u0000\u0000\u0625\u0629\u0001\u0000"+
		"\u0000\u0000\u0626\u0627\u0005\u008e\u0000\u0000\u0627\u0629\u00059\u0000"+
		"\u0000\u0628\u0621\u0001\u0000\u0000\u0000\u0628\u0626\u0001\u0000\u0000"+
		"\u0000\u0629\u012b\u0001\u0000\u0000\u0000\u062a\u062d\u0005u\u0000\u0000"+
		"\u062b\u062c\u0005\u0002\u0000\u0000\u062c\u062e\u0005\u0003\u0000\u0000"+
		"\u062d\u062b\u0001\u0000\u0000\u0000\u062d\u062e\u0001\u0000\u0000\u0000"+
		"\u062e\u0632\u0001\u0000\u0000\u0000\u062f\u0630\u0005t\u0000\u0000\u0630"+
		"\u0632\u00058\u0000\u0000\u0631\u062a\u0001\u0000\u0000\u0000\u0631\u062f"+
		"\u0001\u0000\u0000\u0000\u0632\u012d\u0001\u0000\u0000\u0000\u0633\u0636"+
		"\u0005w\u0000\u0000\u0634\u0635\u0005\u0002\u0000\u0000\u0635\u0637\u0005"+
		"\u0003\u0000\u0000\u0636\u0634\u0001\u0000\u0000\u0000\u0636\u0637\u0001"+
		"\u0000\u0000\u0000\u0637\u063b\u0001\u0000\u0000\u0000\u0638\u0639\u0005"+
		"t\u0000\u0000\u0639\u063b\u0005\u00b0\u0000\u0000\u063a\u0633\u0001\u0000"+
		"\u0000\u0000\u063a\u0638\u0001\u0000\u0000\u0000\u063b\u012f\u0001\u0000"+
		"\u0000\u0000\u063c\u063d\u0005T\u0000\u0000\u063d\u063e\u0005\u0002\u0000"+
		"\u0000\u063e\u063f\u0003\u00c4b\u0000\u063f\u0640\u0005!\u0000\u0000\u0640"+
		"\u0641\u0003\u013a\u009d\u0000\u0641\u0642\u0005\u0003\u0000\u0000\u0642"+
		"\u0131\u0001\u0000\u0000\u0000\u0643\u0644\u0003\u00ceg\u0000\u0644\u0133"+
		"\u0001\u0000\u0000\u0000\u0645\u0646\u0005*\u0000\u0000\u0646\u0647\u0005"+
		"\u0002\u0000\u0000\u0647\u0648\u0003\u00c4b\u0000\u0648\u0649\u0005!\u0000"+
		"\u0000\u0649\u064a\u0003\u0132\u0099\u0000\u064a\u064b\u0005\u0003\u0000"+
		"\u0000\u064b\u0135\u0001\u0000\u0000\u0000\u064c\u064d\u00051\u0000\u0000"+
		"\u064d\u064e\u0005\u0002\u0000\u0000\u064e\u0653\u0003\u0176\u00bb\u0000"+
		"\u064f\u0650\u0005\u0001\u0000\u0000\u0650\u0652\u0003\u0176\u00bb\u0000"+
		"\u0651\u064f\u0001\u0000\u0000\u0000\u0652\u0655\u0001\u0000\u0000\u0000"+
		"\u0653\u0651\u0001\u0000\u0000\u0000\u0653\u0654\u0001\u0000\u0000\u0000"+
		"\u0654\u0656\u0001\u0000\u0000\u0000\u0655\u0653\u0001\u0000\u0000\u0000"+
		"\u0656\u0657\u0005\u0003\u0000\u0000\u0657\u0137\u0001\u0000\u0000\u0000"+
		"\u0658\u0659\u0005\u00a3\u0000\u0000\u0659\u065a\u0005\u0002\u0000\u0000"+
		"\u065a\u065f\u0003\u0176\u00bb\u0000\u065b\u065c\u0005\u0001\u0000\u0000"+
		"\u065c\u065e\u0003\u0176\u00bb\u0000\u065d\u065b\u0001\u0000\u0000\u0000"+
		"\u065e\u0661\u0001\u0000\u0000\u0000\u065f\u065d\u0001\u0000\u0000\u0000"+
		"\u065f\u0660\u0001\u0000\u0000\u0000\u0660\u0662\u0001\u0000\u0000\u0000"+
		"\u0661\u065f\u0001\u0000\u0000\u0000\u0662\u0663\u0005\u0003\u0000\u0000"+
		"\u0663\u0139\u0001\u0000\u0000\u0000\u0664\u0665\u0005\u00cc\u0000\u0000"+
		"\u0665\u013b\u0001\u0000\u0000\u0000\u0666\u0667\u0005N\u0000\u0000\u0667"+
		"\u0668\u0005\u0002\u0000\u0000\u0668\u0669\u0003\u00b4Z\u0000\u0669\u066a"+
		"\u0005U\u0000\u0000\u066a\u066b\u0003\u00c4b\u0000\u066b\u066c\u0005\u0003"+
		"\u0000\u0000\u066c\u0673\u0001\u0000\u0000\u0000\u066d\u066e\u0003\u00b6"+
		"[\u0000\u066e\u066f\u0005\u0002\u0000\u0000\u066f\u0670\u0003\u00c4b\u0000"+
		"\u0670\u0671\u0005\u0003\u0000\u0000\u0671\u0673\u0001\u0000\u0000\u0000"+
		"\u0672\u0666\u0001\u0000\u0000\u0000\u0672\u066d\u0001\u0000\u0000\u0000"+
		"\u0673\u013d\u0001\u0000\u0000\u0000\u0674\u0675\u0007\u0011\u0000\u0000"+
		"\u0675\u0676\u0005\u0002\u0000\u0000\u0676\u067c\u0003\u00c4b\u0000\u0677"+
		"\u067a\u0005\u0001\u0000\u0000\u0678\u067b\u0003\u00b6[\u0000\u0679\u067b"+
		"\u0003\u00c4b\u0000\u067a\u0678\u0001\u0000\u0000\u0000\u067a\u0679\u0001"+
		"\u0000\u0000\u0000\u067b\u067d\u0001\u0000\u0000\u0000\u067c\u0677\u0001"+
		"\u0000\u0000\u0000\u067c\u067d\u0001\u0000\u0000\u0000\u067d\u067e\u0001"+
		"\u0000\u0000\u0000\u067e\u067f\u0005\u0003\u0000\u0000\u067f\u013f\u0001"+
		"\u0000\u0000\u0000\u0680\u0681\u0005W\u0000\u0000\u0681\u0682\u0005\u0002"+
		"\u0000\u0000\u0682\u0685\u0003\u0142\u00a1\u0000\u0683\u0684\u0005!\u0000"+
		"\u0000\u0684\u0686\u0003\u00f8|\u0000\u0685\u0683\u0001\u0000\u0000\u0000"+
		"\u0685\u0686\u0001\u0000\u0000\u0000\u0686\u0689\u0001\u0000\u0000\u0000"+
		"\u0687\u0688\u0005\u0001\u0000\u0000\u0688\u068a\u0003\u014a\u00a5\u0000"+
		"\u0689\u0687\u0001\u0000\u0000\u0000\u0689\u068a\u0001\u0000\u0000\u0000"+
		"\u068a\u068b\u0001\u0000\u0000\u0000\u068b\u068c\u0005\u0003\u0000\u0000"+
		"\u068c\u0141\u0001\u0000\u0000\u0000\u068d\u0690\u0005\u00cc\u0000\u0000"+
		"\u068e\u0690\u0003\u01a0\u00d0\u0000\u068f\u068d\u0001\u0000\u0000\u0000"+
		"\u068f\u068e\u0001\u0000\u0000\u0000\u0690\u0143\u0001\u0000\u0000\u0000"+
		"\u0691\u0692\u0005+\u0000\u0000\u0692\u0693\u0005\u0002\u0000\u0000\u0693"+
		"\u0694\u0003\u00c8d\u0000\u0694\u0695\u0005\r\u0000\u0000\u0695\u0698"+
		"\u0003\u0142\u00a1\u0000\u0696\u0697\u0005!\u0000\u0000\u0697\u0699\u0003"+
		"\u00f8|\u0000\u0698\u0696\u0001\u0000\u0000\u0000\u0698\u0699\u0001\u0000"+
		"\u0000\u0000\u0699\u069a\u0001\u0000\u0000\u0000\u069a\u069b\u0005\u0003"+
		"\u0000\u0000\u069b\u0145\u0001\u0000\u0000\u0000\u069c\u069d\u0003\u0148"+
		"\u00a4\u0000\u069d\u06a0\u0005\u0002\u0000\u0000\u069e\u06a1\u0003\u014a"+
		"\u00a5\u0000\u069f\u06a1\u0005\u0018\u0000\u0000\u06a0\u069e\u0001\u0000"+
		"\u0000\u0000\u06a0\u069f\u0001\u0000\u0000\u0000\u06a0\u06a1\u0001\u0000"+
		"\u0000\u0000\u06a1\u06a2\u0001\u0000\u0000\u0000\u06a2\u06a4\u0005\u0003"+
		"\u0000\u0000\u06a3\u06a5\u0003\u00d2i\u0000\u06a4\u06a3\u0001\u0000\u0000"+
		"\u0000\u06a4\u06a5\u0001\u0000\u0000\u0000\u06a5\u06a7\u0001\u0000\u0000"+
		"\u0000\u06a6\u06a8\u0003\u0166\u00b3\u0000\u06a7\u06a6\u0001\u0000\u0000"+
		"\u0000\u06a7\u06a8\u0001\u0000\u0000\u0000\u06a8\u06aa\u0001\u0000\u0000"+
		"\u0000\u06a9\u06ab\u0003\u0164\u00b2\u0000\u06aa\u06a9\u0001\u0000\u0000"+
		"\u0000\u06aa\u06ab\u0001\u0000\u0000\u0000\u06ab\u06ad\u0001\u0000\u0000"+
		"\u0000\u06ac\u06ae\u0003\u0160\u00b0\u0000\u06ad\u06ac\u0001\u0000\u0000"+
		"\u0000\u06ad\u06ae\u0001\u0000\u0000\u0000\u06ae\u06b0\u0001\u0000\u0000"+
		"\u0000\u06af\u06b1\u0003\u0162\u00b1\u0000\u06b0\u06af\u0001\u0000\u0000"+
		"\u0000\u06b0\u06b1\u0001\u0000\u0000\u0000\u06b1\u06b3\u0001\u0000\u0000"+
		"\u0000\u06b2\u06b4\u0003\u0168\u00b4\u0000\u06b3\u06b2\u0001\u0000\u0000"+
		"\u0000\u06b3\u06b4\u0001\u0000\u0000\u0000\u06b4\u0147\u0001\u0000\u0000"+
		"\u0000\u06b5\u06b6\u0003\u00ceg\u0000\u06b6\u0149\u0001\u0000\u0000\u0000"+
		"\u06b7\u06bc\u0005?\u0000\u0000\u06b8\u06b9\u0003\u00b6[\u0000\u06b9\u06ba"+
		"\u0005\u0001\u0000\u0000\u06ba\u06bc\u0001\u0000\u0000\u0000\u06bb\u06b7"+
		"\u0001\u0000\u0000\u0000\u06bb\u06b8\u0001\u0000\u0000\u0000\u06bb\u06bc"+
		"\u0001\u0000\u0000\u0000\u06bc\u06bd\u0001\u0000\u0000\u0000\u06bd\u06c2"+
		"\u0003\u0176\u00bb\u0000\u06be\u06bf\u0005\u0001\u0000\u0000\u06bf\u06c1"+
		"\u0003\u0176\u00bb\u0000\u06c0\u06be\u0001\u0000\u0000\u0000\u06c1\u06c4"+
		"\u0001\u0000\u0000\u0000\u06c2\u06c0\u0001\u0000\u0000\u0000\u06c2\u06c3"+
		"\u0001\u0000\u0000\u0000\u06c3\u014b\u0001\u0000\u0000\u0000\u06c4\u06c2"+
		"\u0001\u0000\u0000\u0000\u06c5\u06c6\u0005\u00aa\u0000\u0000\u06c6\u06c7"+
		"\u0005\u0002\u0000\u0000\u06c7\u06c8\u0003\u00c8d\u0000\u06c8\u06c9\u0005"+
		"\u0003\u0000\u0000\u06c9\u014d\u0001\u0000\u0000\u0000\u06ca\u06cb\u0007"+
		"\u0012\u0000\u0000\u06cb\u06cc\u0005\u0002\u0000\u0000\u06cc\u06cd\u0003"+
		"\u017a\u00bd\u0000\u06cd\u06ce\u0005\u0002\u0000\u0000\u06ce\u06cf\u0003"+
		"\u00c8d\u0000\u06cf\u06d0\u0005\u0003\u0000\u0000\u06d0\u06d1\u0005\u0003"+
		"\u0000\u0000\u06d1\u06e5\u0001\u0000\u0000\u0000\u06d2\u06d3\u0007\u0012"+
		"\u0000\u0000\u06d3\u06d4\u0005\u0002\u0000\u0000\u06d4\u06d5\u0003\u0180"+
		"\u00c0\u0000\u06d5\u06d6\u0005\u0002\u0000\u0000\u06d6\u06d7\u0003\u00c8"+
		"d\u0000\u06d7\u06d8\u0005\u0003\u0000\u0000\u06d8\u06d9\u0005\u0003\u0000"+
		"\u0000\u06d9\u06e5\u0001\u0000\u0000\u0000\u06da\u06db\u0007\u0013\u0000"+
		"\u0000\u06db\u06dc\u0005\u0002\u0000\u0000\u06dc\u06dd\u0003\u00c8d\u0000"+
		"\u06dd\u06de\u0005\u0003\u0000\u0000\u06de\u06e5\u0001\u0000\u0000\u0000"+
		"\u06df\u06e0\u0007\u0014\u0000\u0000\u06e0\u06e1\u0005\u0002\u0000\u0000"+
		"\u06e1\u06e2\u0003\u00c8d\u0000\u06e2\u06e3\u0005\u0003\u0000\u0000\u06e3"+
		"\u06e5\u0001\u0000\u0000\u0000\u06e4\u06ca\u0001\u0000\u0000\u0000\u06e4"+
		"\u06d2\u0001\u0000\u0000\u0000\u06e4\u06da\u0001\u0000\u0000\u0000\u06e4"+
		"\u06df\u0001\u0000\u0000\u0000\u06e5\u014f\u0001\u0000\u0000\u0000\u06e6"+
		"\u06e7\u0003\u017a\u00bd\u0000\u06e7\u06e8\u0005\u0002\u0000\u0000\u06e8"+
		"\u06e9\u0003\u00c8d\u0000\u06e9\u06ea\u0005\u0003\u0000\u0000\u06ea\u06f1"+
		"\u0001\u0000\u0000\u0000\u06eb\u06ec\u0003\u0180\u00c0\u0000\u06ec\u06ed"+
		"\u0005\u0002\u0000\u0000\u06ed\u06ee\u0003\u00c8d\u0000\u06ee\u06ef\u0005"+
		"\u0003\u0000\u0000\u06ef\u06f1\u0001\u0000\u0000\u0000\u06f0\u06e6\u0001"+
		"\u0000\u0000\u0000\u06f0\u06eb\u0001\u0000\u0000\u0000\u06f1\u0151\u0001"+
		"\u0000\u0000\u0000\u06f2\u06f6\u0003\u0154\u00aa\u0000\u06f3\u06f6\u0003"+
		"\u0156\u00ab\u0000\u06f4\u06f6\u0003\u015c\u00ae\u0000\u06f5\u06f2\u0001"+
		"\u0000\u0000\u0000\u06f5\u06f3\u0001\u0000\u0000\u0000\u06f5\u06f4\u0001"+
		"\u0000\u0000\u0000\u06f6\u0153\u0001\u0000\u0000\u0000\u06f7\u06f8\u0003"+
		"\u0158\u00ac\u0000\u06f8\u06f9\u0005\u0002\u0000\u0000\u06f9\u06fa\u0003"+
		"\u0174\u00ba\u0000\u06fa\u06fc\u0005\u0003\u0000\u0000\u06fb\u06fd\u0003"+
		"\u0162\u00b1\u0000\u06fc\u06fb\u0001\u0000\u0000\u0000\u06fc\u06fd\u0001"+
		"\u0000\u0000\u0000\u06fd\u06ff\u0001\u0000\u0000\u0000\u06fe\u0700\u0003"+
		"\u0168\u00b4\u0000\u06ff\u06fe\u0001\u0000\u0000\u0000\u06ff\u0700\u0001"+
		"\u0000\u0000\u0000\u0700\u070d\u0001\u0000\u0000\u0000\u0701\u0702\u0003"+
		"\u0158\u00ac\u0000\u0702\u0703\u0005\u0002\u0000\u0000\u0703\u0704\u0003"+
		"R)\u0000\u0704\u0705\u0005\u0003\u0000\u0000\u0705\u070d\u0001\u0000\u0000"+
		"\u0000\u0706\u0707\u0003\u0158\u00ac\u0000\u0707\u0708\u0003\u0178\u00bc"+
		"\u0000\u0708\u0709\u0005\u0002\u0000\u0000\u0709\u070a\u0003\u00ceg\u0000"+
		"\u070a\u070b\u0005\u0003\u0000\u0000\u070b\u070d\u0001\u0000\u0000\u0000"+
		"\u070c\u06f7\u0001\u0000\u0000\u0000\u070c\u0701\u0001\u0000\u0000\u0000"+
		"\u070c\u0706\u0001\u0000\u0000\u0000\u070d\u0155\u0001\u0000\u0000\u0000"+
		"\u070e\u070f\u0003\u015a\u00ad\u0000\u070f\u0710\u0005\u0002\u0000\u0000"+
		"\u0710\u0711\u0003\u0174\u00ba\u0000\u0711\u0713\u0005\u0003\u0000\u0000"+
		"\u0712\u0714\u0003\u0162\u00b1\u0000\u0713\u0712\u0001\u0000\u0000\u0000"+
		"\u0713\u0714\u0001\u0000\u0000\u0000\u0714\u0716\u0001\u0000\u0000\u0000"+
		"\u0715\u0717\u0003\u0168\u00b4\u0000\u0716\u0715\u0001\u0000\u0000\u0000"+
		"\u0716\u0717\u0001\u0000\u0000\u0000\u0717\u0724\u0001\u0000\u0000\u0000"+
		"\u0718\u0719\u0003\u015a\u00ad\u0000\u0719\u071a\u0005\u0002\u0000\u0000"+
		"\u071a\u071b\u0003R)\u0000\u071b\u071c\u0005\u0003\u0000\u0000\u071c\u0724"+
		"\u0001\u0000\u0000\u0000\u071d\u071e\u0003\u015a\u00ad\u0000\u071e\u071f"+
		"\u0003\u0178\u00bc\u0000\u071f\u0720\u0005\u0002\u0000\u0000\u0720\u0721"+
		"\u0003\u00ceg\u0000\u0721\u0722\u0005\u0003\u0000\u0000\u0722\u0724\u0001"+
		"\u0000\u0000\u0000\u0723\u070e\u0001\u0000\u0000\u0000\u0723\u0718\u0001"+
		"\u0000\u0000\u0000\u0723\u071d\u0001\u0000\u0000\u0000\u0724\u0157\u0001"+
		"\u0000\u0000\u0000\u0725\u0726\u0007\u0015\u0000\u0000\u0726\u0159\u0001"+
		"\u0000\u0000\u0000\u0727\u0728\u0007\u0016\u0000\u0000\u0728\u015b\u0001"+
		"\u0000\u0000\u0000\u0729\u072a\u0005s\u0000\u0000\u072a\u072c\u0005\u0002"+
		"\u0000\u0000\u072b\u072d\u0005?\u0000\u0000\u072c\u072b\u0001\u0000\u0000"+
		"\u0000\u072c\u072d\u0001\u0000\u0000\u0000\u072d\u072e\u0001\u0000\u0000"+
		"\u0000\u072e\u072f\u0003\u0176\u00bb\u0000\u072f\u0730\u0005\u0001\u0000"+
		"\u0000\u0730\u0732\u0003\u0176\u00bb\u0000\u0731\u0733\u0003\u015e\u00af"+
		"\u0000\u0732\u0731\u0001\u0000\u0000\u0000\u0732\u0733\u0001\u0000\u0000"+
		"\u0000\u0733\u0734\u0001\u0000\u0000\u0000\u0734\u0736\u0005\u0003\u0000"+
		"\u0000\u0735\u0737\u0003\u0160\u00b0\u0000\u0736\u0735\u0001\u0000\u0000"+
		"\u0000\u0736\u0737\u0001\u0000\u0000\u0000\u0737\u0739\u0001\u0000\u0000"+
		"\u0000\u0738\u073a\u0003\u0162\u00b1\u0000\u0739\u0738\u0001\u0000\u0000"+
		"\u0000\u0739\u073a\u0001\u0000\u0000\u0000\u073a\u073c\u0001\u0000\u0000"+
		"\u0000\u073b\u073d\u0003\u0168\u00b4\u0000\u073c\u073b\u0001\u0000\u0000"+
		"\u0000\u073c\u073d\u0001\u0000\u0000\u0000\u073d\u015d\u0001\u0000\u0000"+
		"\u0000\u073e\u073f\u0005\u0090\u0000\u0000\u073f\u0747\u0005\u0097\u0000"+
		"\u0000\u0740\u0748\u0005H\u0000\u0000\u0741\u0743\u0005\u00b9\u0000\u0000"+
		"\u0742\u0744\u0003\u00c4b\u0000\u0743\u0742\u0001\u0000\u0000\u0000\u0743"+
		"\u0744\u0001\u0000\u0000\u0000\u0744\u0745\u0001\u0000\u0000\u0000\u0745"+
		"\u0746\u0007\u0017\u0000\u0000\u0746\u0748\u0005/\u0000\u0000\u0747\u0740"+
		"\u0001\u0000\u0000\u0000\u0747\u0741\u0001\u0000\u0000\u0000\u0748\u015f"+
		"\u0001\u0000\u0000\u0000\u0749\u074a\u0005\u00c5\u0000\u0000\u074a\u074b"+
		"\u0005X\u0000\u0000\u074b\u074c\u0005\u0002\u0000\u0000\u074c\u074d\u0003"+
		"l6\u0000\u074d\u074e\u0005\u0003\u0000\u0000\u074e\u0161\u0001\u0000\u0000"+
		"\u0000\u074f\u0750\u0005P\u0000\u0000\u0750\u0751\u0005\u0002\u0000\u0000"+
		"\u0751\u0752\u0003`0\u0000\u0752\u0753\u0005\u0003\u0000\u0000\u0753\u0163"+
		"\u0001\u0000\u0000\u0000\u0754\u0755\u0005\u00a1\u0000\u0000\u0755\u0759"+
		"\u0005\u008b\u0000\u0000\u0756\u0757\u0005\\\u0000\u0000\u0757\u0759\u0005"+
		"\u008b\u0000\u0000\u0758\u0754\u0001\u0000\u0000\u0000\u0758\u0756\u0001"+
		"\u0000\u0000\u0000\u0759\u0165\u0001\u0000\u0000\u0000\u075a\u075b\u0005"+
		"U\u0000\u0000\u075b\u075f\u0005Q\u0000\u0000\u075c\u075d\u0005U\u0000"+
		"\u0000\u075d\u075f\u0005l\u0000\u0000\u075e\u075a\u0001\u0000\u0000\u0000"+
		"\u075e\u075c\u0001\u0000\u0000\u0000\u075f\u0167\u0001\u0000\u0000\u0000"+
		"\u0760\u0761\u0005\u0096\u0000\u0000\u0761\u0763\u0005\u0002\u0000\u0000"+
		"\u0762\u0764\u0003\u016a\u00b5\u0000\u0763\u0762\u0001\u0000\u0000\u0000"+
		"\u0763\u0764\u0001\u0000\u0000\u0000\u0764\u0766\u0001\u0000\u0000\u0000"+
		"\u0765\u0767\u0003l6\u0000\u0766\u0765\u0001\u0000\u0000\u0000\u0766\u0767"+
		"\u0001\u0000\u0000\u0000\u0767\u0769\u0001\u0000\u0000\u0000\u0768\u076a"+
		"\u0003\u016c\u00b6\u0000\u0769\u0768\u0001\u0000\u0000\u0000\u0769\u076a"+
		"\u0001\u0000\u0000\u0000\u076a\u076b\u0001\u0000\u0000\u0000\u076b\u076c"+
		"\u0005\u0003\u0000\u0000\u076c\u0169\u0001\u0000\u0000\u0000\u076d\u076e"+
		"\u0005\u009a\u0000\u0000\u076e\u076f\u0005\'\u0000\u0000\u076f\u0774\u0003"+
		"\u00c4b\u0000\u0770\u0771\u0005\u0001\u0000\u0000\u0771\u0773\u0003\u00c4"+
		"b\u0000\u0772\u0770\u0001\u0000\u0000\u0000\u0773\u0776\u0001\u0000\u0000"+
		"\u0000\u0774\u0772\u0001\u0000\u0000\u0000\u0774\u0775\u0001\u0000\u0000"+
		"\u0000\u0775\u016b\u0001\u0000\u0000\u0000\u0776\u0774\u0001\u0000\u0000"+
		"\u0000\u0777\u0778\u0007\u0018\u0000\u0000\u0778\u077a\u0003\u016e\u00b7"+
		"\u0000\u0779\u077b\u0003\u0172\u00b9\u0000\u077a\u0779\u0001\u0000\u0000"+
		"\u0000\u077a\u077b\u0001\u0000\u0000\u0000\u077b\u0785\u0001\u0000\u0000"+
		"\u0000\u077c\u077d\u0007\u0018\u0000\u0000\u077d\u077e\u0005$\u0000\u0000"+
		"\u077e\u077f\u0003\u016e\u00b7\u0000\u077f\u0780\u0005\u001f\u0000\u0000"+
		"\u0780\u0782\u0003\u0170\u00b8\u0000\u0781\u0783\u0003\u0172\u00b9\u0000"+
		"\u0782\u0781\u0001\u0000\u0000\u0000\u0782\u0783\u0001\u0000\u0000\u0000"+
		"\u0783\u0785\u0001\u0000\u0000\u0000\u0784\u0777\u0001\u0000\u0000\u0000"+
		"\u0784\u077c\u0001\u0000\u0000\u0000\u0785\u016d\u0001\u0000\u0000\u0000"+
		"\u0786\u0787\u00052\u0000\u0000\u0787\u0791\u0005\u00a4\u0000\u0000\u0788"+
		"\u0789\u0005\u00bb\u0000\u0000\u0789\u0791\u0005\u009e\u0000\u0000\u078a"+
		"\u078b\u0003\u00c4b\u0000\u078b\u078c\u0005\u009e\u0000\u0000\u078c\u0791"+
		"\u0001\u0000\u0000\u0000\u078d\u078e\u0003\u00c4b\u0000\u078e\u078f\u0005"+
		"R\u0000\u0000\u078f\u0791\u0001\u0000\u0000\u0000\u0790\u0786\u0001\u0000"+
		"\u0000\u0000\u0790\u0788\u0001\u0000\u0000\u0000\u0790\u078a\u0001\u0000"+
		"\u0000\u0000\u0790\u078d\u0001\u0000\u0000\u0000\u0791\u016f\u0001\u0000"+
		"\u0000\u0000\u0792\u0793\u00052\u0000\u0000\u0793\u079d\u0005\u00a4\u0000"+
		"\u0000\u0794\u0795\u0005\u00bb\u0000\u0000\u0795\u079d\u0005R\u0000\u0000"+
		"\u0796\u0797\u0003\u00c4b\u0000\u0797\u0798\u0005\u009e\u0000\u0000\u0798"+
		"\u079d\u0001\u0000\u0000\u0000\u0799\u079a\u0003\u00c4b\u0000\u079a\u079b"+
		"\u0005R\u0000\u0000\u079b\u079d\u0001\u0000\u0000\u0000\u079c\u0792\u0001"+
		"\u0000\u0000\u0000\u079c\u0794\u0001\u0000\u0000\u0000\u079c\u0796\u0001"+
		"\u0000\u0000\u0000\u079c\u0799\u0001\u0000\u0000\u0000\u079d\u0171\u0001"+
		"\u0000\u0000\u0000\u079e\u079f\u0005L\u0000\u0000\u079f\u07a0\u00052\u0000"+
		"\u0000\u07a0\u07a9\u0005\u00a4\u0000\u0000\u07a1\u07a2\u0005L\u0000\u0000"+
		"\u07a2\u07a9\u0005X\u0000\u0000\u07a3\u07a4\u0005L\u0000\u0000\u07a4\u07a9"+
		"\u0005\u00af\u0000\u0000\u07a5\u07a6\u0005L\u0000\u0000\u07a6\u07a7\u0005"+
		"\u0088\u0000\u0000\u07a7\u07a9\u0005\u0094\u0000\u0000\u07a8\u079e\u0001"+
		"\u0000\u0000\u0000\u07a8\u07a1\u0001\u0000\u0000\u0000\u07a8\u07a3\u0001"+
		"\u0000\u0000\u0000\u07a8\u07a5\u0001\u0000\u0000\u0000\u07a9\u0173\u0001"+
		"\u0000\u0000\u0000\u07aa\u07ab\u0006\u00ba\uffff\uffff\u0000\u07ab\u07ac"+
		"\u0005\u0002\u0000\u0000\u07ac\u07ad\u0003\u0174\u00ba\u0000\u07ad\u07ae"+
		"\u0005\u0003\u0000\u0000\u07ae\u07d9\u0001\u0000\u0000\u0000\u07af\u07b0"+
		"\u0003\u00c4b\u0000\u07b0\u07b2\u0005h\u0000\u0000\u07b1\u07b3\u0005\u0089"+
		"\u0000\u0000\u07b2\u07b1\u0001\u0000\u0000\u0000\u07b2\u07b3\u0001\u0000"+
		"\u0000\u0000\u07b3\u07b4\u0001\u0000\u0000\u0000\u07b4\u07b5\u0007\u0019"+
		"\u0000\u0000\u07b5\u07d9\u0001\u0000\u0000\u0000\u07b6\u07b7\u0003\u00c4"+
		"b\u0000\u07b7\u07b9\u0005h\u0000\u0000\u07b8\u07ba\u0005\u0089\u0000\u0000"+
		"\u07b9\u07b8\u0001\u0000\u0000\u0000\u07b9\u07ba\u0001\u0000\u0000\u0000"+
		"\u07ba\u07bb\u0001\u0000\u0000\u0000\u07bb\u07bc\u0005?\u0000\u0000\u07bc"+
		"\u07bd\u0005U\u0000\u0000\u07bd\u07be\u0003\u00c4b\u0000\u07be\u07d9\u0001"+
		"\u0000\u0000\u0000\u07bf\u07c1\u0003\u00c4b\u0000\u07c0\u07c2\u0005\u0089"+
		"\u0000\u0000\u07c1\u07c0\u0001\u0000\u0000\u0000\u07c1\u07c2\u0001\u0000"+
		"\u0000\u0000\u07c2\u07c3\u0001\u0000\u0000\u0000\u07c3\u07c5\u0005}\u0000"+
		"\u0000\u07c4\u07c6\u0005\u008d\u0000\u0000\u07c5\u07c4\u0001\u0000\u0000"+
		"\u0000\u07c5\u07c6\u0001\u0000\u0000\u0000\u07c6\u07c7\u0001\u0000\u0000"+
		"\u0000\u07c7\u07c8\u0003\u00c8d\u0000\u07c8\u07d9\u0001\u0000\u0000\u0000"+
		"\u07c9\u07d9\u0003\u0188\u00c4\u0000\u07ca\u07d9\u0003\u0184\u00c2\u0000"+
		"\u07cb\u07cd\u0003\u00c4b\u0000\u07cc\u07ce\u0005\u0089\u0000\u0000\u07cd"+
		"\u07cc\u0001\u0000\u0000\u0000\u07cd\u07ce\u0001\u0000\u0000\u0000\u07ce"+
		"\u07cf\u0001\u0000\u0000\u0000\u07cf\u07d0\u0007\u001a\u0000\u0000\u07d0"+
		"\u07d1\u0003\u00c4b\u0000\u07d1\u07d9\u0001\u0000\u0000\u0000\u07d2\u07d9"+
		"\u0003\u0182\u00c1\u0000\u07d3\u07d9\u0003\u0186\u00c3\u0000\u07d4\u07d9"+
		"\u0003\u018c\u00c6\u0000\u07d5\u07d6\u0005\u0089\u0000\u0000\u07d6\u07d9"+
		"\u0003\u0174\u00ba\u0004\u07d7\u07d9\u0003\u00c4b\u0000\u07d8\u07aa\u0001"+
		"\u0000\u0000\u0000\u07d8\u07af\u0001\u0000\u0000\u0000\u07d8\u07b6\u0001"+
		"\u0000\u0000\u0000\u07d8\u07bf\u0001\u0000\u0000\u0000\u07d8\u07c9\u0001"+
		"\u0000\u0000\u0000\u07d8\u07ca\u0001\u0000\u0000\u0000\u07d8\u07cb\u0001"+
		"\u0000\u0000\u0000\u07d8\u07d2\u0001\u0000\u0000\u0000\u07d8\u07d3\u0001"+
		"\u0000\u0000\u0000\u07d8\u07d4\u0001\u0000\u0000\u0000\u07d8\u07d5\u0001"+
		"\u0000\u0000\u0000\u07d8\u07d7\u0001\u0000\u0000\u0000\u07d9\u07e2\u0001"+
		"\u0000\u0000\u0000\u07da\u07db\n\u0003\u0000\u0000\u07db\u07dc\u0005\u001f"+
		"\u0000\u0000\u07dc\u07e1\u0003\u0174\u00ba\u0004\u07dd\u07de\n\u0002\u0000"+
		"\u0000\u07de\u07df\u0005\u0092\u0000\u0000\u07df\u07e1\u0003\u0174\u00ba"+
		"\u0003\u07e0\u07da\u0001\u0000\u0000\u0000\u07e0\u07dd\u0001\u0000\u0000"+
		"\u0000\u07e1\u07e4\u0001\u0000\u0000\u0000\u07e2\u07e0\u0001\u0000\u0000"+
		"\u0000\u07e2\u07e3\u0001\u0000\u0000\u0000\u07e3\u0175\u0001\u0000\u0000"+
		"\u0000\u07e4\u07e2\u0001\u0000\u0000\u0000\u07e5\u07e8\u0003\u00c4b\u0000"+
		"\u07e6\u07e8\u0003\u0174\u00ba\u0000\u07e7\u07e5\u0001\u0000\u0000\u0000"+
		"\u07e7\u07e6\u0001\u0000\u0000\u0000\u07e8\u0177\u0001\u0000\u0000\u0000"+
		"\u07e9\u07ec\u0003\u017a\u00bd\u0000\u07ea\u07ec\u0003\u0180\u00c0\u0000"+
		"\u07eb\u07e9\u0001\u0000\u0000\u0000\u07eb\u07ea\u0001\u0000\u0000\u0000"+
		"\u07ec\u0179\u0001\u0000\u0000\u0000\u07ed\u07ee\u0007\u001b\u0000\u0000"+
		"\u07ee\u017b\u0001\u0000\u0000\u0000\u07ef\u07f0\u0007\u001c\u0000\u0000"+
		"\u07f0\u017d\u0001\u0000\u0000\u0000\u07f1\u07f2\u0007\u001d\u0000\u0000"+
		"\u07f2\u017f\u0001\u0000\u0000\u0000\u07f3\u07f4\u0007\u001e\u0000\u0000"+
		"\u07f4\u0181\u0001\u0000\u0000\u0000\u07f5\u07f6\u0003\u00c4b\u0000\u07f6"+
		"\u07f7\u0007\u001f\u0000\u0000\u07f7\u07f8\u0003\u00c4b\u0000\u07f8\u0183"+
		"\u0001\u0000\u0000\u0000\u07f9\u07fb\u0003\u00c4b\u0000\u07fa\u07fc\u0005"+
		"\u0089\u0000\u0000\u07fb\u07fa\u0001\u0000\u0000\u0000\u07fb\u07fc\u0001"+
		"\u0000\u0000\u0000\u07fc\u07fd\u0001\u0000\u0000\u0000\u07fd\u07fe\u0005"+
		"$\u0000\u0000\u07fe\u07ff\u0003\u00c4b\u0000\u07ff\u0800\u0005\u001f\u0000"+
		"\u0000\u0800\u0801\u0003\u00c4b\u0000\u0801\u0185\u0001\u0000\u0000\u0000"+
		"\u0802\u0804\u0003\u00c4b\u0000\u0803\u0805\u0005\u0089\u0000\u0000\u0804"+
		"\u0803\u0001\u0000\u0000\u0000\u0804\u0805\u0001\u0000\u0000\u0000\u0805"+
		"\u0806\u0001\u0000\u0000\u0000\u0806\u0807\u0007 \u0000\u0000\u0807\u080e"+
		"\u0003\u00c4b\u0000\u0808\u080c\u0005I\u0000\u0000\u0809\u080d\u0005\u00cc"+
		"\u0000\u0000\u080a\u080d\u0005\u00cd\u0000\u0000\u080b\u080d\u0003\u019a"+
		"\u00cd\u0000\u080c\u0809\u0001\u0000\u0000\u0000\u080c\u080a\u0001\u0000"+
		"\u0000\u0000\u080c\u080b\u0001\u0000\u0000\u0000\u080d\u080f\u0001\u0000"+
		"\u0000\u0000\u080e\u0808\u0001\u0000\u0000\u0000\u080e\u080f\u0001\u0000"+
		"\u0000\u0000\u080f\u0187\u0001\u0000\u0000\u0000\u0810\u0812\u0003\u00c4"+
		"b\u0000\u0811\u0813\u0005\u0089\u0000\u0000\u0812\u0811\u0001\u0000\u0000"+
		"\u0000\u0812\u0813\u0001\u0000\u0000\u0000\u0813\u0814\u0001\u0000\u0000"+
		"\u0000\u0814\u0815\u0005^\u0000\u0000\u0815\u0816\u0003\u018a\u00c5\u0000"+
		"\u0816\u0189\u0001\u0000\u0000\u0000\u0817\u0818\u0007!\u0000\u0000\u0818"+
		"\u0819\u0005\u0002\u0000\u0000\u0819\u081a\u0003\u00ceg\u0000\u081a\u081b"+
		"\u0005\u0003\u0000\u0000\u081b\u082e\u0001\u0000\u0000\u0000\u081c\u081d"+
		"\u0005\u0002\u0000\u0000\u081d\u081e\u0003R)\u0000\u081e\u081f\u0005\u0003"+
		"\u0000\u0000\u081f\u082e\u0001\u0000\u0000\u0000\u0820\u082e\u0003\u019a"+
		"\u00cd\u0000\u0821\u082a\u0005\u0002\u0000\u0000\u0822\u0827\u0003\u0176"+
		"\u00bb\u0000\u0823\u0824\u0005\u0001\u0000\u0000\u0824\u0826\u0003\u0176"+
		"\u00bb\u0000\u0825\u0823\u0001\u0000\u0000\u0000\u0826\u0829\u0001\u0000"+
		"\u0000\u0000\u0827\u0825\u0001\u0000\u0000\u0000\u0827\u0828\u0001\u0000"+
		"\u0000\u0000\u0828\u082b\u0001\u0000\u0000\u0000\u0829\u0827\u0001\u0000"+
		"\u0000\u0000\u082a\u0822\u0001\u0000\u0000\u0000\u082a\u082b\u0001\u0000"+
		"\u0000\u0000\u082b\u082c\u0001\u0000\u0000\u0000\u082c\u082e\u0005\u0003"+
		"\u0000\u0000\u082d\u0817\u0001\u0000\u0000\u0000\u082d\u081c\u0001\u0000"+
		"\u0000\u0000\u082d\u0820\u0001\u0000\u0000\u0000\u082d\u0821\u0001\u0000"+
		"\u0000\u0000\u082e\u018b\u0001\u0000\u0000\u0000\u082f\u0830\u0005M\u0000"+
		"\u0000\u0830\u0831\u0007!\u0000\u0000\u0831\u0832\u0005\u0002\u0000\u0000"+
		"\u0832\u0833\u0003\u00ceg\u0000\u0833\u0834\u0005\u0003\u0000\u0000\u0834"+
		"\u0838\u0001\u0000\u0000\u0000\u0835\u0836\u0005M\u0000\u0000\u0836\u0838"+
		"\u0003\u00c4b\u0000\u0837\u082f\u0001\u0000\u0000\u0000\u0837\u0835\u0001"+
		"\u0000\u0000\u0000\u0838\u018d\u0001\u0000\u0000\u0000\u0839\u083d\u0005"+
		"r\u0000\u0000\u083a\u083d\u0005x\u0000\u0000\u083b\u083d\u0003\u00ceg"+
		"\u0000\u083c\u0839\u0001\u0000\u0000\u0000\u083c\u083a\u0001\u0000\u0000"+
		"\u0000\u083c\u083b\u0001\u0000\u0000\u0000\u083d\u018f\u0001\u0000\u0000"+
		"\u0000\u083e\u0843\u0003\u0192\u00c9\u0000\u083f\u0840\u0005\u0001\u0000"+
		"\u0000\u0840\u0842\u0003\u0192\u00c9\u0000\u0841\u083f\u0001\u0000\u0000"+
		"\u0000\u0842\u0845\u0001\u0000\u0000\u0000\u0843\u0841\u0001\u0000\u0000"+
		"\u0000\u0843\u0844\u0001\u0000\u0000\u0000\u0844\u0191\u0001\u0000\u0000"+
		"\u0000\u0845\u0843\u0001\u0000\u0000\u0000\u0846\u0849\u0003\u0176\u00bb"+
		"\u0000\u0847\u0849\u0003@ \u0000\u0848\u0846\u0001\u0000\u0000\u0000\u0848"+
		"\u0847\u0001\u0000\u0000\u0000\u0849\u084b\u0001\u0000\u0000\u0000\u084a"+
		"\u084c\u0003\u0198\u00cc\u0000\u084b\u084a\u0001\u0000\u0000\u0000\u084b"+
		"\u084c\u0001\u0000\u0000\u0000\u084c\u0193\u0001\u0000\u0000\u0000\u084d"+
		"\u0850\u0003\u019a\u00cd\u0000\u084e\u0850\u0005\u00ce\u0000\u0000\u084f"+
		"\u084d\u0001\u0000\u0000\u0000\u084f\u084e\u0001\u0000\u0000\u0000\u0850"+
		"\u0195\u0001\u0000\u0000\u0000\u0851\u0854\u0003\u019a\u00cd\u0000\u0852"+
		"\u0854\u0003v;\u0000\u0853\u0851\u0001\u0000\u0000\u0000\u0853\u0852\u0001"+
		"\u0000\u0000\u0000\u0854\u0197\u0001\u0000\u0000\u0000\u0855\u0856\u0005"+
		"!\u0000\u0000\u0856\u0859\u0003\u01a0\u00d0\u0000\u0857\u0859\u0003\u019e"+
		"\u00cf\u0000\u0858\u0855\u0001\u0000\u0000\u0000\u0858\u0857\u0001\u0000"+
		"\u0000\u0000\u0859\u0199\u0001\u0000\u0000\u0000\u085a\u085b\u0005\t\u0000"+
		"\u0000\u085b\u0861\u0003\u01a0\u00d0\u0000\u085c\u085e\u0005\u0015\u0000"+
		"\u0000\u085d\u085f\u0005\u00ce\u0000\u0000\u085e\u085d\u0001\u0000\u0000"+
		"\u0000\u085e\u085f\u0001\u0000\u0000\u0000\u085f\u0861\u0001\u0000\u0000"+
		"\u0000\u0860\u085a\u0001\u0000\u0000\u0000\u0860\u085c\u0001\u0000\u0000"+
		"\u0000\u0861\u019b\u0001\u0000\u0000\u0000\u0862\u0867\u0003\u01a0\u00d0"+
		"\u0000\u0863\u0864\u0005\r\u0000\u0000\u0864\u0866\u0003\u01a0\u00d0\u0000"+
		"\u0865\u0863\u0001\u0000\u0000\u0000\u0866\u0869\u0001\u0000\u0000\u0000"+
		"\u0867\u0865\u0001\u0000\u0000\u0000\u0867\u0868\u0001\u0000\u0000\u0000"+
		"\u0868\u019d\u0001\u0000\u0000\u0000\u0869\u0867\u0001\u0000\u0000\u0000"+
		"\u086a\u086e\u0005\u00db\u0000\u0000\u086b\u086e\u0005\u00dc\u0000\u0000"+
		"\u086c\u086e\u0007\"\u0000\u0000\u086d\u086a\u0001\u0000\u0000\u0000\u086d"+
		"\u086b\u0001\u0000\u0000\u0000\u086d\u086c\u0001\u0000\u0000\u0000\u086e"+
		"\u019f\u0001\u0000\u0000\u0000\u086f\u0876\u0003\u019e\u00cf\u0000\u0870"+
		"\u0876\u0005V\u0000\u0000\u0871\u0876\u0005b\u0000\u0000\u0872\u0876\u0005"+
		"o\u0000\u0000\u0873\u0876\u0005\u0095\u0000\u0000\u0874\u0876\u0005\u00a2"+
		"\u0000\u0000\u0875\u086f\u0001\u0000\u0000\u0000\u0875\u0870\u0001\u0000"+
		"\u0000\u0000\u0875\u0871\u0001\u0000\u0000\u0000\u0875\u0872\u0001\u0000"+
		"\u0000\u0000\u0875\u0873\u0001\u0000\u0000\u0000\u0875\u0874\u0001\u0000"+
		"\u0000\u0000\u0876\u01a1\u0001\u0000\u0000\u0000\u00f4\u01a9\u01ae\u01b6"+
		"\u01bf\u01c5\u01c8\u01ce\u01d1\u01e0\u01e5\u01e8\u01f3\u01f7\u01fe\u0206"+
		"\u0209\u020c\u020f\u0212\u0216\u0219\u021c\u021f\u0223\u0226\u0229\u022c"+
		"\u022e\u0238\u023f\u0245\u0249\u024c\u0252\u0254\u0259\u025d\u0261\u0264"+
		"\u026a\u026c\u0270\u0275\u0279\u0281\u028a\u028e\u0292\u0298\u029b\u02a3"+
		"\u02ae\u02b7\u02bf\u02cd\u02d2\u02d8\u02da\u02e5\u02e9\u02ec\u02f1\u02fe"+
		"\u0306\u030c\u0312\u031b\u0320\u0326\u0338\u033c\u033f\u0342\u0345\u034b"+
		"\u0356\u035f\u0369\u0372\u0377\u037b\u037f\u0381\u038c\u0395\u039c\u03a0"+
		"\u03a7\u03ab\u03b2\u03b6\u03bd\u03c1\u03c8\u03cc\u03d1\u03e5\u03ec\u03f3"+
		"\u03ff\u0402\u041b\u0421\u0437\u043a\u0441\u044e\u0456\u045a\u045e\u0469"+
		"\u046d\u0475\u0482\u0498\u04a8\u04aa\u04b6\u04ba\u04be\u04c1\u04c5\u04cc"+
		"\u04d2\u04df\u04e8\u04f4\u0506\u050b\u051a\u0521\u0528\u0531\u0538\u053c"+
		"\u0544\u0548\u055e\u0575\u0583\u0586\u0591\u059b\u05a6\u05aa\u05b3\u05b6"+
		"\u05b9\u05c2\u05cb\u05e9\u05f8\u05fc\u0601\u0605\u060a\u060e\u0613\u0616"+
		"\u061b\u061f\u0624\u0628\u062d\u0631\u0636\u063a\u0653\u065f\u0672\u067a"+
		"\u067c\u0685\u0689\u068f\u0698\u06a0\u06a4\u06a7\u06aa\u06ad\u06b0\u06b3"+
		"\u06bb\u06c2\u06e4\u06f0\u06f5\u06fc\u06ff\u070c\u0713\u0716\u0723\u072c"+
		"\u0732\u0736\u0739\u073c\u0743\u0747\u0758\u075e\u0763\u0766\u0769\u0774"+
		"\u077a\u0782\u0784\u0790\u079c\u07a8\u07b2\u07b9\u07c1\u07c5\u07cd\u07d8"+
		"\u07e0\u07e2\u07e7\u07eb\u07fb\u0804\u080c\u080e\u0812\u0827\u082a\u082d"+
		"\u0837\u083c\u0843\u0848\u084b\u084f\u0853\u0858\u085e\u0860\u0867\u086d"+
		"\u0875";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}