// Generated from org/springframework/data/jpa/repository/query/Hql.g4 by ANTLR 4.13.2
package org.springframework.data.jpa.repository.query;

/**
 * HQL per https://docs.jboss.org/hibernate/orm/6.1/userguide/html_single/Hibernate_User_Guide.html#query-language
 *
 * This is a mixture of Hibernate's BNF and missing bits of grammar. There are gaps and inconsistencies in the
 * BNF itself, explained by other fragments of their spec. Additionally, alternate labels are used to provide easier
 * management of complex rules in the generated Visitor. Finally, there are labels applied to rule elements (op=('+'|'-')
 * to simplify the processing.
 *
 * @author Greg Turnquist
 * @author Mark Paluch
 * @author Yannick Brandt
 * @since 3.1
 */


import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import org.jspecify.annotations.NullUnmarked;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import jakarta.annotation.Generated;


@NullUnmarked
@Generated("HqlParser")
@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "NullAway"})
class HqlParser extends Parser {
	// Customization: Suppress version check
	// static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, WS=22, COMMENT=23, ASTERISK=24, 
		ID=25, VERSION=26, VERSIONED=27, NATURALID=28, FK=29, ABSENT=30, ALL=31, 
		AND=32, ANY=33, ARRAY=34, AS=35, ASC=36, AVG=37, BETWEEN=38, BOTH=39, 
		BREADTH=40, BY=41, CASE=42, CAST=43, COLLATE=44, COLUMN=45, COLUMNS=46, 
		CONDITIONAL=47, CONFLICT=48, CONSTRAINT=49, CONTAINS=50, COUNT=51, CROSS=52, 
		CUBE=53, CURRENT=54, CURRENT_DATE=55, CURRENT_INSTANT=56, CURRENT_TIME=57, 
		CURRENT_TIMESTAMP=58, CYCLE=59, DATE=60, DATETIME=61, DAY=62, DEFAULT=63, 
		DELETE=64, DEPTH=65, DESC=66, DISTINCT=67, DO=68, ELEMENT=69, ELEMENTS=70, 
		ELSE=71, EMPTY=72, END=73, ENTRY=74, EPOCH=75, ERROR=76, ESCAPE=77, EVERY=78, 
		EXCEPT=79, EXCLUDE=80, EXISTS=81, EXTRACT=82, FETCH=83, FILTER=84, FIRST=85, 
		FOLLOWING=86, FOR=87, FORMAT=88, FROM=89, FULL=90, FUNCTION=91, GROUP=92, 
		GROUPS=93, HAVING=94, HOUR=95, IGNORE=96, ILIKE=97, IN=98, INCLUDES=99, 
		INDEX=100, INDICES=101, INNER=102, INSERT=103, INSTANT=104, INTERSECT=105, 
		INTERSECTS=106, INTO=107, IS=108, JOIN=109, JSON=110, JSON_ARRAY=111, 
		JSON_ARRAYAGG=112, JSON_EXISTS=113, JSON_OBJECT=114, JSON_OBJECTAGG=115, 
		JSON_QUERY=116, JSON_TABLE=117, JSON_VALUE=118, KEY=119, KEYS=120, LAST=121, 
		LATERAL=122, LEADING=123, LEFT=124, LIKE=125, LIMIT=126, LIST=127, LISTAGG=128, 
		LOCAL=129, LOCAL_DATE=130, LOCAL_DATETIME=131, LOCAL_TIME=132, MAP=133, 
		MATERIALIZED=134, MAX=135, MAXELEMENT=136, MAXINDEX=137, MEMBER=138, MICROSECOND=139, 
		MILLISECOND=140, MIN=141, MINELEMENT=142, MININDEX=143, MINUTE=144, MONTH=145, 
		NAME=146, NANOSECOND=147, NEW=148, NESTED=149, NEXT=150, NO=151, NOT=152, 
		NOTHING=153, NULLS=154, OBJECT=155, OF=156, OFFSET=157, OFFSET_DATETIME=158, 
		ON=159, ONLY=160, OR=161, ORDER=162, ORDINALITY=163, OTHERS=164, OUTER=165, 
		OVER=166, OVERFLOW=167, OVERLAY=168, PAD=169, PATH=170, PARTITION=171, 
		PASSING=172, PERCENT=173, PLACING=174, POSITION=175, PRECEDING=176, QUARTER=177, 
		RANGE=178, RESPECT=179, RETURNING=180, RIGHT=181, ROLLUP=182, ROW=183, 
		ROWS=184, SEARCH=185, SECOND=186, SELECT=187, SET=188, SIZE=189, SOME=190, 
		SUBSTRING=191, SUM=192, THEN=193, TIES=194, TIME=195, TIMESTAMP=196, TIMEZONE_HOUR=197, 
		TIMEZONE_MINUTE=198, TO=199, TRAILING=200, TREAT=201, TRIM=202, TRUNC=203, 
		TRUNCATE=204, TYPE=205, UNBOUNDED=206, UNCONDITIONAL=207, UNION=208, UNIQUE=209, 
		UPDATE=210, USING=211, VALUE=212, VALUES=213, WEEK=214, WHEN=215, WHERE=216, 
		WITH=217, WITHIN=218, WITHOUT=219, WRAPPER=220, XML=221, XMLAGG=222, XMLATTRIBUTES=223, 
		XMLELEMENT=224, XMLEXISTS=225, XMLFOREST=226, XMLPI=227, XMLQUERY=228, 
		XMLTABLE=229, YEAR=230, ZONED=231, NULL=232, TRUE=233, FALSE=234, STRING_LITERAL=235, 
		JAVA_STRING_LITERAL=236, INTEGER_LITERAL=237, LONG_LITERAL=238, FLOAT_LITERAL=239, 
		DOUBLE_LITERAL=240, BIG_INTEGER_LITERAL=241, BIG_DECIMAL_LITERAL=242, 
		HEX_LITERAL=243, BINARY_LITERAL=244, TIMESTAMP_ESCAPE_START=245, DATE_ESCAPE_START=246, 
		TIME_ESCAPE_START=247, PLUS=248, MINUS=249, IDENTIFIER=250, QUOTED_IDENTIFIER=251;
	public static final int
		RULE_start = 0, RULE_ql_statement = 1, RULE_selectStatement = 2, RULE_queryExpression = 3, 
		RULE_withClause = 4, RULE_cte = 5, RULE_searchClause = 6, RULE_searchSpecifications = 7, 
		RULE_searchSpecification = 8, RULE_cycleClause = 9, RULE_cteAttributes = 10, 
		RULE_orderedQuery = 11, RULE_query = 12, RULE_queryOrder = 13, RULE_fromClause = 14, 
		RULE_entityWithJoins = 15, RULE_joinSpecifier = 16, RULE_fromRoot = 17, 
		RULE_join = 18, RULE_joinTarget = 19, RULE_updateStatement = 20, RULE_targetEntity = 21, 
		RULE_setClause = 22, RULE_assignment = 23, RULE_deleteStatement = 24, 
		RULE_insertStatement = 25, RULE_targetFields = 26, RULE_valuesList = 27, 
		RULE_values = 28, RULE_conflictClause = 29, RULE_conflictTarget = 30, 
		RULE_conflictAction = 31, RULE_instantiation = 32, RULE_groupedItem = 33, 
		RULE_sortedItem = 34, RULE_sortExpression = 35, RULE_sortDirection = 36, 
		RULE_nullsPrecedence = 37, RULE_limitClause = 38, RULE_offsetClause = 39, 
		RULE_fetchClause = 40, RULE_subquery = 41, RULE_selectClause = 42, RULE_selectionList = 43, 
		RULE_selection = 44, RULE_selectExpression = 45, RULE_mapEntrySelection = 46, 
		RULE_jpaSelectObjectSyntax = 47, RULE_whereClause = 48, RULE_joinType = 49, 
		RULE_crossJoin = 50, RULE_joinRestriction = 51, RULE_jpaCollectionJoin = 52, 
		RULE_groupByClause = 53, RULE_orderByClause = 54, RULE_havingClause = 55, 
		RULE_setOperator = 56, RULE_literal = 57, RULE_booleanLiteral = 58, RULE_numericLiteral = 59, 
		RULE_dateTimeLiteral = 60, RULE_localDateTimeLiteral = 61, RULE_zonedDateTimeLiteral = 62, 
		RULE_offsetDateTimeLiteral = 63, RULE_dateLiteral = 64, RULE_timeLiteral = 65, 
		RULE_dateTime = 66, RULE_localDateTime = 67, RULE_zonedDateTime = 68, 
		RULE_offsetDateTime = 69, RULE_offsetDateTimeWithMinutes = 70, RULE_jdbcTimestampLiteral = 71, 
		RULE_jdbcDateLiteral = 72, RULE_jdbcTimeLiteral = 73, RULE_genericTemporalLiteralText = 74, 
		RULE_arrayLiteral = 75, RULE_generalizedLiteral = 76, RULE_generalizedLiteralType = 77, 
		RULE_generalizedLiteralText = 78, RULE_date = 79, RULE_time = 80, RULE_offset = 81, 
		RULE_offsetWithMinutes = 82, RULE_year = 83, RULE_month = 84, RULE_day = 85, 
		RULE_hour = 86, RULE_minute = 87, RULE_second = 88, RULE_zoneId = 89, 
		RULE_extractField = 90, RULE_datetimeField = 91, RULE_dayField = 92, RULE_weekField = 93, 
		RULE_timeZoneField = 94, RULE_dateOrTimeField = 95, RULE_binaryLiteral = 96, 
		RULE_temporalLiteral = 97, RULE_expression = 98, RULE_primaryExpression = 99, 
		RULE_path = 100, RULE_generalPathFragment = 101, RULE_indexedPathAccessFragment = 102, 
		RULE_simplePath = 103, RULE_simplePathElement = 104, RULE_pathContinuation = 105, 
		RULE_entityTypeReference = 106, RULE_entityIdReference = 107, RULE_entityVersionReference = 108, 
		RULE_entityNaturalIdReference = 109, RULE_syntacticDomainPath = 110, RULE_slicedPathAccessFragment = 111, 
		RULE_treatedNavigablePath = 112, RULE_collectionValueNavigablePath = 113, 
		RULE_mapKeyNavigablePath = 114, RULE_toOneFkReference = 115, RULE_caseList = 116, 
		RULE_simpleCaseExpression = 117, RULE_searchedCaseExpression = 118, RULE_caseWhenExpressionClause = 119, 
		RULE_caseWhenPredicateClause = 120, RULE_function = 121, RULE_setReturningFunction = 122, 
		RULE_simpleSetReturningFunction = 123, RULE_standardFunction = 124, RULE_castFunction = 125, 
		RULE_castTarget = 126, RULE_castTargetType = 127, RULE_substringFunction = 128, 
		RULE_substringFunctionStartArgument = 129, RULE_substringFunctionLengthArgument = 130, 
		RULE_trimFunction = 131, RULE_trimSpecification = 132, RULE_trimCharacter = 133, 
		RULE_padFunction = 134, RULE_padSpecification = 135, RULE_padCharacter = 136, 
		RULE_padLength = 137, RULE_positionFunction = 138, RULE_positionFunctionPatternArgument = 139, 
		RULE_positionFunctionStringArgument = 140, RULE_overlayFunction = 141, 
		RULE_overlayFunctionStringArgument = 142, RULE_overlayFunctionReplacementArgument = 143, 
		RULE_overlayFunctionStartArgument = 144, RULE_overlayFunctionLengthArgument = 145, 
		RULE_currentDateFunction = 146, RULE_currentTimeFunction = 147, RULE_currentTimestampFunction = 148, 
		RULE_instantFunction = 149, RULE_localDateTimeFunction = 150, RULE_offsetDateTimeFunction = 151, 
		RULE_localDateFunction = 152, RULE_localTimeFunction = 153, RULE_formatFunction = 154, 
		RULE_collation = 155, RULE_collateFunction = 156, RULE_cube = 157, RULE_rollup = 158, 
		RULE_format = 159, RULE_extractFunction = 160, RULE_truncFunction = 161, 
		RULE_jpaNonstandardFunction = 162, RULE_jpaNonstandardFunctionName = 163, 
		RULE_columnFunction = 164, RULE_genericFunction = 165, RULE_genericFunctionName = 166, 
		RULE_genericFunctionArguments = 167, RULE_collectionSizeFunction = 168, 
		RULE_collectionAggregateFunction = 169, RULE_collectionFunctionMisuse = 170, 
		RULE_aggregateFunction = 171, RULE_everyFunction = 172, RULE_anyFunction = 173, 
		RULE_everyAllQuantifier = 174, RULE_anySomeQuantifier = 175, RULE_listaggFunction = 176, 
		RULE_onOverflowClause = 177, RULE_withinGroupClause = 178, RULE_filterClause = 179, 
		RULE_nullsClause = 180, RULE_nthSideClause = 181, RULE_overClause = 182, 
		RULE_partitionClause = 183, RULE_frameClause = 184, RULE_frameStart = 185, 
		RULE_frameEnd = 186, RULE_frameExclusion = 187, RULE_jsonFunction = 188, 
		RULE_jsonArrayFunction = 189, RULE_jsonExistsFunction = 190, RULE_jsonExistsOnErrorClause = 191, 
		RULE_jsonObjectFunction = 192, RULE_jsonObjectFunctionEntry = 193, RULE_jsonObjectKeyValueEntry = 194, 
		RULE_jsonObjectAssignmentEntry = 195, RULE_jsonQueryFunction = 196, RULE_jsonQueryWrapperClause = 197, 
		RULE_jsonQueryOnErrorOrEmptyClause = 198, RULE_jsonValueFunction = 199, 
		RULE_jsonValueReturningClause = 200, RULE_jsonValueOnErrorOrEmptyClause = 201, 
		RULE_jsonArrayAggFunction = 202, RULE_jsonObjectAggFunction = 203, RULE_jsonPassingClause = 204, 
		RULE_jsonNullClause = 205, RULE_jsonUniqueKeysClause = 206, RULE_jsonTableFunction = 207, 
		RULE_jsonTableErrorClause = 208, RULE_jsonTableColumnsClause = 209, RULE_jsonTableColumns = 210, 
		RULE_jsonTableColumn = 211, RULE_xmlFunction = 212, RULE_xmlElementFunction = 213, 
		RULE_xmlAttributesFunction = 214, RULE_xmlForestFunction = 215, RULE_xmlPiFunction = 216, 
		RULE_xmlQueryFunction = 217, RULE_xmlExistsFunction = 218, RULE_xmlAggFunction = 219, 
		RULE_aliasedExpressionOrPredicate = 220, RULE_potentiallyAliasedExpressionOrPredicate = 221, 
		RULE_xmlTableFunction = 222, RULE_xmlTableColumnsClause = 223, RULE_xmlTableColumn = 224, 
		RULE_xmltableDefaultClause = 225, RULE_predicate = 226, RULE_expressionOrPredicate = 227, 
		RULE_collectionQuantifier = 228, RULE_elementsValuesQuantifier = 229, 
		RULE_elementValueQuantifier = 230, RULE_indexKeyQuantifier = 231, RULE_indicesKeysQuantifier = 232, 
		RULE_relationalExpression = 233, RULE_betweenExpression = 234, RULE_stringPatternMatching = 235, 
		RULE_inExpression = 236, RULE_inList = 237, RULE_existsExpression = 238, 
		RULE_instantiationTarget = 239, RULE_instantiationArguments = 240, RULE_instantiationArgument = 241, 
		RULE_parameterOrIntegerLiteral = 242, RULE_parameterOrNumberLiteral = 243, 
		RULE_variable = 244, RULE_parameter = 245, RULE_entityName = 246, RULE_nakedIdentifier = 247, 
		RULE_identifier = 248;
	private static String[] makeRuleNames() {
		return new String[] {
			"start", "ql_statement", "selectStatement", "queryExpression", "withClause", 
			"cte", "searchClause", "searchSpecifications", "searchSpecification", 
			"cycleClause", "cteAttributes", "orderedQuery", "query", "queryOrder", 
			"fromClause", "entityWithJoins", "joinSpecifier", "fromRoot", "join", 
			"joinTarget", "updateStatement", "targetEntity", "setClause", "assignment", 
			"deleteStatement", "insertStatement", "targetFields", "valuesList", "values", 
			"conflictClause", "conflictTarget", "conflictAction", "instantiation", 
			"groupedItem", "sortedItem", "sortExpression", "sortDirection", "nullsPrecedence", 
			"limitClause", "offsetClause", "fetchClause", "subquery", "selectClause", 
			"selectionList", "selection", "selectExpression", "mapEntrySelection", 
			"jpaSelectObjectSyntax", "whereClause", "joinType", "crossJoin", "joinRestriction", 
			"jpaCollectionJoin", "groupByClause", "orderByClause", "havingClause", 
			"setOperator", "literal", "booleanLiteral", "numericLiteral", "dateTimeLiteral", 
			"localDateTimeLiteral", "zonedDateTimeLiteral", "offsetDateTimeLiteral", 
			"dateLiteral", "timeLiteral", "dateTime", "localDateTime", "zonedDateTime", 
			"offsetDateTime", "offsetDateTimeWithMinutes", "jdbcTimestampLiteral", 
			"jdbcDateLiteral", "jdbcTimeLiteral", "genericTemporalLiteralText", "arrayLiteral", 
			"generalizedLiteral", "generalizedLiteralType", "generalizedLiteralText", 
			"date", "time", "offset", "offsetWithMinutes", "year", "month", "day", 
			"hour", "minute", "second", "zoneId", "extractField", "datetimeField", 
			"dayField", "weekField", "timeZoneField", "dateOrTimeField", "binaryLiteral", 
			"temporalLiteral", "expression", "primaryExpression", "path", "generalPathFragment", 
			"indexedPathAccessFragment", "simplePath", "simplePathElement", "pathContinuation", 
			"entityTypeReference", "entityIdReference", "entityVersionReference", 
			"entityNaturalIdReference", "syntacticDomainPath", "slicedPathAccessFragment", 
			"treatedNavigablePath", "collectionValueNavigablePath", "mapKeyNavigablePath", 
			"toOneFkReference", "caseList", "simpleCaseExpression", "searchedCaseExpression", 
			"caseWhenExpressionClause", "caseWhenPredicateClause", "function", "setReturningFunction", 
			"simpleSetReturningFunction", "standardFunction", "castFunction", "castTarget", 
			"castTargetType", "substringFunction", "substringFunctionStartArgument", 
			"substringFunctionLengthArgument", "trimFunction", "trimSpecification", 
			"trimCharacter", "padFunction", "padSpecification", "padCharacter", "padLength", 
			"positionFunction", "positionFunctionPatternArgument", "positionFunctionStringArgument", 
			"overlayFunction", "overlayFunctionStringArgument", "overlayFunctionReplacementArgument", 
			"overlayFunctionStartArgument", "overlayFunctionLengthArgument", "currentDateFunction", 
			"currentTimeFunction", "currentTimestampFunction", "instantFunction", 
			"localDateTimeFunction", "offsetDateTimeFunction", "localDateFunction", 
			"localTimeFunction", "formatFunction", "collation", "collateFunction", 
			"cube", "rollup", "format", "extractFunction", "truncFunction", "jpaNonstandardFunction", 
			"jpaNonstandardFunctionName", "columnFunction", "genericFunction", "genericFunctionName", 
			"genericFunctionArguments", "collectionSizeFunction", "collectionAggregateFunction", 
			"collectionFunctionMisuse", "aggregateFunction", "everyFunction", "anyFunction", 
			"everyAllQuantifier", "anySomeQuantifier", "listaggFunction", "onOverflowClause", 
			"withinGroupClause", "filterClause", "nullsClause", "nthSideClause", 
			"overClause", "partitionClause", "frameClause", "frameStart", "frameEnd", 
			"frameExclusion", "jsonFunction", "jsonArrayFunction", "jsonExistsFunction", 
			"jsonExistsOnErrorClause", "jsonObjectFunction", "jsonObjectFunctionEntry", 
			"jsonObjectKeyValueEntry", "jsonObjectAssignmentEntry", "jsonQueryFunction", 
			"jsonQueryWrapperClause", "jsonQueryOnErrorOrEmptyClause", "jsonValueFunction", 
			"jsonValueReturningClause", "jsonValueOnErrorOrEmptyClause", "jsonArrayAggFunction", 
			"jsonObjectAggFunction", "jsonPassingClause", "jsonNullClause", "jsonUniqueKeysClause", 
			"jsonTableFunction", "jsonTableErrorClause", "jsonTableColumnsClause", 
			"jsonTableColumns", "jsonTableColumn", "xmlFunction", "xmlElementFunction", 
			"xmlAttributesFunction", "xmlForestFunction", "xmlPiFunction", "xmlQueryFunction", 
			"xmlExistsFunction", "xmlAggFunction", "aliasedExpressionOrPredicate", 
			"potentiallyAliasedExpressionOrPredicate", "xmlTableFunction", "xmlTableColumnsClause", 
			"xmlTableColumn", "xmltableDefaultClause", "predicate", "expressionOrPredicate", 
			"collectionQuantifier", "elementsValuesQuantifier", "elementValueQuantifier", 
			"indexKeyQuantifier", "indicesKeysQuantifier", "relationalExpression", 
			"betweenExpression", "stringPatternMatching", "inExpression", "inList", 
			"existsExpression", "instantiationTarget", "instantiationArguments", 
			"instantiationArgument", "parameterOrIntegerLiteral", "parameterOrNumberLiteral", 
			"variable", "parameter", "entityName", "nakedIdentifier", "identifier"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'('", "')'", "'='", "'%'", "'}'", "'['", "']'", "':'", 
			"'/'", "'{'", "'||'", "'.'", "'>'", "'>='", "'<'", "'<='", "'<>'", "'!='", 
			"'^='", "'?'", null, null, "'*'", null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, "'{ts'", 
			"'{d'", "'{t'", "'+'", "'-'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, "WS", "COMMENT", 
			"ASTERISK", "ID", "VERSION", "VERSIONED", "NATURALID", "FK", "ABSENT", 
			"ALL", "AND", "ANY", "ARRAY", "AS", "ASC", "AVG", "BETWEEN", "BOTH", 
			"BREADTH", "BY", "CASE", "CAST", "COLLATE", "COLUMN", "COLUMNS", "CONDITIONAL", 
			"CONFLICT", "CONSTRAINT", "CONTAINS", "COUNT", "CROSS", "CUBE", "CURRENT", 
			"CURRENT_DATE", "CURRENT_INSTANT", "CURRENT_TIME", "CURRENT_TIMESTAMP", 
			"CYCLE", "DATE", "DATETIME", "DAY", "DEFAULT", "DELETE", "DEPTH", "DESC", 
			"DISTINCT", "DO", "ELEMENT", "ELEMENTS", "ELSE", "EMPTY", "END", "ENTRY", 
			"EPOCH", "ERROR", "ESCAPE", "EVERY", "EXCEPT", "EXCLUDE", "EXISTS", "EXTRACT", 
			"FETCH", "FILTER", "FIRST", "FOLLOWING", "FOR", "FORMAT", "FROM", "FULL", 
			"FUNCTION", "GROUP", "GROUPS", "HAVING", "HOUR", "IGNORE", "ILIKE", "IN", 
			"INCLUDES", "INDEX", "INDICES", "INNER", "INSERT", "INSTANT", "INTERSECT", 
			"INTERSECTS", "INTO", "IS", "JOIN", "JSON", "JSON_ARRAY", "JSON_ARRAYAGG", 
			"JSON_EXISTS", "JSON_OBJECT", "JSON_OBJECTAGG", "JSON_QUERY", "JSON_TABLE", 
			"JSON_VALUE", "KEY", "KEYS", "LAST", "LATERAL", "LEADING", "LEFT", "LIKE", 
			"LIMIT", "LIST", "LISTAGG", "LOCAL", "LOCAL_DATE", "LOCAL_DATETIME", 
			"LOCAL_TIME", "MAP", "MATERIALIZED", "MAX", "MAXELEMENT", "MAXINDEX", 
			"MEMBER", "MICROSECOND", "MILLISECOND", "MIN", "MINELEMENT", "MININDEX", 
			"MINUTE", "MONTH", "NAME", "NANOSECOND", "NEW", "NESTED", "NEXT", "NO", 
			"NOT", "NOTHING", "NULLS", "OBJECT", "OF", "OFFSET", "OFFSET_DATETIME", 
			"ON", "ONLY", "OR", "ORDER", "ORDINALITY", "OTHERS", "OUTER", "OVER", 
			"OVERFLOW", "OVERLAY", "PAD", "PATH", "PARTITION", "PASSING", "PERCENT", 
			"PLACING", "POSITION", "PRECEDING", "QUARTER", "RANGE", "RESPECT", "RETURNING", 
			"RIGHT", "ROLLUP", "ROW", "ROWS", "SEARCH", "SECOND", "SELECT", "SET", 
			"SIZE", "SOME", "SUBSTRING", "SUM", "THEN", "TIES", "TIME", "TIMESTAMP", 
			"TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TREAT", "TRIM", 
			"TRUNC", "TRUNCATE", "TYPE", "UNBOUNDED", "UNCONDITIONAL", "UNION", "UNIQUE", 
			"UPDATE", "USING", "VALUE", "VALUES", "WEEK", "WHEN", "WHERE", "WITH", 
			"WITHIN", "WITHOUT", "WRAPPER", "XML", "XMLAGG", "XMLATTRIBUTES", "XMLELEMENT", 
			"XMLEXISTS", "XMLFOREST", "XMLPI", "XMLQUERY", "XMLTABLE", "YEAR", "ZONED", 
			"NULL", "TRUE", "FALSE", "STRING_LITERAL", "JAVA_STRING_LITERAL", "INTEGER_LITERAL", 
			"LONG_LITERAL", "FLOAT_LITERAL", "DOUBLE_LITERAL", "BIG_INTEGER_LITERAL", 
			"BIG_DECIMAL_LITERAL", "HEX_LITERAL", "BINARY_LITERAL", "TIMESTAMP_ESCAPE_START", 
			"DATE_ESCAPE_START", "TIME_ESCAPE_START", "PLUS", "MINUS", "IDENTIFIER", 
			"QUOTED_IDENTIFIER"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Hql.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public HqlParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StartContext extends ParserRuleContext {
		public Ql_statementContext ql_statement() {
			return getRuleContext(Ql_statementContext.class,0);
		}
		public TerminalNode EOF() { return getToken(HqlParser.EOF, 0); }
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(498);
			ql_statement();
			setState(499);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Ql_statementContext extends ParserRuleContext {
		public SelectStatementContext selectStatement() {
			return getRuleContext(SelectStatementContext.class,0);
		}
		public UpdateStatementContext updateStatement() {
			return getRuleContext(UpdateStatementContext.class,0);
		}
		public DeleteStatementContext deleteStatement() {
			return getRuleContext(DeleteStatementContext.class,0);
		}
		public InsertStatementContext insertStatement() {
			return getRuleContext(InsertStatementContext.class,0);
		}
		public Ql_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ql_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterQl_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitQl_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitQl_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ql_statementContext ql_statement() throws RecognitionException {
		Ql_statementContext _localctx = new Ql_statementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_ql_statement);
		try {
			setState(505);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
			case FROM:
			case SELECT:
			case WITH:
				enterOuterAlt(_localctx, 1);
				{
				setState(501);
				selectStatement();
				}
				break;
			case UPDATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(502);
				updateStatement();
				}
				break;
			case DELETE:
				enterOuterAlt(_localctx, 3);
				{
				setState(503);
				deleteStatement();
				}
				break;
			case INSERT:
				enterOuterAlt(_localctx, 4);
				{
				setState(504);
				insertStatement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectStatementContext extends ParserRuleContext {
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public SelectStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectStatementContext selectStatement() throws RecognitionException {
		SelectStatementContext _localctx = new SelectStatementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_selectStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(507);
			queryExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QueryExpressionContext extends ParserRuleContext {
		public List<OrderedQueryContext> orderedQuery() {
			return getRuleContexts(OrderedQueryContext.class);
		}
		public OrderedQueryContext orderedQuery(int i) {
			return getRuleContext(OrderedQueryContext.class,i);
		}
		public WithClauseContext withClause() {
			return getRuleContext(WithClauseContext.class,0);
		}
		public List<SetOperatorContext> setOperator() {
			return getRuleContexts(SetOperatorContext.class);
		}
		public SetOperatorContext setOperator(int i) {
			return getRuleContext(SetOperatorContext.class,i);
		}
		public QueryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterQueryExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitQueryExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitQueryExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryExpressionContext queryExpression() throws RecognitionException {
		QueryExpressionContext _localctx = new QueryExpressionContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_queryExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(510);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WITH) {
				{
				setState(509);
				withClause();
				}
			}

			setState(512);
			orderedQuery();
			setState(518);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXCEPT || _la==INTERSECT || _la==UNION) {
				{
				{
				setState(513);
				setOperator();
				setState(514);
				orderedQuery();
				}
				}
				setState(520);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WithClauseContext extends ParserRuleContext {
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public List<CteContext> cte() {
			return getRuleContexts(CteContext.class);
		}
		public CteContext cte(int i) {
			return getRuleContext(CteContext.class,i);
		}
		public WithClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_withClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWithClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWithClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWithClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WithClauseContext withClause() throws RecognitionException {
		WithClauseContext _localctx = new WithClauseContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_withClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(521);
			match(WITH);
			setState(522);
			cte();
			setState(527);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(523);
				match(T__0);
				setState(524);
				cte();
				}
				}
				setState(529);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CteContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public TerminalNode MATERIALIZED() { return getToken(HqlParser.MATERIALIZED, 0); }
		public SearchClauseContext searchClause() {
			return getRuleContext(SearchClauseContext.class,0);
		}
		public CycleClauseContext cycleClause() {
			return getRuleContext(CycleClauseContext.class,0);
		}
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public CteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cte; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCte(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCte(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCte(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CteContext cte() throws RecognitionException {
		CteContext _localctx = new CteContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_cte);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(530);
			identifier();
			setState(531);
			match(AS);
			setState(536);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==MATERIALIZED || _la==NOT) {
				{
				setState(533);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(532);
					match(NOT);
					}
				}

				setState(535);
				match(MATERIALIZED);
				}
			}

			setState(538);
			match(T__1);
			setState(539);
			queryExpression();
			setState(540);
			match(T__2);
			setState(542);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==SEARCH) {
				{
				setState(541);
				searchClause();
				}
			}

			setState(545);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CYCLE) {
				{
				setState(544);
				cycleClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchClauseContext extends ParserRuleContext {
		public TerminalNode SEARCH() { return getToken(HqlParser.SEARCH, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public SearchSpecificationsContext searchSpecifications() {
			return getRuleContext(SearchSpecificationsContext.class,0);
		}
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode BREADTH() { return getToken(HqlParser.BREADTH, 0); }
		public TerminalNode DEPTH() { return getToken(HqlParser.DEPTH, 0); }
		public SearchClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchClauseContext searchClause() throws RecognitionException {
		SearchClauseContext _localctx = new SearchClauseContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_searchClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(547);
			match(SEARCH);
			setState(548);
			_la = _input.LA(1);
			if ( !(_la==BREADTH || _la==DEPTH) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(549);
			match(FIRST);
			setState(550);
			match(BY);
			setState(551);
			searchSpecifications();
			setState(552);
			match(SET);
			setState(553);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchSpecificationsContext extends ParserRuleContext {
		public List<SearchSpecificationContext> searchSpecification() {
			return getRuleContexts(SearchSpecificationContext.class);
		}
		public SearchSpecificationContext searchSpecification(int i) {
			return getRuleContext(SearchSpecificationContext.class,i);
		}
		public SearchSpecificationsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchSpecifications; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchSpecifications(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchSpecifications(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchSpecifications(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchSpecificationsContext searchSpecifications() throws RecognitionException {
		SearchSpecificationsContext _localctx = new SearchSpecificationsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_searchSpecifications);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(555);
			searchSpecification();
			setState(560);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(556);
				match(T__0);
				setState(557);
				searchSpecification();
				}
				}
				setState(562);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchSpecificationContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public SortDirectionContext sortDirection() {
			return getRuleContext(SortDirectionContext.class,0);
		}
		public NullsPrecedenceContext nullsPrecedence() {
			return getRuleContext(NullsPrecedenceContext.class,0);
		}
		public SearchSpecificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchSpecification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchSpecification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchSpecification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchSpecification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchSpecificationContext searchSpecification() throws RecognitionException {
		SearchSpecificationContext _localctx = new SearchSpecificationContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_searchSpecification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(563);
			identifier();
			setState(565);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(564);
				sortDirection();
				}
			}

			setState(568);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NULLS) {
				{
				setState(567);
				nullsPrecedence();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CycleClauseContext extends ParserRuleContext {
		public TerminalNode CYCLE() { return getToken(HqlParser.CYCLE, 0); }
		public CteAttributesContext cteAttributes() {
			return getRuleContext(CteAttributesContext.class,0);
		}
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode TO() { return getToken(HqlParser.TO, 0); }
		public List<LiteralContext> literal() {
			return getRuleContexts(LiteralContext.class);
		}
		public LiteralContext literal(int i) {
			return getRuleContext(LiteralContext.class,i);
		}
		public TerminalNode DEFAULT() { return getToken(HqlParser.DEFAULT, 0); }
		public TerminalNode USING() { return getToken(HqlParser.USING, 0); }
		public CycleClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cycleClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCycleClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCycleClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCycleClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CycleClauseContext cycleClause() throws RecognitionException {
		CycleClauseContext _localctx = new CycleClauseContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_cycleClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(570);
			match(CYCLE);
			setState(571);
			cteAttributes();
			setState(572);
			match(SET);
			setState(573);
			identifier();
			setState(579);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TO) {
				{
				setState(574);
				match(TO);
				setState(575);
				literal();
				setState(576);
				match(DEFAULT);
				setState(577);
				literal();
				}
			}

			setState(583);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==USING) {
				{
				setState(581);
				match(USING);
				setState(582);
				identifier();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CteAttributesContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public CteAttributesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cteAttributes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCteAttributes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCteAttributes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCteAttributes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CteAttributesContext cteAttributes() throws RecognitionException {
		CteAttributesContext _localctx = new CteAttributesContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_cteAttributes);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(585);
			identifier();
			setState(590);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(586);
				match(T__0);
				setState(587);
				identifier();
				}
				}
				setState(592);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrderedQueryContext extends ParserRuleContext {
		public QueryContext query() {
			return getRuleContext(QueryContext.class,0);
		}
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public QueryOrderContext queryOrder() {
			return getRuleContext(QueryOrderContext.class,0);
		}
		public LimitClauseContext limitClause() {
			return getRuleContext(LimitClauseContext.class,0);
		}
		public OffsetClauseContext offsetClause() {
			return getRuleContext(OffsetClauseContext.class,0);
		}
		public FetchClauseContext fetchClause() {
			return getRuleContext(FetchClauseContext.class,0);
		}
		public OrderedQueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderedQuery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOrderedQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOrderedQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOrderedQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrderedQueryContext orderedQuery() throws RecognitionException {
		OrderedQueryContext _localctx = new OrderedQueryContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_orderedQuery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(598);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FROM:
			case SELECT:
				{
				setState(593);
				query();
				}
				break;
			case T__1:
				{
				setState(594);
				match(T__1);
				setState(595);
				queryExpression();
				setState(596);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(601);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(600);
				queryOrder();
				}
			}

			setState(604);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==LIMIT) {
				{
				setState(603);
				limitClause();
				}
			}

			setState(607);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==OFFSET) {
				{
				setState(606);
				offsetClause();
				}
			}

			setState(610);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FETCH) {
				{
				setState(609);
				fetchClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QueryContext extends ParserRuleContext {
		public QueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query; }
	 
		public QueryContext() { }
		public void copyFrom(QueryContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SelectQueryContext extends QueryContext {
		public SelectClauseContext selectClause() {
			return getRuleContext(SelectClauseContext.class,0);
		}
		public FromClauseContext fromClause() {
			return getRuleContext(FromClauseContext.class,0);
		}
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public GroupByClauseContext groupByClause() {
			return getRuleContext(GroupByClauseContext.class,0);
		}
		public HavingClauseContext havingClause() {
			return getRuleContext(HavingClauseContext.class,0);
		}
		public SelectQueryContext(QueryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectQuery(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FromQueryContext extends QueryContext {
		public FromClauseContext fromClause() {
			return getRuleContext(FromClauseContext.class,0);
		}
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public GroupByClauseContext groupByClause() {
			return getRuleContext(GroupByClauseContext.class,0);
		}
		public HavingClauseContext havingClause() {
			return getRuleContext(HavingClauseContext.class,0);
		}
		public SelectClauseContext selectClause() {
			return getRuleContext(SelectClauseContext.class,0);
		}
		public FromQueryContext(QueryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryContext query() throws RecognitionException {
		QueryContext _localctx = new QueryContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_query);
		int _la;
		try {
			setState(638);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SELECT:
				_localctx = new SelectQueryContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(612);
				selectClause();
				setState(614);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FROM) {
					{
					setState(613);
					fromClause();
					}
				}

				setState(617);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(616);
					whereClause();
					}
				}

				setState(620);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GROUP) {
					{
					setState(619);
					groupByClause();
					}
				}

				setState(623);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(622);
					havingClause();
					}
				}

				}
				break;
			case FROM:
				_localctx = new FromQueryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(625);
				fromClause();
				setState(627);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(626);
					whereClause();
					}
				}

				setState(630);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GROUP) {
					{
					setState(629);
					groupByClause();
					}
				}

				setState(633);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(632);
					havingClause();
					}
				}

				setState(636);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==SELECT) {
					{
					setState(635);
					selectClause();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QueryOrderContext extends ParserRuleContext {
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public QueryOrderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryOrder; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterQueryOrder(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitQueryOrder(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitQueryOrder(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryOrderContext queryOrder() throws RecognitionException {
		QueryOrderContext _localctx = new QueryOrderContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_queryOrder);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(640);
			orderByClause();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FromClauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public List<EntityWithJoinsContext> entityWithJoins() {
			return getRuleContexts(EntityWithJoinsContext.class);
		}
		public EntityWithJoinsContext entityWithJoins(int i) {
			return getRuleContext(EntityWithJoinsContext.class,i);
		}
		public FromClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fromClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FromClauseContext fromClause() throws RecognitionException {
		FromClauseContext _localctx = new FromClauseContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_fromClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(642);
			match(FROM);
			setState(643);
			entityWithJoins();
			setState(648);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(644);
				match(T__0);
				setState(645);
				entityWithJoins();
				}
				}
				setState(650);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityWithJoinsContext extends ParserRuleContext {
		public FromRootContext fromRoot() {
			return getRuleContext(FromRootContext.class,0);
		}
		public List<JoinSpecifierContext> joinSpecifier() {
			return getRuleContexts(JoinSpecifierContext.class);
		}
		public JoinSpecifierContext joinSpecifier(int i) {
			return getRuleContext(JoinSpecifierContext.class,i);
		}
		public EntityWithJoinsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityWithJoins; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityWithJoins(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityWithJoins(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityWithJoins(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityWithJoinsContext entityWithJoins() throws RecognitionException {
		EntityWithJoinsContext _localctx = new EntityWithJoinsContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_entityWithJoins);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(651);
			fromRoot();
			setState(655);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,29,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(652);
					joinSpecifier();
					}
					} 
				}
				setState(657);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,29,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinSpecifierContext extends ParserRuleContext {
		public JoinContext join() {
			return getRuleContext(JoinContext.class,0);
		}
		public CrossJoinContext crossJoin() {
			return getRuleContext(CrossJoinContext.class,0);
		}
		public JpaCollectionJoinContext jpaCollectionJoin() {
			return getRuleContext(JpaCollectionJoinContext.class,0);
		}
		public JoinSpecifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinSpecifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinSpecifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinSpecifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinSpecifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinSpecifierContext joinSpecifier() throws RecognitionException {
		JoinSpecifierContext _localctx = new JoinSpecifierContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_joinSpecifier);
		try {
			setState(661);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,30,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(658);
				join();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(659);
				crossJoin();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(660);
				jpaCollectionJoin();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FromRootContext extends ParserRuleContext {
		public FromRootContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fromRoot; }
	 
		public FromRootContext() { }
		public void copyFrom(FromRootContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RootSubqueryContext extends FromRootContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public RootSubqueryContext(FromRootContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRootSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRootSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRootSubquery(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RootFunctionContext extends FromRootContext {
		public SetReturningFunctionContext setReturningFunction() {
			return getRuleContext(SetReturningFunctionContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public RootFunctionContext(FromRootContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRootFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRootFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRootFunction(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RootEntityContext extends FromRootContext {
		public EntityNameContext entityName() {
			return getRuleContext(EntityNameContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public RootEntityContext(FromRootContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRootEntity(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRootEntity(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRootEntity(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FromRootContext fromRoot() throws RecognitionException {
		FromRootContext _localctx = new FromRootContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_fromRoot);
		int _la;
		try {
			setState(680);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,35,_ctx) ) {
			case 1:
				_localctx = new RootEntityContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(663);
				entityName();
				setState(665);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,31,_ctx) ) {
				case 1:
					{
					setState(664);
					variable();
					}
					break;
				}
				}
				break;
			case 2:
				_localctx = new RootSubqueryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(668);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LATERAL) {
					{
					setState(667);
					match(LATERAL);
					}
				}

				setState(670);
				match(T__1);
				setState(671);
				subquery();
				setState(672);
				match(T__2);
				setState(674);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
				case 1:
					{
					setState(673);
					variable();
					}
					break;
				}
				}
				break;
			case 3:
				_localctx = new RootFunctionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(676);
				setReturningFunction();
				setState(678);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,34,_ctx) ) {
				case 1:
					{
					setState(677);
					variable();
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinContext extends ParserRuleContext {
		public JoinTypeContext joinType() {
			return getRuleContext(JoinTypeContext.class,0);
		}
		public TerminalNode JOIN() { return getToken(HqlParser.JOIN, 0); }
		public JoinTargetContext joinTarget() {
			return getRuleContext(JoinTargetContext.class,0);
		}
		public TerminalNode FETCH() { return getToken(HqlParser.FETCH, 0); }
		public JoinRestrictionContext joinRestriction() {
			return getRuleContext(JoinRestrictionContext.class,0);
		}
		public JoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinContext join() throws RecognitionException {
		JoinContext _localctx = new JoinContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_join);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(682);
			joinType();
			setState(683);
			match(JOIN);
			setState(685);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,36,_ctx) ) {
			case 1:
				{
				setState(684);
				match(FETCH);
				}
				break;
			}
			setState(687);
			joinTarget();
			setState(689);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
			case 1:
				{
				setState(688);
				joinRestriction();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinTargetContext extends ParserRuleContext {
		public JoinTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinTarget; }
	 
		public JoinTargetContext() { }
		public void copyFrom(JoinTargetContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinPathContext extends JoinTargetContext {
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JoinPathContext(JoinTargetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinPath(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinSubqueryContext extends JoinTargetContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JoinSubqueryContext(JoinTargetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinSubquery(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JoinFunctionCallContext extends JoinTargetContext {
		public SetReturningFunctionContext setReturningFunction() {
			return getRuleContext(SetReturningFunctionContext.class,0);
		}
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JoinFunctionCallContext(JoinTargetContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinFunctionCall(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinFunctionCall(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinFunctionCall(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinTargetContext joinTarget() throws RecognitionException {
		JoinTargetContext _localctx = new JoinTargetContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_joinTarget);
		int _la;
		try {
			setState(711);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,43,_ctx) ) {
			case 1:
				_localctx = new JoinPathContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(691);
				path();
				setState(693);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,38,_ctx) ) {
				case 1:
					{
					setState(692);
					variable();
					}
					break;
				}
				}
				break;
			case 2:
				_localctx = new JoinSubqueryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(696);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LATERAL) {
					{
					setState(695);
					match(LATERAL);
					}
				}

				setState(698);
				match(T__1);
				setState(699);
				subquery();
				setState(700);
				match(T__2);
				setState(702);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,40,_ctx) ) {
				case 1:
					{
					setState(701);
					variable();
					}
					break;
				}
				}
				break;
			case 3:
				_localctx = new JoinFunctionCallContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(705);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
				case 1:
					{
					setState(704);
					match(LATERAL);
					}
					break;
				}
				setState(707);
				setReturningFunction();
				setState(709);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,42,_ctx) ) {
				case 1:
					{
					setState(708);
					variable();
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UpdateStatementContext extends ParserRuleContext {
		public TerminalNode UPDATE() { return getToken(HqlParser.UPDATE, 0); }
		public TargetEntityContext targetEntity() {
			return getRuleContext(TargetEntityContext.class,0);
		}
		public SetClauseContext setClause() {
			return getRuleContext(SetClauseContext.class,0);
		}
		public TerminalNode VERSIONED() { return getToken(HqlParser.VERSIONED, 0); }
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public UpdateStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_updateStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterUpdateStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitUpdateStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitUpdateStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UpdateStatementContext updateStatement() throws RecognitionException {
		UpdateStatementContext _localctx = new UpdateStatementContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_updateStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(713);
			match(UPDATE);
			setState(715);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,44,_ctx) ) {
			case 1:
				{
				setState(714);
				match(VERSIONED);
				}
				break;
			}
			setState(717);
			targetEntity();
			setState(718);
			setClause();
			setState(720);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(719);
				whereClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TargetEntityContext extends ParserRuleContext {
		public EntityNameContext entityName() {
			return getRuleContext(EntityNameContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TargetEntityContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_targetEntity; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTargetEntity(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTargetEntity(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTargetEntity(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TargetEntityContext targetEntity() throws RecognitionException {
		TargetEntityContext _localctx = new TargetEntityContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_targetEntity);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(722);
			entityName();
			setState(724);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,46,_ctx) ) {
			case 1:
				{
				setState(723);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetClauseContext extends ParserRuleContext {
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public List<AssignmentContext> assignment() {
			return getRuleContexts(AssignmentContext.class);
		}
		public AssignmentContext assignment(int i) {
			return getRuleContext(AssignmentContext.class,i);
		}
		public SetClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSetClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSetClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSetClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetClauseContext setClause() throws RecognitionException {
		SetClauseContext _localctx = new SetClauseContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_setClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(726);
			match(SET);
			setState(727);
			assignment();
			setState(732);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(728);
				match(T__0);
				setState(729);
				assignment();
				}
				}
				setState(734);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AssignmentContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public AssignmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAssignment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAssignment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignmentContext assignment() throws RecognitionException {
		AssignmentContext _localctx = new AssignmentContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_assignment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(735);
			simplePath();
			setState(736);
			match(T__3);
			setState(737);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DeleteStatementContext extends ParserRuleContext {
		public TerminalNode DELETE() { return getToken(HqlParser.DELETE, 0); }
		public TargetEntityContext targetEntity() {
			return getRuleContext(TargetEntityContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public DeleteStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_deleteStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDeleteStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDeleteStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDeleteStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeleteStatementContext deleteStatement() throws RecognitionException {
		DeleteStatementContext _localctx = new DeleteStatementContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_deleteStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(739);
			match(DELETE);
			setState(741);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,48,_ctx) ) {
			case 1:
				{
				setState(740);
				match(FROM);
				}
				break;
			}
			setState(743);
			targetEntity();
			setState(745);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(744);
				whereClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InsertStatementContext extends ParserRuleContext {
		public TerminalNode INSERT() { return getToken(HqlParser.INSERT, 0); }
		public TargetEntityContext targetEntity() {
			return getRuleContext(TargetEntityContext.class,0);
		}
		public TargetFieldsContext targetFields() {
			return getRuleContext(TargetFieldsContext.class,0);
		}
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public ValuesListContext valuesList() {
			return getRuleContext(ValuesListContext.class,0);
		}
		public TerminalNode INTO() { return getToken(HqlParser.INTO, 0); }
		public ConflictClauseContext conflictClause() {
			return getRuleContext(ConflictClauseContext.class,0);
		}
		public InsertStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_insertStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInsertStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInsertStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInsertStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InsertStatementContext insertStatement() throws RecognitionException {
		InsertStatementContext _localctx = new InsertStatementContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_insertStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(747);
			match(INSERT);
			setState(749);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,50,_ctx) ) {
			case 1:
				{
				setState(748);
				match(INTO);
				}
				break;
			}
			setState(751);
			targetEntity();
			setState(752);
			targetFields();
			setState(755);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
			case FROM:
			case SELECT:
			case WITH:
				{
				setState(753);
				queryExpression();
				}
				break;
			case VALUES:
				{
				setState(754);
				valuesList();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(758);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(757);
				conflictClause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TargetFieldsContext extends ParserRuleContext {
		public List<SimplePathContext> simplePath() {
			return getRuleContexts(SimplePathContext.class);
		}
		public SimplePathContext simplePath(int i) {
			return getRuleContext(SimplePathContext.class,i);
		}
		public TargetFieldsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_targetFields; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTargetFields(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTargetFields(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTargetFields(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TargetFieldsContext targetFields() throws RecognitionException {
		TargetFieldsContext _localctx = new TargetFieldsContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_targetFields);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(760);
			match(T__1);
			setState(761);
			simplePath();
			setState(766);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(762);
				match(T__0);
				setState(763);
				simplePath();
				}
				}
				setState(768);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(769);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValuesListContext extends ParserRuleContext {
		public TerminalNode VALUES() { return getToken(HqlParser.VALUES, 0); }
		public List<ValuesContext> values() {
			return getRuleContexts(ValuesContext.class);
		}
		public ValuesContext values(int i) {
			return getRuleContext(ValuesContext.class,i);
		}
		public ValuesListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_valuesList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterValuesList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitValuesList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitValuesList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValuesListContext valuesList() throws RecognitionException {
		ValuesListContext _localctx = new ValuesListContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_valuesList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(771);
			match(VALUES);
			setState(772);
			values();
			setState(777);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(773);
				match(T__0);
				setState(774);
				values();
				}
				}
				setState(779);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ValuesContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public ValuesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_values; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterValues(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitValues(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitValues(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValuesContext values() throws RecognitionException {
		ValuesContext _localctx = new ValuesContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_values);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(780);
			match(T__1);
			setState(781);
			expression(0);
			setState(786);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(782);
				match(T__0);
				setState(783);
				expression(0);
				}
				}
				setState(788);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(789);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConflictClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode CONFLICT() { return getToken(HqlParser.CONFLICT, 0); }
		public TerminalNode DO() { return getToken(HqlParser.DO, 0); }
		public ConflictActionContext conflictAction() {
			return getRuleContext(ConflictActionContext.class,0);
		}
		public ConflictTargetContext conflictTarget() {
			return getRuleContext(ConflictTargetContext.class,0);
		}
		public ConflictClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conflictClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterConflictClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitConflictClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitConflictClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConflictClauseContext conflictClause() throws RecognitionException {
		ConflictClauseContext _localctx = new ConflictClauseContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_conflictClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(791);
			match(ON);
			setState(792);
			match(CONFLICT);
			setState(794);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1 || _la==ON) {
				{
				setState(793);
				conflictTarget();
				}
			}

			setState(796);
			match(DO);
			setState(797);
			conflictAction();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConflictTargetContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode CONSTRAINT() { return getToken(HqlParser.CONSTRAINT, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public List<SimplePathContext> simplePath() {
			return getRuleContexts(SimplePathContext.class);
		}
		public SimplePathContext simplePath(int i) {
			return getRuleContext(SimplePathContext.class,i);
		}
		public ConflictTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conflictTarget; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterConflictTarget(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitConflictTarget(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitConflictTarget(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConflictTargetContext conflictTarget() throws RecognitionException {
		ConflictTargetContext _localctx = new ConflictTargetContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_conflictTarget);
		int _la;
		try {
			setState(813);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ON:
				enterOuterAlt(_localctx, 1);
				{
				setState(799);
				match(ON);
				setState(800);
				match(CONSTRAINT);
				setState(801);
				identifier();
				}
				break;
			case T__1:
				enterOuterAlt(_localctx, 2);
				{
				setState(802);
				match(T__1);
				setState(803);
				simplePath();
				setState(808);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(804);
					match(T__0);
					setState(805);
					simplePath();
					}
					}
					setState(810);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(811);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConflictActionContext extends ParserRuleContext {
		public TerminalNode NOTHING() { return getToken(HqlParser.NOTHING, 0); }
		public TerminalNode UPDATE() { return getToken(HqlParser.UPDATE, 0); }
		public SetClauseContext setClause() {
			return getRuleContext(SetClauseContext.class,0);
		}
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public ConflictActionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conflictAction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterConflictAction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitConflictAction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitConflictAction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConflictActionContext conflictAction() throws RecognitionException {
		ConflictActionContext _localctx = new ConflictActionContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_conflictAction);
		int _la;
		try {
			setState(821);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOTHING:
				enterOuterAlt(_localctx, 1);
				{
				setState(815);
				match(NOTHING);
				}
				break;
			case UPDATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(816);
				match(UPDATE);
				setState(817);
				setClause();
				setState(819);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(818);
					whereClause();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationContext extends ParserRuleContext {
		public TerminalNode NEW() { return getToken(HqlParser.NEW, 0); }
		public InstantiationTargetContext instantiationTarget() {
			return getRuleContext(InstantiationTargetContext.class,0);
		}
		public InstantiationArgumentsContext instantiationArguments() {
			return getRuleContext(InstantiationArgumentsContext.class,0);
		}
		public InstantiationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationContext instantiation() throws RecognitionException {
		InstantiationContext _localctx = new InstantiationContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_instantiation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(823);
			match(NEW);
			setState(824);
			instantiationTarget();
			setState(825);
			match(T__1);
			setState(826);
			instantiationArguments();
			setState(827);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GroupedItemContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public GroupedItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupedItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupedItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupedItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupedItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GroupedItemContext groupedItem() throws RecognitionException {
		GroupedItemContext _localctx = new GroupedItemContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_groupedItem);
		try {
			setState(832);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,61,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(829);
				identifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(830);
				match(INTEGER_LITERAL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(831);
				expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SortedItemContext extends ParserRuleContext {
		public SortExpressionContext sortExpression() {
			return getRuleContext(SortExpressionContext.class,0);
		}
		public SortDirectionContext sortDirection() {
			return getRuleContext(SortDirectionContext.class,0);
		}
		public NullsPrecedenceContext nullsPrecedence() {
			return getRuleContext(NullsPrecedenceContext.class,0);
		}
		public SortedItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sortedItem; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSortedItem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSortedItem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSortedItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SortedItemContext sortedItem() throws RecognitionException {
		SortedItemContext _localctx = new SortedItemContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_sortedItem);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(834);
			sortExpression();
			setState(836);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(835);
				sortDirection();
				}
			}

			setState(839);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NULLS) {
				{
				setState(838);
				nullsPrecedence();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SortExpressionContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SortExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sortExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSortExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSortExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSortExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SortExpressionContext sortExpression() throws RecognitionException {
		SortExpressionContext _localctx = new SortExpressionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_sortExpression);
		try {
			setState(844);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,64,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(841);
				identifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(842);
				match(INTEGER_LITERAL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(843);
				expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SortDirectionContext extends ParserRuleContext {
		public TerminalNode ASC() { return getToken(HqlParser.ASC, 0); }
		public TerminalNode DESC() { return getToken(HqlParser.DESC, 0); }
		public SortDirectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sortDirection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSortDirection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSortDirection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSortDirection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SortDirectionContext sortDirection() throws RecognitionException {
		SortDirectionContext _localctx = new SortDirectionContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_sortDirection);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(846);
			_la = _input.LA(1);
			if ( !(_la==ASC || _la==DESC) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NullsPrecedenceContext extends ParserRuleContext {
		public TerminalNode NULLS() { return getToken(HqlParser.NULLS, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(HqlParser.LAST, 0); }
		public NullsPrecedenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullsPrecedence; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNullsPrecedence(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNullsPrecedence(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNullsPrecedence(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NullsPrecedenceContext nullsPrecedence() throws RecognitionException {
		NullsPrecedenceContext _localctx = new NullsPrecedenceContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_nullsPrecedence);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(848);
			match(NULLS);
			setState(849);
			_la = _input.LA(1);
			if ( !(_la==FIRST || _la==LAST) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LimitClauseContext extends ParserRuleContext {
		public TerminalNode LIMIT() { return getToken(HqlParser.LIMIT, 0); }
		public ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() {
			return getRuleContext(ParameterOrIntegerLiteralContext.class,0);
		}
		public LimitClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_limitClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLimitClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLimitClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLimitClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LimitClauseContext limitClause() throws RecognitionException {
		LimitClauseContext _localctx = new LimitClauseContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_limitClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(851);
			match(LIMIT);
			setState(852);
			parameterOrIntegerLiteral();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetClauseContext extends ParserRuleContext {
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() {
			return getRuleContext(ParameterOrIntegerLiteralContext.class,0);
		}
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public OffsetClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetClauseContext offsetClause() throws RecognitionException {
		OffsetClauseContext _localctx = new OffsetClauseContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_offsetClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(854);
			match(OFFSET);
			setState(855);
			parameterOrIntegerLiteral();
			setState(857);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ROW || _la==ROWS) {
				{
				setState(856);
				_la = _input.LA(1);
				if ( !(_la==ROW || _la==ROWS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FetchClauseContext extends ParserRuleContext {
		public TerminalNode FETCH() { return getToken(HqlParser.FETCH, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode NEXT() { return getToken(HqlParser.NEXT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() {
			return getRuleContext(ParameterOrIntegerLiteralContext.class,0);
		}
		public ParameterOrNumberLiteralContext parameterOrNumberLiteral() {
			return getRuleContext(ParameterOrNumberLiteralContext.class,0);
		}
		public TerminalNode ONLY() { return getToken(HqlParser.ONLY, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode TIES() { return getToken(HqlParser.TIES, 0); }
		public FetchClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fetchClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFetchClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFetchClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFetchClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FetchClauseContext fetchClause() throws RecognitionException {
		FetchClauseContext _localctx = new FetchClauseContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_fetchClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(859);
			match(FETCH);
			setState(860);
			_la = _input.LA(1);
			if ( !(_la==FIRST || _la==NEXT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(865);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,66,_ctx) ) {
			case 1:
				{
				setState(861);
				parameterOrIntegerLiteral();
				}
				break;
			case 2:
				{
				setState(862);
				parameterOrNumberLiteral();
				setState(863);
				match(T__4);
				}
				break;
			}
			setState(867);
			_la = _input.LA(1);
			if ( !(_la==ROW || _la==ROWS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(871);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ONLY:
				{
				setState(868);
				match(ONLY);
				}
				break;
			case WITH:
				{
				setState(869);
				match(WITH);
				setState(870);
				match(TIES);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubqueryContext extends ParserRuleContext {
		public QueryExpressionContext queryExpression() {
			return getRuleContext(QueryExpressionContext.class,0);
		}
		public SubqueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subquery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubquery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubqueryContext subquery() throws RecognitionException {
		SubqueryContext _localctx = new SubqueryContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_subquery);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(873);
			queryExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectClauseContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(HqlParser.SELECT, 0); }
		public SelectionListContext selectionList() {
			return getRuleContext(SelectionListContext.class,0);
		}
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public SelectClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectClauseContext selectClause() throws RecognitionException {
		SelectClauseContext _localctx = new SelectClauseContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_selectClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(875);
			match(SELECT);
			setState(877);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,68,_ctx) ) {
			case 1:
				{
				setState(876);
				match(DISTINCT);
				}
				break;
			}
			setState(879);
			selectionList();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectionListContext extends ParserRuleContext {
		public List<SelectionContext> selection() {
			return getRuleContexts(SelectionContext.class);
		}
		public SelectionContext selection(int i) {
			return getRuleContext(SelectionContext.class,i);
		}
		public SelectionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectionList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectionList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectionList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectionList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectionListContext selectionList() throws RecognitionException {
		SelectionListContext _localctx = new SelectionListContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_selectionList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(881);
			selection();
			setState(886);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(882);
				match(T__0);
				setState(883);
				selection();
				}
				}
				setState(888);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectionContext extends ParserRuleContext {
		public SelectExpressionContext selectExpression() {
			return getRuleContext(SelectExpressionContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public SelectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectionContext selection() throws RecognitionException {
		SelectionContext _localctx = new SelectionContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_selection);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(889);
			selectExpression();
			setState(891);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,70,_ctx) ) {
			case 1:
				{
				setState(890);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelectExpressionContext extends ParserRuleContext {
		public InstantiationContext instantiation() {
			return getRuleContext(InstantiationContext.class,0);
		}
		public MapEntrySelectionContext mapEntrySelection() {
			return getRuleContext(MapEntrySelectionContext.class,0);
		}
		public JpaSelectObjectSyntaxContext jpaSelectObjectSyntax() {
			return getRuleContext(JpaSelectObjectSyntaxContext.class,0);
		}
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public SelectExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selectExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSelectExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSelectExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSelectExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectExpressionContext selectExpression() throws RecognitionException {
		SelectExpressionContext _localctx = new SelectExpressionContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_selectExpression);
		try {
			setState(897);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,71,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(893);
				instantiation();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(894);
				mapEntrySelection();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(895);
				jpaSelectObjectSyntax();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(896);
				expressionOrPredicate();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapEntrySelectionContext extends ParserRuleContext {
		public TerminalNode ENTRY() { return getToken(HqlParser.ENTRY, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public MapEntrySelectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapEntrySelection; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMapEntrySelection(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMapEntrySelection(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMapEntrySelection(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MapEntrySelectionContext mapEntrySelection() throws RecognitionException {
		MapEntrySelectionContext _localctx = new MapEntrySelectionContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_mapEntrySelection);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(899);
			match(ENTRY);
			setState(900);
			match(T__1);
			setState(901);
			path();
			setState(902);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaSelectObjectSyntaxContext extends ParserRuleContext {
		public TerminalNode OBJECT() { return getToken(HqlParser.OBJECT, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public JpaSelectObjectSyntaxContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaSelectObjectSyntax; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaSelectObjectSyntax(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaSelectObjectSyntax(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaSelectObjectSyntax(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaSelectObjectSyntaxContext jpaSelectObjectSyntax() throws RecognitionException {
		JpaSelectObjectSyntaxContext _localctx = new JpaSelectObjectSyntaxContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_jpaSelectObjectSyntax);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(904);
			match(OBJECT);
			setState(905);
			match(T__1);
			setState(906);
			identifier();
			setState(907);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WhereClauseContext extends ParserRuleContext {
		public TerminalNode WHERE() { return getToken(HqlParser.WHERE, 0); }
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public WhereClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whereClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWhereClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWhereClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWhereClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhereClauseContext whereClause() throws RecognitionException {
		WhereClauseContext _localctx = new WhereClauseContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_whereClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(909);
			match(WHERE);
			setState(910);
			predicate(0);
			setState(915);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(911);
				match(T__0);
				setState(912);
				predicate(0);
				}
				}
				setState(917);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinTypeContext extends ParserRuleContext {
		public TerminalNode INNER() { return getToken(HqlParser.INNER, 0); }
		public TerminalNode OUTER() { return getToken(HqlParser.OUTER, 0); }
		public TerminalNode LEFT() { return getToken(HqlParser.LEFT, 0); }
		public TerminalNode RIGHT() { return getToken(HqlParser.RIGHT, 0); }
		public TerminalNode FULL() { return getToken(HqlParser.FULL, 0); }
		public TerminalNode CROSS() { return getToken(HqlParser.CROSS, 0); }
		public JoinTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinTypeContext joinType() throws RecognitionException {
		JoinTypeContext _localctx = new JoinTypeContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_joinType);
		int _la;
		try {
			setState(928);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,76,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(919);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==INNER) {
					{
					setState(918);
					match(INNER);
					}
				}

				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(922);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FULL || _la==LEFT || _la==RIGHT) {
					{
					setState(921);
					_la = _input.LA(1);
					if ( !(_la==FULL || _la==LEFT || _la==RIGHT) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(925);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==OUTER) {
					{
					setState(924);
					match(OUTER);
					}
				}

				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(927);
				match(CROSS);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CrossJoinContext extends ParserRuleContext {
		public TerminalNode CROSS() { return getToken(HqlParser.CROSS, 0); }
		public TerminalNode JOIN() { return getToken(HqlParser.JOIN, 0); }
		public EntityNameContext entityName() {
			return getRuleContext(EntityNameContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public CrossJoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_crossJoin; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCrossJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCrossJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCrossJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CrossJoinContext crossJoin() throws RecognitionException {
		CrossJoinContext _localctx = new CrossJoinContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_crossJoin);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(930);
			match(CROSS);
			setState(931);
			match(JOIN);
			setState(932);
			entityName();
			setState(934);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,77,_ctx) ) {
			case 1:
				{
				setState(933);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinRestrictionContext extends ParserRuleContext {
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public JoinRestrictionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_joinRestriction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJoinRestriction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJoinRestriction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJoinRestriction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinRestrictionContext joinRestriction() throws RecognitionException {
		JoinRestrictionContext _localctx = new JoinRestrictionContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_joinRestriction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(936);
			_la = _input.LA(1);
			if ( !(_la==ON || _la==WITH) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(937);
			predicate(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaCollectionJoinContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public JpaCollectionJoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaCollectionJoin; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaCollectionJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaCollectionJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaCollectionJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaCollectionJoinContext jpaCollectionJoin() throws RecognitionException {
		JpaCollectionJoinContext _localctx = new JpaCollectionJoinContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_jpaCollectionJoin);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(939);
			match(T__0);
			setState(940);
			match(IN);
			setState(941);
			match(T__1);
			setState(942);
			path();
			setState(943);
			match(T__2);
			setState(945);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,78,_ctx) ) {
			case 1:
				{
				setState(944);
				variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GroupByClauseContext extends ParserRuleContext {
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public List<GroupedItemContext> groupedItem() {
			return getRuleContexts(GroupedItemContext.class);
		}
		public GroupedItemContext groupedItem(int i) {
			return getRuleContext(GroupedItemContext.class,i);
		}
		public GroupByClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupByClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupByClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupByClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupByClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GroupByClauseContext groupByClause() throws RecognitionException {
		GroupByClauseContext _localctx = new GroupByClauseContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_groupByClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(947);
			match(GROUP);
			setState(948);
			match(BY);
			setState(949);
			groupedItem();
			setState(954);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(950);
				match(T__0);
				setState(951);
				groupedItem();
				}
				}
				setState(956);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrderByClauseContext extends ParserRuleContext {
		public TerminalNode ORDER() { return getToken(HqlParser.ORDER, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public List<SortedItemContext> sortedItem() {
			return getRuleContexts(SortedItemContext.class);
		}
		public SortedItemContext sortedItem(int i) {
			return getRuleContext(SortedItemContext.class,i);
		}
		public OrderByClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderByClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOrderByClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOrderByClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOrderByClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrderByClauseContext orderByClause() throws RecognitionException {
		OrderByClauseContext _localctx = new OrderByClauseContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_orderByClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(957);
			match(ORDER);
			setState(958);
			match(BY);
			setState(959);
			sortedItem();
			setState(964);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(960);
				match(T__0);
				setState(961);
				sortedItem();
				}
				}
				setState(966);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HavingClauseContext extends ParserRuleContext {
		public TerminalNode HAVING() { return getToken(HqlParser.HAVING, 0); }
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public HavingClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_havingClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterHavingClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitHavingClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitHavingClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HavingClauseContext havingClause() throws RecognitionException {
		HavingClauseContext _localctx = new HavingClauseContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_havingClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(967);
			match(HAVING);
			setState(968);
			predicate(0);
			setState(973);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(969);
				match(T__0);
				setState(970);
				predicate(0);
				}
				}
				setState(975);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetOperatorContext extends ParserRuleContext {
		public TerminalNode UNION() { return getToken(HqlParser.UNION, 0); }
		public TerminalNode ALL() { return getToken(HqlParser.ALL, 0); }
		public TerminalNode INTERSECT() { return getToken(HqlParser.INTERSECT, 0); }
		public TerminalNode EXCEPT() { return getToken(HqlParser.EXCEPT, 0); }
		public SetOperatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setOperator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSetOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSetOperator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSetOperator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetOperatorContext setOperator() throws RecognitionException {
		SetOperatorContext _localctx = new SetOperatorContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_setOperator);
		int _la;
		try {
			setState(988);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case UNION:
				enterOuterAlt(_localctx, 1);
				{
				setState(976);
				match(UNION);
				setState(978);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(977);
					match(ALL);
					}
				}

				}
				break;
			case INTERSECT:
				enterOuterAlt(_localctx, 2);
				{
				setState(980);
				match(INTERSECT);
				setState(982);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(981);
					match(ALL);
					}
				}

				}
				break;
			case EXCEPT:
				enterOuterAlt(_localctx, 3);
				{
				setState(984);
				match(EXCEPT);
				setState(986);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(985);
					match(ALL);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LiteralContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public TerminalNode JAVA_STRING_LITERAL() { return getToken(HqlParser.JAVA_STRING_LITERAL, 0); }
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public BooleanLiteralContext booleanLiteral() {
			return getRuleContext(BooleanLiteralContext.class,0);
		}
		public NumericLiteralContext numericLiteral() {
			return getRuleContext(NumericLiteralContext.class,0);
		}
		public BinaryLiteralContext binaryLiteral() {
			return getRuleContext(BinaryLiteralContext.class,0);
		}
		public TemporalLiteralContext temporalLiteral() {
			return getRuleContext(TemporalLiteralContext.class,0);
		}
		public ArrayLiteralContext arrayLiteral() {
			return getRuleContext(ArrayLiteralContext.class,0);
		}
		public GeneralizedLiteralContext generalizedLiteral() {
			return getRuleContext(GeneralizedLiteralContext.class,0);
		}
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_literal);
		try {
			setState(999);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,86,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(990);
				match(STRING_LITERAL);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(991);
				match(JAVA_STRING_LITERAL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(992);
				match(NULL);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(993);
				booleanLiteral();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(994);
				numericLiteral();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(995);
				binaryLiteral();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(996);
				temporalLiteral();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(997);
				arrayLiteral();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(998);
				generalizedLiteral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BooleanLiteralContext extends ParserRuleContext {
		public TerminalNode TRUE() { return getToken(HqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(HqlParser.FALSE, 0); }
		public BooleanLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_booleanLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBooleanLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBooleanLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBooleanLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BooleanLiteralContext booleanLiteral() throws RecognitionException {
		BooleanLiteralContext _localctx = new BooleanLiteralContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_booleanLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1001);
			_la = _input.LA(1);
			if ( !(_la==TRUE || _la==FALSE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumericLiteralContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public TerminalNode LONG_LITERAL() { return getToken(HqlParser.LONG_LITERAL, 0); }
		public TerminalNode BIG_INTEGER_LITERAL() { return getToken(HqlParser.BIG_INTEGER_LITERAL, 0); }
		public TerminalNode FLOAT_LITERAL() { return getToken(HqlParser.FLOAT_LITERAL, 0); }
		public TerminalNode DOUBLE_LITERAL() { return getToken(HqlParser.DOUBLE_LITERAL, 0); }
		public TerminalNode BIG_DECIMAL_LITERAL() { return getToken(HqlParser.BIG_DECIMAL_LITERAL, 0); }
		public TerminalNode HEX_LITERAL() { return getToken(HqlParser.HEX_LITERAL, 0); }
		public NumericLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNumericLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNumericLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNumericLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericLiteralContext numericLiteral() throws RecognitionException {
		NumericLiteralContext _localctx = new NumericLiteralContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_numericLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1003);
			_la = _input.LA(1);
			if ( !(((((_la - 237)) & ~0x3f) == 0 && ((1L << (_la - 237)) & 127L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateTimeLiteralContext extends ParserRuleContext {
		public LocalDateTimeLiteralContext localDateTimeLiteral() {
			return getRuleContext(LocalDateTimeLiteralContext.class,0);
		}
		public ZonedDateTimeLiteralContext zonedDateTimeLiteral() {
			return getRuleContext(ZonedDateTimeLiteralContext.class,0);
		}
		public OffsetDateTimeLiteralContext offsetDateTimeLiteral() {
			return getRuleContext(OffsetDateTimeLiteralContext.class,0);
		}
		public DateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateTimeLiteralContext dateTimeLiteral() throws RecognitionException {
		DateTimeLiteralContext _localctx = new DateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_dateTimeLiteral);
		try {
			setState(1008);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,87,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1005);
				localDateTimeLiteral();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1006);
				zonedDateTimeLiteral();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1007);
				offsetDateTimeLiteral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateTimeLiteralContext extends ParserRuleContext {
		public LocalDateTimeContext localDateTime() {
			return getRuleContext(LocalDateTimeContext.class,0);
		}
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public LocalDateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateTimeLiteralContext localDateTimeLiteral() throws RecognitionException {
		LocalDateTimeLiteralContext _localctx = new LocalDateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_localDateTimeLiteral);
		int _la;
		try {
			setState(1019);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1010);
				match(T__1);
				setState(1011);
				localDateTime();
				setState(1012);
				match(T__2);
				}
				break;
			case DATETIME:
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1015);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LOCAL) {
					{
					setState(1014);
					match(LOCAL);
					}
				}

				setState(1017);
				match(DATETIME);
				setState(1018);
				localDateTime();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZonedDateTimeLiteralContext extends ParserRuleContext {
		public ZonedDateTimeContext zonedDateTime() {
			return getRuleContext(ZonedDateTimeContext.class,0);
		}
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public TerminalNode ZONED() { return getToken(HqlParser.ZONED, 0); }
		public ZonedDateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zonedDateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterZonedDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitZonedDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitZonedDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZonedDateTimeLiteralContext zonedDateTimeLiteral() throws RecognitionException {
		ZonedDateTimeLiteralContext _localctx = new ZonedDateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_zonedDateTimeLiteral);
		int _la;
		try {
			setState(1030);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1021);
				match(T__1);
				setState(1022);
				zonedDateTime();
				setState(1023);
				match(T__2);
				}
				break;
			case DATETIME:
			case ZONED:
				enterOuterAlt(_localctx, 2);
				{
				setState(1026);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ZONED) {
					{
					setState(1025);
					match(ZONED);
					}
				}

				setState(1028);
				match(DATETIME);
				setState(1029);
				zonedDateTime();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeLiteralContext extends ParserRuleContext {
		public OffsetDateTimeContext offsetDateTime() {
			return getRuleContext(OffsetDateTimeContext.class,0);
		}
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public OffsetDateTimeWithMinutesContext offsetDateTimeWithMinutes() {
			return getRuleContext(OffsetDateTimeWithMinutesContext.class,0);
		}
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public OffsetDateTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeLiteralContext offsetDateTimeLiteral() throws RecognitionException {
		OffsetDateTimeLiteralContext _localctx = new OffsetDateTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_offsetDateTimeLiteral);
		int _la;
		try {
			setState(1041);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1032);
				match(T__1);
				setState(1033);
				offsetDateTime();
				setState(1034);
				match(T__2);
				}
				break;
			case DATETIME:
			case OFFSET:
				enterOuterAlt(_localctx, 2);
				{
				setState(1037);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==OFFSET) {
					{
					setState(1036);
					match(OFFSET);
					}
				}

				setState(1039);
				match(DATETIME);
				setState(1040);
				offsetDateTimeWithMinutes();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateLiteralContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public DateLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateLiteralContext dateLiteral() throws RecognitionException {
		DateLiteralContext _localctx = new DateLiteralContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_dateLiteral);
		int _la;
		try {
			setState(1052);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1043);
				match(T__1);
				setState(1044);
				date();
				setState(1045);
				match(T__2);
				}
				break;
			case DATE:
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1048);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LOCAL) {
					{
					setState(1047);
					match(LOCAL);
					}
				}

				setState(1050);
				match(DATE);
				setState(1051);
				date();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeLiteralContext extends ParserRuleContext {
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeLiteralContext timeLiteral() throws RecognitionException {
		TimeLiteralContext _localctx = new TimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_timeLiteral);
		int _la;
		try {
			setState(1063);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1054);
				match(T__1);
				setState(1055);
				time();
				setState(1056);
				match(T__2);
				}
				break;
			case LOCAL:
			case TIME:
				enterOuterAlt(_localctx, 2);
				{
				setState(1059);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==LOCAL) {
					{
					setState(1058);
					match(LOCAL);
					}
				}

				setState(1061);
				match(TIME);
				setState(1062);
				time();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateTimeContext extends ParserRuleContext {
		public LocalDateTimeContext localDateTime() {
			return getRuleContext(LocalDateTimeContext.class,0);
		}
		public ZonedDateTimeContext zonedDateTime() {
			return getRuleContext(ZonedDateTimeContext.class,0);
		}
		public OffsetDateTimeContext offsetDateTime() {
			return getRuleContext(OffsetDateTimeContext.class,0);
		}
		public DateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateTimeContext dateTime() throws RecognitionException {
		DateTimeContext _localctx = new DateTimeContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_dateTime);
		try {
			setState(1068);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,98,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1065);
				localDateTime();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1066);
				zonedDateTime();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1067);
				offsetDateTime();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateTimeContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public LocalDateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateTimeContext localDateTime() throws RecognitionException {
		LocalDateTimeContext _localctx = new LocalDateTimeContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_localDateTime);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1070);
			date();
			setState(1071);
			time();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZonedDateTimeContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public ZoneIdContext zoneId() {
			return getRuleContext(ZoneIdContext.class,0);
		}
		public ZonedDateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zonedDateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterZonedDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitZonedDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitZonedDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZonedDateTimeContext zonedDateTime() throws RecognitionException {
		ZonedDateTimeContext _localctx = new ZonedDateTimeContext(_ctx, getState());
		enterRule(_localctx, 136, RULE_zonedDateTime);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1073);
			date();
			setState(1074);
			time();
			setState(1075);
			zoneId();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public OffsetContext offset() {
			return getRuleContext(OffsetContext.class,0);
		}
		public OffsetDateTimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeContext offsetDateTime() throws RecognitionException {
		OffsetDateTimeContext _localctx = new OffsetDateTimeContext(_ctx, getState());
		enterRule(_localctx, 138, RULE_offsetDateTime);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1077);
			date();
			setState(1078);
			time();
			setState(1079);
			offset();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeWithMinutesContext extends ParserRuleContext {
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public OffsetWithMinutesContext offsetWithMinutes() {
			return getRuleContext(OffsetWithMinutesContext.class,0);
		}
		public OffsetDateTimeWithMinutesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTimeWithMinutes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTimeWithMinutes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTimeWithMinutes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTimeWithMinutes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeWithMinutesContext offsetDateTimeWithMinutes() throws RecognitionException {
		OffsetDateTimeWithMinutesContext _localctx = new OffsetDateTimeWithMinutesContext(_ctx, getState());
		enterRule(_localctx, 140, RULE_offsetDateTimeWithMinutes);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1081);
			date();
			setState(1082);
			time();
			setState(1083);
			offsetWithMinutes();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JdbcTimestampLiteralContext extends ParserRuleContext {
		public TerminalNode TIMESTAMP_ESCAPE_START() { return getToken(HqlParser.TIMESTAMP_ESCAPE_START, 0); }
		public DateTimeContext dateTime() {
			return getRuleContext(DateTimeContext.class,0);
		}
		public GenericTemporalLiteralTextContext genericTemporalLiteralText() {
			return getRuleContext(GenericTemporalLiteralTextContext.class,0);
		}
		public JdbcTimestampLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbcTimestampLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJdbcTimestampLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJdbcTimestampLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJdbcTimestampLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JdbcTimestampLiteralContext jdbcTimestampLiteral() throws RecognitionException {
		JdbcTimestampLiteralContext _localctx = new JdbcTimestampLiteralContext(_ctx, getState());
		enterRule(_localctx, 142, RULE_jdbcTimestampLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1085);
			match(TIMESTAMP_ESCAPE_START);
			setState(1088);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				{
				setState(1086);
				dateTime();
				}
				break;
			case STRING_LITERAL:
				{
				setState(1087);
				genericTemporalLiteralText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1090);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JdbcDateLiteralContext extends ParserRuleContext {
		public TerminalNode DATE_ESCAPE_START() { return getToken(HqlParser.DATE_ESCAPE_START, 0); }
		public DateContext date() {
			return getRuleContext(DateContext.class,0);
		}
		public GenericTemporalLiteralTextContext genericTemporalLiteralText() {
			return getRuleContext(GenericTemporalLiteralTextContext.class,0);
		}
		public JdbcDateLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbcDateLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJdbcDateLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJdbcDateLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJdbcDateLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JdbcDateLiteralContext jdbcDateLiteral() throws RecognitionException {
		JdbcDateLiteralContext _localctx = new JdbcDateLiteralContext(_ctx, getState());
		enterRule(_localctx, 144, RULE_jdbcDateLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1092);
			match(DATE_ESCAPE_START);
			setState(1095);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				{
				setState(1093);
				date();
				}
				break;
			case STRING_LITERAL:
				{
				setState(1094);
				genericTemporalLiteralText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1097);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JdbcTimeLiteralContext extends ParserRuleContext {
		public TerminalNode TIME_ESCAPE_START() { return getToken(HqlParser.TIME_ESCAPE_START, 0); }
		public TimeContext time() {
			return getRuleContext(TimeContext.class,0);
		}
		public GenericTemporalLiteralTextContext genericTemporalLiteralText() {
			return getRuleContext(GenericTemporalLiteralTextContext.class,0);
		}
		public JdbcTimeLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbcTimeLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJdbcTimeLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJdbcTimeLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJdbcTimeLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JdbcTimeLiteralContext jdbcTimeLiteral() throws RecognitionException {
		JdbcTimeLiteralContext _localctx = new JdbcTimeLiteralContext(_ctx, getState());
		enterRule(_localctx, 146, RULE_jdbcTimeLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1099);
			match(TIME_ESCAPE_START);
			setState(1102);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				{
				setState(1100);
				time();
				}
				break;
			case STRING_LITERAL:
				{
				setState(1101);
				genericTemporalLiteralText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1104);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericTemporalLiteralTextContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public GenericTemporalLiteralTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericTemporalLiteralText; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericTemporalLiteralText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericTemporalLiteralText(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericTemporalLiteralText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericTemporalLiteralTextContext genericTemporalLiteralText() throws RecognitionException {
		GenericTemporalLiteralTextContext _localctx = new GenericTemporalLiteralTextContext(_ctx, getState());
		enterRule(_localctx, 148, RULE_genericTemporalLiteralText);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1106);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ArrayLiteralContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public ArrayLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterArrayLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitArrayLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitArrayLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArrayLiteralContext arrayLiteral() throws RecognitionException {
		ArrayLiteralContext _localctx = new ArrayLiteralContext(_ctx, getState());
		enterRule(_localctx, 150, RULE_arrayLiteral);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1108);
			match(T__6);
			setState(1117);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -31454588L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -1L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 1152921504606846975L) != 0)) {
				{
				setState(1109);
				expression(0);
				setState(1114);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1110);
					match(T__0);
					setState(1111);
					expression(0);
					}
					}
					setState(1116);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(1119);
			match(T__7);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralizedLiteralContext extends ParserRuleContext {
		public GeneralizedLiteralTypeContext generalizedLiteralType() {
			return getRuleContext(GeneralizedLiteralTypeContext.class,0);
		}
		public GeneralizedLiteralTextContext generalizedLiteralText() {
			return getRuleContext(GeneralizedLiteralTextContext.class,0);
		}
		public GeneralizedLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalizedLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralizedLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralizedLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralizedLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralizedLiteralContext generalizedLiteral() throws RecognitionException {
		GeneralizedLiteralContext _localctx = new GeneralizedLiteralContext(_ctx, getState());
		enterRule(_localctx, 152, RULE_generalizedLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1121);
			match(T__1);
			setState(1122);
			generalizedLiteralType();
			setState(1123);
			match(T__8);
			setState(1124);
			generalizedLiteralText();
			setState(1125);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralizedLiteralTypeContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public GeneralizedLiteralTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalizedLiteralType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralizedLiteralType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralizedLiteralType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralizedLiteralType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralizedLiteralTypeContext generalizedLiteralType() throws RecognitionException {
		GeneralizedLiteralTypeContext _localctx = new GeneralizedLiteralTypeContext(_ctx, getState());
		enterRule(_localctx, 154, RULE_generalizedLiteralType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1127);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralizedLiteralTextContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public GeneralizedLiteralTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalizedLiteralText; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralizedLiteralText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralizedLiteralText(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralizedLiteralText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralizedLiteralTextContext generalizedLiteralText() throws RecognitionException {
		GeneralizedLiteralTextContext _localctx = new GeneralizedLiteralTextContext(_ctx, getState());
		enterRule(_localctx, 156, RULE_generalizedLiteralText);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1129);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateContext extends ParserRuleContext {
		public YearContext year() {
			return getRuleContext(YearContext.class,0);
		}
		public List<TerminalNode> MINUS() { return getTokens(HqlParser.MINUS); }
		public TerminalNode MINUS(int i) {
			return getToken(HqlParser.MINUS, i);
		}
		public MonthContext month() {
			return getRuleContext(MonthContext.class,0);
		}
		public DayContext day() {
			return getRuleContext(DayContext.class,0);
		}
		public DateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_date; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateContext date() throws RecognitionException {
		DateContext _localctx = new DateContext(_ctx, getState());
		enterRule(_localctx, 158, RULE_date);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1131);
			year();
			setState(1132);
			match(MINUS);
			setState(1133);
			month();
			setState(1134);
			match(MINUS);
			setState(1135);
			day();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeContext extends ParserRuleContext {
		public HourContext hour() {
			return getRuleContext(HourContext.class,0);
		}
		public MinuteContext minute() {
			return getRuleContext(MinuteContext.class,0);
		}
		public SecondContext second() {
			return getRuleContext(SecondContext.class,0);
		}
		public TimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_time; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeContext time() throws RecognitionException {
		TimeContext _localctx = new TimeContext(_ctx, getState());
		enterRule(_localctx, 160, RULE_time);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1137);
			hour();
			setState(1138);
			match(T__8);
			setState(1139);
			minute();
			setState(1142);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,104,_ctx) ) {
			case 1:
				{
				setState(1140);
				match(T__8);
				setState(1141);
				second();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetContext extends ParserRuleContext {
		public HourContext hour() {
			return getRuleContext(HourContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public MinuteContext minute() {
			return getRuleContext(MinuteContext.class,0);
		}
		public OffsetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offset; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffset(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffset(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffset(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetContext offset() throws RecognitionException {
		OffsetContext _localctx = new OffsetContext(_ctx, getState());
		enterRule(_localctx, 162, RULE_offset);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1144);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1145);
			hour();
			setState(1148);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__8) {
				{
				setState(1146);
				match(T__8);
				setState(1147);
				minute();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetWithMinutesContext extends ParserRuleContext {
		public HourContext hour() {
			return getRuleContext(HourContext.class,0);
		}
		public MinuteContext minute() {
			return getRuleContext(MinuteContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public OffsetWithMinutesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetWithMinutes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetWithMinutes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetWithMinutes(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetWithMinutes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetWithMinutesContext offsetWithMinutes() throws RecognitionException {
		OffsetWithMinutesContext _localctx = new OffsetWithMinutesContext(_ctx, getState());
		enterRule(_localctx, 164, RULE_offsetWithMinutes);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1150);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1151);
			hour();
			setState(1152);
			match(T__8);
			setState(1153);
			minute();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class YearContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public YearContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_year; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterYear(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitYear(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitYear(this);
			else return visitor.visitChildren(this);
		}
	}

	public final YearContext year() throws RecognitionException {
		YearContext _localctx = new YearContext(_ctx, getState());
		enterRule(_localctx, 166, RULE_year);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1155);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MonthContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public MonthContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_month; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMonth(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMonth(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMonth(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MonthContext month() throws RecognitionException {
		MonthContext _localctx = new MonthContext(_ctx, getState());
		enterRule(_localctx, 168, RULE_month);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1157);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DayContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public DayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_day; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDay(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDay(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDay(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DayContext day() throws RecognitionException {
		DayContext _localctx = new DayContext(_ctx, getState());
		enterRule(_localctx, 170, RULE_day);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1159);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HourContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public HourContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hour; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterHour(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitHour(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitHour(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HourContext hour() throws RecognitionException {
		HourContext _localctx = new HourContext(_ctx, getState());
		enterRule(_localctx, 172, RULE_hour);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1161);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MinuteContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public MinuteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_minute; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMinute(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMinute(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMinute(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MinuteContext minute() throws RecognitionException {
		MinuteContext _localctx = new MinuteContext(_ctx, getState());
		enterRule(_localctx, 174, RULE_minute);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1163);
			match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SecondContext extends ParserRuleContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public TerminalNode DOUBLE_LITERAL() { return getToken(HqlParser.DOUBLE_LITERAL, 0); }
		public SecondContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_second; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSecond(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSecond(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSecond(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SecondContext second() throws RecognitionException {
		SecondContext _localctx = new SecondContext(_ctx, getState());
		enterRule(_localctx, 176, RULE_second);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1165);
			_la = _input.LA(1);
			if ( !(_la==INTEGER_LITERAL || _la==DOUBLE_LITERAL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ZoneIdContext extends ParserRuleContext {
		public List<TerminalNode> IDENTIFIER() { return getTokens(HqlParser.IDENTIFIER); }
		public TerminalNode IDENTIFIER(int i) {
			return getToken(HqlParser.IDENTIFIER, i);
		}
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public ZoneIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zoneId; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterZoneId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitZoneId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitZoneId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ZoneIdContext zoneId() throws RecognitionException {
		ZoneIdContext _localctx = new ZoneIdContext(_ctx, getState());
		enterRule(_localctx, 178, RULE_zoneId);
		try {
			setState(1173);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1167);
				match(IDENTIFIER);
				setState(1170);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,106,_ctx) ) {
				case 1:
					{
					setState(1168);
					match(T__9);
					setState(1169);
					match(IDENTIFIER);
					}
					break;
				}
				}
				break;
			case STRING_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1172);
				match(STRING_LITERAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExtractFieldContext extends ParserRuleContext {
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public DayFieldContext dayField() {
			return getRuleContext(DayFieldContext.class,0);
		}
		public WeekFieldContext weekField() {
			return getRuleContext(WeekFieldContext.class,0);
		}
		public TimeZoneFieldContext timeZoneField() {
			return getRuleContext(TimeZoneFieldContext.class,0);
		}
		public DateOrTimeFieldContext dateOrTimeField() {
			return getRuleContext(DateOrTimeFieldContext.class,0);
		}
		public ExtractFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extractField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExtractField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExtractField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExtractField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExtractFieldContext extractField() throws RecognitionException {
		ExtractFieldContext _localctx = new ExtractFieldContext(_ctx, getState());
		enterRule(_localctx, 180, RULE_extractField);
		try {
			setState(1180);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,108,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1175);
				datetimeField();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1176);
				dayField();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1177);
				weekField();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1178);
				timeZoneField();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1179);
				dateOrTimeField();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DatetimeFieldContext extends ParserRuleContext {
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode QUARTER() { return getToken(HqlParser.QUARTER, 0); }
		public TerminalNode HOUR() { return getToken(HqlParser.HOUR, 0); }
		public TerminalNode MINUTE() { return getToken(HqlParser.MINUTE, 0); }
		public TerminalNode SECOND() { return getToken(HqlParser.SECOND, 0); }
		public TerminalNode NANOSECOND() { return getToken(HqlParser.NANOSECOND, 0); }
		public TerminalNode EPOCH() { return getToken(HqlParser.EPOCH, 0); }
		public DatetimeFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetimeField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDatetimeField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDatetimeField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDatetimeField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DatetimeFieldContext datetimeField() throws RecognitionException {
		DatetimeFieldContext _localctx = new DatetimeFieldContext(_ctx, getState());
		enterRule(_localctx, 182, RULE_datetimeField);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1182);
			_la = _input.LA(1);
			if ( !(((((_la - 62)) & ~0x3f) == 0 && ((1L << (_la - 62)) & 8589942785L) != 0) || ((((_la - 144)) & ~0x3f) == 0 && ((1L << (_la - 144)) & 4406636445707L) != 0) || _la==WEEK || _la==YEAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DayFieldContext extends ParserRuleContext {
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public DayFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dayField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDayField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDayField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDayField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DayFieldContext dayField() throws RecognitionException {
		DayFieldContext _localctx = new DayFieldContext(_ctx, getState());
		enterRule(_localctx, 184, RULE_dayField);
		try {
			setState(1193);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,109,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1184);
				match(DAY);
				setState(1185);
				match(OF);
				setState(1186);
				match(MONTH);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1187);
				match(DAY);
				setState(1188);
				match(OF);
				setState(1189);
				match(WEEK);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1190);
				match(DAY);
				setState(1191);
				match(OF);
				setState(1192);
				match(YEAR);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WeekFieldContext extends ParserRuleContext {
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public WeekFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_weekField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWeekField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWeekField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWeekField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WeekFieldContext weekField() throws RecognitionException {
		WeekFieldContext _localctx = new WeekFieldContext(_ctx, getState());
		enterRule(_localctx, 186, RULE_weekField);
		try {
			setState(1201);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,110,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1195);
				match(WEEK);
				setState(1196);
				match(OF);
				setState(1197);
				match(MONTH);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1198);
				match(WEEK);
				setState(1199);
				match(OF);
				setState(1200);
				match(YEAR);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TimeZoneFieldContext extends ParserRuleContext {
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public TerminalNode HOUR() { return getToken(HqlParser.HOUR, 0); }
		public TerminalNode MINUTE() { return getToken(HqlParser.MINUTE, 0); }
		public TerminalNode TIMEZONE_HOUR() { return getToken(HqlParser.TIMEZONE_HOUR, 0); }
		public TerminalNode TIMEZONE_MINUTE() { return getToken(HqlParser.TIMEZONE_MINUTE, 0); }
		public TimeZoneFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeZoneField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTimeZoneField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTimeZoneField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTimeZoneField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeZoneFieldContext timeZoneField() throws RecognitionException {
		TimeZoneFieldContext _localctx = new TimeZoneFieldContext(_ctx, getState());
		enterRule(_localctx, 188, RULE_timeZoneField);
		int _la;
		try {
			setState(1209);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case OFFSET:
				enterOuterAlt(_localctx, 1);
				{
				setState(1203);
				match(OFFSET);
				setState(1205);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HOUR || _la==MINUTE) {
					{
					setState(1204);
					_la = _input.LA(1);
					if ( !(_la==HOUR || _la==MINUTE) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				}
				break;
			case TIMEZONE_HOUR:
				enterOuterAlt(_localctx, 2);
				{
				setState(1207);
				match(TIMEZONE_HOUR);
				}
				break;
			case TIMEZONE_MINUTE:
				enterOuterAlt(_localctx, 3);
				{
				setState(1208);
				match(TIMEZONE_MINUTE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DateOrTimeFieldContext extends ParserRuleContext {
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public DateOrTimeFieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dateOrTimeField; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDateOrTimeField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDateOrTimeField(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDateOrTimeField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DateOrTimeFieldContext dateOrTimeField() throws RecognitionException {
		DateOrTimeFieldContext _localctx = new DateOrTimeFieldContext(_ctx, getState());
		enterRule(_localctx, 190, RULE_dateOrTimeField);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1211);
			_la = _input.LA(1);
			if ( !(_la==DATE || _la==TIME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BinaryLiteralContext extends ParserRuleContext {
		public TerminalNode BINARY_LITERAL() { return getToken(HqlParser.BINARY_LITERAL, 0); }
		public List<TerminalNode> HEX_LITERAL() { return getTokens(HqlParser.HEX_LITERAL); }
		public TerminalNode HEX_LITERAL(int i) {
			return getToken(HqlParser.HEX_LITERAL, i);
		}
		public BinaryLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBinaryLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBinaryLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBinaryLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BinaryLiteralContext binaryLiteral() throws RecognitionException {
		BinaryLiteralContext _localctx = new BinaryLiteralContext(_ctx, getState());
		enterRule(_localctx, 192, RULE_binaryLiteral);
		int _la;
		try {
			setState(1224);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BINARY_LITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1213);
				match(BINARY_LITERAL);
				}
				break;
			case T__10:
				enterOuterAlt(_localctx, 2);
				{
				setState(1214);
				match(T__10);
				setState(1215);
				match(HEX_LITERAL);
				setState(1220);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1216);
					match(T__0);
					setState(1217);
					match(HEX_LITERAL);
					}
					}
					setState(1222);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1223);
				match(T__5);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TemporalLiteralContext extends ParserRuleContext {
		public DateTimeLiteralContext dateTimeLiteral() {
			return getRuleContext(DateTimeLiteralContext.class,0);
		}
		public DateLiteralContext dateLiteral() {
			return getRuleContext(DateLiteralContext.class,0);
		}
		public TimeLiteralContext timeLiteral() {
			return getRuleContext(TimeLiteralContext.class,0);
		}
		public JdbcTimestampLiteralContext jdbcTimestampLiteral() {
			return getRuleContext(JdbcTimestampLiteralContext.class,0);
		}
		public JdbcDateLiteralContext jdbcDateLiteral() {
			return getRuleContext(JdbcDateLiteralContext.class,0);
		}
		public JdbcTimeLiteralContext jdbcTimeLiteral() {
			return getRuleContext(JdbcTimeLiteralContext.class,0);
		}
		public TemporalLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_temporalLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTemporalLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTemporalLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTemporalLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TemporalLiteralContext temporalLiteral() throws RecognitionException {
		TemporalLiteralContext _localctx = new TemporalLiteralContext(_ctx, getState());
		enterRule(_localctx, 194, RULE_temporalLiteral);
		try {
			setState(1232);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,115,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1226);
				dateTimeLiteral();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1227);
				dateLiteral();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1228);
				timeLiteral();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1229);
				jdbcTimestampLiteral();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1230);
				jdbcDateLiteral();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1231);
				jdbcTimeLiteral();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AdditionExpressionContext extends ExpressionContext {
		public Token op;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public AdditionExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAdditionExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAdditionExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAdditionExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FromDurationExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public FromDurationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFromDurationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFromDurationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFromDurationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PlainPrimaryExpressionContext extends ExpressionContext {
		public PrimaryExpressionContext primaryExpression() {
			return getRuleContext(PrimaryExpressionContext.class,0);
		}
		public PlainPrimaryExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPlainPrimaryExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPlainPrimaryExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPlainPrimaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TupleExpressionContext extends ExpressionContext {
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TupleExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTupleExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTupleExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTupleExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupedExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public GroupedExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupedExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupedExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SignedNumericLiteralContext extends ExpressionContext {
		public Token op;
		public NumericLiteralContext numericLiteral() {
			return getRuleContext(NumericLiteralContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public SignedNumericLiteralContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSignedNumericLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSignedNumericLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSignedNumericLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ToDurationExpressionContext extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public ToDurationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterToDurationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitToDurationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitToDurationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SubqueryExpressionContext extends ExpressionContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public SubqueryExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubqueryExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubqueryExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubqueryExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DayOfMonthExpressionContext extends ExpressionContext {
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public DayOfMonthExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDayOfMonthExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDayOfMonthExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDayOfMonthExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DayOfWeekExpressionContext extends ExpressionContext {
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public DayOfWeekExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterDayOfWeekExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitDayOfWeekExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitDayOfWeekExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class WeekOfYearExpressionContext extends ExpressionContext {
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public WeekOfYearExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWeekOfYearExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWeekOfYearExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWeekOfYearExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HqlConcatenationExpressionContext extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public HqlConcatenationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterHqlConcatenationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitHqlConcatenationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitHqlConcatenationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MultiplicationExpressionContext extends ExpressionContext {
		public Token op;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode ASTERISK() { return getToken(HqlParser.ASTERISK, 0); }
		public MultiplicationExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMultiplicationExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMultiplicationExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMultiplicationExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SignedExpressionContext extends ExpressionContext {
		public Token op;
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(HqlParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(HqlParser.MINUS, 0); }
		public SignedExpressionContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSignedExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSignedExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSignedExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		return expression(0);
	}

	private ExpressionContext expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExpressionContext _localctx = new ExpressionContext(_ctx, _parentState);
		ExpressionContext _prevctx = _localctx;
		int _startState = 196;
		enterRecursionRule(_localctx, 196, RULE_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1267);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,117,_ctx) ) {
			case 1:
				{
				_localctx = new GroupedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(1235);
				match(T__1);
				setState(1236);
				expression(0);
				setState(1237);
				match(T__2);
				}
				break;
			case 2:
				{
				_localctx = new TupleExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1239);
				match(T__1);
				setState(1240);
				expressionOrPredicate();
				setState(1243); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(1241);
					match(T__0);
					setState(1242);
					expressionOrPredicate();
					}
					}
					setState(1245); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==T__0 );
				setState(1247);
				match(T__2);
				}
				break;
			case 3:
				{
				_localctx = new SubqueryExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1249);
				match(T__1);
				setState(1250);
				subquery();
				setState(1251);
				match(T__2);
				}
				break;
			case 4:
				{
				_localctx = new PlainPrimaryExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1253);
				primaryExpression();
				}
				break;
			case 5:
				{
				_localctx = new SignedNumericLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1254);
				((SignedNumericLiteralContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					((SignedNumericLiteralContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1255);
				numericLiteral();
				}
				break;
			case 6:
				{
				_localctx = new SignedExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1256);
				((SignedExpressionContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					((SignedExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1257);
				expression(9);
				}
				break;
			case 7:
				{
				_localctx = new DayOfWeekExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1258);
				match(DAY);
				setState(1259);
				match(OF);
				setState(1260);
				match(WEEK);
				}
				break;
			case 8:
				{
				_localctx = new DayOfMonthExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1261);
				match(DAY);
				setState(1262);
				match(OF);
				setState(1263);
				match(MONTH);
				}
				break;
			case 9:
				{
				_localctx = new WeekOfYearExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(1264);
				match(WEEK);
				setState(1265);
				match(OF);
				setState(1266);
				match(YEAR);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(1285);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,119,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(1283);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,118,_ctx) ) {
					case 1:
						{
						_localctx = new MultiplicationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1269);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(1270);
						((MultiplicationExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__9 || _la==ASTERISK) ) {
							((MultiplicationExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(1271);
						expression(7);
						}
						break;
					case 2:
						{
						_localctx = new AdditionExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1272);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(1273);
						((AdditionExpressionContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
							((AdditionExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(1274);
						expression(6);
						}
						break;
					case 3:
						{
						_localctx = new HqlConcatenationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1275);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(1276);
						match(T__11);
						setState(1277);
						expression(5);
						}
						break;
					case 4:
						{
						_localctx = new ToDurationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1278);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(1279);
						datetimeField();
						}
						break;
					case 5:
						{
						_localctx = new FromDurationExpressionContext(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(1280);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(1281);
						match(BY);
						setState(1282);
						datetimeField();
						}
						break;
					}
					} 
				}
				setState(1287);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,119,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PrimaryExpressionContext extends ParserRuleContext {
		public PrimaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_primaryExpression; }
	 
		public PrimaryExpressionContext() { }
		public void copyFrom(PrimaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FunctionExpressionContext extends PrimaryExpressionContext {
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public FunctionExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFunctionExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFunctionExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFunctionExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LiteralExpressionContext extends PrimaryExpressionContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLiteralExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLiteralExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLiteralExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ParameterExpressionContext extends PrimaryExpressionContext {
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public ParameterExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameterExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameterExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityTypeExpressionContext extends PrimaryExpressionContext {
		public EntityTypeReferenceContext entityTypeReference() {
			return getRuleContext(EntityTypeReferenceContext.class,0);
		}
		public EntityTypeExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityTypeExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityTypeExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityTypeExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityIdExpressionContext extends PrimaryExpressionContext {
		public EntityIdReferenceContext entityIdReference() {
			return getRuleContext(EntityIdReferenceContext.class,0);
		}
		public EntityIdExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityIdExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityIdExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityIdExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityVersionExpressionContext extends PrimaryExpressionContext {
		public EntityVersionReferenceContext entityVersionReference() {
			return getRuleContext(EntityVersionReferenceContext.class,0);
		}
		public EntityVersionExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityVersionExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityVersionExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityVersionExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GeneralPathExpressionContext extends PrimaryExpressionContext {
		public GeneralPathFragmentContext generalPathFragment() {
			return getRuleContext(GeneralPathFragmentContext.class,0);
		}
		public GeneralPathExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralPathExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralPathExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralPathExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityNaturalIdExpressionContext extends PrimaryExpressionContext {
		public EntityNaturalIdReferenceContext entityNaturalIdReference() {
			return getRuleContext(EntityNaturalIdReferenceContext.class,0);
		}
		public EntityNaturalIdExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityNaturalIdExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityNaturalIdExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityNaturalIdExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CaseExpressionContext extends PrimaryExpressionContext {
		public CaseListContext caseList() {
			return getRuleContext(CaseListContext.class,0);
		}
		public CaseExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SyntacticPathExpressionContext extends PrimaryExpressionContext {
		public SyntacticDomainPathContext syntacticDomainPath() {
			return getRuleContext(SyntacticDomainPathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public SyntacticPathExpressionContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSyntacticPathExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSyntacticPathExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSyntacticPathExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrimaryExpressionContext primaryExpression() throws RecognitionException {
		PrimaryExpressionContext _localctx = new PrimaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 198, RULE_primaryExpression);
		try {
			setState(1301);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,121,_ctx) ) {
			case 1:
				_localctx = new CaseExpressionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1288);
				caseList();
				}
				break;
			case 2:
				_localctx = new LiteralExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1289);
				literal();
				}
				break;
			case 3:
				_localctx = new ParameterExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1290);
				parameter();
				}
				break;
			case 4:
				_localctx = new EntityTypeExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1291);
				entityTypeReference();
				}
				break;
			case 5:
				_localctx = new EntityIdExpressionContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(1292);
				entityIdReference();
				}
				break;
			case 6:
				_localctx = new EntityVersionExpressionContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(1293);
				entityVersionReference();
				}
				break;
			case 7:
				_localctx = new EntityNaturalIdExpressionContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(1294);
				entityNaturalIdReference();
				}
				break;
			case 8:
				_localctx = new SyntacticPathExpressionContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(1295);
				syntacticDomainPath();
				setState(1297);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,120,_ctx) ) {
				case 1:
					{
					setState(1296);
					pathContinuation();
					}
					break;
				}
				}
				break;
			case 9:
				_localctx = new FunctionExpressionContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(1299);
				function();
				}
				break;
			case 10:
				_localctx = new GeneralPathExpressionContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(1300);
				generalPathFragment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PathContext extends ParserRuleContext {
		public SyntacticDomainPathContext syntacticDomainPath() {
			return getRuleContext(SyntacticDomainPathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public GeneralPathFragmentContext generalPathFragment() {
			return getRuleContext(GeneralPathFragmentContext.class,0);
		}
		public PathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PathContext path() throws RecognitionException {
		PathContext _localctx = new PathContext(_ctx, getState());
		enterRule(_localctx, 200, RULE_path);
		try {
			setState(1308);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,123,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1303);
				syntacticDomainPath();
				setState(1305);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,122,_ctx) ) {
				case 1:
					{
					setState(1304);
					pathContinuation();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1307);
				generalPathFragment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GeneralPathFragmentContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public IndexedPathAccessFragmentContext indexedPathAccessFragment() {
			return getRuleContext(IndexedPathAccessFragmentContext.class,0);
		}
		public GeneralPathFragmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_generalPathFragment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGeneralPathFragment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGeneralPathFragment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGeneralPathFragment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GeneralPathFragmentContext generalPathFragment() throws RecognitionException {
		GeneralPathFragmentContext _localctx = new GeneralPathFragmentContext(_ctx, getState());
		enterRule(_localctx, 202, RULE_generalPathFragment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1310);
			simplePath();
			setState(1312);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,124,_ctx) ) {
			case 1:
				{
				setState(1311);
				indexedPathAccessFragment();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IndexedPathAccessFragmentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public GeneralPathFragmentContext generalPathFragment() {
			return getRuleContext(GeneralPathFragmentContext.class,0);
		}
		public IndexedPathAccessFragmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_indexedPathAccessFragment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndexedPathAccessFragment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndexedPathAccessFragment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndexedPathAccessFragment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IndexedPathAccessFragmentContext indexedPathAccessFragment() throws RecognitionException {
		IndexedPathAccessFragmentContext _localctx = new IndexedPathAccessFragmentContext(_ctx, getState());
		enterRule(_localctx, 204, RULE_indexedPathAccessFragment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1314);
			match(T__6);
			setState(1315);
			expression(0);
			setState(1316);
			match(T__7);
			setState(1319);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,125,_ctx) ) {
			case 1:
				{
				setState(1317);
				match(T__12);
				setState(1318);
				generalPathFragment();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimplePathContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public List<SimplePathElementContext> simplePathElement() {
			return getRuleContexts(SimplePathElementContext.class);
		}
		public SimplePathElementContext simplePathElement(int i) {
			return getRuleContext(SimplePathElementContext.class,i);
		}
		public SimplePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simplePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimplePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimplePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimplePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimplePathContext simplePath() throws RecognitionException {
		SimplePathContext _localctx = new SimplePathContext(_ctx, getState());
		enterRule(_localctx, 206, RULE_simplePath);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1321);
			identifier();
			setState(1325);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,126,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1322);
					simplePathElement();
					}
					} 
				}
				setState(1327);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,126,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimplePathElementContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public SimplePathElementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simplePathElement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimplePathElement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimplePathElement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimplePathElement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimplePathElementContext simplePathElement() throws RecognitionException {
		SimplePathElementContext _localctx = new SimplePathElementContext(_ctx, getState());
		enterRule(_localctx, 208, RULE_simplePathElement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1328);
			match(T__12);
			setState(1329);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PathContinuationContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public PathContinuationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pathContinuation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPathContinuation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPathContinuation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPathContinuation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PathContinuationContext pathContinuation() throws RecognitionException {
		PathContinuationContext _localctx = new PathContinuationContext(_ctx, getState());
		enterRule(_localctx, 210, RULE_pathContinuation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1331);
			match(T__12);
			setState(1332);
			simplePath();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityTypeReferenceContext extends ParserRuleContext {
		public TerminalNode TYPE() { return getToken(HqlParser.TYPE, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public EntityTypeReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityTypeReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityTypeReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityTypeReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityTypeReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityTypeReferenceContext entityTypeReference() throws RecognitionException {
		EntityTypeReferenceContext _localctx = new EntityTypeReferenceContext(_ctx, getState());
		enterRule(_localctx, 212, RULE_entityTypeReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1334);
			match(TYPE);
			setState(1335);
			match(T__1);
			setState(1338);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ABSENT:
			case ALL:
			case AND:
			case ANY:
			case ARRAY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case COLUMNS:
			case CONDITIONAL:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FULL:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INNER:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case JSON:
			case JSON_ARRAY:
			case JSON_ARRAYAGG:
			case JSON_EXISTS:
			case JSON_OBJECT:
			case JSON_OBJECTAGG:
			case JSON_QUERY:
			case JSON_TABLE:
			case JSON_VALUE:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LEFT:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NAME:
			case NANOSECOND:
			case NEW:
			case NESTED:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case ORDINALITY:
			case OTHERS:
			case OUTER:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PATH:
			case PARTITION:
			case PASSING:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RETURNING:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNCONDITIONAL:
			case UNION:
			case UNIQUE:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case WRAPPER:
			case XML:
			case XMLAGG:
			case XMLATTRIBUTES:
			case XMLELEMENT:
			case XMLEXISTS:
			case XMLFOREST:
			case XMLPI:
			case XMLQUERY:
			case XMLTABLE:
			case YEAR:
			case ZONED:
			case IDENTIFIER:
			case QUOTED_IDENTIFIER:
				{
				setState(1336);
				path();
				}
				break;
			case T__8:
			case T__20:
				{
				setState(1337);
				parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1340);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityIdReferenceContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(HqlParser.ID, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public EntityIdReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityIdReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityIdReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityIdReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityIdReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityIdReferenceContext entityIdReference() throws RecognitionException {
		EntityIdReferenceContext _localctx = new EntityIdReferenceContext(_ctx, getState());
		enterRule(_localctx, 214, RULE_entityIdReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1342);
			match(ID);
			setState(1343);
			match(T__1);
			setState(1344);
			path();
			setState(1345);
			match(T__2);
			setState(1347);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,128,_ctx) ) {
			case 1:
				{
				setState(1346);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityVersionReferenceContext extends ParserRuleContext {
		public TerminalNode VERSION() { return getToken(HqlParser.VERSION, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public EntityVersionReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityVersionReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityVersionReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityVersionReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityVersionReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityVersionReferenceContext entityVersionReference() throws RecognitionException {
		EntityVersionReferenceContext _localctx = new EntityVersionReferenceContext(_ctx, getState());
		enterRule(_localctx, 216, RULE_entityVersionReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1349);
			match(VERSION);
			setState(1350);
			match(T__1);
			setState(1351);
			path();
			setState(1352);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityNaturalIdReferenceContext extends ParserRuleContext {
		public TerminalNode NATURALID() { return getToken(HqlParser.NATURALID, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public EntityNaturalIdReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityNaturalIdReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityNaturalIdReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityNaturalIdReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityNaturalIdReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityNaturalIdReferenceContext entityNaturalIdReference() throws RecognitionException {
		EntityNaturalIdReferenceContext _localctx = new EntityNaturalIdReferenceContext(_ctx, getState());
		enterRule(_localctx, 218, RULE_entityNaturalIdReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1354);
			match(NATURALID);
			setState(1355);
			match(T__1);
			setState(1356);
			path();
			setState(1357);
			match(T__2);
			setState(1359);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,129,_ctx) ) {
			case 1:
				{
				setState(1358);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SyntacticDomainPathContext extends ParserRuleContext {
		public TreatedNavigablePathContext treatedNavigablePath() {
			return getRuleContext(TreatedNavigablePathContext.class,0);
		}
		public CollectionValueNavigablePathContext collectionValueNavigablePath() {
			return getRuleContext(CollectionValueNavigablePathContext.class,0);
		}
		public MapKeyNavigablePathContext mapKeyNavigablePath() {
			return getRuleContext(MapKeyNavigablePathContext.class,0);
		}
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public IndexedPathAccessFragmentContext indexedPathAccessFragment() {
			return getRuleContext(IndexedPathAccessFragmentContext.class,0);
		}
		public SlicedPathAccessFragmentContext slicedPathAccessFragment() {
			return getRuleContext(SlicedPathAccessFragmentContext.class,0);
		}
		public ToOneFkReferenceContext toOneFkReference() {
			return getRuleContext(ToOneFkReferenceContext.class,0);
		}
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public SyntacticDomainPathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_syntacticDomainPath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSyntacticDomainPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSyntacticDomainPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSyntacticDomainPath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SyntacticDomainPathContext syntacticDomainPath() throws RecognitionException {
		SyntacticDomainPathContext _localctx = new SyntacticDomainPathContext(_ctx, getState());
		enterRule(_localctx, 220, RULE_syntacticDomainPath);
		try {
			setState(1382);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,131,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1361);
				treatedNavigablePath();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1362);
				collectionValueNavigablePath();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1363);
				mapKeyNavigablePath();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1364);
				simplePath();
				setState(1365);
				indexedPathAccessFragment();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1367);
				simplePath();
				setState(1368);
				slicedPathAccessFragment();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1370);
				toOneFkReference();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1371);
				function();
				setState(1372);
				pathContinuation();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1374);
				function();
				setState(1375);
				indexedPathAccessFragment();
				setState(1377);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,130,_ctx) ) {
				case 1:
					{
					setState(1376);
					pathContinuation();
					}
					break;
				}
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1379);
				function();
				setState(1380);
				slicedPathAccessFragment();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SlicedPathAccessFragmentContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public SlicedPathAccessFragmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_slicedPathAccessFragment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSlicedPathAccessFragment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSlicedPathAccessFragment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSlicedPathAccessFragment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SlicedPathAccessFragmentContext slicedPathAccessFragment() throws RecognitionException {
		SlicedPathAccessFragmentContext _localctx = new SlicedPathAccessFragmentContext(_ctx, getState());
		enterRule(_localctx, 222, RULE_slicedPathAccessFragment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1384);
			match(T__6);
			setState(1385);
			expression(0);
			setState(1386);
			match(T__8);
			setState(1387);
			expression(0);
			setState(1388);
			match(T__7);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TreatedNavigablePathContext extends ParserRuleContext {
		public TerminalNode TREAT() { return getToken(HqlParser.TREAT, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public TreatedNavigablePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_treatedNavigablePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTreatedNavigablePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTreatedNavigablePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTreatedNavigablePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TreatedNavigablePathContext treatedNavigablePath() throws RecognitionException {
		TreatedNavigablePathContext _localctx = new TreatedNavigablePathContext(_ctx, getState());
		enterRule(_localctx, 224, RULE_treatedNavigablePath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1390);
			match(TREAT);
			setState(1391);
			match(T__1);
			setState(1392);
			path();
			setState(1393);
			match(AS);
			setState(1394);
			simplePath();
			setState(1395);
			match(T__2);
			setState(1397);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,132,_ctx) ) {
			case 1:
				{
				setState(1396);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionValueNavigablePathContext extends ParserRuleContext {
		public ElementValueQuantifierContext elementValueQuantifier() {
			return getRuleContext(ElementValueQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public CollectionValueNavigablePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionValueNavigablePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionValueNavigablePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionValueNavigablePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionValueNavigablePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionValueNavigablePathContext collectionValueNavigablePath() throws RecognitionException {
		CollectionValueNavigablePathContext _localctx = new CollectionValueNavigablePathContext(_ctx, getState());
		enterRule(_localctx, 226, RULE_collectionValueNavigablePath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1399);
			elementValueQuantifier();
			setState(1400);
			match(T__1);
			setState(1401);
			path();
			setState(1402);
			match(T__2);
			setState(1404);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,133,_ctx) ) {
			case 1:
				{
				setState(1403);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MapKeyNavigablePathContext extends ParserRuleContext {
		public IndexKeyQuantifierContext indexKeyQuantifier() {
			return getRuleContext(IndexKeyQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public MapKeyNavigablePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mapKeyNavigablePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMapKeyNavigablePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMapKeyNavigablePath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMapKeyNavigablePath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MapKeyNavigablePathContext mapKeyNavigablePath() throws RecognitionException {
		MapKeyNavigablePathContext _localctx = new MapKeyNavigablePathContext(_ctx, getState());
		enterRule(_localctx, 228, RULE_mapKeyNavigablePath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1406);
			indexKeyQuantifier();
			setState(1407);
			match(T__1);
			setState(1408);
			path();
			setState(1409);
			match(T__2);
			setState(1411);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,134,_ctx) ) {
			case 1:
				{
				setState(1410);
				pathContinuation();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ToOneFkReferenceContext extends ParserRuleContext {
		public TerminalNode FK() { return getToken(HqlParser.FK, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public ToOneFkReferenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_toOneFkReference; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterToOneFkReference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitToOneFkReference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitToOneFkReference(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ToOneFkReferenceContext toOneFkReference() throws RecognitionException {
		ToOneFkReferenceContext _localctx = new ToOneFkReferenceContext(_ctx, getState());
		enterRule(_localctx, 230, RULE_toOneFkReference);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1413);
			match(FK);
			setState(1414);
			match(T__1);
			setState(1415);
			path();
			setState(1416);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CaseListContext extends ParserRuleContext {
		public SimpleCaseExpressionContext simpleCaseExpression() {
			return getRuleContext(SimpleCaseExpressionContext.class,0);
		}
		public SearchedCaseExpressionContext searchedCaseExpression() {
			return getRuleContext(SearchedCaseExpressionContext.class,0);
		}
		public CaseListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caseList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseListContext caseList() throws RecognitionException {
		CaseListContext _localctx = new CaseListContext(_ctx, getState());
		enterRule(_localctx, 232, RULE_caseList);
		try {
			setState(1420);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,135,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1418);
				simpleCaseExpression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1419);
				searchedCaseExpression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimpleCaseExpressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(HqlParser.CASE, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode END() { return getToken(HqlParser.END, 0); }
		public List<CaseWhenExpressionClauseContext> caseWhenExpressionClause() {
			return getRuleContexts(CaseWhenExpressionClauseContext.class);
		}
		public CaseWhenExpressionClauseContext caseWhenExpressionClause(int i) {
			return getRuleContext(CaseWhenExpressionClauseContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(HqlParser.ELSE, 0); }
		public SimpleCaseExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleCaseExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimpleCaseExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimpleCaseExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimpleCaseExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimpleCaseExpressionContext simpleCaseExpression() throws RecognitionException {
		SimpleCaseExpressionContext _localctx = new SimpleCaseExpressionContext(_ctx, getState());
		enterRule(_localctx, 234, RULE_simpleCaseExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1422);
			match(CASE);
			setState(1423);
			expressionOrPredicate();
			setState(1425); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1424);
				caseWhenExpressionClause();
				}
				}
				setState(1427); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WHEN );
			setState(1431);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(1429);
				match(ELSE);
				setState(1430);
				expressionOrPredicate();
				}
			}

			setState(1433);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchedCaseExpressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(HqlParser.CASE, 0); }
		public TerminalNode END() { return getToken(HqlParser.END, 0); }
		public List<CaseWhenPredicateClauseContext> caseWhenPredicateClause() {
			return getRuleContexts(CaseWhenPredicateClauseContext.class);
		}
		public CaseWhenPredicateClauseContext caseWhenPredicateClause(int i) {
			return getRuleContext(CaseWhenPredicateClauseContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(HqlParser.ELSE, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public SearchedCaseExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_searchedCaseExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSearchedCaseExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSearchedCaseExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSearchedCaseExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchedCaseExpressionContext searchedCaseExpression() throws RecognitionException {
		SearchedCaseExpressionContext _localctx = new SearchedCaseExpressionContext(_ctx, getState());
		enterRule(_localctx, 236, RULE_searchedCaseExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1435);
			match(CASE);
			setState(1437); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1436);
				caseWhenPredicateClause();
				}
				}
				setState(1439); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WHEN );
			setState(1443);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(1441);
				match(ELSE);
				setState(1442);
				expressionOrPredicate();
				}
			}

			setState(1445);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CaseWhenExpressionClauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(HqlParser.WHEN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode THEN() { return getToken(HqlParser.THEN, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public CaseWhenExpressionClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caseWhenExpressionClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseWhenExpressionClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseWhenExpressionClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseWhenExpressionClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseWhenExpressionClauseContext caseWhenExpressionClause() throws RecognitionException {
		CaseWhenExpressionClauseContext _localctx = new CaseWhenExpressionClauseContext(_ctx, getState());
		enterRule(_localctx, 238, RULE_caseWhenExpressionClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1447);
			match(WHEN);
			setState(1448);
			expression(0);
			setState(1449);
			match(THEN);
			setState(1450);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CaseWhenPredicateClauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(HqlParser.WHEN, 0); }
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public TerminalNode THEN() { return getToken(HqlParser.THEN, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public CaseWhenPredicateClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caseWhenPredicateClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCaseWhenPredicateClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCaseWhenPredicateClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCaseWhenPredicateClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseWhenPredicateClauseContext caseWhenPredicateClause() throws RecognitionException {
		CaseWhenPredicateClauseContext _localctx = new CaseWhenPredicateClauseContext(_ctx, getState());
		enterRule(_localctx, 240, RULE_caseWhenPredicateClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1452);
			match(WHEN);
			setState(1453);
			predicate(0);
			setState(1454);
			match(THEN);
			setState(1455);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionContext extends ParserRuleContext {
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
	 
		public FunctionContext() { }
		public void copyFrom(FunctionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionAggregateFunctionInvocationContext extends FunctionContext {
		public CollectionAggregateFunctionContext collectionAggregateFunction() {
			return getRuleContext(CollectionAggregateFunctionContext.class,0);
		}
		public CollectionAggregateFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionAggregateFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionAggregateFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionAggregateFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AggregateFunctionInvocationContext extends FunctionContext {
		public AggregateFunctionContext aggregateFunction() {
			return getRuleContext(AggregateFunctionContext.class,0);
		}
		public AggregateFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAggregateFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAggregateFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAggregateFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class XmlFunctionInvocationContext extends FunctionContext {
		public XmlFunctionContext xmlFunction() {
			return getRuleContext(XmlFunctionContext.class,0);
		}
		public XmlFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionSizeFunctionInvocationContext extends FunctionContext {
		public CollectionSizeFunctionContext collectionSizeFunction() {
			return getRuleContext(CollectionSizeFunctionContext.class,0);
		}
		public CollectionSizeFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionSizeFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionSizeFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionSizeFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JsonFunctionInvocationContext extends FunctionContext {
		public JsonFunctionContext jsonFunction() {
			return getRuleContext(JsonFunctionContext.class,0);
		}
		public JsonFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JpaNonstandardFunctionInvocationContext extends FunctionContext {
		public JpaNonstandardFunctionContext jpaNonstandardFunction() {
			return getRuleContext(JpaNonstandardFunctionContext.class,0);
		}
		public JpaNonstandardFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaNonstandardFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaNonstandardFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaNonstandardFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ColumnFunctionInvocationContext extends FunctionContext {
		public ColumnFunctionContext columnFunction() {
			return getRuleContext(ColumnFunctionContext.class,0);
		}
		public ColumnFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterColumnFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitColumnFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitColumnFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionFunctionMisuseInvocationContext extends FunctionContext {
		public CollectionFunctionMisuseContext collectionFunctionMisuse() {
			return getRuleContext(CollectionFunctionMisuseContext.class,0);
		}
		public CollectionFunctionMisuseInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionFunctionMisuseInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionFunctionMisuseInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionFunctionMisuseInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StandardFunctionInvocationContext extends FunctionContext {
		public StandardFunctionContext standardFunction() {
			return getRuleContext(StandardFunctionContext.class,0);
		}
		public StandardFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStandardFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStandardFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStandardFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionInvocationContext extends FunctionContext {
		public GenericFunctionContext genericFunction() {
			return getRuleContext(GenericFunctionContext.class,0);
		}
		public GenericFunctionInvocationContext(FunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunctionInvocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunctionInvocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunctionInvocation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 242, RULE_function);
		try {
			setState(1467);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,140,_ctx) ) {
			case 1:
				_localctx = new StandardFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1457);
				standardFunction();
				}
				break;
			case 2:
				_localctx = new AggregateFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1458);
				aggregateFunction();
				}
				break;
			case 3:
				_localctx = new CollectionSizeFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1459);
				collectionSizeFunction();
				}
				break;
			case 4:
				_localctx = new CollectionAggregateFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1460);
				collectionAggregateFunction();
				}
				break;
			case 5:
				_localctx = new CollectionFunctionMisuseInvocationContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(1461);
				collectionFunctionMisuse();
				}
				break;
			case 6:
				_localctx = new JpaNonstandardFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(1462);
				jpaNonstandardFunction();
				}
				break;
			case 7:
				_localctx = new ColumnFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(1463);
				columnFunction();
				}
				break;
			case 8:
				_localctx = new JsonFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(1464);
				jsonFunction();
				}
				break;
			case 9:
				_localctx = new XmlFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(1465);
				xmlFunction();
				}
				break;
			case 10:
				_localctx = new GenericFunctionInvocationContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(1466);
				genericFunction();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetReturningFunctionContext extends ParserRuleContext {
		public SimpleSetReturningFunctionContext simpleSetReturningFunction() {
			return getRuleContext(SimpleSetReturningFunctionContext.class,0);
		}
		public JsonTableFunctionContext jsonTableFunction() {
			return getRuleContext(JsonTableFunctionContext.class,0);
		}
		public XmlTableFunctionContext xmlTableFunction() {
			return getRuleContext(XmlTableFunctionContext.class,0);
		}
		public SetReturningFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setReturningFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSetReturningFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSetReturningFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSetReturningFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetReturningFunctionContext setReturningFunction() throws RecognitionException {
		SetReturningFunctionContext _localctx = new SetReturningFunctionContext(_ctx, getState());
		enterRule(_localctx, 244, RULE_setReturningFunction);
		try {
			setState(1472);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,141,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1469);
				simpleSetReturningFunction();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1470);
				jsonTableFunction();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1471);
				xmlTableFunction();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SimpleSetReturningFunctionContext extends ParserRuleContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public GenericFunctionArgumentsContext genericFunctionArguments() {
			return getRuleContext(GenericFunctionArgumentsContext.class,0);
		}
		public SimpleSetReturningFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleSetReturningFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSimpleSetReturningFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSimpleSetReturningFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSimpleSetReturningFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimpleSetReturningFunctionContext simpleSetReturningFunction() throws RecognitionException {
		SimpleSetReturningFunctionContext _localctx = new SimpleSetReturningFunctionContext(_ctx, getState());
		enterRule(_localctx, 246, RULE_simpleSetReturningFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1474);
			identifier();
			setState(1475);
			match(T__1);
			setState(1477);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -31454588L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -1L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 1152921504606846975L) != 0)) {
				{
				setState(1476);
				genericFunctionArguments();
				}
			}

			setState(1479);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StandardFunctionContext extends ParserRuleContext {
		public CastFunctionContext castFunction() {
			return getRuleContext(CastFunctionContext.class,0);
		}
		public TreatedNavigablePathContext treatedNavigablePath() {
			return getRuleContext(TreatedNavigablePathContext.class,0);
		}
		public ExtractFunctionContext extractFunction() {
			return getRuleContext(ExtractFunctionContext.class,0);
		}
		public TruncFunctionContext truncFunction() {
			return getRuleContext(TruncFunctionContext.class,0);
		}
		public FormatFunctionContext formatFunction() {
			return getRuleContext(FormatFunctionContext.class,0);
		}
		public CollateFunctionContext collateFunction() {
			return getRuleContext(CollateFunctionContext.class,0);
		}
		public SubstringFunctionContext substringFunction() {
			return getRuleContext(SubstringFunctionContext.class,0);
		}
		public OverlayFunctionContext overlayFunction() {
			return getRuleContext(OverlayFunctionContext.class,0);
		}
		public TrimFunctionContext trimFunction() {
			return getRuleContext(TrimFunctionContext.class,0);
		}
		public PadFunctionContext padFunction() {
			return getRuleContext(PadFunctionContext.class,0);
		}
		public PositionFunctionContext positionFunction() {
			return getRuleContext(PositionFunctionContext.class,0);
		}
		public CurrentDateFunctionContext currentDateFunction() {
			return getRuleContext(CurrentDateFunctionContext.class,0);
		}
		public CurrentTimeFunctionContext currentTimeFunction() {
			return getRuleContext(CurrentTimeFunctionContext.class,0);
		}
		public CurrentTimestampFunctionContext currentTimestampFunction() {
			return getRuleContext(CurrentTimestampFunctionContext.class,0);
		}
		public InstantFunctionContext instantFunction() {
			return getRuleContext(InstantFunctionContext.class,0);
		}
		public LocalDateFunctionContext localDateFunction() {
			return getRuleContext(LocalDateFunctionContext.class,0);
		}
		public LocalTimeFunctionContext localTimeFunction() {
			return getRuleContext(LocalTimeFunctionContext.class,0);
		}
		public LocalDateTimeFunctionContext localDateTimeFunction() {
			return getRuleContext(LocalDateTimeFunctionContext.class,0);
		}
		public OffsetDateTimeFunctionContext offsetDateTimeFunction() {
			return getRuleContext(OffsetDateTimeFunctionContext.class,0);
		}
		public CubeContext cube() {
			return getRuleContext(CubeContext.class,0);
		}
		public RollupContext rollup() {
			return getRuleContext(RollupContext.class,0);
		}
		public StandardFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_standardFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStandardFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStandardFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStandardFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StandardFunctionContext standardFunction() throws RecognitionException {
		StandardFunctionContext _localctx = new StandardFunctionContext(_ctx, getState());
		enterRule(_localctx, 248, RULE_standardFunction);
		try {
			setState(1502);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,143,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1481);
				castFunction();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1482);
				treatedNavigablePath();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1483);
				extractFunction();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1484);
				truncFunction();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1485);
				formatFunction();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1486);
				collateFunction();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1487);
				substringFunction();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1488);
				overlayFunction();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1489);
				trimFunction();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(1490);
				padFunction();
				}
				break;
			case 11:
				enterOuterAlt(_localctx, 11);
				{
				setState(1491);
				positionFunction();
				}
				break;
			case 12:
				enterOuterAlt(_localctx, 12);
				{
				setState(1492);
				currentDateFunction();
				}
				break;
			case 13:
				enterOuterAlt(_localctx, 13);
				{
				setState(1493);
				currentTimeFunction();
				}
				break;
			case 14:
				enterOuterAlt(_localctx, 14);
				{
				setState(1494);
				currentTimestampFunction();
				}
				break;
			case 15:
				enterOuterAlt(_localctx, 15);
				{
				setState(1495);
				instantFunction();
				}
				break;
			case 16:
				enterOuterAlt(_localctx, 16);
				{
				setState(1496);
				localDateFunction();
				}
				break;
			case 17:
				enterOuterAlt(_localctx, 17);
				{
				setState(1497);
				localTimeFunction();
				}
				break;
			case 18:
				enterOuterAlt(_localctx, 18);
				{
				setState(1498);
				localDateTimeFunction();
				}
				break;
			case 19:
				enterOuterAlt(_localctx, 19);
				{
				setState(1499);
				offsetDateTimeFunction();
				}
				break;
			case 20:
				enterOuterAlt(_localctx, 20);
				{
				setState(1500);
				cube();
				}
				break;
			case 21:
				enterOuterAlt(_localctx, 21);
				{
				setState(1501);
				rollup();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CastFunctionContext extends ParserRuleContext {
		public TerminalNode CAST() { return getToken(HqlParser.CAST, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public CastFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_castFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCastFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCastFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCastFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CastFunctionContext castFunction() throws RecognitionException {
		CastFunctionContext _localctx = new CastFunctionContext(_ctx, getState());
		enterRule(_localctx, 250, RULE_castFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1504);
			match(CAST);
			setState(1505);
			match(T__1);
			setState(1506);
			expression(0);
			setState(1507);
			match(AS);
			setState(1508);
			castTarget();
			setState(1509);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CastTargetContext extends ParserRuleContext {
		public CastTargetTypeContext castTargetType() {
			return getRuleContext(CastTargetTypeContext.class,0);
		}
		public List<TerminalNode> INTEGER_LITERAL() { return getTokens(HqlParser.INTEGER_LITERAL); }
		public TerminalNode INTEGER_LITERAL(int i) {
			return getToken(HqlParser.INTEGER_LITERAL, i);
		}
		public CastTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_castTarget; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCastTarget(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCastTarget(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCastTarget(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CastTargetContext castTarget() throws RecognitionException {
		CastTargetContext _localctx = new CastTargetContext(_ctx, getState());
		enterRule(_localctx, 252, RULE_castTarget);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1511);
			castTargetType();
			setState(1519);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(1512);
				match(T__1);
				setState(1513);
				match(INTEGER_LITERAL);
				setState(1516);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1514);
					match(T__0);
					setState(1515);
					match(INTEGER_LITERAL);
					}
				}

				setState(1518);
				match(T__2);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CastTargetTypeContext extends ParserRuleContext {
		public String fullTargetName;
		public IdentifierContext i;
		public IdentifierContext c;
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public CastTargetTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_castTargetType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCastTargetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCastTargetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCastTargetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CastTargetTypeContext castTargetType() throws RecognitionException {
		CastTargetTypeContext _localctx = new CastTargetTypeContext(_ctx, getState());
		enterRule(_localctx, 254, RULE_castTargetType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(1521);
			((CastTargetTypeContext)_localctx).i = identifier();
			 ((CastTargetTypeContext)_localctx).fullTargetName =  _localctx.i.getText(); 
			}
			setState(1530);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__12) {
				{
				{
				setState(1524);
				match(T__12);
				setState(1525);
				((CastTargetTypeContext)_localctx).c = identifier();
				 _localctx.fullTargetName += ("." + _localctx.c.getText() ); 
				}
				}
				setState(1532);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubstringFunctionContext extends ParserRuleContext {
		public TerminalNode SUBSTRING() { return getToken(HqlParser.SUBSTRING, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SubstringFunctionStartArgumentContext substringFunctionStartArgument() {
			return getRuleContext(SubstringFunctionStartArgumentContext.class,0);
		}
		public SubstringFunctionLengthArgumentContext substringFunctionLengthArgument() {
			return getRuleContext(SubstringFunctionLengthArgumentContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public SubstringFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_substringFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubstringFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubstringFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubstringFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubstringFunctionContext substringFunction() throws RecognitionException {
		SubstringFunctionContext _localctx = new SubstringFunctionContext(_ctx, getState());
		enterRule(_localctx, 256, RULE_substringFunction);
		int _la;
		try {
			setState(1555);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,149,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1533);
				match(SUBSTRING);
				setState(1534);
				match(T__1);
				setState(1535);
				expression(0);
				setState(1536);
				match(T__0);
				setState(1537);
				substringFunctionStartArgument();
				setState(1540);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1538);
					match(T__0);
					setState(1539);
					substringFunctionLengthArgument();
					}
				}

				setState(1542);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1544);
				match(SUBSTRING);
				setState(1545);
				match(T__1);
				setState(1546);
				expression(0);
				setState(1547);
				match(FROM);
				setState(1548);
				substringFunctionStartArgument();
				setState(1551);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FOR) {
					{
					setState(1549);
					match(FOR);
					setState(1550);
					substringFunctionLengthArgument();
					}
				}

				setState(1553);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubstringFunctionStartArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SubstringFunctionStartArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_substringFunctionStartArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubstringFunctionStartArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubstringFunctionStartArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubstringFunctionStartArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubstringFunctionStartArgumentContext substringFunctionStartArgument() throws RecognitionException {
		SubstringFunctionStartArgumentContext _localctx = new SubstringFunctionStartArgumentContext(_ctx, getState());
		enterRule(_localctx, 258, RULE_substringFunctionStartArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1557);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubstringFunctionLengthArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public SubstringFunctionLengthArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_substringFunctionLengthArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterSubstringFunctionLengthArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitSubstringFunctionLengthArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitSubstringFunctionLengthArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubstringFunctionLengthArgumentContext substringFunctionLengthArgument() throws RecognitionException {
		SubstringFunctionLengthArgumentContext _localctx = new SubstringFunctionLengthArgumentContext(_ctx, getState());
		enterRule(_localctx, 260, RULE_substringFunctionLengthArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1559);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrimFunctionContext extends ParserRuleContext {
		public TerminalNode TRIM() { return getToken(HqlParser.TRIM, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TrimSpecificationContext trimSpecification() {
			return getRuleContext(TrimSpecificationContext.class,0);
		}
		public TrimCharacterContext trimCharacter() {
			return getRuleContext(TrimCharacterContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TrimFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trimFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTrimFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTrimFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTrimFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TrimFunctionContext trimFunction() throws RecognitionException {
		TrimFunctionContext _localctx = new TrimFunctionContext(_ctx, getState());
		enterRule(_localctx, 262, RULE_trimFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1561);
			match(TRIM);
			setState(1562);
			match(T__1);
			setState(1564);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,150,_ctx) ) {
			case 1:
				{
				setState(1563);
				trimSpecification();
				}
				break;
			}
			setState(1567);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,151,_ctx) ) {
			case 1:
				{
				setState(1566);
				trimCharacter();
				}
				break;
			}
			setState(1570);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,152,_ctx) ) {
			case 1:
				{
				setState(1569);
				match(FROM);
				}
				break;
			}
			setState(1572);
			expression(0);
			setState(1573);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrimSpecificationContext extends ParserRuleContext {
		public TerminalNode LEADING() { return getToken(HqlParser.LEADING, 0); }
		public TerminalNode TRAILING() { return getToken(HqlParser.TRAILING, 0); }
		public TerminalNode BOTH() { return getToken(HqlParser.BOTH, 0); }
		public TrimSpecificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trimSpecification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTrimSpecification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTrimSpecification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTrimSpecification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TrimSpecificationContext trimSpecification() throws RecognitionException {
		TrimSpecificationContext _localctx = new TrimSpecificationContext(_ctx, getState());
		enterRule(_localctx, 264, RULE_trimSpecification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1575);
			_la = _input.LA(1);
			if ( !(_la==BOTH || _la==LEADING || _la==TRAILING) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrimCharacterContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public TrimCharacterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trimCharacter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTrimCharacter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTrimCharacter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTrimCharacter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TrimCharacterContext trimCharacter() throws RecognitionException {
		TrimCharacterContext _localctx = new TrimCharacterContext(_ctx, getState());
		enterRule(_localctx, 266, RULE_trimCharacter);
		try {
			setState(1579);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING_LITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1577);
				match(STRING_LITERAL);
				}
				break;
			case T__8:
			case T__20:
				enterOuterAlt(_localctx, 2);
				{
				setState(1578);
				parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadFunctionContext extends ParserRuleContext {
		public TerminalNode PAD() { return getToken(HqlParser.PAD, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public PadLengthContext padLength() {
			return getRuleContext(PadLengthContext.class,0);
		}
		public PadSpecificationContext padSpecification() {
			return getRuleContext(PadSpecificationContext.class,0);
		}
		public PadCharacterContext padCharacter() {
			return getRuleContext(PadCharacterContext.class,0);
		}
		public PadFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadFunctionContext padFunction() throws RecognitionException {
		PadFunctionContext _localctx = new PadFunctionContext(_ctx, getState());
		enterRule(_localctx, 268, RULE_padFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1581);
			match(PAD);
			setState(1582);
			match(T__1);
			setState(1583);
			expression(0);
			setState(1584);
			match(WITH);
			setState(1585);
			padLength();
			setState(1586);
			padSpecification();
			setState(1588);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==STRING_LITERAL) {
				{
				setState(1587);
				padCharacter();
				}
			}

			setState(1590);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadSpecificationContext extends ParserRuleContext {
		public TerminalNode LEADING() { return getToken(HqlParser.LEADING, 0); }
		public TerminalNode TRAILING() { return getToken(HqlParser.TRAILING, 0); }
		public PadSpecificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padSpecification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadSpecification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadSpecification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadSpecification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadSpecificationContext padSpecification() throws RecognitionException {
		PadSpecificationContext _localctx = new PadSpecificationContext(_ctx, getState());
		enterRule(_localctx, 270, RULE_padSpecification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1592);
			_la = _input.LA(1);
			if ( !(_la==LEADING || _la==TRAILING) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadCharacterContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public PadCharacterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padCharacter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadCharacter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadCharacter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadCharacter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadCharacterContext padCharacter() throws RecognitionException {
		PadCharacterContext _localctx = new PadCharacterContext(_ctx, getState());
		enterRule(_localctx, 272, RULE_padCharacter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1594);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PadLengthContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PadLengthContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_padLength; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPadLength(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPadLength(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPadLength(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PadLengthContext padLength() throws RecognitionException {
		PadLengthContext _localctx = new PadLengthContext(_ctx, getState());
		enterRule(_localctx, 274, RULE_padLength);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1596);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionFunctionContext extends ParserRuleContext {
		public TerminalNode POSITION() { return getToken(HqlParser.POSITION, 0); }
		public PositionFunctionPatternArgumentContext positionFunctionPatternArgument() {
			return getRuleContext(PositionFunctionPatternArgumentContext.class,0);
		}
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public PositionFunctionStringArgumentContext positionFunctionStringArgument() {
			return getRuleContext(PositionFunctionStringArgumentContext.class,0);
		}
		public PositionFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPositionFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPositionFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPositionFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionFunctionContext positionFunction() throws RecognitionException {
		PositionFunctionContext _localctx = new PositionFunctionContext(_ctx, getState());
		enterRule(_localctx, 276, RULE_positionFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1598);
			match(POSITION);
			setState(1599);
			match(T__1);
			setState(1600);
			positionFunctionPatternArgument();
			setState(1601);
			match(IN);
			setState(1602);
			positionFunctionStringArgument();
			setState(1603);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionFunctionPatternArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositionFunctionPatternArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionFunctionPatternArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPositionFunctionPatternArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPositionFunctionPatternArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPositionFunctionPatternArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionFunctionPatternArgumentContext positionFunctionPatternArgument() throws RecognitionException {
		PositionFunctionPatternArgumentContext _localctx = new PositionFunctionPatternArgumentContext(_ctx, getState());
		enterRule(_localctx, 278, RULE_positionFunctionPatternArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1605);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionFunctionStringArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositionFunctionStringArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionFunctionStringArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPositionFunctionStringArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPositionFunctionStringArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPositionFunctionStringArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionFunctionStringArgumentContext positionFunctionStringArgument() throws RecognitionException {
		PositionFunctionStringArgumentContext _localctx = new PositionFunctionStringArgumentContext(_ctx, getState());
		enterRule(_localctx, 280, RULE_positionFunctionStringArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1607);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionContext extends ParserRuleContext {
		public TerminalNode OVERLAY() { return getToken(HqlParser.OVERLAY, 0); }
		public OverlayFunctionStringArgumentContext overlayFunctionStringArgument() {
			return getRuleContext(OverlayFunctionStringArgumentContext.class,0);
		}
		public TerminalNode PLACING() { return getToken(HqlParser.PLACING, 0); }
		public OverlayFunctionReplacementArgumentContext overlayFunctionReplacementArgument() {
			return getRuleContext(OverlayFunctionReplacementArgumentContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public OverlayFunctionStartArgumentContext overlayFunctionStartArgument() {
			return getRuleContext(OverlayFunctionStartArgumentContext.class,0);
		}
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public OverlayFunctionLengthArgumentContext overlayFunctionLengthArgument() {
			return getRuleContext(OverlayFunctionLengthArgumentContext.class,0);
		}
		public OverlayFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionContext overlayFunction() throws RecognitionException {
		OverlayFunctionContext _localctx = new OverlayFunctionContext(_ctx, getState());
		enterRule(_localctx, 282, RULE_overlayFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1609);
			match(OVERLAY);
			setState(1610);
			match(T__1);
			setState(1611);
			overlayFunctionStringArgument();
			setState(1612);
			match(PLACING);
			setState(1613);
			overlayFunctionReplacementArgument();
			setState(1614);
			match(FROM);
			setState(1615);
			overlayFunctionStartArgument();
			setState(1618);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FOR) {
				{
				setState(1616);
				match(FOR);
				setState(1617);
				overlayFunctionLengthArgument();
				}
			}

			setState(1620);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionStringArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionStringArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionStringArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionStringArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionStringArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionStringArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionStringArgumentContext overlayFunctionStringArgument() throws RecognitionException {
		OverlayFunctionStringArgumentContext _localctx = new OverlayFunctionStringArgumentContext(_ctx, getState());
		enterRule(_localctx, 284, RULE_overlayFunctionStringArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1622);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionReplacementArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionReplacementArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionReplacementArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionReplacementArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionReplacementArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionReplacementArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionReplacementArgumentContext overlayFunctionReplacementArgument() throws RecognitionException {
		OverlayFunctionReplacementArgumentContext _localctx = new OverlayFunctionReplacementArgumentContext(_ctx, getState());
		enterRule(_localctx, 286, RULE_overlayFunctionReplacementArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1624);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionStartArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionStartArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionStartArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionStartArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionStartArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionStartArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionStartArgumentContext overlayFunctionStartArgument() throws RecognitionException {
		OverlayFunctionStartArgumentContext _localctx = new OverlayFunctionStartArgumentContext(_ctx, getState());
		enterRule(_localctx, 288, RULE_overlayFunctionStartArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1626);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverlayFunctionLengthArgumentContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OverlayFunctionLengthArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overlayFunctionLengthArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverlayFunctionLengthArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverlayFunctionLengthArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverlayFunctionLengthArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverlayFunctionLengthArgumentContext overlayFunctionLengthArgument() throws RecognitionException {
		OverlayFunctionLengthArgumentContext _localctx = new OverlayFunctionLengthArgumentContext(_ctx, getState());
		enterRule(_localctx, 290, RULE_overlayFunctionLengthArgument);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1628);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CurrentDateFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_DATE() { return getToken(HqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public CurrentDateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_currentDateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCurrentDateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCurrentDateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCurrentDateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CurrentDateFunctionContext currentDateFunction() throws RecognitionException {
		CurrentDateFunctionContext _localctx = new CurrentDateFunctionContext(_ctx, getState());
		enterRule(_localctx, 292, RULE_currentDateFunction);
		try {
			setState(1637);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_DATE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1630);
				match(CURRENT_DATE);
				setState(1633);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,156,_ctx) ) {
				case 1:
					{
					setState(1631);
					match(T__1);
					setState(1632);
					match(T__2);
					}
					break;
				}
				}
				break;
			case CURRENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1635);
				match(CURRENT);
				setState(1636);
				match(DATE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CurrentTimeFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_TIME() { return getToken(HqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public CurrentTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_currentTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCurrentTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCurrentTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCurrentTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CurrentTimeFunctionContext currentTimeFunction() throws RecognitionException {
		CurrentTimeFunctionContext _localctx = new CurrentTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 294, RULE_currentTimeFunction);
		try {
			setState(1646);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_TIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1639);
				match(CURRENT_TIME);
				setState(1642);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,158,_ctx) ) {
				case 1:
					{
					setState(1640);
					match(T__1);
					setState(1641);
					match(T__2);
					}
					break;
				}
				}
				break;
			case CURRENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1644);
				match(CURRENT);
				setState(1645);
				match(TIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CurrentTimestampFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(HqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode TIMESTAMP() { return getToken(HqlParser.TIMESTAMP, 0); }
		public CurrentTimestampFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_currentTimestampFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCurrentTimestampFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCurrentTimestampFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCurrentTimestampFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CurrentTimestampFunctionContext currentTimestampFunction() throws RecognitionException {
		CurrentTimestampFunctionContext _localctx = new CurrentTimestampFunctionContext(_ctx, getState());
		enterRule(_localctx, 296, RULE_currentTimestampFunction);
		try {
			setState(1655);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_TIMESTAMP:
				enterOuterAlt(_localctx, 1);
				{
				setState(1648);
				match(CURRENT_TIMESTAMP);
				setState(1651);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,160,_ctx) ) {
				case 1:
					{
					setState(1649);
					match(T__1);
					setState(1650);
					match(T__2);
					}
					break;
				}
				}
				break;
			case CURRENT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1653);
				match(CURRENT);
				setState(1654);
				match(TIMESTAMP);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantFunctionContext extends ParserRuleContext {
		public TerminalNode CURRENT_INSTANT() { return getToken(HqlParser.CURRENT_INSTANT, 0); }
		public TerminalNode INSTANT() { return getToken(HqlParser.INSTANT, 0); }
		public InstantFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantFunctionContext instantFunction() throws RecognitionException {
		InstantFunctionContext _localctx = new InstantFunctionContext(_ctx, getState());
		enterRule(_localctx, 298, RULE_instantFunction);
		try {
			setState(1663);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURRENT_INSTANT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1657);
				match(CURRENT_INSTANT);
				setState(1660);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,162,_ctx) ) {
				case 1:
					{
					setState(1658);
					match(T__1);
					setState(1659);
					match(T__2);
					}
					break;
				}
				}
				break;
			case INSTANT:
				enterOuterAlt(_localctx, 2);
				{
				setState(1662);
				match(INSTANT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateTimeFunctionContext extends ParserRuleContext {
		public TerminalNode LOCAL_DATETIME() { return getToken(HqlParser.LOCAL_DATETIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public LocalDateTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateTimeFunctionContext localDateTimeFunction() throws RecognitionException {
		LocalDateTimeFunctionContext _localctx = new LocalDateTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 300, RULE_localDateTimeFunction);
		try {
			setState(1672);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOCAL_DATETIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1665);
				match(LOCAL_DATETIME);
				setState(1668);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,164,_ctx) ) {
				case 1:
					{
					setState(1666);
					match(T__1);
					setState(1667);
					match(T__2);
					}
					break;
				}
				}
				break;
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1670);
				match(LOCAL);
				setState(1671);
				match(DATETIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OffsetDateTimeFunctionContext extends ParserRuleContext {
		public TerminalNode OFFSET_DATETIME() { return getToken(HqlParser.OFFSET_DATETIME, 0); }
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public OffsetDateTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_offsetDateTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOffsetDateTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOffsetDateTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOffsetDateTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OffsetDateTimeFunctionContext offsetDateTimeFunction() throws RecognitionException {
		OffsetDateTimeFunctionContext _localctx = new OffsetDateTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 302, RULE_offsetDateTimeFunction);
		try {
			setState(1681);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case OFFSET_DATETIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1674);
				match(OFFSET_DATETIME);
				setState(1677);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,166,_ctx) ) {
				case 1:
					{
					setState(1675);
					match(T__1);
					setState(1676);
					match(T__2);
					}
					break;
				}
				}
				break;
			case OFFSET:
				enterOuterAlt(_localctx, 2);
				{
				setState(1679);
				match(OFFSET);
				setState(1680);
				match(DATETIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalDateFunctionContext extends ParserRuleContext {
		public TerminalNode LOCAL_DATE() { return getToken(HqlParser.LOCAL_DATE, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public LocalDateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localDateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalDateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalDateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalDateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalDateFunctionContext localDateFunction() throws RecognitionException {
		LocalDateFunctionContext _localctx = new LocalDateFunctionContext(_ctx, getState());
		enterRule(_localctx, 304, RULE_localDateFunction);
		try {
			setState(1690);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOCAL_DATE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1683);
				match(LOCAL_DATE);
				setState(1686);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,168,_ctx) ) {
				case 1:
					{
					setState(1684);
					match(T__1);
					setState(1685);
					match(T__2);
					}
					break;
				}
				}
				break;
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1688);
				match(LOCAL);
				setState(1689);
				match(DATE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LocalTimeFunctionContext extends ParserRuleContext {
		public TerminalNode LOCAL_TIME() { return getToken(HqlParser.LOCAL_TIME, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public LocalTimeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_localTimeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLocalTimeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLocalTimeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLocalTimeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LocalTimeFunctionContext localTimeFunction() throws RecognitionException {
		LocalTimeFunctionContext _localctx = new LocalTimeFunctionContext(_ctx, getState());
		enterRule(_localctx, 306, RULE_localTimeFunction);
		try {
			setState(1699);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LOCAL_TIME:
				enterOuterAlt(_localctx, 1);
				{
				setState(1692);
				match(LOCAL_TIME);
				setState(1695);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,170,_ctx) ) {
				case 1:
					{
					setState(1693);
					match(T__1);
					setState(1694);
					match(T__2);
					}
					break;
				}
				}
				break;
			case LOCAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1697);
				match(LOCAL);
				setState(1698);
				match(TIME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormatFunctionContext extends ParserRuleContext {
		public TerminalNode FORMAT() { return getToken(HqlParser.FORMAT, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public FormatContext format() {
			return getRuleContext(FormatContext.class,0);
		}
		public FormatFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formatFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFormatFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFormatFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFormatFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormatFunctionContext formatFunction() throws RecognitionException {
		FormatFunctionContext _localctx = new FormatFunctionContext(_ctx, getState());
		enterRule(_localctx, 308, RULE_formatFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1701);
			match(FORMAT);
			setState(1702);
			match(T__1);
			setState(1703);
			expression(0);
			setState(1704);
			match(AS);
			setState(1705);
			format();
			setState(1706);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollationContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public CollationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollationContext collation() throws RecognitionException {
		CollationContext _localctx = new CollationContext(_ctx, getState());
		enterRule(_localctx, 310, RULE_collation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1708);
			simplePath();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollateFunctionContext extends ParserRuleContext {
		public TerminalNode COLLATE() { return getToken(HqlParser.COLLATE, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CollationContext collation() {
			return getRuleContext(CollationContext.class,0);
		}
		public CollateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollateFunctionContext collateFunction() throws RecognitionException {
		CollateFunctionContext _localctx = new CollateFunctionContext(_ctx, getState());
		enterRule(_localctx, 312, RULE_collateFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1710);
			match(COLLATE);
			setState(1711);
			match(T__1);
			setState(1712);
			expression(0);
			setState(1713);
			match(AS);
			setState(1714);
			collation();
			setState(1715);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CubeContext extends ParserRuleContext {
		public TerminalNode CUBE() { return getToken(HqlParser.CUBE, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public CubeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cube; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCube(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCube(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCube(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CubeContext cube() throws RecognitionException {
		CubeContext _localctx = new CubeContext(_ctx, getState());
		enterRule(_localctx, 314, RULE_cube);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1717);
			match(CUBE);
			setState(1718);
			match(T__1);
			setState(1719);
			expressionOrPredicate();
			setState(1724);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1720);
				match(T__0);
				setState(1721);
				expressionOrPredicate();
				}
				}
				setState(1726);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1727);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RollupContext extends ParserRuleContext {
		public TerminalNode ROLLUP() { return getToken(HqlParser.ROLLUP, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public RollupContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rollup; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRollup(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRollup(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRollup(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RollupContext rollup() throws RecognitionException {
		RollupContext _localctx = new RollupContext(_ctx, getState());
		enterRule(_localctx, 316, RULE_rollup);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1729);
			match(ROLLUP);
			setState(1730);
			match(T__1);
			setState(1731);
			expressionOrPredicate();
			setState(1736);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1732);
				match(T__0);
				setState(1733);
				expressionOrPredicate();
				}
				}
				setState(1738);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1739);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormatContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public FormatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_format; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFormat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFormat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFormat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormatContext format() throws RecognitionException {
		FormatContext _localctx = new FormatContext(_ctx, getState());
		enterRule(_localctx, 318, RULE_format);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1741);
			match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExtractFunctionContext extends ParserRuleContext {
		public TerminalNode EXTRACT() { return getToken(HqlParser.EXTRACT, 0); }
		public ExtractFieldContext extractField() {
			return getRuleContext(ExtractFieldContext.class,0);
		}
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public ExtractFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extractFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExtractFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExtractFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExtractFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExtractFunctionContext extractFunction() throws RecognitionException {
		ExtractFunctionContext _localctx = new ExtractFunctionContext(_ctx, getState());
		enterRule(_localctx, 320, RULE_extractFunction);
		try {
			setState(1755);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXTRACT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1743);
				match(EXTRACT);
				setState(1744);
				match(T__1);
				setState(1745);
				extractField();
				setState(1746);
				match(FROM);
				setState(1747);
				expression(0);
				setState(1748);
				match(T__2);
				}
				break;
			case DAY:
			case EPOCH:
			case HOUR:
			case MINUTE:
			case MONTH:
			case NANOSECOND:
			case QUARTER:
			case SECOND:
			case WEEK:
			case YEAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(1750);
				datetimeField();
				setState(1751);
				match(T__1);
				setState(1752);
				expression(0);
				setState(1753);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TruncFunctionContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode TRUNC() { return getToken(HqlParser.TRUNC, 0); }
		public TerminalNode TRUNCATE() { return getToken(HqlParser.TRUNCATE, 0); }
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public TruncFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_truncFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterTruncFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitTruncFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitTruncFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TruncFunctionContext truncFunction() throws RecognitionException {
		TruncFunctionContext _localctx = new TruncFunctionContext(_ctx, getState());
		enterRule(_localctx, 322, RULE_truncFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1757);
			_la = _input.LA(1);
			if ( !(_la==TRUNC || _la==TRUNCATE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1758);
			match(T__1);
			setState(1759);
			expression(0);
			setState(1765);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(1760);
				match(T__0);
				setState(1763);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,175,_ctx) ) {
				case 1:
					{
					setState(1761);
					datetimeField();
					}
					break;
				case 2:
					{
					setState(1762);
					expression(0);
					}
					break;
				}
				}
			}

			setState(1767);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaNonstandardFunctionContext extends ParserRuleContext {
		public TerminalNode FUNCTION() { return getToken(HqlParser.FUNCTION, 0); }
		public JpaNonstandardFunctionNameContext jpaNonstandardFunctionName() {
			return getRuleContext(JpaNonstandardFunctionNameContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public GenericFunctionArgumentsContext genericFunctionArguments() {
			return getRuleContext(GenericFunctionArgumentsContext.class,0);
		}
		public JpaNonstandardFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaNonstandardFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaNonstandardFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaNonstandardFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaNonstandardFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaNonstandardFunctionContext jpaNonstandardFunction() throws RecognitionException {
		JpaNonstandardFunctionContext _localctx = new JpaNonstandardFunctionContext(_ctx, getState());
		enterRule(_localctx, 324, RULE_jpaNonstandardFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1769);
			match(FUNCTION);
			setState(1770);
			match(T__1);
			setState(1771);
			jpaNonstandardFunctionName();
			setState(1774);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1772);
				match(AS);
				setState(1773);
				castTarget();
				}
			}

			setState(1778);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(1776);
				match(T__0);
				setState(1777);
				genericFunctionArguments();
				}
			}

			setState(1780);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JpaNonstandardFunctionNameContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public JpaNonstandardFunctionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jpaNonstandardFunctionName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJpaNonstandardFunctionName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJpaNonstandardFunctionName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJpaNonstandardFunctionName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JpaNonstandardFunctionNameContext jpaNonstandardFunctionName() throws RecognitionException {
		JpaNonstandardFunctionNameContext _localctx = new JpaNonstandardFunctionNameContext(_ctx, getState());
		enterRule(_localctx, 326, RULE_jpaNonstandardFunctionName);
		try {
			setState(1784);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRING_LITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1782);
				match(STRING_LITERAL);
				}
				break;
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ABSENT:
			case ALL:
			case AND:
			case ANY:
			case ARRAY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case COLUMNS:
			case CONDITIONAL:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FULL:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INNER:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case JSON:
			case JSON_ARRAY:
			case JSON_ARRAYAGG:
			case JSON_EXISTS:
			case JSON_OBJECT:
			case JSON_OBJECTAGG:
			case JSON_QUERY:
			case JSON_TABLE:
			case JSON_VALUE:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LEFT:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NAME:
			case NANOSECOND:
			case NEW:
			case NESTED:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case ORDINALITY:
			case OTHERS:
			case OUTER:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PATH:
			case PARTITION:
			case PASSING:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RETURNING:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNCONDITIONAL:
			case UNION:
			case UNIQUE:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case WRAPPER:
			case XML:
			case XMLAGG:
			case XMLATTRIBUTES:
			case XMLELEMENT:
			case XMLEXISTS:
			case XMLFOREST:
			case XMLPI:
			case XMLQUERY:
			case XMLTABLE:
			case YEAR:
			case ZONED:
			case IDENTIFIER:
			case QUOTED_IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(1783);
				identifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColumnFunctionContext extends ParserRuleContext {
		public TerminalNode COLUMN() { return getToken(HqlParser.COLUMN, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public JpaNonstandardFunctionNameContext jpaNonstandardFunctionName() {
			return getRuleContext(JpaNonstandardFunctionNameContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public ColumnFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_columnFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterColumnFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitColumnFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitColumnFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ColumnFunctionContext columnFunction() throws RecognitionException {
		ColumnFunctionContext _localctx = new ColumnFunctionContext(_ctx, getState());
		enterRule(_localctx, 328, RULE_columnFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1786);
			match(COLUMN);
			setState(1787);
			match(T__1);
			setState(1788);
			path();
			setState(1789);
			match(T__12);
			setState(1790);
			jpaNonstandardFunctionName();
			setState(1793);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1791);
				match(AS);
				setState(1792);
				castTarget();
				}
			}

			setState(1795);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionContext extends ParserRuleContext {
		public GenericFunctionNameContext genericFunctionName() {
			return getRuleContext(GenericFunctionNameContext.class,0);
		}
		public GenericFunctionArgumentsContext genericFunctionArguments() {
			return getRuleContext(GenericFunctionArgumentsContext.class,0);
		}
		public TerminalNode ASTERISK() { return getToken(HqlParser.ASTERISK, 0); }
		public PathContinuationContext pathContinuation() {
			return getRuleContext(PathContinuationContext.class,0);
		}
		public NthSideClauseContext nthSideClause() {
			return getRuleContext(NthSideClauseContext.class,0);
		}
		public NullsClauseContext nullsClause() {
			return getRuleContext(NullsClauseContext.class,0);
		}
		public WithinGroupClauseContext withinGroupClause() {
			return getRuleContext(WithinGroupClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public GenericFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericFunctionContext genericFunction() throws RecognitionException {
		GenericFunctionContext _localctx = new GenericFunctionContext(_ctx, getState());
		enterRule(_localctx, 330, RULE_genericFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1797);
			genericFunctionName();
			setState(1798);
			match(T__1);
			setState(1801);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__1:
			case T__6:
			case T__8:
			case T__10:
			case T__20:
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ABSENT:
			case ALL:
			case AND:
			case ANY:
			case ARRAY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case COLUMNS:
			case CONDITIONAL:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FULL:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INNER:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case JSON:
			case JSON_ARRAY:
			case JSON_ARRAYAGG:
			case JSON_EXISTS:
			case JSON_OBJECT:
			case JSON_OBJECTAGG:
			case JSON_QUERY:
			case JSON_TABLE:
			case JSON_VALUE:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LEFT:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NAME:
			case NANOSECOND:
			case NEW:
			case NESTED:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case ORDINALITY:
			case OTHERS:
			case OUTER:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PATH:
			case PARTITION:
			case PASSING:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RETURNING:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNCONDITIONAL:
			case UNION:
			case UNIQUE:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case WRAPPER:
			case XML:
			case XMLAGG:
			case XMLATTRIBUTES:
			case XMLELEMENT:
			case XMLEXISTS:
			case XMLFOREST:
			case XMLPI:
			case XMLQUERY:
			case XMLTABLE:
			case YEAR:
			case ZONED:
			case NULL:
			case TRUE:
			case FALSE:
			case STRING_LITERAL:
			case JAVA_STRING_LITERAL:
			case INTEGER_LITERAL:
			case LONG_LITERAL:
			case FLOAT_LITERAL:
			case DOUBLE_LITERAL:
			case BIG_INTEGER_LITERAL:
			case BIG_DECIMAL_LITERAL:
			case HEX_LITERAL:
			case BINARY_LITERAL:
			case TIMESTAMP_ESCAPE_START:
			case DATE_ESCAPE_START:
			case TIME_ESCAPE_START:
			case PLUS:
			case MINUS:
			case IDENTIFIER:
			case QUOTED_IDENTIFIER:
				{
				setState(1799);
				genericFunctionArguments();
				}
				break;
			case ASTERISK:
				{
				setState(1800);
				match(ASTERISK);
				}
				break;
			case T__2:
				break;
			default:
				break;
			}
			setState(1803);
			match(T__2);
			setState(1805);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,182,_ctx) ) {
			case 1:
				{
				setState(1804);
				pathContinuation();
				}
				break;
			}
			setState(1808);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,183,_ctx) ) {
			case 1:
				{
				setState(1807);
				nthSideClause();
				}
				break;
			}
			setState(1811);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,184,_ctx) ) {
			case 1:
				{
				setState(1810);
				nullsClause();
				}
				break;
			}
			setState(1814);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,185,_ctx) ) {
			case 1:
				{
				setState(1813);
				withinGroupClause();
				}
				break;
			}
			setState(1817);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,186,_ctx) ) {
			case 1:
				{
				setState(1816);
				filterClause();
				}
				break;
			}
			setState(1820);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,187,_ctx) ) {
			case 1:
				{
				setState(1819);
				overClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionNameContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public GenericFunctionNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericFunctionName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunctionName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunctionName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunctionName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericFunctionNameContext genericFunctionName() throws RecognitionException {
		GenericFunctionNameContext _localctx = new GenericFunctionNameContext(_ctx, getState());
		enterRule(_localctx, 332, RULE_genericFunctionName);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1822);
			simplePath();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GenericFunctionArgumentsContext extends ParserRuleContext {
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public DatetimeFieldContext datetimeField() {
			return getRuleContext(DatetimeFieldContext.class,0);
		}
		public GenericFunctionArgumentsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_genericFunctionArguments; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGenericFunctionArguments(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGenericFunctionArguments(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGenericFunctionArguments(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GenericFunctionArgumentsContext genericFunctionArguments() throws RecognitionException {
		GenericFunctionArgumentsContext _localctx = new GenericFunctionArgumentsContext(_ctx, getState());
		enterRule(_localctx, 334, RULE_genericFunctionArguments);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1828);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,188,_ctx) ) {
			case 1:
				{
				setState(1824);
				match(DISTINCT);
				}
				break;
			case 2:
				{
				setState(1825);
				datetimeField();
				setState(1826);
				match(T__0);
				}
				break;
			}
			setState(1830);
			expressionOrPredicate();
			setState(1835);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1831);
				match(T__0);
				setState(1832);
				expressionOrPredicate();
				}
				}
				setState(1837);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionSizeFunctionContext extends ParserRuleContext {
		public TerminalNode SIZE() { return getToken(HqlParser.SIZE, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public CollectionSizeFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionSizeFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionSizeFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionSizeFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionSizeFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionSizeFunctionContext collectionSizeFunction() throws RecognitionException {
		CollectionSizeFunctionContext _localctx = new CollectionSizeFunctionContext(_ctx, getState());
		enterRule(_localctx, 336, RULE_collectionSizeFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1838);
			match(SIZE);
			setState(1839);
			match(T__1);
			setState(1840);
			path();
			setState(1841);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionAggregateFunctionContext extends ParserRuleContext {
		public CollectionAggregateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionAggregateFunction; }
	 
		public CollectionAggregateFunctionContext() { }
		public void copyFrom(CollectionAggregateFunctionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IndexAggregateFunctionContext extends CollectionAggregateFunctionContext {
		public IndicesKeysQuantifierContext indicesKeysQuantifier() {
			return getRuleContext(IndicesKeysQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode MAX() { return getToken(HqlParser.MAX, 0); }
		public TerminalNode MIN() { return getToken(HqlParser.MIN, 0); }
		public TerminalNode SUM() { return getToken(HqlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(HqlParser.AVG, 0); }
		public TerminalNode MAXINDEX() { return getToken(HqlParser.MAXINDEX, 0); }
		public TerminalNode MININDEX() { return getToken(HqlParser.MININDEX, 0); }
		public IndexAggregateFunctionContext(CollectionAggregateFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndexAggregateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndexAggregateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndexAggregateFunction(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ElementAggregateFunctionContext extends CollectionAggregateFunctionContext {
		public ElementsValuesQuantifierContext elementsValuesQuantifier() {
			return getRuleContext(ElementsValuesQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode MAX() { return getToken(HqlParser.MAX, 0); }
		public TerminalNode MIN() { return getToken(HqlParser.MIN, 0); }
		public TerminalNode SUM() { return getToken(HqlParser.SUM, 0); }
		public TerminalNode AVG() { return getToken(HqlParser.AVG, 0); }
		public TerminalNode MAXELEMENT() { return getToken(HqlParser.MAXELEMENT, 0); }
		public TerminalNode MINELEMENT() { return getToken(HqlParser.MINELEMENT, 0); }
		public ElementAggregateFunctionContext(CollectionAggregateFunctionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterElementAggregateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitElementAggregateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitElementAggregateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionAggregateFunctionContext collectionAggregateFunction() throws RecognitionException {
		CollectionAggregateFunctionContext _localctx = new CollectionAggregateFunctionContext(_ctx, getState());
		enterRule(_localctx, 338, RULE_collectionAggregateFunction);
		int _la;
		try {
			setState(1869);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,190,_ctx) ) {
			case 1:
				_localctx = new ElementAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(1843);
				_la = _input.LA(1);
				if ( !(_la==AVG || ((((_la - 135)) & ~0x3f) == 0 && ((1L << (_la - 135)) & 144115188075855937L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1844);
				match(T__1);
				setState(1845);
				elementsValuesQuantifier();
				setState(1846);
				match(T__1);
				setState(1847);
				path();
				setState(1848);
				match(T__2);
				setState(1849);
				match(T__2);
				}
				break;
			case 2:
				_localctx = new IndexAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(1851);
				_la = _input.LA(1);
				if ( !(_la==AVG || ((((_la - 135)) & ~0x3f) == 0 && ((1L << (_la - 135)) & 144115188075855937L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1852);
				match(T__1);
				setState(1853);
				indicesKeysQuantifier();
				setState(1854);
				match(T__1);
				setState(1855);
				path();
				setState(1856);
				match(T__2);
				setState(1857);
				match(T__2);
				}
				break;
			case 3:
				_localctx = new ElementAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1859);
				_la = _input.LA(1);
				if ( !(_la==MAXELEMENT || _la==MINELEMENT) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1860);
				match(T__1);
				setState(1861);
				path();
				setState(1862);
				match(T__2);
				}
				break;
			case 4:
				_localctx = new IndexAggregateFunctionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1864);
				_la = _input.LA(1);
				if ( !(_la==MAXINDEX || _la==MININDEX) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1865);
				match(T__1);
				setState(1866);
				path();
				setState(1867);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionFunctionMisuseContext extends ParserRuleContext {
		public ElementsValuesQuantifierContext elementsValuesQuantifier() {
			return getRuleContext(ElementsValuesQuantifierContext.class,0);
		}
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public IndicesKeysQuantifierContext indicesKeysQuantifier() {
			return getRuleContext(IndicesKeysQuantifierContext.class,0);
		}
		public CollectionFunctionMisuseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionFunctionMisuse; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionFunctionMisuse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionFunctionMisuse(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionFunctionMisuse(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionFunctionMisuseContext collectionFunctionMisuse() throws RecognitionException {
		CollectionFunctionMisuseContext _localctx = new CollectionFunctionMisuseContext(_ctx, getState());
		enterRule(_localctx, 340, RULE_collectionFunctionMisuse);
		try {
			setState(1881);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ELEMENTS:
			case VALUES:
				enterOuterAlt(_localctx, 1);
				{
				setState(1871);
				elementsValuesQuantifier();
				setState(1872);
				match(T__1);
				setState(1873);
				path();
				setState(1874);
				match(T__2);
				}
				break;
			case INDICES:
			case KEYS:
				enterOuterAlt(_localctx, 2);
				{
				setState(1876);
				indicesKeysQuantifier();
				setState(1877);
				match(T__1);
				setState(1878);
				path();
				setState(1879);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AggregateFunctionContext extends ParserRuleContext {
		public EveryFunctionContext everyFunction() {
			return getRuleContext(EveryFunctionContext.class,0);
		}
		public AnyFunctionContext anyFunction() {
			return getRuleContext(AnyFunctionContext.class,0);
		}
		public ListaggFunctionContext listaggFunction() {
			return getRuleContext(ListaggFunctionContext.class,0);
		}
		public AggregateFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggregateFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAggregateFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAggregateFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAggregateFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AggregateFunctionContext aggregateFunction() throws RecognitionException {
		AggregateFunctionContext _localctx = new AggregateFunctionContext(_ctx, getState());
		enterRule(_localctx, 342, RULE_aggregateFunction);
		try {
			setState(1886);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ALL:
			case EVERY:
				enterOuterAlt(_localctx, 1);
				{
				setState(1883);
				everyFunction();
				}
				break;
			case ANY:
			case SOME:
				enterOuterAlt(_localctx, 2);
				{
				setState(1884);
				anyFunction();
				}
				break;
			case LISTAGG:
				enterOuterAlt(_localctx, 3);
				{
				setState(1885);
				listaggFunction();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EveryFunctionContext extends ParserRuleContext {
		public EveryAllQuantifierContext everyAllQuantifier() {
			return getRuleContext(EveryAllQuantifierContext.class,0);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public CollectionQuantifierContext collectionQuantifier() {
			return getRuleContext(CollectionQuantifierContext.class,0);
		}
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public EveryFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_everyFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEveryFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEveryFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEveryFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EveryFunctionContext everyFunction() throws RecognitionException {
		EveryFunctionContext _localctx = new EveryFunctionContext(_ctx, getState());
		enterRule(_localctx, 344, RULE_everyFunction);
		try {
			setState(1909);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,195,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1888);
				everyAllQuantifier();
				setState(1889);
				match(T__1);
				setState(1890);
				predicate(0);
				setState(1891);
				match(T__2);
				setState(1893);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,193,_ctx) ) {
				case 1:
					{
					setState(1892);
					filterClause();
					}
					break;
				}
				setState(1896);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,194,_ctx) ) {
				case 1:
					{
					setState(1895);
					overClause();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1898);
				everyAllQuantifier();
				setState(1899);
				match(T__1);
				setState(1900);
				subquery();
				setState(1901);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1903);
				everyAllQuantifier();
				setState(1904);
				collectionQuantifier();
				setState(1905);
				match(T__1);
				setState(1906);
				simplePath();
				setState(1907);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnyFunctionContext extends ParserRuleContext {
		public AnySomeQuantifierContext anySomeQuantifier() {
			return getRuleContext(AnySomeQuantifierContext.class,0);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public CollectionQuantifierContext collectionQuantifier() {
			return getRuleContext(CollectionQuantifierContext.class,0);
		}
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public AnyFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anyFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAnyFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAnyFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAnyFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnyFunctionContext anyFunction() throws RecognitionException {
		AnyFunctionContext _localctx = new AnyFunctionContext(_ctx, getState());
		enterRule(_localctx, 346, RULE_anyFunction);
		try {
			setState(1932);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,198,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1911);
				anySomeQuantifier();
				setState(1912);
				match(T__1);
				setState(1913);
				predicate(0);
				setState(1914);
				match(T__2);
				setState(1916);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,196,_ctx) ) {
				case 1:
					{
					setState(1915);
					filterClause();
					}
					break;
				}
				setState(1919);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,197,_ctx) ) {
				case 1:
					{
					setState(1918);
					overClause();
					}
					break;
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1921);
				anySomeQuantifier();
				setState(1922);
				match(T__1);
				setState(1923);
				subquery();
				setState(1924);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1926);
				anySomeQuantifier();
				setState(1927);
				collectionQuantifier();
				setState(1928);
				match(T__1);
				setState(1929);
				simplePath();
				setState(1930);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EveryAllQuantifierContext extends ParserRuleContext {
		public TerminalNode EVERY() { return getToken(HqlParser.EVERY, 0); }
		public TerminalNode ALL() { return getToken(HqlParser.ALL, 0); }
		public EveryAllQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_everyAllQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEveryAllQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEveryAllQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEveryAllQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EveryAllQuantifierContext everyAllQuantifier() throws RecognitionException {
		EveryAllQuantifierContext _localctx = new EveryAllQuantifierContext(_ctx, getState());
		enterRule(_localctx, 348, RULE_everyAllQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1934);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==EVERY) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnySomeQuantifierContext extends ParserRuleContext {
		public TerminalNode ANY() { return getToken(HqlParser.ANY, 0); }
		public TerminalNode SOME() { return getToken(HqlParser.SOME, 0); }
		public AnySomeQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_anySomeQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAnySomeQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAnySomeQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAnySomeQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnySomeQuantifierContext anySomeQuantifier() throws RecognitionException {
		AnySomeQuantifierContext _localctx = new AnySomeQuantifierContext(_ctx, getState());
		enterRule(_localctx, 350, RULE_anySomeQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1936);
			_la = _input.LA(1);
			if ( !(_la==ANY || _la==SOME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ListaggFunctionContext extends ParserRuleContext {
		public TerminalNode LISTAGG() { return getToken(HqlParser.LISTAGG, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public OnOverflowClauseContext onOverflowClause() {
			return getRuleContext(OnOverflowClauseContext.class,0);
		}
		public WithinGroupClauseContext withinGroupClause() {
			return getRuleContext(WithinGroupClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public ListaggFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_listaggFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterListaggFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitListaggFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitListaggFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ListaggFunctionContext listaggFunction() throws RecognitionException {
		ListaggFunctionContext _localctx = new ListaggFunctionContext(_ctx, getState());
		enterRule(_localctx, 352, RULE_listaggFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1938);
			match(LISTAGG);
			setState(1939);
			match(T__1);
			setState(1941);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,199,_ctx) ) {
			case 1:
				{
				setState(1940);
				match(DISTINCT);
				}
				break;
			}
			setState(1943);
			expressionOrPredicate();
			setState(1944);
			match(T__0);
			setState(1945);
			expressionOrPredicate();
			setState(1947);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(1946);
				onOverflowClause();
				}
			}

			setState(1949);
			match(T__2);
			setState(1951);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,201,_ctx) ) {
			case 1:
				{
				setState(1950);
				withinGroupClause();
				}
				break;
			}
			setState(1954);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,202,_ctx) ) {
			case 1:
				{
				setState(1953);
				filterClause();
				}
				break;
			}
			setState(1957);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,203,_ctx) ) {
			case 1:
				{
				setState(1956);
				overClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OnOverflowClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode OVERFLOW() { return getToken(HqlParser.OVERFLOW, 0); }
		public TerminalNode ERROR() { return getToken(HqlParser.ERROR, 0); }
		public TerminalNode TRUNCATE() { return getToken(HqlParser.TRUNCATE, 0); }
		public TerminalNode COUNT() { return getToken(HqlParser.COUNT, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode WITHOUT() { return getToken(HqlParser.WITHOUT, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OnOverflowClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_onOverflowClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOnOverflowClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOnOverflowClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOnOverflowClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OnOverflowClauseContext onOverflowClause() throws RecognitionException {
		OnOverflowClauseContext _localctx = new OnOverflowClauseContext(_ctx, getState());
		enterRule(_localctx, 354, RULE_onOverflowClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1959);
			match(ON);
			setState(1960);
			match(OVERFLOW);
			setState(1968);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ERROR:
				{
				setState(1961);
				match(ERROR);
				}
				break;
			case TRUNCATE:
				{
				setState(1962);
				match(TRUNCATE);
				setState(1964);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,204,_ctx) ) {
				case 1:
					{
					setState(1963);
					expression(0);
					}
					break;
				}
				setState(1966);
				_la = _input.LA(1);
				if ( !(_la==WITH || _la==WITHOUT) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1967);
				match(COUNT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WithinGroupClauseContext extends ParserRuleContext {
		public TerminalNode WITHIN() { return getToken(HqlParser.WITHIN, 0); }
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public WithinGroupClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_withinGroupClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterWithinGroupClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitWithinGroupClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitWithinGroupClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WithinGroupClauseContext withinGroupClause() throws RecognitionException {
		WithinGroupClauseContext _localctx = new WithinGroupClauseContext(_ctx, getState());
		enterRule(_localctx, 356, RULE_withinGroupClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1970);
			match(WITHIN);
			setState(1971);
			match(GROUP);
			setState(1972);
			match(T__1);
			setState(1973);
			orderByClause();
			setState(1974);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FilterClauseContext extends ParserRuleContext {
		public TerminalNode FILTER() { return getToken(HqlParser.FILTER, 0); }
		public WhereClauseContext whereClause() {
			return getRuleContext(WhereClauseContext.class,0);
		}
		public FilterClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_filterClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFilterClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFilterClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFilterClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FilterClauseContext filterClause() throws RecognitionException {
		FilterClauseContext _localctx = new FilterClauseContext(_ctx, getState());
		enterRule(_localctx, 358, RULE_filterClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1976);
			match(FILTER);
			setState(1977);
			match(T__1);
			setState(1978);
			whereClause();
			setState(1979);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NullsClauseContext extends ParserRuleContext {
		public TerminalNode RESPECT() { return getToken(HqlParser.RESPECT, 0); }
		public TerminalNode NULLS() { return getToken(HqlParser.NULLS, 0); }
		public TerminalNode IGNORE() { return getToken(HqlParser.IGNORE, 0); }
		public NullsClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullsClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNullsClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNullsClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNullsClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NullsClauseContext nullsClause() throws RecognitionException {
		NullsClauseContext _localctx = new NullsClauseContext(_ctx, getState());
		enterRule(_localctx, 360, RULE_nullsClause);
		try {
			setState(1985);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RESPECT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1981);
				match(RESPECT);
				setState(1982);
				match(NULLS);
				}
				break;
			case IGNORE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1983);
				match(IGNORE);
				setState(1984);
				match(NULLS);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NthSideClauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(HqlParser.LAST, 0); }
		public NthSideClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nthSideClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNthSideClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNthSideClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNthSideClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NthSideClauseContext nthSideClause() throws RecognitionException {
		NthSideClauseContext _localctx = new NthSideClauseContext(_ctx, getState());
		enterRule(_localctx, 362, RULE_nthSideClause);
		try {
			setState(1991);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,207,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1987);
				match(FROM);
				setState(1988);
				match(FIRST);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1989);
				match(FROM);
				setState(1990);
				match(LAST);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverClauseContext extends ParserRuleContext {
		public TerminalNode OVER() { return getToken(HqlParser.OVER, 0); }
		public PartitionClauseContext partitionClause() {
			return getRuleContext(PartitionClauseContext.class,0);
		}
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public FrameClauseContext frameClause() {
			return getRuleContext(FrameClauseContext.class,0);
		}
		public OverClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOverClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOverClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOverClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OverClauseContext overClause() throws RecognitionException {
		OverClauseContext _localctx = new OverClauseContext(_ctx, getState());
		enterRule(_localctx, 364, RULE_overClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1993);
			match(OVER);
			setState(1994);
			match(T__1);
			setState(1996);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PARTITION) {
				{
				setState(1995);
				partitionClause();
				}
			}

			setState(1999);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(1998);
				orderByClause();
				}
			}

			setState(2002);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUPS || _la==RANGE || _la==ROWS) {
				{
				setState(2001);
				frameClause();
				}
			}

			setState(2004);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PartitionClauseContext extends ParserRuleContext {
		public TerminalNode PARTITION() { return getToken(HqlParser.PARTITION, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public PartitionClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_partitionClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPartitionClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPartitionClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPartitionClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PartitionClauseContext partitionClause() throws RecognitionException {
		PartitionClauseContext _localctx = new PartitionClauseContext(_ctx, getState());
		enterRule(_localctx, 366, RULE_partitionClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2006);
			match(PARTITION);
			setState(2007);
			match(BY);
			setState(2008);
			expression(0);
			setState(2013);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2009);
				match(T__0);
				setState(2010);
				expression(0);
				}
				}
				setState(2015);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameClauseContext extends ParserRuleContext {
		public FrameStartContext frameStart() {
			return getRuleContext(FrameStartContext.class,0);
		}
		public TerminalNode RANGE() { return getToken(HqlParser.RANGE, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public TerminalNode GROUPS() { return getToken(HqlParser.GROUPS, 0); }
		public FrameExclusionContext frameExclusion() {
			return getRuleContext(FrameExclusionContext.class,0);
		}
		public TerminalNode BETWEEN() { return getToken(HqlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public FrameEndContext frameEnd() {
			return getRuleContext(FrameEndContext.class,0);
		}
		public FrameClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameClauseContext frameClause() throws RecognitionException {
		FrameClauseContext _localctx = new FrameClauseContext(_ctx, getState());
		enterRule(_localctx, 368, RULE_frameClause);
		int _la;
		try {
			setState(2029);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,214,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2016);
				_la = _input.LA(1);
				if ( !(_la==GROUPS || _la==RANGE || _la==ROWS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2017);
				frameStart();
				setState(2019);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXCLUDE) {
					{
					setState(2018);
					frameExclusion();
					}
				}

				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2021);
				_la = _input.LA(1);
				if ( !(_la==GROUPS || _la==RANGE || _la==ROWS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2022);
				match(BETWEEN);
				setState(2023);
				frameStart();
				setState(2024);
				match(AND);
				setState(2025);
				frameEnd();
				setState(2027);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXCLUDE) {
					{
					setState(2026);
					frameExclusion();
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameStartContext extends ParserRuleContext {
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode UNBOUNDED() { return getToken(HqlParser.UNBOUNDED, 0); }
		public TerminalNode PRECEDING() { return getToken(HqlParser.PRECEDING, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode FOLLOWING() { return getToken(HqlParser.FOLLOWING, 0); }
		public FrameStartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameStart; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameStartContext frameStart() throws RecognitionException {
		FrameStartContext _localctx = new FrameStartContext(_ctx, getState());
		enterRule(_localctx, 370, RULE_frameStart);
		try {
			setState(2041);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,215,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2031);
				match(CURRENT);
				setState(2032);
				match(ROW);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2033);
				match(UNBOUNDED);
				setState(2034);
				match(PRECEDING);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2035);
				expression(0);
				setState(2036);
				match(PRECEDING);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2038);
				expression(0);
				setState(2039);
				match(FOLLOWING);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameEndContext extends ParserRuleContext {
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode UNBOUNDED() { return getToken(HqlParser.UNBOUNDED, 0); }
		public TerminalNode FOLLOWING() { return getToken(HqlParser.FOLLOWING, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode PRECEDING() { return getToken(HqlParser.PRECEDING, 0); }
		public FrameEndContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameEnd; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameEnd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameEnd(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameEnd(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameEndContext frameEnd() throws RecognitionException {
		FrameEndContext _localctx = new FrameEndContext(_ctx, getState());
		enterRule(_localctx, 372, RULE_frameEnd);
		try {
			setState(2053);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,216,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2043);
				match(CURRENT);
				setState(2044);
				match(ROW);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2045);
				match(UNBOUNDED);
				setState(2046);
				match(FOLLOWING);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2047);
				expression(0);
				setState(2048);
				match(PRECEDING);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2050);
				expression(0);
				setState(2051);
				match(FOLLOWING);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FrameExclusionContext extends ParserRuleContext {
		public TerminalNode EXCLUDE() { return getToken(HqlParser.EXCLUDE, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public TerminalNode TIES() { return getToken(HqlParser.TIES, 0); }
		public TerminalNode NO() { return getToken(HqlParser.NO, 0); }
		public TerminalNode OTHERS() { return getToken(HqlParser.OTHERS, 0); }
		public FrameExclusionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_frameExclusion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterFrameExclusion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitFrameExclusion(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitFrameExclusion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FrameExclusionContext frameExclusion() throws RecognitionException {
		FrameExclusionContext _localctx = new FrameExclusionContext(_ctx, getState());
		enterRule(_localctx, 374, RULE_frameExclusion);
		try {
			setState(2065);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,217,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2055);
				match(EXCLUDE);
				setState(2056);
				match(CURRENT);
				setState(2057);
				match(ROW);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2058);
				match(EXCLUDE);
				setState(2059);
				match(GROUP);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2060);
				match(EXCLUDE);
				setState(2061);
				match(TIES);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2062);
				match(EXCLUDE);
				setState(2063);
				match(NO);
				setState(2064);
				match(OTHERS);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonFunctionContext extends ParserRuleContext {
		public JsonArrayFunctionContext jsonArrayFunction() {
			return getRuleContext(JsonArrayFunctionContext.class,0);
		}
		public JsonExistsFunctionContext jsonExistsFunction() {
			return getRuleContext(JsonExistsFunctionContext.class,0);
		}
		public JsonObjectFunctionContext jsonObjectFunction() {
			return getRuleContext(JsonObjectFunctionContext.class,0);
		}
		public JsonQueryFunctionContext jsonQueryFunction() {
			return getRuleContext(JsonQueryFunctionContext.class,0);
		}
		public JsonValueFunctionContext jsonValueFunction() {
			return getRuleContext(JsonValueFunctionContext.class,0);
		}
		public JsonArrayAggFunctionContext jsonArrayAggFunction() {
			return getRuleContext(JsonArrayAggFunctionContext.class,0);
		}
		public JsonObjectAggFunctionContext jsonObjectAggFunction() {
			return getRuleContext(JsonObjectAggFunctionContext.class,0);
		}
		public JsonFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonFunctionContext jsonFunction() throws RecognitionException {
		JsonFunctionContext _localctx = new JsonFunctionContext(_ctx, getState());
		enterRule(_localctx, 376, RULE_jsonFunction);
		try {
			setState(2074);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case JSON_ARRAY:
				enterOuterAlt(_localctx, 1);
				{
				setState(2067);
				jsonArrayFunction();
				}
				break;
			case JSON_EXISTS:
				enterOuterAlt(_localctx, 2);
				{
				setState(2068);
				jsonExistsFunction();
				}
				break;
			case JSON_OBJECT:
				enterOuterAlt(_localctx, 3);
				{
				setState(2069);
				jsonObjectFunction();
				}
				break;
			case JSON_QUERY:
				enterOuterAlt(_localctx, 4);
				{
				setState(2070);
				jsonQueryFunction();
				}
				break;
			case JSON_VALUE:
				enterOuterAlt(_localctx, 5);
				{
				setState(2071);
				jsonValueFunction();
				}
				break;
			case JSON_ARRAYAGG:
				enterOuterAlt(_localctx, 6);
				{
				setState(2072);
				jsonArrayAggFunction();
				}
				break;
			case JSON_OBJECTAGG:
				enterOuterAlt(_localctx, 7);
				{
				setState(2073);
				jsonObjectAggFunction();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonArrayFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_ARRAY() { return getToken(HqlParser.JSON_ARRAY, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public JsonNullClauseContext jsonNullClause() {
			return getRuleContext(JsonNullClauseContext.class,0);
		}
		public JsonArrayFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonArrayFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonArrayFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonArrayFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonArrayFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonArrayFunctionContext jsonArrayFunction() throws RecognitionException {
		JsonArrayFunctionContext _localctx = new JsonArrayFunctionContext(_ctx, getState());
		enterRule(_localctx, 378, RULE_jsonArrayFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2076);
			match(JSON_ARRAY);
			setState(2077);
			match(T__1);
			setState(2089);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -31454588L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -1L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 1152921504606846975L) != 0)) {
				{
				setState(2078);
				expressionOrPredicate();
				setState(2083);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(2079);
					match(T__0);
					setState(2080);
					expressionOrPredicate();
					}
					}
					setState(2085);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(2087);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ABSENT || _la==NULL) {
					{
					setState(2086);
					jsonNullClause();
					}
				}

				}
			}

			setState(2091);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonExistsFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_EXISTS() { return getToken(HqlParser.JSON_EXISTS, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public JsonPassingClauseContext jsonPassingClause() {
			return getRuleContext(JsonPassingClauseContext.class,0);
		}
		public JsonExistsOnErrorClauseContext jsonExistsOnErrorClause() {
			return getRuleContext(JsonExistsOnErrorClauseContext.class,0);
		}
		public JsonExistsFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonExistsFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonExistsFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonExistsFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonExistsFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonExistsFunctionContext jsonExistsFunction() throws RecognitionException {
		JsonExistsFunctionContext _localctx = new JsonExistsFunctionContext(_ctx, getState());
		enterRule(_localctx, 380, RULE_jsonExistsFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2093);
			match(JSON_EXISTS);
			setState(2094);
			match(T__1);
			setState(2095);
			expression(0);
			setState(2096);
			match(T__0);
			setState(2097);
			expression(0);
			setState(2099);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PASSING) {
				{
				setState(2098);
				jsonPassingClause();
				}
			}

			setState(2102);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ERROR || _la==TRUE || _la==FALSE) {
				{
				setState(2101);
				jsonExistsOnErrorClause();
				}
			}

			setState(2104);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonExistsOnErrorClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public List<TerminalNode> ERROR() { return getTokens(HqlParser.ERROR); }
		public TerminalNode ERROR(int i) {
			return getToken(HqlParser.ERROR, i);
		}
		public TerminalNode TRUE() { return getToken(HqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(HqlParser.FALSE, 0); }
		public JsonExistsOnErrorClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonExistsOnErrorClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonExistsOnErrorClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonExistsOnErrorClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonExistsOnErrorClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonExistsOnErrorClauseContext jsonExistsOnErrorClause() throws RecognitionException {
		JsonExistsOnErrorClauseContext _localctx = new JsonExistsOnErrorClauseContext(_ctx, getState());
		enterRule(_localctx, 382, RULE_jsonExistsOnErrorClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2106);
			_la = _input.LA(1);
			if ( !(_la==ERROR || _la==TRUE || _la==FALSE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2107);
			match(ON);
			setState(2108);
			match(ERROR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonObjectFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_OBJECT() { return getToken(HqlParser.JSON_OBJECT, 0); }
		public List<JsonObjectFunctionEntryContext> jsonObjectFunctionEntry() {
			return getRuleContexts(JsonObjectFunctionEntryContext.class);
		}
		public JsonObjectFunctionEntryContext jsonObjectFunctionEntry(int i) {
			return getRuleContext(JsonObjectFunctionEntryContext.class,i);
		}
		public JsonNullClauseContext jsonNullClause() {
			return getRuleContext(JsonNullClauseContext.class,0);
		}
		public JsonObjectFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonObjectFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonObjectFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonObjectFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonObjectFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonObjectFunctionContext jsonObjectFunction() throws RecognitionException {
		JsonObjectFunctionContext _localctx = new JsonObjectFunctionContext(_ctx, getState());
		enterRule(_localctx, 384, RULE_jsonObjectFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2110);
			match(JSON_OBJECT);
			setState(2111);
			match(T__1);
			setState(2113);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,224,_ctx) ) {
			case 1:
				{
				setState(2112);
				jsonObjectFunctionEntry();
				}
				break;
			}
			setState(2119);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2115);
				match(T__0);
				setState(2116);
				jsonObjectFunctionEntry();
				}
				}
				setState(2121);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(2123);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ABSENT || _la==NULL) {
				{
				setState(2122);
				jsonNullClause();
				}
			}

			setState(2125);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonObjectFunctionEntryContext extends ParserRuleContext {
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public JsonObjectKeyValueEntryContext jsonObjectKeyValueEntry() {
			return getRuleContext(JsonObjectKeyValueEntryContext.class,0);
		}
		public JsonObjectAssignmentEntryContext jsonObjectAssignmentEntry() {
			return getRuleContext(JsonObjectAssignmentEntryContext.class,0);
		}
		public JsonObjectFunctionEntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonObjectFunctionEntry; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonObjectFunctionEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonObjectFunctionEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonObjectFunctionEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonObjectFunctionEntryContext jsonObjectFunctionEntry() throws RecognitionException {
		JsonObjectFunctionEntryContext _localctx = new JsonObjectFunctionEntryContext(_ctx, getState());
		enterRule(_localctx, 386, RULE_jsonObjectFunctionEntry);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2130);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,227,_ctx) ) {
			case 1:
				{
				setState(2127);
				expressionOrPredicate();
				}
				break;
			case 2:
				{
				setState(2128);
				jsonObjectKeyValueEntry();
				}
				break;
			case 3:
				{
				setState(2129);
				jsonObjectAssignmentEntry();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonObjectKeyValueEntryContext extends ParserRuleContext {
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode VALUE() { return getToken(HqlParser.VALUE, 0); }
		public TerminalNode KEY() { return getToken(HqlParser.KEY, 0); }
		public JsonObjectKeyValueEntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonObjectKeyValueEntry; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonObjectKeyValueEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonObjectKeyValueEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonObjectKeyValueEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonObjectKeyValueEntryContext jsonObjectKeyValueEntry() throws RecognitionException {
		JsonObjectKeyValueEntryContext _localctx = new JsonObjectKeyValueEntryContext(_ctx, getState());
		enterRule(_localctx, 388, RULE_jsonObjectKeyValueEntry);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2133);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,228,_ctx) ) {
			case 1:
				{
				setState(2132);
				match(KEY);
				}
				break;
			}
			setState(2135);
			expressionOrPredicate();
			setState(2136);
			match(VALUE);
			setState(2137);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonObjectAssignmentEntryContext extends ParserRuleContext {
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public JsonObjectAssignmentEntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonObjectAssignmentEntry; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonObjectAssignmentEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonObjectAssignmentEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonObjectAssignmentEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonObjectAssignmentEntryContext jsonObjectAssignmentEntry() throws RecognitionException {
		JsonObjectAssignmentEntryContext _localctx = new JsonObjectAssignmentEntryContext(_ctx, getState());
		enterRule(_localctx, 390, RULE_jsonObjectAssignmentEntry);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2139);
			expressionOrPredicate();
			setState(2140);
			match(T__8);
			setState(2141);
			expressionOrPredicate();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonQueryFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_QUERY() { return getToken(HqlParser.JSON_QUERY, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public JsonPassingClauseContext jsonPassingClause() {
			return getRuleContext(JsonPassingClauseContext.class,0);
		}
		public JsonQueryWrapperClauseContext jsonQueryWrapperClause() {
			return getRuleContext(JsonQueryWrapperClauseContext.class,0);
		}
		public List<JsonQueryOnErrorOrEmptyClauseContext> jsonQueryOnErrorOrEmptyClause() {
			return getRuleContexts(JsonQueryOnErrorOrEmptyClauseContext.class);
		}
		public JsonQueryOnErrorOrEmptyClauseContext jsonQueryOnErrorOrEmptyClause(int i) {
			return getRuleContext(JsonQueryOnErrorOrEmptyClauseContext.class,i);
		}
		public JsonQueryFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonQueryFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonQueryFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonQueryFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonQueryFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonQueryFunctionContext jsonQueryFunction() throws RecognitionException {
		JsonQueryFunctionContext _localctx = new JsonQueryFunctionContext(_ctx, getState());
		enterRule(_localctx, 392, RULE_jsonQueryFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2143);
			match(JSON_QUERY);
			setState(2144);
			match(T__1);
			setState(2145);
			expression(0);
			setState(2146);
			match(T__0);
			setState(2147);
			expression(0);
			setState(2149);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PASSING) {
				{
				setState(2148);
				jsonPassingClause();
				}
			}

			setState(2152);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WITH || _la==WITHOUT) {
				{
				setState(2151);
				jsonQueryWrapperClause();
				}
			}

			setState(2155);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,231,_ctx) ) {
			case 1:
				{
				setState(2154);
				jsonQueryOnErrorOrEmptyClause();
				}
				break;
			}
			setState(2158);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==EMPTY || _la==ERROR || _la==NULL) {
				{
				setState(2157);
				jsonQueryOnErrorOrEmptyClause();
				}
			}

			setState(2160);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonQueryWrapperClauseContext extends ParserRuleContext {
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode WRAPPER() { return getToken(HqlParser.WRAPPER, 0); }
		public TerminalNode ARRAY() { return getToken(HqlParser.ARRAY, 0); }
		public TerminalNode CONDITIONAL() { return getToken(HqlParser.CONDITIONAL, 0); }
		public TerminalNode UNCONDITIONAL() { return getToken(HqlParser.UNCONDITIONAL, 0); }
		public TerminalNode WITHOUT() { return getToken(HqlParser.WITHOUT, 0); }
		public JsonQueryWrapperClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonQueryWrapperClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonQueryWrapperClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonQueryWrapperClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonQueryWrapperClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonQueryWrapperClauseContext jsonQueryWrapperClause() throws RecognitionException {
		JsonQueryWrapperClauseContext _localctx = new JsonQueryWrapperClauseContext(_ctx, getState());
		enterRule(_localctx, 394, RULE_jsonQueryWrapperClause);
		int _la;
		try {
			setState(2175);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case WITH:
				enterOuterAlt(_localctx, 1);
				{
				setState(2162);
				match(WITH);
				setState(2164);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==CONDITIONAL || _la==UNCONDITIONAL) {
					{
					setState(2163);
					_la = _input.LA(1);
					if ( !(_la==CONDITIONAL || _la==UNCONDITIONAL) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(2167);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ARRAY) {
					{
					setState(2166);
					match(ARRAY);
					}
				}

				setState(2169);
				match(WRAPPER);
				}
				break;
			case WITHOUT:
				enterOuterAlt(_localctx, 2);
				{
				setState(2170);
				match(WITHOUT);
				setState(2172);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ARRAY) {
					{
					setState(2171);
					match(ARRAY);
					}
				}

				setState(2174);
				match(WRAPPER);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonQueryOnErrorOrEmptyClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public List<TerminalNode> ERROR() { return getTokens(HqlParser.ERROR); }
		public TerminalNode ERROR(int i) {
			return getToken(HqlParser.ERROR, i);
		}
		public List<TerminalNode> EMPTY() { return getTokens(HqlParser.EMPTY); }
		public TerminalNode EMPTY(int i) {
			return getToken(HqlParser.EMPTY, i);
		}
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public TerminalNode ARRAY() { return getToken(HqlParser.ARRAY, 0); }
		public TerminalNode OBJECT() { return getToken(HqlParser.OBJECT, 0); }
		public JsonQueryOnErrorOrEmptyClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonQueryOnErrorOrEmptyClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonQueryOnErrorOrEmptyClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonQueryOnErrorOrEmptyClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonQueryOnErrorOrEmptyClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonQueryOnErrorOrEmptyClauseContext jsonQueryOnErrorOrEmptyClause() throws RecognitionException {
		JsonQueryOnErrorOrEmptyClauseContext _localctx = new JsonQueryOnErrorOrEmptyClauseContext(_ctx, getState());
		enterRule(_localctx, 396, RULE_jsonQueryOnErrorOrEmptyClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2183);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ERROR:
				{
				setState(2177);
				match(ERROR);
				}
				break;
			case NULL:
				{
				setState(2178);
				match(NULL);
				}
				break;
			case EMPTY:
				{
				setState(2179);
				match(EMPTY);
				setState(2181);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ARRAY || _la==OBJECT) {
					{
					setState(2180);
					_la = _input.LA(1);
					if ( !(_la==ARRAY || _la==OBJECT) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(2185);
			match(ON);
			setState(2186);
			_la = _input.LA(1);
			if ( !(_la==EMPTY || _la==ERROR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonValueFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_VALUE() { return getToken(HqlParser.JSON_VALUE, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public JsonPassingClauseContext jsonPassingClause() {
			return getRuleContext(JsonPassingClauseContext.class,0);
		}
		public JsonValueReturningClauseContext jsonValueReturningClause() {
			return getRuleContext(JsonValueReturningClauseContext.class,0);
		}
		public List<JsonValueOnErrorOrEmptyClauseContext> jsonValueOnErrorOrEmptyClause() {
			return getRuleContexts(JsonValueOnErrorOrEmptyClauseContext.class);
		}
		public JsonValueOnErrorOrEmptyClauseContext jsonValueOnErrorOrEmptyClause(int i) {
			return getRuleContext(JsonValueOnErrorOrEmptyClauseContext.class,i);
		}
		public JsonValueFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonValueFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonValueFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonValueFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonValueFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonValueFunctionContext jsonValueFunction() throws RecognitionException {
		JsonValueFunctionContext _localctx = new JsonValueFunctionContext(_ctx, getState());
		enterRule(_localctx, 398, RULE_jsonValueFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2188);
			match(JSON_VALUE);
			setState(2189);
			match(T__1);
			setState(2190);
			expression(0);
			setState(2191);
			match(T__0);
			setState(2192);
			expression(0);
			setState(2194);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PASSING) {
				{
				setState(2193);
				jsonPassingClause();
				}
			}

			setState(2197);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==RETURNING) {
				{
				setState(2196);
				jsonValueReturningClause();
				}
			}

			setState(2200);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,241,_ctx) ) {
			case 1:
				{
				setState(2199);
				jsonValueOnErrorOrEmptyClause();
				}
				break;
			}
			setState(2203);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DEFAULT || _la==ERROR || _la==NULL) {
				{
				setState(2202);
				jsonValueOnErrorOrEmptyClause();
				}
			}

			setState(2205);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonValueReturningClauseContext extends ParserRuleContext {
		public TerminalNode RETURNING() { return getToken(HqlParser.RETURNING, 0); }
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public JsonValueReturningClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonValueReturningClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonValueReturningClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonValueReturningClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonValueReturningClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonValueReturningClauseContext jsonValueReturningClause() throws RecognitionException {
		JsonValueReturningClauseContext _localctx = new JsonValueReturningClauseContext(_ctx, getState());
		enterRule(_localctx, 400, RULE_jsonValueReturningClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2207);
			match(RETURNING);
			setState(2208);
			castTarget();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonValueOnErrorOrEmptyClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public List<TerminalNode> ERROR() { return getTokens(HqlParser.ERROR); }
		public TerminalNode ERROR(int i) {
			return getToken(HqlParser.ERROR, i);
		}
		public TerminalNode EMPTY() { return getToken(HqlParser.EMPTY, 0); }
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public TerminalNode DEFAULT() { return getToken(HqlParser.DEFAULT, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public JsonValueOnErrorOrEmptyClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonValueOnErrorOrEmptyClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonValueOnErrorOrEmptyClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonValueOnErrorOrEmptyClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonValueOnErrorOrEmptyClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonValueOnErrorOrEmptyClauseContext jsonValueOnErrorOrEmptyClause() throws RecognitionException {
		JsonValueOnErrorOrEmptyClauseContext _localctx = new JsonValueOnErrorOrEmptyClauseContext(_ctx, getState());
		enterRule(_localctx, 402, RULE_jsonValueOnErrorOrEmptyClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2214);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ERROR:
				{
				setState(2210);
				match(ERROR);
				}
				break;
			case NULL:
				{
				setState(2211);
				match(NULL);
				}
				break;
			case DEFAULT:
				{
				setState(2212);
				match(DEFAULT);
				setState(2213);
				expression(0);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(2216);
			match(ON);
			setState(2217);
			_la = _input.LA(1);
			if ( !(_la==EMPTY || _la==ERROR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonArrayAggFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_ARRAYAGG() { return getToken(HqlParser.JSON_ARRAYAGG, 0); }
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public JsonNullClauseContext jsonNullClause() {
			return getRuleContext(JsonNullClauseContext.class,0);
		}
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public JsonArrayAggFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonArrayAggFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonArrayAggFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonArrayAggFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonArrayAggFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonArrayAggFunctionContext jsonArrayAggFunction() throws RecognitionException {
		JsonArrayAggFunctionContext _localctx = new JsonArrayAggFunctionContext(_ctx, getState());
		enterRule(_localctx, 404, RULE_jsonArrayAggFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2219);
			match(JSON_ARRAYAGG);
			setState(2220);
			match(T__1);
			setState(2221);
			expressionOrPredicate();
			setState(2223);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ABSENT || _la==NULL) {
				{
				setState(2222);
				jsonNullClause();
				}
			}

			setState(2226);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(2225);
				orderByClause();
				}
			}

			setState(2228);
			match(T__2);
			setState(2230);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,246,_ctx) ) {
			case 1:
				{
				setState(2229);
				filterClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonObjectAggFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_OBJECTAGG() { return getToken(HqlParser.JSON_OBJECTAGG, 0); }
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public TerminalNode VALUE() { return getToken(HqlParser.VALUE, 0); }
		public TerminalNode KEY() { return getToken(HqlParser.KEY, 0); }
		public JsonNullClauseContext jsonNullClause() {
			return getRuleContext(JsonNullClauseContext.class,0);
		}
		public JsonUniqueKeysClauseContext jsonUniqueKeysClause() {
			return getRuleContext(JsonUniqueKeysClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public JsonObjectAggFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonObjectAggFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonObjectAggFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonObjectAggFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonObjectAggFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonObjectAggFunctionContext jsonObjectAggFunction() throws RecognitionException {
		JsonObjectAggFunctionContext _localctx = new JsonObjectAggFunctionContext(_ctx, getState());
		enterRule(_localctx, 406, RULE_jsonObjectAggFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2232);
			match(JSON_OBJECTAGG);
			setState(2233);
			match(T__1);
			setState(2235);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,247,_ctx) ) {
			case 1:
				{
				setState(2234);
				match(KEY);
				}
				break;
			}
			setState(2237);
			expressionOrPredicate();
			setState(2238);
			_la = _input.LA(1);
			if ( !(_la==T__8 || _la==VALUE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2239);
			expressionOrPredicate();
			setState(2241);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ABSENT || _la==NULL) {
				{
				setState(2240);
				jsonNullClause();
				}
			}

			setState(2244);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WITH || _la==WITHOUT) {
				{
				setState(2243);
				jsonUniqueKeysClause();
				}
			}

			setState(2246);
			match(T__2);
			setState(2248);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,250,_ctx) ) {
			case 1:
				{
				setState(2247);
				filterClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonPassingClauseContext extends ParserRuleContext {
		public TerminalNode PASSING() { return getToken(HqlParser.PASSING, 0); }
		public List<AliasedExpressionOrPredicateContext> aliasedExpressionOrPredicate() {
			return getRuleContexts(AliasedExpressionOrPredicateContext.class);
		}
		public AliasedExpressionOrPredicateContext aliasedExpressionOrPredicate(int i) {
			return getRuleContext(AliasedExpressionOrPredicateContext.class,i);
		}
		public JsonPassingClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonPassingClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonPassingClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonPassingClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonPassingClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonPassingClauseContext jsonPassingClause() throws RecognitionException {
		JsonPassingClauseContext _localctx = new JsonPassingClauseContext(_ctx, getState());
		enterRule(_localctx, 408, RULE_jsonPassingClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2250);
			match(PASSING);
			setState(2251);
			aliasedExpressionOrPredicate();
			setState(2256);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2252);
				match(T__0);
				setState(2253);
				aliasedExpressionOrPredicate();
				}
				}
				setState(2258);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonNullClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public List<TerminalNode> NULL() { return getTokens(HqlParser.NULL); }
		public TerminalNode NULL(int i) {
			return getToken(HqlParser.NULL, i);
		}
		public TerminalNode ABSENT() { return getToken(HqlParser.ABSENT, 0); }
		public JsonNullClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonNullClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonNullClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonNullClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonNullClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonNullClauseContext jsonNullClause() throws RecognitionException {
		JsonNullClauseContext _localctx = new JsonNullClauseContext(_ctx, getState());
		enterRule(_localctx, 410, RULE_jsonNullClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2259);
			_la = _input.LA(1);
			if ( !(_la==ABSENT || _la==NULL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2260);
			match(ON);
			setState(2261);
			match(NULL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonUniqueKeysClauseContext extends ParserRuleContext {
		public TerminalNode UNIQUE() { return getToken(HqlParser.UNIQUE, 0); }
		public TerminalNode KEYS() { return getToken(HqlParser.KEYS, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode WITHOUT() { return getToken(HqlParser.WITHOUT, 0); }
		public JsonUniqueKeysClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonUniqueKeysClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonUniqueKeysClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonUniqueKeysClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonUniqueKeysClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonUniqueKeysClauseContext jsonUniqueKeysClause() throws RecognitionException {
		JsonUniqueKeysClauseContext _localctx = new JsonUniqueKeysClauseContext(_ctx, getState());
		enterRule(_localctx, 412, RULE_jsonUniqueKeysClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2263);
			_la = _input.LA(1);
			if ( !(_la==WITH || _la==WITHOUT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2264);
			match(UNIQUE);
			setState(2265);
			match(KEYS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableFunctionContext extends ParserRuleContext {
		public TerminalNode JSON_TABLE() { return getToken(HqlParser.JSON_TABLE, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public JsonTableColumnsClauseContext jsonTableColumnsClause() {
			return getRuleContext(JsonTableColumnsClauseContext.class,0);
		}
		public JsonPassingClauseContext jsonPassingClause() {
			return getRuleContext(JsonPassingClauseContext.class,0);
		}
		public JsonTableErrorClauseContext jsonTableErrorClause() {
			return getRuleContext(JsonTableErrorClauseContext.class,0);
		}
		public JsonTableFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonTableFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonTableFunctionContext jsonTableFunction() throws RecognitionException {
		JsonTableFunctionContext _localctx = new JsonTableFunctionContext(_ctx, getState());
		enterRule(_localctx, 414, RULE_jsonTableFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2267);
			match(JSON_TABLE);
			setState(2268);
			match(T__1);
			setState(2269);
			expression(0);
			setState(2272);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(2270);
				match(T__0);
				setState(2271);
				expression(0);
				}
			}

			setState(2275);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PASSING) {
				{
				setState(2274);
				jsonPassingClause();
				}
			}

			setState(2277);
			jsonTableColumnsClause();
			setState(2279);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ERROR || _la==NULL) {
				{
				setState(2278);
				jsonTableErrorClause();
				}
			}

			setState(2281);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableErrorClauseContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public List<TerminalNode> ERROR() { return getTokens(HqlParser.ERROR); }
		public TerminalNode ERROR(int i) {
			return getToken(HqlParser.ERROR, i);
		}
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public JsonTableErrorClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonTableErrorClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableErrorClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableErrorClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableErrorClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonTableErrorClauseContext jsonTableErrorClause() throws RecognitionException {
		JsonTableErrorClauseContext _localctx = new JsonTableErrorClauseContext(_ctx, getState());
		enterRule(_localctx, 416, RULE_jsonTableErrorClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2283);
			_la = _input.LA(1);
			if ( !(_la==ERROR || _la==NULL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2284);
			match(ON);
			setState(2285);
			match(ERROR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableColumnsClauseContext extends ParserRuleContext {
		public TerminalNode COLUMNS() { return getToken(HqlParser.COLUMNS, 0); }
		public JsonTableColumnsContext jsonTableColumns() {
			return getRuleContext(JsonTableColumnsContext.class,0);
		}
		public JsonTableColumnsClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonTableColumnsClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableColumnsClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableColumnsClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableColumnsClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonTableColumnsClauseContext jsonTableColumnsClause() throws RecognitionException {
		JsonTableColumnsClauseContext _localctx = new JsonTableColumnsClauseContext(_ctx, getState());
		enterRule(_localctx, 418, RULE_jsonTableColumnsClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2287);
			match(COLUMNS);
			setState(2288);
			match(T__1);
			setState(2289);
			jsonTableColumns();
			setState(2290);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableColumnsContext extends ParserRuleContext {
		public List<JsonTableColumnContext> jsonTableColumn() {
			return getRuleContexts(JsonTableColumnContext.class);
		}
		public JsonTableColumnContext jsonTableColumn(int i) {
			return getRuleContext(JsonTableColumnContext.class,i);
		}
		public JsonTableColumnsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonTableColumns; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableColumns(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableColumns(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableColumns(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonTableColumnsContext jsonTableColumns() throws RecognitionException {
		JsonTableColumnsContext _localctx = new JsonTableColumnsContext(_ctx, getState());
		enterRule(_localctx, 420, RULE_jsonTableColumns);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2292);
			jsonTableColumn();
			setState(2297);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2293);
				match(T__0);
				setState(2294);
				jsonTableColumn();
				}
				}
				setState(2299);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableColumnContext extends ParserRuleContext {
		public JsonTableColumnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jsonTableColumn; }
	 
		public JsonTableColumnContext() { }
		public void copyFrom(JsonTableColumnContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableExistsColumnContext extends JsonTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode EXISTS() { return getToken(HqlParser.EXISTS, 0); }
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public JsonExistsOnErrorClauseContext jsonExistsOnErrorClause() {
			return getRuleContext(JsonExistsOnErrorClauseContext.class,0);
		}
		public JsonTableExistsColumnContext(JsonTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableExistsColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableExistsColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableExistsColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableNestedColumnContext extends JsonTableColumnContext {
		public TerminalNode NESTED() { return getToken(HqlParser.NESTED, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public JsonTableColumnsClauseContext jsonTableColumnsClause() {
			return getRuleContext(JsonTableColumnsClauseContext.class,0);
		}
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public JsonTableNestedColumnContext(JsonTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableNestedColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableNestedColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableNestedColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableQueryColumnContext extends JsonTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode JSON() { return getToken(HqlParser.JSON, 0); }
		public JsonQueryWrapperClauseContext jsonQueryWrapperClause() {
			return getRuleContext(JsonQueryWrapperClauseContext.class,0);
		}
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public List<JsonQueryOnErrorOrEmptyClauseContext> jsonQueryOnErrorOrEmptyClause() {
			return getRuleContexts(JsonQueryOnErrorOrEmptyClauseContext.class);
		}
		public JsonQueryOnErrorOrEmptyClauseContext jsonQueryOnErrorOrEmptyClause(int i) {
			return getRuleContext(JsonQueryOnErrorOrEmptyClauseContext.class,i);
		}
		public JsonTableQueryColumnContext(JsonTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableQueryColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableQueryColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableQueryColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableOrdinalityColumnContext extends JsonTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public TerminalNode ORDINALITY() { return getToken(HqlParser.ORDINALITY, 0); }
		public JsonTableOrdinalityColumnContext(JsonTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableOrdinalityColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableOrdinalityColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableOrdinalityColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JsonTableValueColumnContext extends JsonTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public List<JsonValueOnErrorOrEmptyClauseContext> jsonValueOnErrorOrEmptyClause() {
			return getRuleContexts(JsonValueOnErrorOrEmptyClauseContext.class);
		}
		public JsonValueOnErrorOrEmptyClauseContext jsonValueOnErrorOrEmptyClause(int i) {
			return getRuleContext(JsonValueOnErrorOrEmptyClauseContext.class,i);
		}
		public JsonTableValueColumnContext(JsonTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterJsonTableValueColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitJsonTableValueColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitJsonTableValueColumn(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonTableColumnContext jsonTableColumn() throws RecognitionException {
		JsonTableColumnContext _localctx = new JsonTableColumnContext(_ctx, getState());
		enterRule(_localctx, 422, RULE_jsonTableColumn);
		int _la;
		try {
			setState(2346);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,266,_ctx) ) {
			case 1:
				_localctx = new JsonTableNestedColumnContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(2300);
				match(NESTED);
				setState(2302);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PATH) {
					{
					setState(2301);
					match(PATH);
					}
				}

				setState(2304);
				match(STRING_LITERAL);
				setState(2305);
				jsonTableColumnsClause();
				}
				break;
			case 2:
				_localctx = new JsonTableQueryColumnContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(2306);
				identifier();
				setState(2307);
				match(JSON);
				setState(2309);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WITH || _la==WITHOUT) {
					{
					setState(2308);
					jsonQueryWrapperClause();
					}
				}

				setState(2313);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PATH) {
					{
					setState(2311);
					match(PATH);
					setState(2312);
					match(STRING_LITERAL);
					}
				}

				setState(2316);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,259,_ctx) ) {
				case 1:
					{
					setState(2315);
					jsonQueryOnErrorOrEmptyClause();
					}
					break;
				}
				setState(2319);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EMPTY || _la==ERROR || _la==NULL) {
					{
					setState(2318);
					jsonQueryOnErrorOrEmptyClause();
					}
				}

				}
				break;
			case 3:
				_localctx = new JsonTableOrdinalityColumnContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(2321);
				identifier();
				setState(2322);
				match(FOR);
				setState(2323);
				match(ORDINALITY);
				}
				break;
			case 4:
				_localctx = new JsonTableExistsColumnContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(2325);
				identifier();
				setState(2326);
				match(EXISTS);
				setState(2329);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PATH) {
					{
					setState(2327);
					match(PATH);
					setState(2328);
					match(STRING_LITERAL);
					}
				}

				setState(2332);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ERROR || _la==TRUE || _la==FALSE) {
					{
					setState(2331);
					jsonExistsOnErrorClause();
					}
				}

				}
				break;
			case 5:
				_localctx = new JsonTableValueColumnContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(2334);
				identifier();
				setState(2335);
				castTarget();
				setState(2338);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PATH) {
					{
					setState(2336);
					match(PATH);
					setState(2337);
					match(STRING_LITERAL);
					}
				}

				setState(2341);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,264,_ctx) ) {
				case 1:
					{
					setState(2340);
					jsonValueOnErrorOrEmptyClause();
					}
					break;
				}
				setState(2344);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DEFAULT || _la==ERROR || _la==NULL) {
					{
					setState(2343);
					jsonValueOnErrorOrEmptyClause();
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlFunctionContext extends ParserRuleContext {
		public XmlElementFunctionContext xmlElementFunction() {
			return getRuleContext(XmlElementFunctionContext.class,0);
		}
		public XmlForestFunctionContext xmlForestFunction() {
			return getRuleContext(XmlForestFunctionContext.class,0);
		}
		public XmlPiFunctionContext xmlPiFunction() {
			return getRuleContext(XmlPiFunctionContext.class,0);
		}
		public XmlQueryFunctionContext xmlQueryFunction() {
			return getRuleContext(XmlQueryFunctionContext.class,0);
		}
		public XmlExistsFunctionContext xmlExistsFunction() {
			return getRuleContext(XmlExistsFunctionContext.class,0);
		}
		public XmlAggFunctionContext xmlAggFunction() {
			return getRuleContext(XmlAggFunctionContext.class,0);
		}
		public XmlFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlFunctionContext xmlFunction() throws RecognitionException {
		XmlFunctionContext _localctx = new XmlFunctionContext(_ctx, getState());
		enterRule(_localctx, 424, RULE_xmlFunction);
		try {
			setState(2354);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case XMLELEMENT:
				enterOuterAlt(_localctx, 1);
				{
				setState(2348);
				xmlElementFunction();
				}
				break;
			case XMLFOREST:
				enterOuterAlt(_localctx, 2);
				{
				setState(2349);
				xmlForestFunction();
				}
				break;
			case XMLPI:
				enterOuterAlt(_localctx, 3);
				{
				setState(2350);
				xmlPiFunction();
				}
				break;
			case XMLQUERY:
				enterOuterAlt(_localctx, 4);
				{
				setState(2351);
				xmlQueryFunction();
				}
				break;
			case XMLEXISTS:
				enterOuterAlt(_localctx, 5);
				{
				setState(2352);
				xmlExistsFunction();
				}
				break;
			case XMLAGG:
				enterOuterAlt(_localctx, 6);
				{
				setState(2353);
				xmlAggFunction();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlElementFunctionContext extends ParserRuleContext {
		public TerminalNode XMLELEMENT() { return getToken(HqlParser.XMLELEMENT, 0); }
		public TerminalNode NAME() { return getToken(HqlParser.NAME, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public XmlAttributesFunctionContext xmlAttributesFunction() {
			return getRuleContext(XmlAttributesFunctionContext.class,0);
		}
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public XmlElementFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlElementFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlElementFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlElementFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlElementFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlElementFunctionContext xmlElementFunction() throws RecognitionException {
		XmlElementFunctionContext _localctx = new XmlElementFunctionContext(_ctx, getState());
		enterRule(_localctx, 426, RULE_xmlElementFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2356);
			match(XMLELEMENT);
			setState(2357);
			match(T__1);
			setState(2358);
			match(NAME);
			setState(2359);
			identifier();
			setState(2362);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,268,_ctx) ) {
			case 1:
				{
				setState(2360);
				match(T__0);
				setState(2361);
				xmlAttributesFunction();
				}
				break;
			}
			setState(2368);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2364);
				match(T__0);
				setState(2365);
				expressionOrPredicate();
				}
				}
				setState(2370);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(2371);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlAttributesFunctionContext extends ParserRuleContext {
		public TerminalNode XMLATTRIBUTES() { return getToken(HqlParser.XMLATTRIBUTES, 0); }
		public List<AliasedExpressionOrPredicateContext> aliasedExpressionOrPredicate() {
			return getRuleContexts(AliasedExpressionOrPredicateContext.class);
		}
		public AliasedExpressionOrPredicateContext aliasedExpressionOrPredicate(int i) {
			return getRuleContext(AliasedExpressionOrPredicateContext.class,i);
		}
		public XmlAttributesFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlAttributesFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlAttributesFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlAttributesFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlAttributesFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlAttributesFunctionContext xmlAttributesFunction() throws RecognitionException {
		XmlAttributesFunctionContext _localctx = new XmlAttributesFunctionContext(_ctx, getState());
		enterRule(_localctx, 428, RULE_xmlAttributesFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2373);
			match(XMLATTRIBUTES);
			setState(2374);
			match(T__1);
			setState(2375);
			aliasedExpressionOrPredicate();
			setState(2380);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2376);
				match(T__0);
				setState(2377);
				aliasedExpressionOrPredicate();
				}
				}
				setState(2382);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(2383);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlForestFunctionContext extends ParserRuleContext {
		public TerminalNode XMLFOREST() { return getToken(HqlParser.XMLFOREST, 0); }
		public List<PotentiallyAliasedExpressionOrPredicateContext> potentiallyAliasedExpressionOrPredicate() {
			return getRuleContexts(PotentiallyAliasedExpressionOrPredicateContext.class);
		}
		public PotentiallyAliasedExpressionOrPredicateContext potentiallyAliasedExpressionOrPredicate(int i) {
			return getRuleContext(PotentiallyAliasedExpressionOrPredicateContext.class,i);
		}
		public XmlForestFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlForestFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlForestFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlForestFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlForestFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlForestFunctionContext xmlForestFunction() throws RecognitionException {
		XmlForestFunctionContext _localctx = new XmlForestFunctionContext(_ctx, getState());
		enterRule(_localctx, 430, RULE_xmlForestFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2385);
			match(XMLFOREST);
			setState(2386);
			match(T__1);
			setState(2387);
			potentiallyAliasedExpressionOrPredicate();
			setState(2392);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2388);
				match(T__0);
				setState(2389);
				potentiallyAliasedExpressionOrPredicate();
				}
				}
				setState(2394);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(2395);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlPiFunctionContext extends ParserRuleContext {
		public TerminalNode XMLPI() { return getToken(HqlParser.XMLPI, 0); }
		public TerminalNode NAME() { return getToken(HqlParser.NAME, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public XmlPiFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlPiFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlPiFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlPiFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlPiFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlPiFunctionContext xmlPiFunction() throws RecognitionException {
		XmlPiFunctionContext _localctx = new XmlPiFunctionContext(_ctx, getState());
		enterRule(_localctx, 432, RULE_xmlPiFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2397);
			match(XMLPI);
			setState(2398);
			match(T__1);
			setState(2399);
			match(NAME);
			setState(2400);
			identifier();
			setState(2403);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(2401);
				match(T__0);
				setState(2402);
				expression(0);
				}
			}

			setState(2405);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlQueryFunctionContext extends ParserRuleContext {
		public TerminalNode XMLQUERY() { return getToken(HqlParser.XMLQUERY, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode PASSING() { return getToken(HqlParser.PASSING, 0); }
		public XmlQueryFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlQueryFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlQueryFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlQueryFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlQueryFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlQueryFunctionContext xmlQueryFunction() throws RecognitionException {
		XmlQueryFunctionContext _localctx = new XmlQueryFunctionContext(_ctx, getState());
		enterRule(_localctx, 434, RULE_xmlQueryFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2407);
			match(XMLQUERY);
			setState(2408);
			match(T__1);
			setState(2409);
			expression(0);
			setState(2410);
			match(PASSING);
			setState(2411);
			expression(0);
			setState(2412);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlExistsFunctionContext extends ParserRuleContext {
		public TerminalNode XMLEXISTS() { return getToken(HqlParser.XMLEXISTS, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode PASSING() { return getToken(HqlParser.PASSING, 0); }
		public XmlExistsFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlExistsFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlExistsFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlExistsFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlExistsFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlExistsFunctionContext xmlExistsFunction() throws RecognitionException {
		XmlExistsFunctionContext _localctx = new XmlExistsFunctionContext(_ctx, getState());
		enterRule(_localctx, 436, RULE_xmlExistsFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2414);
			match(XMLEXISTS);
			setState(2415);
			match(T__1);
			setState(2416);
			expression(0);
			setState(2417);
			match(PASSING);
			setState(2418);
			expression(0);
			setState(2419);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlAggFunctionContext extends ParserRuleContext {
		public TerminalNode XMLAGG() { return getToken(HqlParser.XMLAGG, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public OrderByClauseContext orderByClause() {
			return getRuleContext(OrderByClauseContext.class,0);
		}
		public FilterClauseContext filterClause() {
			return getRuleContext(FilterClauseContext.class,0);
		}
		public OverClauseContext overClause() {
			return getRuleContext(OverClauseContext.class,0);
		}
		public XmlAggFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlAggFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlAggFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlAggFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlAggFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlAggFunctionContext xmlAggFunction() throws RecognitionException {
		XmlAggFunctionContext _localctx = new XmlAggFunctionContext(_ctx, getState());
		enterRule(_localctx, 438, RULE_xmlAggFunction);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2421);
			match(XMLAGG);
			setState(2422);
			match(T__1);
			setState(2423);
			expression(0);
			setState(2425);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(2424);
				orderByClause();
				}
			}

			setState(2427);
			match(T__2);
			setState(2429);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,274,_ctx) ) {
			case 1:
				{
				setState(2428);
				filterClause();
				}
				break;
			}
			setState(2432);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,275,_ctx) ) {
			case 1:
				{
				setState(2431);
				overClause();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AliasedExpressionOrPredicateContext extends ParserRuleContext {
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public AliasedExpressionOrPredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aliasedExpressionOrPredicate; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAliasedExpressionOrPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAliasedExpressionOrPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAliasedExpressionOrPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AliasedExpressionOrPredicateContext aliasedExpressionOrPredicate() throws RecognitionException {
		AliasedExpressionOrPredicateContext _localctx = new AliasedExpressionOrPredicateContext(_ctx, getState());
		enterRule(_localctx, 440, RULE_aliasedExpressionOrPredicate);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2434);
			expressionOrPredicate();
			setState(2435);
			match(AS);
			setState(2436);
			identifier();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PotentiallyAliasedExpressionOrPredicateContext extends ParserRuleContext {
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public PotentiallyAliasedExpressionOrPredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_potentiallyAliasedExpressionOrPredicate; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterPotentiallyAliasedExpressionOrPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitPotentiallyAliasedExpressionOrPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitPotentiallyAliasedExpressionOrPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PotentiallyAliasedExpressionOrPredicateContext potentiallyAliasedExpressionOrPredicate() throws RecognitionException {
		PotentiallyAliasedExpressionOrPredicateContext _localctx = new PotentiallyAliasedExpressionOrPredicateContext(_ctx, getState());
		enterRule(_localctx, 442, RULE_potentiallyAliasedExpressionOrPredicate);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2438);
			expressionOrPredicate();
			setState(2441);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(2439);
				match(AS);
				setState(2440);
				identifier();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlTableFunctionContext extends ParserRuleContext {
		public TerminalNode XMLTABLE() { return getToken(HqlParser.XMLTABLE, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode PASSING() { return getToken(HqlParser.PASSING, 0); }
		public XmlTableColumnsClauseContext xmlTableColumnsClause() {
			return getRuleContext(XmlTableColumnsClauseContext.class,0);
		}
		public XmlTableFunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlTableFunction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlTableFunction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlTableFunction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlTableFunction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlTableFunctionContext xmlTableFunction() throws RecognitionException {
		XmlTableFunctionContext _localctx = new XmlTableFunctionContext(_ctx, getState());
		enterRule(_localctx, 444, RULE_xmlTableFunction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2443);
			match(XMLTABLE);
			setState(2444);
			match(T__1);
			setState(2445);
			expression(0);
			setState(2446);
			match(PASSING);
			setState(2447);
			expression(0);
			setState(2448);
			xmlTableColumnsClause();
			setState(2449);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlTableColumnsClauseContext extends ParserRuleContext {
		public TerminalNode COLUMNS() { return getToken(HqlParser.COLUMNS, 0); }
		public List<XmlTableColumnContext> xmlTableColumn() {
			return getRuleContexts(XmlTableColumnContext.class);
		}
		public XmlTableColumnContext xmlTableColumn(int i) {
			return getRuleContext(XmlTableColumnContext.class,i);
		}
		public XmlTableColumnsClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlTableColumnsClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlTableColumnsClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlTableColumnsClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlTableColumnsClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlTableColumnsClauseContext xmlTableColumnsClause() throws RecognitionException {
		XmlTableColumnsClauseContext _localctx = new XmlTableColumnsClauseContext(_ctx, getState());
		enterRule(_localctx, 446, RULE_xmlTableColumnsClause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2451);
			match(COLUMNS);
			setState(2452);
			xmlTableColumn();
			setState(2457);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2453);
				match(T__0);
				setState(2454);
				xmlTableColumn();
				}
				}
				setState(2459);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmlTableColumnContext extends ParserRuleContext {
		public XmlTableColumnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmlTableColumn; }
	 
		public XmlTableColumnContext() { }
		public void copyFrom(XmlTableColumnContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class XmlTableQueryColumnContext extends XmlTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode XML() { return getToken(HqlParser.XML, 0); }
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public XmltableDefaultClauseContext xmltableDefaultClause() {
			return getRuleContext(XmltableDefaultClauseContext.class,0);
		}
		public XmlTableQueryColumnContext(XmlTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlTableQueryColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlTableQueryColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlTableQueryColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class XmlTableOrdinalityColumnContext extends XmlTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public TerminalNode ORDINALITY() { return getToken(HqlParser.ORDINALITY, 0); }
		public XmlTableOrdinalityColumnContext(XmlTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlTableOrdinalityColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlTableOrdinalityColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlTableOrdinalityColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class XmlTableValueColumnContext extends XmlTableColumnContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public CastTargetContext castTarget() {
			return getRuleContext(CastTargetContext.class,0);
		}
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public XmltableDefaultClauseContext xmltableDefaultClause() {
			return getRuleContext(XmltableDefaultClauseContext.class,0);
		}
		public XmlTableValueColumnContext(XmlTableColumnContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmlTableValueColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmlTableValueColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmlTableValueColumn(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmlTableColumnContext xmlTableColumn() throws RecognitionException {
		XmlTableColumnContext _localctx = new XmlTableColumnContext(_ctx, getState());
		enterRule(_localctx, 448, RULE_xmlTableColumn);
		int _la;
		try {
			setState(2482);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,282,_ctx) ) {
			case 1:
				_localctx = new XmlTableQueryColumnContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(2460);
				identifier();
				setState(2461);
				match(XML);
				setState(2464);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PATH) {
					{
					setState(2462);
					match(PATH);
					setState(2463);
					match(STRING_LITERAL);
					}
				}

				setState(2467);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DEFAULT) {
					{
					setState(2466);
					xmltableDefaultClause();
					}
				}

				}
				break;
			case 2:
				_localctx = new XmlTableOrdinalityColumnContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(2469);
				identifier();
				setState(2470);
				match(FOR);
				setState(2471);
				match(ORDINALITY);
				}
				break;
			case 3:
				_localctx = new XmlTableValueColumnContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(2473);
				identifier();
				setState(2474);
				castTarget();
				setState(2477);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PATH) {
					{
					setState(2475);
					match(PATH);
					setState(2476);
					match(STRING_LITERAL);
					}
				}

				setState(2480);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DEFAULT) {
					{
					setState(2479);
					xmltableDefaultClause();
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class XmltableDefaultClauseContext extends ParserRuleContext {
		public TerminalNode DEFAULT() { return getToken(HqlParser.DEFAULT, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public XmltableDefaultClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xmltableDefaultClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterXmltableDefaultClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitXmltableDefaultClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitXmltableDefaultClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XmltableDefaultClauseContext xmltableDefaultClause() throws RecognitionException {
		XmltableDefaultClauseContext _localctx = new XmltableDefaultClauseContext(_ctx, getState());
		enterRule(_localctx, 450, RULE_xmltableDefaultClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2484);
			match(DEFAULT);
			setState(2485);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PredicateContext extends ParserRuleContext {
		public PredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_predicate; }
	 
		public PredicateContext() { }
		public void copyFrom(PredicateContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IsDistinctFromPredicateContext extends PredicateContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode IS() { return getToken(HqlParser.IS, 0); }
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public IsDistinctFromPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIsDistinctFromPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIsDistinctFromPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIsDistinctFromPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ContainsPredicateContext extends PredicateContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode CONTAINS() { return getToken(HqlParser.CONTAINS, 0); }
		public TerminalNode INCLUDES() { return getToken(HqlParser.INCLUDES, 0); }
		public TerminalNode INTERSECTS() { return getToken(HqlParser.INTERSECTS, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public ContainsPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterContainsPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitContainsPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitContainsPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IsBooleanPredicateContext extends PredicateContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode IS() { return getToken(HqlParser.IS, 0); }
		public TerminalNode NULL() { return getToken(HqlParser.NULL, 0); }
		public TerminalNode EMPTY() { return getToken(HqlParser.EMPTY, 0); }
		public TerminalNode TRUE() { return getToken(HqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(HqlParser.FALSE, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public IsBooleanPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIsBooleanPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIsBooleanPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIsBooleanPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BetweenPredicateContext extends PredicateContext {
		public BetweenExpressionContext betweenExpression() {
			return getRuleContext(BetweenExpressionContext.class,0);
		}
		public BetweenPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBetweenPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBetweenPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBetweenPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RelationalPredicateContext extends PredicateContext {
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public RelationalPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRelationalPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRelationalPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRelationalPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExistsPredicateContext extends PredicateContext {
		public ExistsExpressionContext existsExpression() {
			return getRuleContext(ExistsExpressionContext.class,0);
		}
		public ExistsPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExistsPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExistsPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExistsPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AndPredicateContext extends PredicateContext {
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public AndPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterAndPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitAndPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitAndPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupedPredicateContext extends PredicateContext {
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public GroupedPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterGroupedPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitGroupedPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitGroupedPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LikePredicateContext extends PredicateContext {
		public StringPatternMatchingContext stringPatternMatching() {
			return getRuleContext(StringPatternMatchingContext.class,0);
		}
		public LikePredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterLikePredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitLikePredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitLikePredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class InPredicateContext extends PredicateContext {
		public InExpressionContext inExpression() {
			return getRuleContext(InExpressionContext.class,0);
		}
		public InPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotPredicateContext extends PredicateContext {
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public NotPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNotPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNotPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNotPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionPredicateContext extends PredicateContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ExpressionPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExpressionPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExpressionPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExpressionPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OrPredicateContext extends PredicateContext {
		public List<PredicateContext> predicate() {
			return getRuleContexts(PredicateContext.class);
		}
		public PredicateContext predicate(int i) {
			return getRuleContext(PredicateContext.class,i);
		}
		public TerminalNode OR() { return getToken(HqlParser.OR, 0); }
		public OrPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterOrPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitOrPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitOrPredicate(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MemberOfPredicateContext extends PredicateContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode MEMBER() { return getToken(HqlParser.MEMBER, 0); }
		public PathContext path() {
			return getRuleContext(PathContext.class,0);
		}
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public MemberOfPredicateContext(PredicateContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterMemberOfPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitMemberOfPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitMemberOfPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PredicateContext predicate() throws RecognitionException {
		return predicate(0);
	}

	private PredicateContext predicate(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		PredicateContext _localctx = new PredicateContext(_ctx, _parentState);
		PredicateContext _prevctx = _localctx;
		int _startState = 452;
		enterRecursionRule(_localctx, 452, RULE_predicate, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(2533);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,288,_ctx) ) {
			case 1:
				{
				_localctx = new GroupedPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(2488);
				match(T__1);
				setState(2489);
				predicate(0);
				setState(2490);
				match(T__2);
				}
				break;
			case 2:
				{
				_localctx = new IsBooleanPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2492);
				expression(0);
				setState(2493);
				match(IS);
				setState(2495);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(2494);
					match(NOT);
					}
				}

				setState(2497);
				_la = _input.LA(1);
				if ( !(_la==EMPTY || ((((_la - 232)) & ~0x3f) == 0 && ((1L << (_la - 232)) & 7L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case 3:
				{
				_localctx = new IsDistinctFromPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2499);
				expression(0);
				setState(2500);
				match(IS);
				setState(2502);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(2501);
					match(NOT);
					}
				}

				setState(2504);
				match(DISTINCT);
				setState(2505);
				match(FROM);
				setState(2506);
				expression(0);
				}
				break;
			case 4:
				{
				_localctx = new MemberOfPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2508);
				expression(0);
				setState(2510);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(2509);
					match(NOT);
					}
				}

				setState(2512);
				match(MEMBER);
				setState(2514);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,286,_ctx) ) {
				case 1:
					{
					setState(2513);
					match(OF);
					}
					break;
				}
				setState(2516);
				path();
				}
				break;
			case 5:
				{
				_localctx = new InPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2518);
				inExpression();
				}
				break;
			case 6:
				{
				_localctx = new BetweenPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2519);
				betweenExpression();
				}
				break;
			case 7:
				{
				_localctx = new ContainsPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2520);
				expression(0);
				setState(2522);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(2521);
					match(NOT);
					}
				}

				setState(2524);
				_la = _input.LA(1);
				if ( !(((((_la - 50)) & ~0x3f) == 0 && ((1L << (_la - 50)) & 72620543991349249L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2525);
				expression(0);
				}
				break;
			case 8:
				{
				_localctx = new RelationalPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2527);
				relationalExpression();
				}
				break;
			case 9:
				{
				_localctx = new LikePredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2528);
				stringPatternMatching();
				}
				break;
			case 10:
				{
				_localctx = new ExistsPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2529);
				existsExpression();
				}
				break;
			case 11:
				{
				_localctx = new NotPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2530);
				match(NOT);
				setState(2531);
				predicate(4);
				}
				break;
			case 12:
				{
				_localctx = new ExpressionPredicateContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(2532);
				expression(0);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(2543);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,290,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(2541);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,289,_ctx) ) {
					case 1:
						{
						_localctx = new AndPredicateContext(new PredicateContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_predicate);
						setState(2535);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(2536);
						match(AND);
						setState(2537);
						predicate(4);
						}
						break;
					case 2:
						{
						_localctx = new OrPredicateContext(new PredicateContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_predicate);
						setState(2538);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(2539);
						match(OR);
						setState(2540);
						predicate(3);
						}
						break;
					}
					} 
				}
				setState(2545);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,290,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionOrPredicateContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public ExpressionOrPredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionOrPredicate; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExpressionOrPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExpressionOrPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExpressionOrPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionOrPredicateContext expressionOrPredicate() throws RecognitionException {
		ExpressionOrPredicateContext _localctx = new ExpressionOrPredicateContext(_ctx, getState());
		enterRule(_localctx, 454, RULE_expressionOrPredicate);
		try {
			setState(2548);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,291,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2546);
				expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2547);
				predicate(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionQuantifierContext extends ParserRuleContext {
		public ElementsValuesQuantifierContext elementsValuesQuantifier() {
			return getRuleContext(ElementsValuesQuantifierContext.class,0);
		}
		public IndicesKeysQuantifierContext indicesKeysQuantifier() {
			return getRuleContext(IndicesKeysQuantifierContext.class,0);
		}
		public CollectionQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collectionQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterCollectionQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitCollectionQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitCollectionQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionQuantifierContext collectionQuantifier() throws RecognitionException {
		CollectionQuantifierContext _localctx = new CollectionQuantifierContext(_ctx, getState());
		enterRule(_localctx, 456, RULE_collectionQuantifier);
		try {
			setState(2552);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ELEMENTS:
			case VALUES:
				enterOuterAlt(_localctx, 1);
				{
				setState(2550);
				elementsValuesQuantifier();
				}
				break;
			case INDICES:
			case KEYS:
				enterOuterAlt(_localctx, 2);
				{
				setState(2551);
				indicesKeysQuantifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElementsValuesQuantifierContext extends ParserRuleContext {
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode VALUES() { return getToken(HqlParser.VALUES, 0); }
		public ElementsValuesQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elementsValuesQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterElementsValuesQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitElementsValuesQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitElementsValuesQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementsValuesQuantifierContext elementsValuesQuantifier() throws RecognitionException {
		ElementsValuesQuantifierContext _localctx = new ElementsValuesQuantifierContext(_ctx, getState());
		enterRule(_localctx, 458, RULE_elementsValuesQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2554);
			_la = _input.LA(1);
			if ( !(_la==ELEMENTS || _la==VALUES) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElementValueQuantifierContext extends ParserRuleContext {
		public TerminalNode ELEMENT() { return getToken(HqlParser.ELEMENT, 0); }
		public TerminalNode VALUE() { return getToken(HqlParser.VALUE, 0); }
		public ElementValueQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elementValueQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterElementValueQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitElementValueQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitElementValueQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElementValueQuantifierContext elementValueQuantifier() throws RecognitionException {
		ElementValueQuantifierContext _localctx = new ElementValueQuantifierContext(_ctx, getState());
		enterRule(_localctx, 460, RULE_elementValueQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2556);
			_la = _input.LA(1);
			if ( !(_la==ELEMENT || _la==VALUE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IndexKeyQuantifierContext extends ParserRuleContext {
		public TerminalNode INDEX() { return getToken(HqlParser.INDEX, 0); }
		public TerminalNode KEY() { return getToken(HqlParser.KEY, 0); }
		public IndexKeyQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_indexKeyQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndexKeyQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndexKeyQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndexKeyQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IndexKeyQuantifierContext indexKeyQuantifier() throws RecognitionException {
		IndexKeyQuantifierContext _localctx = new IndexKeyQuantifierContext(_ctx, getState());
		enterRule(_localctx, 462, RULE_indexKeyQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2558);
			_la = _input.LA(1);
			if ( !(_la==INDEX || _la==KEY) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IndicesKeysQuantifierContext extends ParserRuleContext {
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public TerminalNode KEYS() { return getToken(HqlParser.KEYS, 0); }
		public IndicesKeysQuantifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_indicesKeysQuantifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIndicesKeysQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIndicesKeysQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIndicesKeysQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IndicesKeysQuantifierContext indicesKeysQuantifier() throws RecognitionException {
		IndicesKeysQuantifierContext _localctx = new IndicesKeysQuantifierContext(_ctx, getState());
		enterRule(_localctx, 464, RULE_indicesKeysQuantifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2560);
			_la = _input.LA(1);
			if ( !(_la==INDICES || _la==KEYS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RelationalExpressionContext extends ParserRuleContext {
		public Token op;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public RelationalExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relationalExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterRelationalExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitRelationalExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitRelationalExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RelationalExpressionContext relationalExpression() throws RecognitionException {
		RelationalExpressionContext _localctx = new RelationalExpressionContext(_ctx, getState());
		enterRule(_localctx, 466, RULE_relationalExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2562);
			expression(0);
			setState(2563);
			((RelationalExpressionContext)_localctx).op = _input.LT(1);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 2080784L) != 0)) ) {
				((RelationalExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2564);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BetweenExpressionContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode BETWEEN() { return getToken(HqlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public BetweenExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_betweenExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterBetweenExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitBetweenExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitBetweenExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BetweenExpressionContext betweenExpression() throws RecognitionException {
		BetweenExpressionContext _localctx = new BetweenExpressionContext(_ctx, getState());
		enterRule(_localctx, 468, RULE_betweenExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2566);
			expression(0);
			setState(2568);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(2567);
				match(NOT);
				}
			}

			setState(2570);
			match(BETWEEN);
			setState(2571);
			expression(0);
			setState(2572);
			match(AND);
			setState(2573);
			expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StringPatternMatchingContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode LIKE() { return getToken(HqlParser.LIKE, 0); }
		public TerminalNode ILIKE() { return getToken(HqlParser.ILIKE, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public TerminalNode ESCAPE() { return getToken(HqlParser.ESCAPE, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(HqlParser.STRING_LITERAL, 0); }
		public TerminalNode JAVA_STRING_LITERAL() { return getToken(HqlParser.JAVA_STRING_LITERAL, 0); }
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public StringPatternMatchingContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringPatternMatching; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterStringPatternMatching(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitStringPatternMatching(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitStringPatternMatching(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringPatternMatchingContext stringPatternMatching() throws RecognitionException {
		StringPatternMatchingContext _localctx = new StringPatternMatchingContext(_ctx, getState());
		enterRule(_localctx, 470, RULE_stringPatternMatching);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2575);
			expression(0);
			setState(2577);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(2576);
				match(NOT);
				}
			}

			setState(2579);
			_la = _input.LA(1);
			if ( !(_la==ILIKE || _la==LIKE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(2580);
			expression(0);
			setState(2587);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,296,_ctx) ) {
			case 1:
				{
				setState(2581);
				match(ESCAPE);
				setState(2585);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case STRING_LITERAL:
					{
					setState(2582);
					match(STRING_LITERAL);
					}
					break;
				case JAVA_STRING_LITERAL:
					{
					setState(2583);
					match(JAVA_STRING_LITERAL);
					}
					break;
				case T__8:
				case T__20:
					{
					setState(2584);
					parameter();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InExpressionContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public InListContext inList() {
			return getRuleContext(InListContext.class,0);
		}
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public InExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InExpressionContext inExpression() throws RecognitionException {
		InExpressionContext _localctx = new InExpressionContext(_ctx, getState());
		enterRule(_localctx, 472, RULE_inExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2589);
			expression(0);
			setState(2591);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(2590);
				match(NOT);
				}
			}

			setState(2593);
			match(IN);
			setState(2594);
			inList();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InListContext extends ParserRuleContext {
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public List<ExpressionOrPredicateContext> expressionOrPredicate() {
			return getRuleContexts(ExpressionOrPredicateContext.class);
		}
		public ExpressionOrPredicateContext expressionOrPredicate(int i) {
			return getRuleContext(ExpressionOrPredicateContext.class,i);
		}
		public InListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inList; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InListContext inList() throws RecognitionException {
		InListContext _localctx = new InListContext(_ctx, getState());
		enterRule(_localctx, 474, RULE_inList);
		int _la;
		try {
			setState(2618);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,300,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2596);
				_la = _input.LA(1);
				if ( !(_la==ELEMENTS || _la==INDICES) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2597);
				match(T__1);
				setState(2598);
				simplePath();
				setState(2599);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2601);
				match(T__1);
				setState(2602);
				subquery();
				setState(2603);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2605);
				parameter();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2606);
				match(T__1);
				setState(2615);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -31454588L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -1L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 1152921504606846975L) != 0)) {
					{
					setState(2607);
					expressionOrPredicate();
					setState(2612);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__0) {
						{
						{
						setState(2608);
						match(T__0);
						setState(2609);
						expressionOrPredicate();
						}
						}
						setState(2614);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(2617);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExistsExpressionContext extends ParserRuleContext {
		public TerminalNode EXISTS() { return getToken(HqlParser.EXISTS, 0); }
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ExistsExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_existsExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterExistsExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitExistsExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitExistsExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExistsExpressionContext existsExpression() throws RecognitionException {
		ExistsExpressionContext _localctx = new ExistsExpressionContext(_ctx, getState());
		enterRule(_localctx, 476, RULE_existsExpression);
		int _la;
		try {
			setState(2628);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,301,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2620);
				match(EXISTS);
				setState(2621);
				_la = _input.LA(1);
				if ( !(_la==ELEMENTS || _la==INDICES) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(2622);
				match(T__1);
				setState(2623);
				simplePath();
				setState(2624);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2626);
				match(EXISTS);
				setState(2627);
				expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationTargetContext extends ParserRuleContext {
		public TerminalNode LIST() { return getToken(HqlParser.LIST, 0); }
		public TerminalNode MAP() { return getToken(HqlParser.MAP, 0); }
		public SimplePathContext simplePath() {
			return getRuleContext(SimplePathContext.class,0);
		}
		public InstantiationTargetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiationTarget; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiationTarget(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiationTarget(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiationTarget(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationTargetContext instantiationTarget() throws RecognitionException {
		InstantiationTargetContext _localctx = new InstantiationTargetContext(_ctx, getState());
		enterRule(_localctx, 478, RULE_instantiationTarget);
		try {
			setState(2633);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,302,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2630);
				match(LIST);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2631);
				match(MAP);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2632);
				simplePath();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationArgumentsContext extends ParserRuleContext {
		public List<InstantiationArgumentContext> instantiationArgument() {
			return getRuleContexts(InstantiationArgumentContext.class);
		}
		public InstantiationArgumentContext instantiationArgument(int i) {
			return getRuleContext(InstantiationArgumentContext.class,i);
		}
		public InstantiationArgumentsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiationArguments; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiationArguments(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiationArguments(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiationArguments(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationArgumentsContext instantiationArguments() throws RecognitionException {
		InstantiationArgumentsContext _localctx = new InstantiationArgumentsContext(_ctx, getState());
		enterRule(_localctx, 480, RULE_instantiationArguments);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2635);
			instantiationArgument();
			setState(2640);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(2636);
				match(T__0);
				setState(2637);
				instantiationArgument();
				}
				}
				setState(2642);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class InstantiationArgumentContext extends ParserRuleContext {
		public ExpressionOrPredicateContext expressionOrPredicate() {
			return getRuleContext(ExpressionOrPredicateContext.class,0);
		}
		public InstantiationContext instantiation() {
			return getRuleContext(InstantiationContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public InstantiationArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instantiationArgument; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterInstantiationArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitInstantiationArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitInstantiationArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstantiationArgumentContext instantiationArgument() throws RecognitionException {
		InstantiationArgumentContext _localctx = new InstantiationArgumentContext(_ctx, getState());
		enterRule(_localctx, 482, RULE_instantiationArgument);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2645);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,304,_ctx) ) {
			case 1:
				{
				setState(2643);
				expressionOrPredicate();
				}
				break;
			case 2:
				{
				setState(2644);
				instantiation();
				}
				break;
			}
			setState(2648);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -33554432L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1152921779551862785L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -137438953473L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 864692227966763007L) != 0)) {
				{
				setState(2647);
				variable();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterOrIntegerLiteralContext extends ParserRuleContext {
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ParameterOrIntegerLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterOrIntegerLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameterOrIntegerLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameterOrIntegerLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameterOrIntegerLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterOrIntegerLiteralContext parameterOrIntegerLiteral() throws RecognitionException {
		ParameterOrIntegerLiteralContext _localctx = new ParameterOrIntegerLiteralContext(_ctx, getState());
		enterRule(_localctx, 484, RULE_parameterOrIntegerLiteral);
		try {
			setState(2652);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__8:
			case T__20:
				enterOuterAlt(_localctx, 1);
				{
				setState(2650);
				parameter();
				}
				break;
			case INTEGER_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(2651);
				match(INTEGER_LITERAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterOrNumberLiteralContext extends ParserRuleContext {
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public NumericLiteralContext numericLiteral() {
			return getRuleContext(NumericLiteralContext.class,0);
		}
		public ParameterOrNumberLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameterOrNumberLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameterOrNumberLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameterOrNumberLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameterOrNumberLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterOrNumberLiteralContext parameterOrNumberLiteral() throws RecognitionException {
		ParameterOrNumberLiteralContext _localctx = new ParameterOrNumberLiteralContext(_ctx, getState());
		enterRule(_localctx, 486, RULE_parameterOrNumberLiteral);
		try {
			setState(2656);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__8:
			case T__20:
				enterOuterAlt(_localctx, 1);
				{
				setState(2654);
				parameter();
				}
				break;
			case INTEGER_LITERAL:
			case LONG_LITERAL:
			case FLOAT_LITERAL:
			case DOUBLE_LITERAL:
			case BIG_INTEGER_LITERAL:
			case BIG_DECIMAL_LITERAL:
			case HEX_LITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(2655);
				numericLiteral();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VariableContext extends ParserRuleContext {
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public NakedIdentifierContext nakedIdentifier() {
			return getRuleContext(NakedIdentifierContext.class,0);
		}
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitVariable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 488, RULE_variable);
		try {
			setState(2661);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,308,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2658);
				match(AS);
				setState(2659);
				identifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2660);
				nakedIdentifier();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterContext extends ParserRuleContext {
		public Token prefix;
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(HqlParser.INTEGER_LITERAL, 0); }
		public ParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterParameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitParameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParameterContext parameter() throws RecognitionException {
		ParameterContext _localctx = new ParameterContext(_ctx, getState());
		enterRule(_localctx, 490, RULE_parameter);
		try {
			setState(2669);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__8:
				enterOuterAlt(_localctx, 1);
				{
				setState(2663);
				((ParameterContext)_localctx).prefix = match(T__8);
				setState(2664);
				identifier();
				}
				break;
			case T__20:
				enterOuterAlt(_localctx, 2);
				{
				setState(2665);
				((ParameterContext)_localctx).prefix = match(T__20);
				setState(2667);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,309,_ctx) ) {
				case 1:
					{
					setState(2666);
					match(INTEGER_LITERAL);
					}
					break;
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EntityNameContext extends ParserRuleContext {
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public EntityNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entityName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterEntityName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitEntityName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitEntityName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EntityNameContext entityName() throws RecognitionException {
		EntityNameContext _localctx = new EntityNameContext(_ctx, getState());
		enterRule(_localctx, 492, RULE_entityName);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2671);
			identifier();
			setState(2676);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__12) {
				{
				{
				setState(2672);
				match(T__12);
				setState(2673);
				identifier();
				}
				}
				setState(2678);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NakedIdentifierContext extends ParserRuleContext {
		public Token f;
		public TerminalNode IDENTIFIER() { return getToken(HqlParser.IDENTIFIER, 0); }
		public TerminalNode QUOTED_IDENTIFIER() { return getToken(HqlParser.QUOTED_IDENTIFIER, 0); }
		public TerminalNode ABSENT() { return getToken(HqlParser.ABSENT, 0); }
		public TerminalNode ALL() { return getToken(HqlParser.ALL, 0); }
		public TerminalNode AND() { return getToken(HqlParser.AND, 0); }
		public TerminalNode ANY() { return getToken(HqlParser.ANY, 0); }
		public TerminalNode ARRAY() { return getToken(HqlParser.ARRAY, 0); }
		public TerminalNode AS() { return getToken(HqlParser.AS, 0); }
		public TerminalNode ASC() { return getToken(HqlParser.ASC, 0); }
		public TerminalNode AVG() { return getToken(HqlParser.AVG, 0); }
		public TerminalNode BETWEEN() { return getToken(HqlParser.BETWEEN, 0); }
		public TerminalNode BOTH() { return getToken(HqlParser.BOTH, 0); }
		public TerminalNode BREADTH() { return getToken(HqlParser.BREADTH, 0); }
		public TerminalNode BY() { return getToken(HqlParser.BY, 0); }
		public TerminalNode CASE() { return getToken(HqlParser.CASE, 0); }
		public TerminalNode CAST() { return getToken(HqlParser.CAST, 0); }
		public TerminalNode COLLATE() { return getToken(HqlParser.COLLATE, 0); }
		public TerminalNode COLUMN() { return getToken(HqlParser.COLUMN, 0); }
		public TerminalNode COLUMNS() { return getToken(HqlParser.COLUMNS, 0); }
		public TerminalNode CONDITIONAL() { return getToken(HqlParser.CONDITIONAL, 0); }
		public TerminalNode CONFLICT() { return getToken(HqlParser.CONFLICT, 0); }
		public TerminalNode CONSTRAINT() { return getToken(HqlParser.CONSTRAINT, 0); }
		public TerminalNode CONTAINS() { return getToken(HqlParser.CONTAINS, 0); }
		public TerminalNode COUNT() { return getToken(HqlParser.COUNT, 0); }
		public TerminalNode CROSS() { return getToken(HqlParser.CROSS, 0); }
		public TerminalNode CUBE() { return getToken(HqlParser.CUBE, 0); }
		public TerminalNode CURRENT() { return getToken(HqlParser.CURRENT, 0); }
		public TerminalNode CURRENT_DATE() { return getToken(HqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT_INSTANT() { return getToken(HqlParser.CURRENT_INSTANT, 0); }
		public TerminalNode CURRENT_TIME() { return getToken(HqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(HqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode CYCLE() { return getToken(HqlParser.CYCLE, 0); }
		public TerminalNode DATE() { return getToken(HqlParser.DATE, 0); }
		public TerminalNode DATETIME() { return getToken(HqlParser.DATETIME, 0); }
		public TerminalNode DAY() { return getToken(HqlParser.DAY, 0); }
		public TerminalNode DEFAULT() { return getToken(HqlParser.DEFAULT, 0); }
		public TerminalNode DELETE() { return getToken(HqlParser.DELETE, 0); }
		public TerminalNode DEPTH() { return getToken(HqlParser.DEPTH, 0); }
		public TerminalNode DESC() { return getToken(HqlParser.DESC, 0); }
		public TerminalNode DISTINCT() { return getToken(HqlParser.DISTINCT, 0); }
		public TerminalNode DO() { return getToken(HqlParser.DO, 0); }
		public TerminalNode ELEMENT() { return getToken(HqlParser.ELEMENT, 0); }
		public TerminalNode ELEMENTS() { return getToken(HqlParser.ELEMENTS, 0); }
		public TerminalNode ELSE() { return getToken(HqlParser.ELSE, 0); }
		public TerminalNode EMPTY() { return getToken(HqlParser.EMPTY, 0); }
		public TerminalNode END() { return getToken(HqlParser.END, 0); }
		public TerminalNode ENTRY() { return getToken(HqlParser.ENTRY, 0); }
		public TerminalNode EPOCH() { return getToken(HqlParser.EPOCH, 0); }
		public TerminalNode ERROR() { return getToken(HqlParser.ERROR, 0); }
		public TerminalNode ESCAPE() { return getToken(HqlParser.ESCAPE, 0); }
		public TerminalNode EVERY() { return getToken(HqlParser.EVERY, 0); }
		public TerminalNode EXCEPT() { return getToken(HqlParser.EXCEPT, 0); }
		public TerminalNode EXCLUDE() { return getToken(HqlParser.EXCLUDE, 0); }
		public TerminalNode EXISTS() { return getToken(HqlParser.EXISTS, 0); }
		public TerminalNode EXTRACT() { return getToken(HqlParser.EXTRACT, 0); }
		public TerminalNode FETCH() { return getToken(HqlParser.FETCH, 0); }
		public TerminalNode FILTER() { return getToken(HqlParser.FILTER, 0); }
		public TerminalNode FIRST() { return getToken(HqlParser.FIRST, 0); }
		public TerminalNode FK() { return getToken(HqlParser.FK, 0); }
		public TerminalNode FOLLOWING() { return getToken(HqlParser.FOLLOWING, 0); }
		public TerminalNode FOR() { return getToken(HqlParser.FOR, 0); }
		public TerminalNode FORMAT() { return getToken(HqlParser.FORMAT, 0); }
		public TerminalNode FROM() { return getToken(HqlParser.FROM, 0); }
		public TerminalNode FUNCTION() { return getToken(HqlParser.FUNCTION, 0); }
		public TerminalNode GROUP() { return getToken(HqlParser.GROUP, 0); }
		public TerminalNode GROUPS() { return getToken(HqlParser.GROUPS, 0); }
		public TerminalNode HAVING() { return getToken(HqlParser.HAVING, 0); }
		public TerminalNode HOUR() { return getToken(HqlParser.HOUR, 0); }
		public TerminalNode ID() { return getToken(HqlParser.ID, 0); }
		public TerminalNode IGNORE() { return getToken(HqlParser.IGNORE, 0); }
		public TerminalNode ILIKE() { return getToken(HqlParser.ILIKE, 0); }
		public TerminalNode IN() { return getToken(HqlParser.IN, 0); }
		public TerminalNode INDEX() { return getToken(HqlParser.INDEX, 0); }
		public TerminalNode INCLUDES() { return getToken(HqlParser.INCLUDES, 0); }
		public TerminalNode INDICES() { return getToken(HqlParser.INDICES, 0); }
		public TerminalNode INSERT() { return getToken(HqlParser.INSERT, 0); }
		public TerminalNode INSTANT() { return getToken(HqlParser.INSTANT, 0); }
		public TerminalNode INTERSECT() { return getToken(HqlParser.INTERSECT, 0); }
		public TerminalNode INTERSECTS() { return getToken(HqlParser.INTERSECTS, 0); }
		public TerminalNode INTO() { return getToken(HqlParser.INTO, 0); }
		public TerminalNode IS() { return getToken(HqlParser.IS, 0); }
		public TerminalNode JOIN() { return getToken(HqlParser.JOIN, 0); }
		public TerminalNode JSON() { return getToken(HqlParser.JSON, 0); }
		public TerminalNode JSON_ARRAY() { return getToken(HqlParser.JSON_ARRAY, 0); }
		public TerminalNode JSON_ARRAYAGG() { return getToken(HqlParser.JSON_ARRAYAGG, 0); }
		public TerminalNode JSON_EXISTS() { return getToken(HqlParser.JSON_EXISTS, 0); }
		public TerminalNode JSON_OBJECT() { return getToken(HqlParser.JSON_OBJECT, 0); }
		public TerminalNode JSON_OBJECTAGG() { return getToken(HqlParser.JSON_OBJECTAGG, 0); }
		public TerminalNode JSON_QUERY() { return getToken(HqlParser.JSON_QUERY, 0); }
		public TerminalNode JSON_TABLE() { return getToken(HqlParser.JSON_TABLE, 0); }
		public TerminalNode JSON_VALUE() { return getToken(HqlParser.JSON_VALUE, 0); }
		public TerminalNode KEY() { return getToken(HqlParser.KEY, 0); }
		public TerminalNode KEYS() { return getToken(HqlParser.KEYS, 0); }
		public TerminalNode LAST() { return getToken(HqlParser.LAST, 0); }
		public TerminalNode LATERAL() { return getToken(HqlParser.LATERAL, 0); }
		public TerminalNode LEADING() { return getToken(HqlParser.LEADING, 0); }
		public TerminalNode LIKE() { return getToken(HqlParser.LIKE, 0); }
		public TerminalNode LIMIT() { return getToken(HqlParser.LIMIT, 0); }
		public TerminalNode LIST() { return getToken(HqlParser.LIST, 0); }
		public TerminalNode LISTAGG() { return getToken(HqlParser.LISTAGG, 0); }
		public TerminalNode LOCAL() { return getToken(HqlParser.LOCAL, 0); }
		public TerminalNode LOCAL_DATE() { return getToken(HqlParser.LOCAL_DATE, 0); }
		public TerminalNode LOCAL_DATETIME() { return getToken(HqlParser.LOCAL_DATETIME, 0); }
		public TerminalNode LOCAL_TIME() { return getToken(HqlParser.LOCAL_TIME, 0); }
		public TerminalNode MAP() { return getToken(HqlParser.MAP, 0); }
		public TerminalNode MATERIALIZED() { return getToken(HqlParser.MATERIALIZED, 0); }
		public TerminalNode MAX() { return getToken(HqlParser.MAX, 0); }
		public TerminalNode MAXELEMENT() { return getToken(HqlParser.MAXELEMENT, 0); }
		public TerminalNode MAXINDEX() { return getToken(HqlParser.MAXINDEX, 0); }
		public TerminalNode MEMBER() { return getToken(HqlParser.MEMBER, 0); }
		public TerminalNode MICROSECOND() { return getToken(HqlParser.MICROSECOND, 0); }
		public TerminalNode MILLISECOND() { return getToken(HqlParser.MILLISECOND, 0); }
		public TerminalNode MIN() { return getToken(HqlParser.MIN, 0); }
		public TerminalNode MINELEMENT() { return getToken(HqlParser.MINELEMENT, 0); }
		public TerminalNode MININDEX() { return getToken(HqlParser.MININDEX, 0); }
		public TerminalNode MINUTE() { return getToken(HqlParser.MINUTE, 0); }
		public TerminalNode MONTH() { return getToken(HqlParser.MONTH, 0); }
		public TerminalNode NAME() { return getToken(HqlParser.NAME, 0); }
		public TerminalNode NANOSECOND() { return getToken(HqlParser.NANOSECOND, 0); }
		public TerminalNode NATURALID() { return getToken(HqlParser.NATURALID, 0); }
		public TerminalNode NEW() { return getToken(HqlParser.NEW, 0); }
		public TerminalNode NESTED() { return getToken(HqlParser.NESTED, 0); }
		public TerminalNode NEXT() { return getToken(HqlParser.NEXT, 0); }
		public TerminalNode NO() { return getToken(HqlParser.NO, 0); }
		public TerminalNode NOT() { return getToken(HqlParser.NOT, 0); }
		public TerminalNode NOTHING() { return getToken(HqlParser.NOTHING, 0); }
		public TerminalNode NULLS() { return getToken(HqlParser.NULLS, 0); }
		public TerminalNode OBJECT() { return getToken(HqlParser.OBJECT, 0); }
		public TerminalNode OF() { return getToken(HqlParser.OF, 0); }
		public TerminalNode OFFSET() { return getToken(HqlParser.OFFSET, 0); }
		public TerminalNode OFFSET_DATETIME() { return getToken(HqlParser.OFFSET_DATETIME, 0); }
		public TerminalNode ON() { return getToken(HqlParser.ON, 0); }
		public TerminalNode ONLY() { return getToken(HqlParser.ONLY, 0); }
		public TerminalNode OR() { return getToken(HqlParser.OR, 0); }
		public TerminalNode ORDER() { return getToken(HqlParser.ORDER, 0); }
		public TerminalNode ORDINALITY() { return getToken(HqlParser.ORDINALITY, 0); }
		public TerminalNode OTHERS() { return getToken(HqlParser.OTHERS, 0); }
		public TerminalNode OVER() { return getToken(HqlParser.OVER, 0); }
		public TerminalNode OVERFLOW() { return getToken(HqlParser.OVERFLOW, 0); }
		public TerminalNode OVERLAY() { return getToken(HqlParser.OVERLAY, 0); }
		public TerminalNode PAD() { return getToken(HqlParser.PAD, 0); }
		public TerminalNode PATH() { return getToken(HqlParser.PATH, 0); }
		public TerminalNode PARTITION() { return getToken(HqlParser.PARTITION, 0); }
		public TerminalNode PASSING() { return getToken(HqlParser.PASSING, 0); }
		public TerminalNode PERCENT() { return getToken(HqlParser.PERCENT, 0); }
		public TerminalNode PLACING() { return getToken(HqlParser.PLACING, 0); }
		public TerminalNode POSITION() { return getToken(HqlParser.POSITION, 0); }
		public TerminalNode PRECEDING() { return getToken(HqlParser.PRECEDING, 0); }
		public TerminalNode QUARTER() { return getToken(HqlParser.QUARTER, 0); }
		public TerminalNode RANGE() { return getToken(HqlParser.RANGE, 0); }
		public TerminalNode RESPECT() { return getToken(HqlParser.RESPECT, 0); }
		public TerminalNode RETURNING() { return getToken(HqlParser.RETURNING, 0); }
		public TerminalNode RIGHT() { return getToken(HqlParser.RIGHT, 0); }
		public TerminalNode ROLLUP() { return getToken(HqlParser.ROLLUP, 0); }
		public TerminalNode ROW() { return getToken(HqlParser.ROW, 0); }
		public TerminalNode ROWS() { return getToken(HqlParser.ROWS, 0); }
		public TerminalNode SEARCH() { return getToken(HqlParser.SEARCH, 0); }
		public TerminalNode SECOND() { return getToken(HqlParser.SECOND, 0); }
		public TerminalNode SELECT() { return getToken(HqlParser.SELECT, 0); }
		public TerminalNode SET() { return getToken(HqlParser.SET, 0); }
		public TerminalNode SIZE() { return getToken(HqlParser.SIZE, 0); }
		public TerminalNode SOME() { return getToken(HqlParser.SOME, 0); }
		public TerminalNode SUBSTRING() { return getToken(HqlParser.SUBSTRING, 0); }
		public TerminalNode SUM() { return getToken(HqlParser.SUM, 0); }
		public TerminalNode THEN() { return getToken(HqlParser.THEN, 0); }
		public TerminalNode TIES() { return getToken(HqlParser.TIES, 0); }
		public TerminalNode TIME() { return getToken(HqlParser.TIME, 0); }
		public TerminalNode TIMESTAMP() { return getToken(HqlParser.TIMESTAMP, 0); }
		public TerminalNode TIMEZONE_HOUR() { return getToken(HqlParser.TIMEZONE_HOUR, 0); }
		public TerminalNode TIMEZONE_MINUTE() { return getToken(HqlParser.TIMEZONE_MINUTE, 0); }
		public TerminalNode TO() { return getToken(HqlParser.TO, 0); }
		public TerminalNode TRAILING() { return getToken(HqlParser.TRAILING, 0); }
		public TerminalNode TREAT() { return getToken(HqlParser.TREAT, 0); }
		public TerminalNode TRIM() { return getToken(HqlParser.TRIM, 0); }
		public TerminalNode TRUNC() { return getToken(HqlParser.TRUNC, 0); }
		public TerminalNode TRUNCATE() { return getToken(HqlParser.TRUNCATE, 0); }
		public TerminalNode TYPE() { return getToken(HqlParser.TYPE, 0); }
		public TerminalNode UNBOUNDED() { return getToken(HqlParser.UNBOUNDED, 0); }
		public TerminalNode UNCONDITIONAL() { return getToken(HqlParser.UNCONDITIONAL, 0); }
		public TerminalNode UNION() { return getToken(HqlParser.UNION, 0); }
		public TerminalNode UNIQUE() { return getToken(HqlParser.UNIQUE, 0); }
		public TerminalNode UPDATE() { return getToken(HqlParser.UPDATE, 0); }
		public TerminalNode USING() { return getToken(HqlParser.USING, 0); }
		public TerminalNode VALUE() { return getToken(HqlParser.VALUE, 0); }
		public TerminalNode VALUES() { return getToken(HqlParser.VALUES, 0); }
		public TerminalNode VERSION() { return getToken(HqlParser.VERSION, 0); }
		public TerminalNode VERSIONED() { return getToken(HqlParser.VERSIONED, 0); }
		public TerminalNode WEEK() { return getToken(HqlParser.WEEK, 0); }
		public TerminalNode WHEN() { return getToken(HqlParser.WHEN, 0); }
		public TerminalNode WHERE() { return getToken(HqlParser.WHERE, 0); }
		public TerminalNode WITH() { return getToken(HqlParser.WITH, 0); }
		public TerminalNode WITHIN() { return getToken(HqlParser.WITHIN, 0); }
		public TerminalNode WITHOUT() { return getToken(HqlParser.WITHOUT, 0); }
		public TerminalNode WRAPPER() { return getToken(HqlParser.WRAPPER, 0); }
		public TerminalNode XML() { return getToken(HqlParser.XML, 0); }
		public TerminalNode XMLAGG() { return getToken(HqlParser.XMLAGG, 0); }
		public TerminalNode XMLATTRIBUTES() { return getToken(HqlParser.XMLATTRIBUTES, 0); }
		public TerminalNode XMLELEMENT() { return getToken(HqlParser.XMLELEMENT, 0); }
		public TerminalNode XMLEXISTS() { return getToken(HqlParser.XMLEXISTS, 0); }
		public TerminalNode XMLFOREST() { return getToken(HqlParser.XMLFOREST, 0); }
		public TerminalNode XMLPI() { return getToken(HqlParser.XMLPI, 0); }
		public TerminalNode XMLQUERY() { return getToken(HqlParser.XMLQUERY, 0); }
		public TerminalNode XMLTABLE() { return getToken(HqlParser.XMLTABLE, 0); }
		public TerminalNode YEAR() { return getToken(HqlParser.YEAR, 0); }
		public TerminalNode ZONED() { return getToken(HqlParser.ZONED, 0); }
		public NakedIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nakedIdentifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterNakedIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitNakedIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitNakedIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NakedIdentifierContext nakedIdentifier() throws RecognitionException {
		NakedIdentifierContext _localctx = new NakedIdentifierContext(_ctx, getState());
		enterRule(_localctx, 494, RULE_nakedIdentifier);
		int _la;
		try {
			setState(2682);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(2679);
				match(IDENTIFIER);
				}
				break;
			case QUOTED_IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(2680);
				match(QUOTED_IDENTIFIER);
				}
				break;
			case ID:
			case VERSION:
			case VERSIONED:
			case NATURALID:
			case FK:
			case ABSENT:
			case ALL:
			case AND:
			case ANY:
			case ARRAY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BREADTH:
			case BY:
			case CASE:
			case CAST:
			case COLLATE:
			case COLUMN:
			case COLUMNS:
			case CONDITIONAL:
			case CONFLICT:
			case CONSTRAINT:
			case CONTAINS:
			case COUNT:
			case CROSS:
			case CUBE:
			case CURRENT:
			case CURRENT_DATE:
			case CURRENT_INSTANT:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case CYCLE:
			case DATE:
			case DATETIME:
			case DAY:
			case DEFAULT:
			case DELETE:
			case DEPTH:
			case DESC:
			case DISTINCT:
			case DO:
			case ELEMENT:
			case ELEMENTS:
			case ELSE:
			case EMPTY:
			case END:
			case ENTRY:
			case EPOCH:
			case ERROR:
			case ESCAPE:
			case EVERY:
			case EXCEPT:
			case EXCLUDE:
			case EXISTS:
			case EXTRACT:
			case FETCH:
			case FILTER:
			case FIRST:
			case FOLLOWING:
			case FOR:
			case FORMAT:
			case FROM:
			case FUNCTION:
			case GROUP:
			case GROUPS:
			case HAVING:
			case HOUR:
			case IGNORE:
			case ILIKE:
			case IN:
			case INCLUDES:
			case INDEX:
			case INDICES:
			case INSERT:
			case INSTANT:
			case INTERSECT:
			case INTERSECTS:
			case INTO:
			case IS:
			case JOIN:
			case JSON:
			case JSON_ARRAY:
			case JSON_ARRAYAGG:
			case JSON_EXISTS:
			case JSON_OBJECT:
			case JSON_OBJECTAGG:
			case JSON_QUERY:
			case JSON_TABLE:
			case JSON_VALUE:
			case KEY:
			case KEYS:
			case LAST:
			case LATERAL:
			case LEADING:
			case LIKE:
			case LIMIT:
			case LIST:
			case LISTAGG:
			case LOCAL:
			case LOCAL_DATE:
			case LOCAL_DATETIME:
			case LOCAL_TIME:
			case MAP:
			case MATERIALIZED:
			case MAX:
			case MAXELEMENT:
			case MAXINDEX:
			case MEMBER:
			case MICROSECOND:
			case MILLISECOND:
			case MIN:
			case MINELEMENT:
			case MININDEX:
			case MINUTE:
			case MONTH:
			case NAME:
			case NANOSECOND:
			case NEW:
			case NESTED:
			case NEXT:
			case NO:
			case NOT:
			case NOTHING:
			case NULLS:
			case OBJECT:
			case OF:
			case OFFSET:
			case OFFSET_DATETIME:
			case ON:
			case ONLY:
			case OR:
			case ORDER:
			case ORDINALITY:
			case OTHERS:
			case OVER:
			case OVERFLOW:
			case OVERLAY:
			case PAD:
			case PATH:
			case PARTITION:
			case PASSING:
			case PERCENT:
			case PLACING:
			case POSITION:
			case PRECEDING:
			case QUARTER:
			case RANGE:
			case RESPECT:
			case RETURNING:
			case RIGHT:
			case ROLLUP:
			case ROW:
			case ROWS:
			case SEARCH:
			case SECOND:
			case SELECT:
			case SET:
			case SIZE:
			case SOME:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIES:
			case TIME:
			case TIMESTAMP:
			case TIMEZONE_HOUR:
			case TIMEZONE_MINUTE:
			case TO:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUNC:
			case TRUNCATE:
			case TYPE:
			case UNBOUNDED:
			case UNCONDITIONAL:
			case UNION:
			case UNIQUE:
			case UPDATE:
			case USING:
			case VALUE:
			case VALUES:
			case WEEK:
			case WHEN:
			case WHERE:
			case WITH:
			case WITHIN:
			case WITHOUT:
			case WRAPPER:
			case XML:
			case XMLAGG:
			case XMLATTRIBUTES:
			case XMLELEMENT:
			case XMLEXISTS:
			case XMLFOREST:
			case XMLPI:
			case XMLQUERY:
			case XMLTABLE:
			case YEAR:
			case ZONED:
				enterOuterAlt(_localctx, 3);
				{
				setState(2681);
				((NakedIdentifierContext)_localctx).f = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & -33554432L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & -1152921779551862785L) != 0) || ((((_la - 128)) & ~0x3f) == 0 && ((1L << (_la - 128)) & -137438953473L) != 0) || ((((_la - 192)) & ~0x3f) == 0 && ((1L << (_la - 192)) & 1099511627775L) != 0)) ) {
					((NakedIdentifierContext)_localctx).f = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierContext extends ParserRuleContext {
		public NakedIdentifierContext nakedIdentifier() {
			return getRuleContext(NakedIdentifierContext.class,0);
		}
		public TerminalNode FULL() { return getToken(HqlParser.FULL, 0); }
		public TerminalNode INNER() { return getToken(HqlParser.INNER, 0); }
		public TerminalNode LEFT() { return getToken(HqlParser.LEFT, 0); }
		public TerminalNode OUTER() { return getToken(HqlParser.OUTER, 0); }
		public TerminalNode RIGHT() { return getToken(HqlParser.RIGHT, 0); }
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).enterIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HqlListener ) ((HqlListener)listener).exitIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HqlVisitor ) return ((HqlVisitor<? extends T>)visitor).visitIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 496, RULE_identifier);
		try {
			setState(2690);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,313,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(2684);
				nakedIdentifier();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(2685);
				match(FULL);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(2686);
				match(INNER);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(2687);
				match(LEFT);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(2688);
				match(OUTER);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(2689);
				match(RIGHT);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 98:
			return expression_sempred((ExpressionContext)_localctx, predIndex);
		case 226:
			return predicate_sempred((PredicateContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expression_sempred(ExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 6);
		case 1:
			return precpred(_ctx, 5);
		case 2:
			return precpred(_ctx, 4);
		case 3:
			return precpred(_ctx, 8);
		case 4:
			return precpred(_ctx, 7);
		}
		return true;
	}
	private boolean predicate_sempred(PredicateContext _localctx, int predIndex) {
		switch (predIndex) {
		case 5:
			return precpred(_ctx, 3);
		case 6:
			return precpred(_ctx, 2);
		}
		return true;
	}

	private static final String _serializedATNSegment0 =
		"\u0004\u0001\u00fb\u0a85\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007"+
		"\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007"+
		"\u0015\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007"+
		"\u0018\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007"+
		"\u001b\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007"+
		"\u001e\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007"+
		"\"\u0002#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007"+
		"\'\u0002(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007"+
		",\u0002-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u0007"+
		"1\u00022\u00072\u00023\u00073\u00024\u00074\u00025\u00075\u00026\u0007"+
		"6\u00027\u00077\u00028\u00078\u00029\u00079\u0002:\u0007:\u0002;\u0007"+
		";\u0002<\u0007<\u0002=\u0007=\u0002>\u0007>\u0002?\u0007?\u0002@\u0007"+
		"@\u0002A\u0007A\u0002B\u0007B\u0002C\u0007C\u0002D\u0007D\u0002E\u0007"+
		"E\u0002F\u0007F\u0002G\u0007G\u0002H\u0007H\u0002I\u0007I\u0002J\u0007"+
		"J\u0002K\u0007K\u0002L\u0007L\u0002M\u0007M\u0002N\u0007N\u0002O\u0007"+
		"O\u0002P\u0007P\u0002Q\u0007Q\u0002R\u0007R\u0002S\u0007S\u0002T\u0007"+
		"T\u0002U\u0007U\u0002V\u0007V\u0002W\u0007W\u0002X\u0007X\u0002Y\u0007"+
		"Y\u0002Z\u0007Z\u0002[\u0007[\u0002\\\u0007\\\u0002]\u0007]\u0002^\u0007"+
		"^\u0002_\u0007_\u0002`\u0007`\u0002a\u0007a\u0002b\u0007b\u0002c\u0007"+
		"c\u0002d\u0007d\u0002e\u0007e\u0002f\u0007f\u0002g\u0007g\u0002h\u0007"+
		"h\u0002i\u0007i\u0002j\u0007j\u0002k\u0007k\u0002l\u0007l\u0002m\u0007"+
		"m\u0002n\u0007n\u0002o\u0007o\u0002p\u0007p\u0002q\u0007q\u0002r\u0007"+
		"r\u0002s\u0007s\u0002t\u0007t\u0002u\u0007u\u0002v\u0007v\u0002w\u0007"+
		"w\u0002x\u0007x\u0002y\u0007y\u0002z\u0007z\u0002{\u0007{\u0002|\u0007"+
		"|\u0002}\u0007}\u0002~\u0007~\u0002\u007f\u0007\u007f\u0002\u0080\u0007"+
		"\u0080\u0002\u0081\u0007\u0081\u0002\u0082\u0007\u0082\u0002\u0083\u0007"+
		"\u0083\u0002\u0084\u0007\u0084\u0002\u0085\u0007\u0085\u0002\u0086\u0007"+
		"\u0086\u0002\u0087\u0007\u0087\u0002\u0088\u0007\u0088\u0002\u0089\u0007"+
		"\u0089\u0002\u008a\u0007\u008a\u0002\u008b\u0007\u008b\u0002\u008c\u0007"+
		"\u008c\u0002\u008d\u0007\u008d\u0002\u008e\u0007\u008e\u0002\u008f\u0007"+
		"\u008f\u0002\u0090\u0007\u0090\u0002\u0091\u0007\u0091\u0002\u0092\u0007"+
		"\u0092\u0002\u0093\u0007\u0093\u0002\u0094\u0007\u0094\u0002\u0095\u0007"+
		"\u0095\u0002\u0096\u0007\u0096\u0002\u0097\u0007\u0097\u0002\u0098\u0007"+
		"\u0098\u0002\u0099\u0007\u0099\u0002\u009a\u0007\u009a\u0002\u009b\u0007"+
		"\u009b\u0002\u009c\u0007\u009c\u0002\u009d\u0007\u009d\u0002\u009e\u0007"+
		"\u009e\u0002\u009f\u0007\u009f\u0002\u00a0\u0007\u00a0\u0002\u00a1\u0007"+
		"\u00a1\u0002\u00a2\u0007\u00a2\u0002\u00a3\u0007\u00a3\u0002\u00a4\u0007"+
		"\u00a4\u0002\u00a5\u0007\u00a5\u0002\u00a6\u0007\u00a6\u0002\u00a7\u0007"+
		"\u00a7\u0002\u00a8\u0007\u00a8\u0002\u00a9\u0007\u00a9\u0002\u00aa\u0007"+
		"\u00aa\u0002\u00ab\u0007\u00ab\u0002\u00ac\u0007\u00ac\u0002\u00ad\u0007"+
		"\u00ad\u0002\u00ae\u0007\u00ae\u0002\u00af\u0007\u00af\u0002\u00b0\u0007"+
		"\u00b0\u0002\u00b1\u0007\u00b1\u0002\u00b2\u0007\u00b2\u0002\u00b3\u0007"+
		"\u00b3\u0002\u00b4\u0007\u00b4\u0002\u00b5\u0007\u00b5\u0002\u00b6\u0007"+
		"\u00b6\u0002\u00b7\u0007\u00b7\u0002\u00b8\u0007\u00b8\u0002\u00b9\u0007"+
		"\u00b9\u0002\u00ba\u0007\u00ba\u0002\u00bb\u0007\u00bb\u0002\u00bc\u0007"+
		"\u00bc\u0002\u00bd\u0007\u00bd\u0002\u00be\u0007\u00be\u0002\u00bf\u0007"+
		"\u00bf\u0002\u00c0\u0007\u00c0\u0002\u00c1\u0007\u00c1\u0002\u00c2\u0007"+
		"\u00c2\u0002\u00c3\u0007\u00c3\u0002\u00c4\u0007\u00c4\u0002\u00c5\u0007"+
		"\u00c5\u0002\u00c6\u0007\u00c6\u0002\u00c7\u0007\u00c7\u0002\u00c8\u0007"+
		"\u00c8\u0002\u00c9\u0007\u00c9\u0002\u00ca\u0007\u00ca\u0002\u00cb\u0007"+
		"\u00cb\u0002\u00cc\u0007\u00cc\u0002\u00cd\u0007\u00cd\u0002\u00ce\u0007"+
		"\u00ce\u0002\u00cf\u0007\u00cf\u0002\u00d0\u0007\u00d0\u0002\u00d1\u0007"+
		"\u00d1\u0002\u00d2\u0007\u00d2\u0002\u00d3\u0007\u00d3\u0002\u00d4\u0007"+
		"\u00d4\u0002\u00d5\u0007\u00d5\u0002\u00d6\u0007\u00d6\u0002\u00d7\u0007"+
		"\u00d7\u0002\u00d8\u0007\u00d8\u0002\u00d9\u0007\u00d9\u0002\u00da\u0007"+
		"\u00da\u0002\u00db\u0007\u00db\u0002\u00dc\u0007\u00dc\u0002\u00dd\u0007"+
		"\u00dd\u0002\u00de\u0007\u00de\u0002\u00df\u0007\u00df\u0002\u00e0\u0007"+
		"\u00e0\u0002\u00e1\u0007\u00e1\u0002\u00e2\u0007\u00e2\u0002\u00e3\u0007"+
		"\u00e3\u0002\u00e4\u0007\u00e4\u0002\u00e5\u0007\u00e5\u0002\u00e6\u0007"+
		"\u00e6\u0002\u00e7\u0007\u00e7\u0002\u00e8\u0007\u00e8\u0002\u00e9\u0007"+
		"\u00e9\u0002\u00ea\u0007\u00ea\u0002\u00eb\u0007\u00eb\u0002\u00ec\u0007"+
		"\u00ec\u0002\u00ed\u0007\u00ed\u0002\u00ee\u0007\u00ee\u0002\u00ef\u0007"+
		"\u00ef\u0002\u00f0\u0007\u00f0\u0002\u00f1\u0007\u00f1\u0002\u00f2\u0007"+
		"\u00f2\u0002\u00f3\u0007\u00f3\u0002\u00f4\u0007\u00f4\u0002\u00f5\u0007"+
		"\u00f5\u0002\u00f6\u0007\u00f6\u0002\u00f7\u0007\u00f7\u0002\u00f8\u0007"+
		"\u00f8\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0003\u0001\u01fa\b\u0001\u0001\u0002\u0001\u0002\u0001"+
		"\u0003\u0003\u0003\u01ff\b\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001"+
		"\u0003\u0005\u0003\u0205\b\u0003\n\u0003\f\u0003\u0208\t\u0003\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0005\u0004\u020e\b\u0004\n\u0004"+
		"\f\u0004\u0211\t\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005"+
		"\u0216\b\u0005\u0001\u0005\u0003\u0005\u0219\b\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0003\u0005\u021f\b\u0005\u0001\u0005\u0003"+
		"\u0005\u0222\b\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001"+
		"\u0007\u0005\u0007\u022f\b\u0007\n\u0007\f\u0007\u0232\t\u0007\u0001\b"+
		"\u0001\b\u0003\b\u0236\b\b\u0001\b\u0003\b\u0239\b\b\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0003\t\u0244\b\t\u0001"+
		"\t\u0001\t\u0003\t\u0248\b\t\u0001\n\u0001\n\u0001\n\u0005\n\u024d\b\n"+
		"\n\n\f\n\u0250\t\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0003\u000b\u0257\b\u000b\u0001\u000b\u0003\u000b\u025a\b\u000b"+
		"\u0001\u000b\u0003\u000b\u025d\b\u000b\u0001\u000b\u0003\u000b\u0260\b"+
		"\u000b\u0001\u000b\u0003\u000b\u0263\b\u000b\u0001\f\u0001\f\u0003\f\u0267"+
		"\b\f\u0001\f\u0003\f\u026a\b\f\u0001\f\u0003\f\u026d\b\f\u0001\f\u0003"+
		"\f\u0270\b\f\u0001\f\u0001\f\u0003\f\u0274\b\f\u0001\f\u0003\f\u0277\b"+
		"\f\u0001\f\u0003\f\u027a\b\f\u0001\f\u0003\f\u027d\b\f\u0003\f\u027f\b"+
		"\f\u0001\r\u0001\r\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0005"+
		"\u000e\u0287\b\u000e\n\u000e\f\u000e\u028a\t\u000e\u0001\u000f\u0001\u000f"+
		"\u0005\u000f\u028e\b\u000f\n\u000f\f\u000f\u0291\t\u000f\u0001\u0010\u0001"+
		"\u0010\u0001\u0010\u0003\u0010\u0296\b\u0010\u0001\u0011\u0001\u0011\u0003"+
		"\u0011\u029a\b\u0011\u0001\u0011\u0003\u0011\u029d\b\u0011\u0001\u0011"+
		"\u0001\u0011\u0001\u0011\u0001\u0011\u0003\u0011\u02a3\b\u0011\u0001\u0011"+
		"\u0001\u0011\u0003\u0011\u02a7\b\u0011\u0003\u0011\u02a9\b\u0011\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0003\u0012\u02ae\b\u0012\u0001\u0012\u0001"+
		"\u0012\u0003\u0012\u02b2\b\u0012\u0001\u0013\u0001\u0013\u0003\u0013\u02b6"+
		"\b\u0013\u0001\u0013\u0003\u0013\u02b9\b\u0013\u0001\u0013\u0001\u0013"+
		"\u0001\u0013\u0001\u0013\u0003\u0013\u02bf\b\u0013\u0001\u0013\u0003\u0013"+
		"\u02c2\b\u0013\u0001\u0013\u0001\u0013\u0003\u0013\u02c6\b\u0013\u0003"+
		"\u0013\u02c8\b\u0013\u0001\u0014\u0001\u0014\u0003\u0014\u02cc\b\u0014"+
		"\u0001\u0014\u0001\u0014\u0001\u0014\u0003\u0014\u02d1\b\u0014\u0001\u0015"+
		"\u0001\u0015\u0003\u0015\u02d5\b\u0015\u0001\u0016\u0001\u0016\u0001\u0016"+
		"\u0001\u0016\u0005\u0016\u02db\b\u0016\n\u0016\f\u0016\u02de\t\u0016\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0018\u0001\u0018\u0003"+
		"\u0018\u02e6\b\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u02ea\b\u0018"+
		"\u0001\u0019\u0001\u0019\u0003\u0019\u02ee\b\u0019\u0001\u0019\u0001\u0019"+
		"\u0001\u0019\u0001\u0019\u0003\u0019\u02f4\b\u0019\u0001\u0019\u0003\u0019"+
		"\u02f7\b\u0019\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0005\u001a"+
		"\u02fd\b\u001a\n\u001a\f\u001a\u0300\t\u001a\u0001\u001a\u0001\u001a\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0005\u001b\u0308\b\u001b\n"+
		"\u001b\f\u001b\u030b\t\u001b\u0001\u001c\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0005\u001c\u0311\b\u001c\n\u001c\f\u001c\u0314\t\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0003\u001d\u031b\b\u001d"+
		"\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001e\u0001\u001e\u0001\u001e"+
		"\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0005\u001e\u0327\b\u001e"+
		"\n\u001e\f\u001e\u032a\t\u001e\u0001\u001e\u0001\u001e\u0003\u001e\u032e"+
		"\b\u001e\u0001\u001f\u0001\u001f\u0001\u001f\u0001\u001f\u0003\u001f\u0334"+
		"\b\u001f\u0003\u001f\u0336\b\u001f\u0001 \u0001 \u0001 \u0001 \u0001 "+
		"\u0001 \u0001!\u0001!\u0001!\u0003!\u0341\b!\u0001\"\u0001\"\u0003\"\u0345"+
		"\b\"\u0001\"\u0003\"\u0348\b\"\u0001#\u0001#\u0001#\u0003#\u034d\b#\u0001"+
		"$\u0001$\u0001%\u0001%\u0001%\u0001&\u0001&\u0001&\u0001\'\u0001\'\u0001"+
		"\'\u0003\'\u035a\b\'\u0001(\u0001(\u0001(\u0001(\u0001(\u0001(\u0003("+
		"\u0362\b(\u0001(\u0001(\u0001(\u0001(\u0003(\u0368\b(\u0001)\u0001)\u0001"+
		"*\u0001*\u0003*\u036e\b*\u0001*\u0001*\u0001+\u0001+\u0001+\u0005+\u0375"+
		"\b+\n+\f+\u0378\t+\u0001,\u0001,\u0003,\u037c\b,\u0001-\u0001-\u0001-"+
		"\u0001-\u0003-\u0382\b-\u0001.\u0001.\u0001.\u0001.\u0001.\u0001/\u0001"+
		"/\u0001/\u0001/\u0001/\u00010\u00010\u00010\u00010\u00050\u0392\b0\n0"+
		"\f0\u0395\t0\u00011\u00031\u0398\b1\u00011\u00031\u039b\b1\u00011\u0003"+
		"1\u039e\b1\u00011\u00031\u03a1\b1\u00012\u00012\u00012\u00012\u00032\u03a7"+
		"\b2\u00013\u00013\u00013\u00014\u00014\u00014\u00014\u00014\u00014\u0003"+
		"4\u03b2\b4\u00015\u00015\u00015\u00015\u00015\u00055\u03b9\b5\n5\f5\u03bc"+
		"\t5\u00016\u00016\u00016\u00016\u00016\u00056\u03c3\b6\n6\f6\u03c6\t6"+
		"\u00017\u00017\u00017\u00017\u00057\u03cc\b7\n7\f7\u03cf\t7\u00018\u0001"+
		"8\u00038\u03d3\b8\u00018\u00018\u00038\u03d7\b8\u00018\u00018\u00038\u03db"+
		"\b8\u00038\u03dd\b8\u00019\u00019\u00019\u00019\u00019\u00019\u00019\u0001"+
		"9\u00019\u00039\u03e8\b9\u0001:\u0001:\u0001;\u0001;\u0001<\u0001<\u0001"+
		"<\u0003<\u03f1\b<\u0001=\u0001=\u0001=\u0001=\u0001=\u0003=\u03f8\b=\u0001"+
		"=\u0001=\u0003=\u03fc\b=\u0001>\u0001>\u0001>\u0001>\u0001>\u0003>\u0403"+
		"\b>\u0001>\u0001>\u0003>\u0407\b>\u0001?\u0001?\u0001?\u0001?\u0001?\u0003"+
		"?\u040e\b?\u0001?\u0001?\u0003?\u0412\b?\u0001@\u0001@\u0001@\u0001@\u0001"+
		"@\u0003@\u0419\b@\u0001@\u0001@\u0003@\u041d\b@\u0001A\u0001A\u0001A\u0001"+
		"A\u0001A\u0003A\u0424\bA\u0001A\u0001A\u0003A\u0428\bA\u0001B\u0001B\u0001"+
		"B\u0003B\u042d\bB\u0001C\u0001C\u0001C\u0001D\u0001D\u0001D\u0001D\u0001"+
		"E\u0001E\u0001E\u0001E\u0001F\u0001F\u0001F\u0001F\u0001G\u0001G\u0001"+
		"G\u0003G\u0441\bG\u0001G\u0001G\u0001H\u0001H\u0001H\u0003H\u0448\bH\u0001"+
		"H\u0001H\u0001I\u0001I\u0001I\u0003I\u044f\bI\u0001I\u0001I\u0001J\u0001"+
		"J\u0001K\u0001K\u0001K\u0001K\u0005K\u0459\bK\nK\fK\u045c\tK\u0003K\u045e"+
		"\bK\u0001K\u0001K\u0001L\u0001L\u0001L\u0001L\u0001L\u0001L\u0001M\u0001"+
		"M\u0001N\u0001N\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001P\u0001"+
		"P\u0001P\u0001P\u0001P\u0003P\u0477\bP\u0001Q\u0001Q\u0001Q\u0001Q\u0003"+
		"Q\u047d\bQ\u0001R\u0001R\u0001R\u0001R\u0001R\u0001S\u0001S\u0001T\u0001"+
		"T\u0001U\u0001U\u0001V\u0001V\u0001W\u0001W\u0001X\u0001X\u0001Y\u0001"+
		"Y\u0001Y\u0003Y\u0493\bY\u0001Y\u0003Y\u0496\bY\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0003Z\u049d\bZ\u0001[\u0001[\u0001\\\u0001\\\u0001\\\u0001\\"+
		"\u0001\\\u0001\\\u0001\\\u0001\\\u0001\\\u0003\\\u04aa\b\\\u0001]\u0001"+
		"]\u0001]\u0001]\u0001]\u0001]\u0003]\u04b2\b]\u0001^\u0001^\u0003^\u04b6"+
		"\b^\u0001^\u0001^\u0003^\u04ba\b^\u0001_\u0001_\u0001`\u0001`\u0001`\u0001"+
		"`\u0001`\u0005`\u04c3\b`\n`\f`\u04c6\t`\u0001`\u0003`\u04c9\b`\u0001a"+
		"\u0001a\u0001a\u0001a\u0001a\u0001a\u0003a\u04d1\ba\u0001b\u0001b\u0001"+
		"b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0004b\u04dc\bb\u000bb\fb"+
		"\u04dd\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b"+
		"\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001"+
		"b\u0001b\u0003b\u04f4\bb\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001"+
		"b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0001b\u0005b\u0504\bb\nb"+
		"\fb\u0507\tb\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001"+
		"c\u0003c\u0512\bc\u0001c\u0001c\u0003c\u0516\bc\u0001d\u0001d\u0003d\u051a"+
		"\bd\u0001d\u0003d\u051d\bd\u0001e\u0001e\u0003e\u0521\be\u0001f\u0001"+
		"f\u0001f\u0001f\u0001f\u0003f\u0528\bf\u0001g\u0001g\u0005g\u052c\bg\n"+
		"g\fg\u052f\tg\u0001h\u0001h\u0001h\u0001i\u0001i\u0001i\u0001j\u0001j"+
		"\u0001j\u0001j\u0003j\u053b\bj\u0001j\u0001j\u0001k\u0001k\u0001k\u0001"+
		"k\u0001k\u0003k\u0544\bk\u0001l\u0001l\u0001l\u0001l\u0001l\u0001m\u0001"+
		"m\u0001m\u0001m\u0001m\u0003m\u0550\bm\u0001n\u0001n\u0001n\u0001n\u0001"+
		"n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001"+
		"n\u0001n\u0003n\u0562\bn\u0001n\u0001n\u0001n\u0003n\u0567\bn\u0001o\u0001"+
		"o\u0001o\u0001o\u0001o\u0001o\u0001p\u0001p\u0001p\u0001p\u0001p\u0001"+
		"p\u0001p\u0003p\u0576\bp\u0001q\u0001q\u0001q\u0001q\u0001q\u0003q\u057d"+
		"\bq\u0001r\u0001r\u0001r\u0001r\u0001r\u0003r\u0584\br\u0001s\u0001s\u0001"+
		"s\u0001s\u0001s\u0001t\u0001t\u0003t\u058d\bt\u0001u\u0001u\u0001u\u0004"+
		"u\u0592\bu\u000bu\fu\u0593\u0001u\u0001u\u0003u\u0598\bu\u0001u\u0001"+
		"u\u0001v\u0001v\u0004v\u059e\bv\u000bv\fv\u059f\u0001v\u0001v\u0003v\u05a4"+
		"\bv\u0001v\u0001v\u0001w\u0001w\u0001w\u0001w\u0001w\u0001x\u0001x\u0001"+
		"x\u0001x\u0001x\u0001y\u0001y\u0001y\u0001y\u0001y\u0001y\u0001y\u0001"+
		"y\u0001y\u0001y\u0003y\u05bc\by\u0001z\u0001z\u0001z\u0003z\u05c1\bz\u0001"+
		"{\u0001{\u0001{\u0003{\u05c6\b{\u0001{\u0001{\u0001|\u0001|\u0001|\u0001"+
		"|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001"+
		"|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001|\u0001|\u0003|\u05df\b|\u0001"+
		"}\u0001}\u0001}\u0001}\u0001}\u0001}\u0001}\u0001~\u0001~\u0001~\u0001"+
		"~\u0001~\u0003~\u05ed\b~\u0001~\u0003~\u05f0\b~\u0001\u007f\u0001\u007f"+
		"\u0001\u007f\u0001\u007f\u0001\u007f\u0001\u007f\u0001\u007f\u0005\u007f"+
		"\u05f9\b\u007f\n\u007f\f\u007f\u05fc\t\u007f\u0001\u0080\u0001\u0080\u0001"+
		"\u0080\u0001\u0080\u0001\u0080\u0001\u0080\u0001\u0080\u0003\u0080\u0605"+
		"\b\u0080\u0001\u0080\u0001\u0080\u0001\u0080\u0001\u0080\u0001\u0080\u0001"+
		"\u0080\u0001\u0080\u0001\u0080\u0001\u0080\u0003\u0080\u0610\b\u0080\u0001"+
		"\u0080\u0001\u0080\u0003\u0080\u0614\b\u0080\u0001\u0081\u0001\u0081\u0001"+
		"\u0082\u0001\u0082\u0001\u0083\u0001\u0083\u0001\u0083\u0003\u0083\u061d"+
		"\b\u0083\u0001\u0083\u0003\u0083\u0620\b\u0083\u0001\u0083\u0003\u0083"+
		"\u0623\b\u0083\u0001\u0083\u0001\u0083\u0001\u0083\u0001\u0084\u0001\u0084"+
		"\u0001\u0085\u0001\u0085\u0003\u0085\u062c\b\u0085\u0001\u0086\u0001\u0086"+
		"\u0001\u0086\u0001\u0086\u0001\u0086\u0001\u0086\u0001\u0086\u0003\u0086"+
		"\u0635\b\u0086\u0001\u0086\u0001\u0086\u0001\u0087\u0001\u0087\u0001\u0088"+
		"\u0001\u0088\u0001\u0089\u0001\u0089\u0001\u008a\u0001\u008a\u0001\u008a"+
		"\u0001\u008a\u0001\u008a\u0001\u008a\u0001\u008a\u0001\u008b\u0001\u008b"+
		"\u0001\u008c\u0001\u008c\u0001\u008d\u0001\u008d\u0001\u008d\u0001\u008d"+
		"\u0001\u008d\u0001\u008d\u0001\u008d\u0001\u008d\u0001\u008d\u0003\u008d"+
		"\u0653\b\u008d\u0001\u008d\u0001\u008d\u0001\u008e\u0001\u008e\u0001\u008f"+
		"\u0001\u008f\u0001\u0090\u0001\u0090\u0001\u0091\u0001\u0091\u0001\u0092"+
		"\u0001\u0092\u0001\u0092\u0003\u0092\u0662\b\u0092\u0001\u0092\u0001\u0092"+
		"\u0003\u0092\u0666\b\u0092\u0001\u0093\u0001\u0093\u0001\u0093\u0003\u0093"+
		"\u066b\b\u0093\u0001\u0093\u0001\u0093\u0003\u0093\u066f\b\u0093\u0001"+
		"\u0094\u0001\u0094\u0001\u0094\u0003\u0094\u0674\b\u0094\u0001\u0094\u0001"+
		"\u0094\u0003\u0094\u0678\b\u0094\u0001\u0095\u0001\u0095\u0001\u0095\u0003"+
		"\u0095\u067d\b\u0095\u0001\u0095\u0003\u0095\u0680\b\u0095\u0001\u0096"+
		"\u0001\u0096\u0001\u0096\u0003\u0096\u0685\b\u0096\u0001\u0096\u0001\u0096"+
		"\u0003\u0096\u0689\b\u0096\u0001\u0097\u0001\u0097\u0001\u0097\u0003\u0097"+
		"\u068e\b\u0097\u0001\u0097\u0001\u0097\u0003\u0097\u0692\b\u0097\u0001"+
		"\u0098\u0001\u0098\u0001\u0098\u0003\u0098\u0697\b\u0098\u0001\u0098\u0001"+
		"\u0098\u0003\u0098\u069b\b\u0098\u0001\u0099\u0001\u0099\u0001\u0099\u0003"+
		"\u0099\u06a0\b\u0099\u0001\u0099\u0001\u0099\u0003\u0099\u06a4\b\u0099"+
		"\u0001\u009a\u0001\u009a\u0001\u009a\u0001\u009a\u0001\u009a\u0001\u009a"+
		"\u0001\u009a\u0001\u009b\u0001\u009b\u0001\u009c\u0001\u009c\u0001\u009c"+
		"\u0001\u009c\u0001\u009c\u0001\u009c\u0001\u009c\u0001\u009d\u0001\u009d"+
		"\u0001\u009d\u0001\u009d\u0001\u009d\u0005\u009d\u06bb\b\u009d\n\u009d"+
		"\f\u009d\u06be\t\u009d\u0001\u009d\u0001\u009d\u0001\u009e\u0001\u009e"+
		"\u0001\u009e\u0001\u009e\u0001\u009e\u0005\u009e\u06c7\b\u009e\n\u009e"+
		"\f\u009e\u06ca\t\u009e\u0001\u009e\u0001\u009e\u0001\u009f\u0001\u009f"+
		"\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a0"+
		"\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a0\u0001\u00a0"+
		"\u0003\u00a0\u06dc\b\u00a0\u0001\u00a1\u0001\u00a1\u0001\u00a1\u0001\u00a1"+
		"\u0001\u00a1\u0001\u00a1\u0003\u00a1\u06e4\b\u00a1\u0003\u00a1\u06e6\b"+
		"\u00a1\u0001\u00a1\u0001\u00a1\u0001\u00a2\u0001\u00a2\u0001\u00a2\u0001"+
		"\u00a2\u0001\u00a2\u0003\u00a2\u06ef\b\u00a2\u0001\u00a2\u0001\u00a2\u0003"+
		"\u00a2\u06f3\b\u00a2\u0001\u00a2\u0001\u00a2\u0001\u00a3\u0001\u00a3\u0003"+
		"\u00a3\u06f9\b\u00a3\u0001\u00a4\u0001\u00a4\u0001\u00a4\u0001\u00a4\u0001"+
		"\u00a4\u0001\u00a4\u0001\u00a4\u0003\u00a4\u0702\b\u00a4\u0001\u00a4\u0001"+
		"\u00a4\u0001\u00a5\u0001\u00a5\u0001\u00a5\u0001\u00a5\u0003\u00a5\u070a"+
		"\b\u00a5\u0001\u00a5\u0001\u00a5\u0003\u00a5\u070e\b\u00a5\u0001\u00a5"+
		"\u0003\u00a5\u0711\b\u00a5\u0001\u00a5\u0003\u00a5\u0714\b\u00a5\u0001"+
		"\u00a5\u0003\u00a5\u0717\b\u00a5\u0001\u00a5\u0003\u00a5\u071a\b\u00a5"+
		"\u0001\u00a5\u0003\u00a5\u071d\b\u00a5\u0001\u00a6\u0001\u00a6\u0001\u00a7"+
		"\u0001\u00a7\u0001\u00a7\u0001\u00a7\u0003\u00a7\u0725\b\u00a7\u0001\u00a7"+
		"\u0001\u00a7\u0001\u00a7\u0005\u00a7\u072a\b\u00a7\n\u00a7\f\u00a7\u072d"+
		"\t\u00a7\u0001\u00a8\u0001\u00a8\u0001\u00a8\u0001\u00a8\u0001\u00a8\u0001"+
		"\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001"+
		"\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001"+
		"\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001"+
		"\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001\u00a9\u0001"+
		"\u00a9\u0001\u00a9\u0003\u00a9\u074e\b\u00a9\u0001\u00aa\u0001\u00aa\u0001"+
		"\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001\u00aa\u0001"+
		"\u00aa\u0001\u00aa\u0003\u00aa\u075a\b\u00aa\u0001\u00ab\u0001\u00ab\u0001"+
		"\u00ab\u0003\u00ab\u075f\b\u00ab\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0001"+
		"\u00ac\u0001\u00ac\u0003\u00ac\u0766\b\u00ac\u0001\u00ac\u0003\u00ac\u0769"+
		"\b\u00ac\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0001"+
		"\u00ac\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0001\u00ac\u0003"+
		"\u00ac\u0776\b\u00ac\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001"+
		"\u00ad\u0003\u00ad\u077d\b\u00ad\u0001\u00ad\u0003\u00ad\u0780\b\u00ad"+
		"\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001\u00ad"+
		"\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0001\u00ad\u0003\u00ad"+
		"\u078d\b\u00ad\u0001\u00ae\u0001\u00ae\u0001\u00af\u0001\u00af\u0001\u00b0"+
		"\u0001\u00b0\u0001\u00b0\u0003\u00b0\u0796\b\u00b0\u0001\u00b0\u0001\u00b0"+
		"\u0001\u00b0\u0001\u00b0\u0003\u00b0\u079c\b\u00b0\u0001\u00b0\u0001\u00b0"+
		"\u0003\u00b0\u07a0\b\u00b0\u0001\u00b0\u0003\u00b0\u07a3\b\u00b0\u0001"+
		"\u00b0\u0003\u00b0\u07a6\b\u00b0\u0001\u00b1\u0001\u00b1\u0001\u00b1\u0001"+
		"\u00b1\u0001\u00b1\u0003\u00b1\u07ad\b\u00b1\u0001\u00b1\u0001\u00b1\u0003"+
		"\u00b1\u07b1\b\u00b1\u0001\u00b2\u0001\u00b2\u0001\u00b2\u0001\u00b2\u0001"+
		"\u00b2\u0001\u00b2\u0001\u00b3\u0001\u00b3\u0001\u00b3\u0001\u00b3\u0001"+
		"\u00b3\u0001\u00b4\u0001\u00b4\u0001\u00b4\u0001\u00b4\u0003\u00b4\u07c2"+
		"\b\u00b4\u0001\u00b5\u0001\u00b5\u0001\u00b5\u0001\u00b5\u0003\u00b5\u07c8"+
		"\b\u00b5\u0001\u00b6\u0001\u00b6\u0001\u00b6\u0003\u00b6\u07cd\b\u00b6"+
		"\u0001\u00b6\u0003\u00b6\u07d0\b\u00b6\u0001\u00b6\u0003\u00b6\u07d3\b"+
		"\u00b6\u0001\u00b6\u0001\u00b6\u0001\u00b7\u0001\u00b7\u0001\u00b7\u0001"+
		"\u00b7\u0001\u00b7\u0005\u00b7\u07dc\b\u00b7\n\u00b7\f\u00b7\u07df\t\u00b7"+
		"\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0003\u00b8\u07e4\b\u00b8\u0001\u00b8"+
		"\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0001\u00b8\u0003\u00b8"+
		"\u07ec\b\u00b8\u0003\u00b8\u07ee\b\u00b8\u0001\u00b9\u0001\u00b9\u0001"+
		"\u00b9\u0001\u00b9\u0001\u00b9\u0001\u00b9\u0001\u00b9\u0001\u00b9\u0001"+
		"\u00b9\u0001\u00b9\u0003\u00b9\u07fa\b\u00b9\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001\u00ba\u0001"+
		"\u00ba\u0001\u00ba\u0003\u00ba\u0806\b\u00ba\u0001\u00bb\u0001\u00bb\u0001"+
		"\u00bb\u0001\u00bb\u0001\u00bb\u0001\u00bb\u0001\u00bb\u0001\u00bb\u0001"+
		"\u00bb\u0001\u00bb\u0003\u00bb\u0812\b\u00bb\u0001\u00bc\u0001\u00bc\u0001"+
		"\u00bc\u0001\u00bc\u0001\u00bc\u0001\u00bc\u0001\u00bc\u0003\u00bc\u081b"+
		"\b\u00bc\u0001\u00bd\u0001\u00bd\u0001\u00bd\u0001\u00bd\u0001\u00bd\u0005"+
		"\u00bd\u0822\b\u00bd\n\u00bd\f\u00bd\u0825\t\u00bd\u0001\u00bd\u0003\u00bd"+
		"\u0828\b\u00bd\u0003\u00bd\u082a\b\u00bd\u0001\u00bd\u0001\u00bd\u0001"+
		"\u00be\u0001\u00be\u0001\u00be\u0001\u00be\u0001\u00be\u0001\u00be\u0003"+
		"\u00be\u0834\b\u00be\u0001\u00be\u0003\u00be\u0837\b\u00be\u0001\u00be"+
		"\u0001\u00be\u0001\u00bf\u0001\u00bf\u0001\u00bf\u0001\u00bf\u0001\u00c0"+
		"\u0001\u00c0\u0001\u00c0\u0003\u00c0\u0842\b\u00c0\u0001\u00c0\u0001\u00c0"+
		"\u0005\u00c0\u0846\b\u00c0\n\u00c0\f\u00c0\u0849\t\u00c0\u0001\u00c0\u0003"+
		"\u00c0\u084c\b\u00c0\u0001\u00c0\u0001\u00c0\u0001\u00c1\u0001\u00c1\u0001"+
		"\u00c1\u0003\u00c1\u0853\b\u00c1\u0001\u00c2\u0003\u00c2\u0856\b\u00c2"+
		"\u0001\u00c2\u0001\u00c2\u0001\u00c2\u0001\u00c2\u0001\u00c3\u0001\u00c3"+
		"\u0001\u00c3\u0001\u00c3\u0001\u00c4\u0001\u00c4\u0001\u00c4\u0001\u00c4"+
		"\u0001\u00c4\u0001\u00c4\u0003\u00c4\u0866\b\u00c4\u0001\u00c4\u0003\u00c4"+
		"\u0869\b\u00c4\u0001\u00c4\u0003\u00c4\u086c\b\u00c4\u0001\u00c4\u0003"+
		"\u00c4\u086f\b\u00c4\u0001\u00c4\u0001\u00c4\u0001\u00c5\u0001\u00c5\u0003"+
		"\u00c5\u0875\b\u00c5\u0001\u00c5\u0003\u00c5\u0878\b\u00c5\u0001\u00c5"+
		"\u0001\u00c5\u0001\u00c5\u0003\u00c5\u087d\b\u00c5\u0001\u00c5\u0003\u00c5"+
		"\u0880\b\u00c5\u0001\u00c6\u0001\u00c6\u0001\u00c6\u0001\u00c6\u0003\u00c6"+
		"\u0886\b\u00c6\u0003\u00c6\u0888\b\u00c6\u0001\u00c6\u0001\u00c6\u0001"+
		"\u00c6\u0001\u00c7\u0001\u00c7\u0001\u00c7\u0001\u00c7\u0001\u00c7\u0001"+
		"\u00c7\u0003\u00c7\u0893\b\u00c7\u0001\u00c7\u0003\u00c7\u0896\b\u00c7"+
		"\u0001\u00c7\u0003\u00c7\u0899\b\u00c7\u0001\u00c7\u0003\u00c7\u089c\b"+
		"\u00c7\u0001\u00c7\u0001\u00c7\u0001\u00c8\u0001\u00c8\u0001\u00c8\u0001"+
		"\u00c9\u0001\u00c9\u0001\u00c9\u0001\u00c9\u0003\u00c9\u08a7\b\u00c9\u0001"+
		"\u00c9\u0001\u00c9\u0001\u00c9\u0001\u00ca\u0001\u00ca\u0001\u00ca\u0001"+
		"\u00ca\u0003\u00ca\u08b0\b\u00ca\u0001\u00ca\u0003\u00ca\u08b3\b\u00ca"+
		"\u0001\u00ca\u0001\u00ca\u0003\u00ca\u08b7\b\u00ca\u0001\u00cb\u0001\u00cb"+
		"\u0001\u00cb\u0003\u00cb\u08bc\b\u00cb\u0001\u00cb\u0001\u00cb\u0001\u00cb"+
		"\u0001\u00cb\u0003\u00cb\u08c2\b\u00cb\u0001\u00cb\u0003\u00cb\u08c5\b"+
		"\u00cb\u0001\u00cb\u0001\u00cb\u0003\u00cb\u08c9\b\u00cb\u0001\u00cc\u0001"+
		"\u00cc\u0001\u00cc\u0001\u00cc\u0005\u00cc\u08cf\b\u00cc\n\u00cc\f\u00cc"+
		"\u08d2\t\u00cc\u0001\u00cd\u0001\u00cd\u0001\u00cd\u0001\u00cd\u0001\u00ce"+
		"\u0001\u00ce\u0001\u00ce\u0001\u00ce\u0001\u00cf\u0001\u00cf\u0001\u00cf"+
		"\u0001\u00cf\u0001\u00cf\u0003\u00cf\u08e1\b\u00cf\u0001\u00cf\u0003\u00cf"+
		"\u08e4\b\u00cf\u0001\u00cf\u0001\u00cf\u0003\u00cf\u08e8\b\u00cf\u0001"+
		"\u00cf\u0001\u00cf\u0001\u00d0\u0001\u00d0\u0001\u00d0\u0001\u00d0\u0001"+
		"\u00d1\u0001\u00d1\u0001\u00d1\u0001\u00d1\u0001\u00d1\u0001\u00d2\u0001"+
		"\u00d2\u0001\u00d2\u0005\u00d2\u08f8\b\u00d2\n\u00d2\f\u00d2\u08fb\t\u00d2"+
		"\u0001\u00d3\u0001\u00d3\u0003\u00d3\u08ff\b\u00d3\u0001\u00d3\u0001\u00d3"+
		"\u0001\u00d3\u0001\u00d3\u0001\u00d3\u0003\u00d3\u0906\b\u00d3\u0001\u00d3"+
		"\u0001\u00d3\u0003\u00d3\u090a\b\u00d3\u0001\u00d3\u0003\u00d3\u090d\b"+
		"\u00d3\u0001\u00d3\u0003\u00d3\u0910\b\u00d3\u0001\u00d3\u0001\u00d3\u0001"+
		"\u00d3\u0001\u00d3\u0001\u00d3\u0001\u00d3\u0001\u00d3\u0001\u00d3\u0003"+
		"\u00d3\u091a\b\u00d3\u0001\u00d3\u0003\u00d3\u091d\b\u00d3\u0001\u00d3"+
		"\u0001\u00d3\u0001\u00d3\u0001\u00d3\u0003\u00d3\u0923\b\u00d3\u0001\u00d3"+
		"\u0003\u00d3\u0926\b\u00d3\u0001\u00d3\u0003\u00d3\u0929\b\u00d3\u0003"+
		"\u00d3\u092b\b\u00d3\u0001\u00d4\u0001\u00d4\u0001\u00d4\u0001\u00d4\u0001"+
		"\u00d4\u0001\u00d4\u0003\u00d4\u0933\b\u00d4\u0001\u00d5\u0001\u00d5\u0001"+
		"\u00d5\u0001\u00d5\u0001\u00d5\u0001\u00d5\u0003\u00d5\u093b\b\u00d5\u0001"+
		"\u00d5\u0001\u00d5\u0005\u00d5\u093f\b\u00d5\n\u00d5\f\u00d5\u0942\t\u00d5"+
		"\u0001\u00d5\u0001\u00d5\u0001\u00d6\u0001\u00d6\u0001\u00d6\u0001\u00d6"+
		"\u0001\u00d6\u0005\u00d6\u094b\b\u00d6\n\u00d6\f\u00d6\u094e\t\u00d6\u0001"+
		"\u00d6\u0001\u00d6\u0001\u00d7\u0001\u00d7\u0001\u00d7\u0001\u00d7\u0001"+
		"\u00d7\u0005\u00d7\u0957\b\u00d7\n\u00d7\f\u00d7\u095a\t\u00d7\u0001\u00d7"+
		"\u0001\u00d7\u0001\u00d8\u0001\u00d8\u0001\u00d8\u0001\u00d8\u0001\u00d8"+
		"\u0001\u00d8\u0003\u00d8\u0964\b\u00d8\u0001\u00d8\u0001\u00d8\u0001\u00d9"+
		"\u0001\u00d9\u0001\u00d9\u0001\u00d9\u0001\u00d9\u0001\u00d9\u0001\u00d9"+
		"\u0001\u00da\u0001\u00da\u0001\u00da\u0001\u00da\u0001\u00da\u0001\u00da"+
		"\u0001\u00da\u0001\u00db\u0001\u00db\u0001\u00db\u0001\u00db\u0003\u00db"+
		"\u097a\b\u00db\u0001\u00db\u0001\u00db\u0003\u00db\u097e\b\u00db\u0001"+
		"\u00db\u0003\u00db\u0981\b\u00db\u0001\u00dc\u0001\u00dc\u0001\u00dc\u0001"+
		"\u00dc\u0001\u00dd\u0001\u00dd\u0001\u00dd\u0003\u00dd\u098a\b\u00dd\u0001"+
		"\u00de\u0001\u00de\u0001\u00de\u0001\u00de\u0001\u00de\u0001\u00de\u0001"+
		"\u00de\u0001\u00de\u0001\u00df\u0001\u00df\u0001\u00df\u0001\u00df\u0005"+
		"\u00df\u0998\b\u00df\n\u00df\f\u00df\u099b\t\u00df\u0001\u00e0\u0001\u00e0"+
		"\u0001\u00e0\u0001\u00e0\u0003\u00e0\u09a1\b\u00e0\u0001\u00e0\u0003\u00e0"+
		"\u09a4\b\u00e0\u0001\u00e0\u0001\u00e0\u0001\u00e0\u0001\u00e0\u0001\u00e0"+
		"\u0001\u00e0\u0001\u00e0\u0001\u00e0\u0003\u00e0\u09ae\b\u00e0\u0001\u00e0"+
		"\u0003\u00e0\u09b1\b\u00e0\u0003\u00e0\u09b3\b\u00e0\u0001\u00e1\u0001"+
		"\u00e1\u0001\u00e1\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001"+
		"\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0003\u00e2\u09c0\b\u00e2\u0001"+
		"\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0003\u00e2\u09c7"+
		"\b\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001"+
		"\u00e2\u0003\u00e2\u09cf\b\u00e2\u0001\u00e2\u0001\u00e2\u0003\u00e2\u09d3"+
		"\b\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001"+
		"\u00e2\u0003\u00e2\u09db\b\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001"+
		"\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0003"+
		"\u00e2\u09e6\b\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001\u00e2\u0001"+
		"\u00e2\u0001\u00e2\u0005\u00e2\u09ee\b\u00e2\n\u00e2\f\u00e2\u09f1\t\u00e2"+
		"\u0001\u00e3\u0001\u00e3\u0003\u00e3\u09f5\b\u00e3\u0001\u00e4\u0001\u00e4"+
		"\u0003\u00e4\u09f9\b\u00e4\u0001\u00e5\u0001\u00e5\u0001\u00e6\u0001\u00e6"+
		"\u0001\u00e7\u0001\u00e7\u0001\u00e8\u0001\u00e8\u0001\u00e9\u0001\u00e9"+
		"\u0001\u00e9\u0001\u00e9\u0001\u00ea\u0001\u00ea\u0003\u00ea\u0a09\b\u00ea"+
		"\u0001\u00ea\u0001\u00ea\u0001\u00ea\u0001\u00ea\u0001\u00ea\u0001\u00eb"+
		"\u0001\u00eb\u0003\u00eb\u0a12\b\u00eb\u0001\u00eb\u0001\u00eb\u0001\u00eb"+
		"\u0001\u00eb\u0001\u00eb\u0001\u00eb\u0003\u00eb\u0a1a\b\u00eb\u0003\u00eb"+
		"\u0a1c\b\u00eb\u0001\u00ec\u0001\u00ec\u0003\u00ec\u0a20\b\u00ec\u0001"+
		"\u00ec\u0001\u00ec\u0001\u00ec\u0001\u00ed\u0001\u00ed\u0001\u00ed\u0001"+
		"\u00ed\u0001\u00ed\u0001\u00ed\u0001\u00ed\u0001\u00ed\u0001\u00ed\u0001"+
		"\u00ed\u0001\u00ed\u0001\u00ed\u0001\u00ed\u0001\u00ed\u0005\u00ed\u0a33"+
		"\b\u00ed\n\u00ed\f\u00ed\u0a36\t\u00ed\u0003\u00ed\u0a38\b\u00ed\u0001"+
		"\u00ed\u0003\u00ed\u0a3b\b\u00ed\u0001\u00ee\u0001\u00ee\u0001\u00ee\u0001"+
		"\u00ee\u0001\u00ee\u0001\u00ee\u0001\u00ee\u0001\u00ee\u0003\u00ee\u0a45"+
		"\b\u00ee\u0001\u00ef\u0001\u00ef\u0001\u00ef\u0003\u00ef\u0a4a\b\u00ef"+
		"\u0001\u00f0\u0001\u00f0\u0001\u00f0\u0005\u00f0\u0a4f\b\u00f0\n\u00f0"+
		"\f\u00f0\u0a52\t\u00f0\u0001\u00f1\u0001\u00f1\u0003\u00f1\u0a56\b\u00f1"+
		"\u0001\u00f1\u0003\u00f1\u0a59\b\u00f1\u0001\u00f2\u0001\u00f2\u0003\u00f2"+
		"\u0a5d\b\u00f2\u0001\u00f3\u0001\u00f3\u0003\u00f3\u0a61\b\u00f3\u0001"+
		"\u00f4\u0001\u00f4\u0001\u00f4\u0003\u00f4\u0a66\b\u00f4\u0001\u00f5\u0001"+
		"\u00f5\u0001\u00f5\u0001\u00f5\u0003\u00f5\u0a6c\b\u00f5\u0003\u00f5\u0a6e"+
		"\b\u00f5\u0001\u00f6\u0001\u00f6\u0001\u00f6\u0005\u00f6\u0a73\b\u00f6"+
		"\n\u00f6\f\u00f6\u0a76\t\u00f6\u0001\u00f7\u0001\u00f7\u0001\u00f7\u0003"+
		"\u00f7\u0a7b\b\u00f7\u0001\u00f8\u0001\u00f8\u0001\u00f8\u0001\u00f8\u0001"+
		"\u00f8\u0001\u00f8\u0003\u00f8\u0a83\b\u00f8\u0001\u00f8\u0000\u0002\u00c4"+
		"\u01c4\u00f9\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016"+
		"\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@BDFHJLNPRTVXZ\\^`bdfhjlnprt"+
		"vxz|~\u0080\u0082\u0084\u0086\u0088\u008a\u008c\u008e\u0090\u0092\u0094"+
		"\u0096\u0098\u009a\u009c\u009e\u00a0\u00a2\u00a4\u00a6\u00a8\u00aa\u00ac"+
		"\u00ae\u00b0\u00b2\u00b4\u00b6\u00b8\u00ba\u00bc\u00be\u00c0\u00c2\u00c4"+
		"\u00c6\u00c8\u00ca\u00cc\u00ce\u00d0\u00d2\u00d4\u00d6\u00d8\u00da\u00dc"+
		"\u00de\u00e0\u00e2\u00e4\u00e6\u00e8\u00ea\u00ec\u00ee\u00f0\u00f2\u00f4"+
		"\u00f6\u00f8\u00fa\u00fc\u00fe\u0100\u0102\u0104\u0106\u0108\u010a\u010c"+
		"\u010e\u0110\u0112\u0114\u0116\u0118\u011a\u011c\u011e\u0120\u0122\u0124"+
		"\u0126\u0128\u012a\u012c\u012e\u0130\u0132\u0134\u0136\u0138\u013a\u013c"+
		"\u013e\u0140\u0142\u0144\u0146\u0148\u014a\u014c\u014e\u0150\u0152\u0154"+
		"\u0156\u0158\u015a\u015c\u015e\u0160\u0162\u0164\u0166\u0168\u016a\u016c"+
		"\u016e\u0170\u0172\u0174\u0176\u0178\u017a\u017c\u017e\u0180\u0182\u0184"+
		"\u0186\u0188\u018a\u018c\u018e\u0190\u0192\u0194\u0196\u0198\u019a\u019c"+
		"\u019e\u01a0\u01a2\u01a4\u01a6\u01a8\u01aa\u01ac\u01ae\u01b0\u01b2\u01b4"+
		"\u01b6\u01b8\u01ba\u01bc\u01be\u01c0\u01c2\u01c4\u01c6\u01c8\u01ca\u01cc"+
		"\u01ce\u01d0\u01d2\u01d4\u01d6\u01d8\u01da\u01dc\u01de\u01e0\u01e2\u01e4"+
		"\u01e6\u01e8\u01ea\u01ec\u01ee\u01f0\u0000*\u0002\u0000((AA\u0002\u0000"+
		"$$BB\u0002\u0000UUyy\u0001\u0000\u00b7\u00b8\u0002\u0000UU\u0096\u0096"+
		"\u0003\u0000ZZ||\u00b5\u00b5\u0002\u0000\u009f\u009f\u00d9\u00d9\u0001"+
		"\u0000\u00e9\u00ea\u0001\u0000\u00ed\u00f3\u0001\u0000\u00f8\u00f9\u0002"+
		"\u0000\u00ed\u00ed\u00f0\u00f0\t\u0000>>KK__\u0090\u0091\u0093\u0093\u00b1"+
		"\u00b1\u00ba\u00ba\u00d6\u00d6\u00e6\u00e6\u0002\u0000__\u0090\u0090\u0002"+
		"\u0000<<\u00c3\u00c3\u0002\u0000\n\n\u0018\u0018\u0003\u0000\'\'{{\u00c8"+
		"\u00c8\u0002\u0000{{\u00c8\u00c8\u0001\u0000\u00cb\u00cc\u0004\u0000%"+
		"%\u0087\u0087\u008d\u008d\u00c0\u00c0\u0002\u0000\u0088\u0088\u008e\u008e"+
		"\u0002\u0000\u0089\u0089\u008f\u008f\u0002\u0000\u001f\u001fNN\u0002\u0000"+
		"!!\u00be\u00be\u0002\u0000\u00d9\u00d9\u00db\u00db\u0003\u0000]]\u00b2"+
		"\u00b2\u00b8\u00b8\u0002\u0000LL\u00e9\u00ea\u0002\u0000//\u00cf\u00cf"+
		"\u0002\u0000\"\"\u009b\u009b\u0002\u0000HHLL\u0002\u0000\t\t\u00d4\u00d4"+
		"\u0002\u0000\u001e\u001e\u00e8\u00e8\u0002\u0000LL\u00e8\u00e8\u0002\u0000"+
		"HH\u00e8\u00ea\u0003\u000022ccjj\u0002\u0000FF\u00d5\u00d5\u0002\u0000"+
		"EE\u00d4\u00d4\u0002\u0000ddww\u0002\u0000eexx\u0002\u0000\u0004\u0004"+
		"\u000e\u0014\u0002\u0000aa}}\u0002\u0000FFee\u0005\u0000\u0019Y[eg{}\u00a4"+
		"\u00a6\u00e7\u0b47\u0000\u01f2\u0001\u0000\u0000\u0000\u0002\u01f9\u0001"+
		"\u0000\u0000\u0000\u0004\u01fb\u0001\u0000\u0000\u0000\u0006\u01fe\u0001"+
		"\u0000\u0000\u0000\b\u0209\u0001\u0000\u0000\u0000\n\u0212\u0001\u0000"+
		"\u0000\u0000\f\u0223\u0001\u0000\u0000\u0000\u000e\u022b\u0001\u0000\u0000"+
		"\u0000\u0010\u0233\u0001\u0000\u0000\u0000\u0012\u023a\u0001\u0000\u0000"+
		"\u0000\u0014\u0249\u0001\u0000\u0000\u0000\u0016\u0256\u0001\u0000\u0000"+
		"\u0000\u0018\u027e\u0001\u0000\u0000\u0000\u001a\u0280\u0001\u0000\u0000"+
		"\u0000\u001c\u0282\u0001\u0000\u0000\u0000\u001e\u028b\u0001\u0000\u0000"+
		"\u0000 \u0295\u0001\u0000\u0000\u0000\"\u02a8\u0001\u0000\u0000\u0000"+
		"$\u02aa\u0001\u0000\u0000\u0000&\u02c7\u0001\u0000\u0000\u0000(\u02c9"+
		"\u0001\u0000\u0000\u0000*\u02d2\u0001\u0000\u0000\u0000,\u02d6\u0001\u0000"+
		"\u0000\u0000.\u02df\u0001\u0000\u0000\u00000\u02e3\u0001\u0000\u0000\u0000"+
		"2\u02eb\u0001\u0000\u0000\u00004\u02f8\u0001\u0000\u0000\u00006\u0303"+
		"\u0001\u0000\u0000\u00008\u030c\u0001\u0000\u0000\u0000:\u0317\u0001\u0000"+
		"\u0000\u0000<\u032d\u0001\u0000\u0000\u0000>\u0335\u0001\u0000\u0000\u0000"+
		"@\u0337\u0001\u0000\u0000\u0000B\u0340\u0001\u0000\u0000\u0000D\u0342"+
		"\u0001\u0000\u0000\u0000F\u034c\u0001\u0000\u0000\u0000H\u034e\u0001\u0000"+
		"\u0000\u0000J\u0350\u0001\u0000\u0000\u0000L\u0353\u0001\u0000\u0000\u0000"+
		"N\u0356\u0001\u0000\u0000\u0000P\u035b\u0001\u0000\u0000\u0000R\u0369"+
		"\u0001\u0000\u0000\u0000T\u036b\u0001\u0000\u0000\u0000V\u0371\u0001\u0000"+
		"\u0000\u0000X\u0379\u0001\u0000\u0000\u0000Z\u0381\u0001\u0000\u0000\u0000"+
		"\\\u0383\u0001\u0000\u0000\u0000^\u0388\u0001\u0000\u0000\u0000`\u038d"+
		"\u0001\u0000\u0000\u0000b\u03a0\u0001\u0000\u0000\u0000d\u03a2\u0001\u0000"+
		"\u0000\u0000f\u03a8\u0001\u0000\u0000\u0000h\u03ab\u0001\u0000\u0000\u0000"+
		"j\u03b3\u0001\u0000\u0000\u0000l\u03bd\u0001\u0000\u0000\u0000n\u03c7"+
		"\u0001\u0000\u0000\u0000p\u03dc\u0001\u0000\u0000\u0000r\u03e7\u0001\u0000"+
		"\u0000\u0000t\u03e9\u0001\u0000\u0000\u0000v\u03eb\u0001\u0000\u0000\u0000"+
		"x\u03f0\u0001\u0000\u0000\u0000z\u03fb\u0001\u0000\u0000\u0000|\u0406"+
		"\u0001\u0000\u0000\u0000~\u0411\u0001\u0000\u0000\u0000\u0080\u041c\u0001"+
		"\u0000\u0000\u0000\u0082\u0427\u0001\u0000\u0000\u0000\u0084\u042c\u0001"+
		"\u0000\u0000\u0000\u0086\u042e\u0001\u0000\u0000\u0000\u0088\u0431\u0001"+
		"\u0000\u0000\u0000\u008a\u0435\u0001\u0000\u0000\u0000\u008c\u0439\u0001"+
		"\u0000\u0000\u0000\u008e\u043d\u0001\u0000\u0000\u0000\u0090\u0444\u0001"+
		"\u0000\u0000\u0000\u0092\u044b\u0001\u0000\u0000\u0000\u0094\u0452\u0001"+
		"\u0000\u0000\u0000\u0096\u0454\u0001\u0000\u0000\u0000\u0098\u0461\u0001"+
		"\u0000\u0000\u0000\u009a\u0467\u0001\u0000\u0000\u0000\u009c\u0469\u0001"+
		"\u0000\u0000\u0000\u009e\u046b\u0001\u0000\u0000\u0000\u00a0\u0471\u0001"+
		"\u0000\u0000\u0000\u00a2\u0478\u0001\u0000\u0000\u0000\u00a4\u047e\u0001"+
		"\u0000\u0000\u0000\u00a6\u0483\u0001\u0000\u0000\u0000\u00a8\u0485\u0001"+
		"\u0000\u0000\u0000\u00aa\u0487\u0001\u0000\u0000\u0000\u00ac\u0489\u0001"+
		"\u0000\u0000\u0000\u00ae\u048b\u0001\u0000\u0000\u0000\u00b0\u048d\u0001"+
		"\u0000\u0000\u0000\u00b2\u0495\u0001\u0000\u0000\u0000\u00b4\u049c\u0001"+
		"\u0000\u0000\u0000\u00b6\u049e\u0001\u0000\u0000\u0000\u00b8\u04a9\u0001"+
		"\u0000\u0000\u0000\u00ba\u04b1\u0001\u0000\u0000\u0000\u00bc\u04b9\u0001"+
		"\u0000\u0000\u0000\u00be\u04bb\u0001\u0000\u0000\u0000\u00c0\u04c8\u0001"+
		"\u0000\u0000\u0000\u00c2\u04d0\u0001\u0000\u0000\u0000\u00c4\u04f3\u0001"+
		"\u0000\u0000\u0000\u00c6\u0515\u0001\u0000\u0000\u0000\u00c8\u051c\u0001"+
		"\u0000\u0000\u0000\u00ca\u051e\u0001\u0000\u0000\u0000\u00cc\u0522\u0001"+
		"\u0000\u0000\u0000\u00ce\u0529\u0001\u0000\u0000\u0000\u00d0\u0530\u0001"+
		"\u0000\u0000\u0000\u00d2\u0533\u0001\u0000\u0000\u0000\u00d4\u0536\u0001"+
		"\u0000\u0000\u0000\u00d6\u053e\u0001\u0000\u0000\u0000\u00d8\u0545\u0001"+
		"\u0000\u0000\u0000\u00da\u054a\u0001\u0000\u0000\u0000\u00dc\u0566\u0001"+
		"\u0000\u0000\u0000\u00de\u0568\u0001\u0000\u0000\u0000\u00e0\u056e\u0001"+
		"\u0000\u0000\u0000\u00e2\u0577\u0001\u0000\u0000\u0000\u00e4\u057e\u0001"+
		"\u0000\u0000\u0000\u00e6\u0585\u0001\u0000\u0000\u0000\u00e8\u058c\u0001"+
		"\u0000\u0000\u0000\u00ea\u058e\u0001\u0000\u0000\u0000\u00ec\u059b\u0001"+
		"\u0000\u0000\u0000\u00ee\u05a7\u0001\u0000\u0000\u0000\u00f0\u05ac\u0001"+
		"\u0000\u0000\u0000\u00f2\u05bb\u0001\u0000\u0000\u0000\u00f4\u05c0\u0001"+
		"\u0000\u0000\u0000\u00f6\u05c2\u0001\u0000\u0000\u0000\u00f8\u05de\u0001"+
		"\u0000\u0000\u0000\u00fa\u05e0\u0001\u0000\u0000\u0000\u00fc\u05e7\u0001"+
		"\u0000\u0000\u0000\u00fe\u05f1\u0001\u0000\u0000\u0000\u0100\u0613\u0001"+
		"\u0000\u0000\u0000\u0102\u0615\u0001\u0000\u0000\u0000\u0104\u0617\u0001"+
		"\u0000\u0000\u0000\u0106\u0619\u0001\u0000\u0000\u0000\u0108\u0627\u0001"+
		"\u0000\u0000\u0000\u010a\u062b\u0001\u0000\u0000\u0000\u010c\u062d\u0001"+
		"\u0000\u0000\u0000\u010e\u0638\u0001\u0000\u0000\u0000\u0110\u063a\u0001"+
		"\u0000\u0000\u0000\u0112\u063c\u0001\u0000\u0000\u0000\u0114\u063e\u0001"+
		"\u0000\u0000\u0000\u0116\u0645\u0001\u0000\u0000\u0000\u0118\u0647\u0001"+
		"\u0000\u0000\u0000\u011a\u0649\u0001\u0000\u0000\u0000\u011c\u0656\u0001"+
		"\u0000\u0000\u0000\u011e\u0658\u0001\u0000\u0000\u0000\u0120\u065a\u0001"+
		"\u0000\u0000\u0000\u0122\u065c\u0001\u0000\u0000\u0000\u0124\u0665\u0001"+
		"\u0000\u0000\u0000\u0126\u066e\u0001\u0000\u0000\u0000\u0128\u0677\u0001"+
		"\u0000\u0000\u0000\u012a\u067f\u0001\u0000\u0000\u0000\u012c\u0688\u0001"+
		"\u0000\u0000\u0000\u012e\u0691\u0001\u0000\u0000\u0000\u0130\u069a\u0001"+
		"\u0000\u0000\u0000\u0132\u06a3\u0001\u0000\u0000\u0000\u0134\u06a5\u0001"+
		"\u0000\u0000\u0000\u0136\u06ac\u0001\u0000\u0000\u0000\u0138\u06ae\u0001"+
		"\u0000\u0000\u0000\u013a\u06b5\u0001\u0000\u0000\u0000\u013c\u06c1\u0001"+
		"\u0000\u0000\u0000\u013e\u06cd\u0001\u0000\u0000\u0000\u0140\u06db\u0001"+
		"\u0000\u0000\u0000\u0142\u06dd\u0001\u0000\u0000\u0000\u0144\u06e9\u0001"+
		"\u0000\u0000\u0000\u0146\u06f8\u0001\u0000\u0000\u0000\u0148\u06fa\u0001"+
		"\u0000\u0000\u0000\u014a\u0705\u0001\u0000\u0000\u0000\u014c\u071e\u0001"+
		"\u0000\u0000\u0000\u014e\u0724\u0001\u0000\u0000\u0000\u0150\u072e\u0001"+
		"\u0000\u0000\u0000\u0152\u074d\u0001\u0000\u0000\u0000\u0154\u0759\u0001"+
		"\u0000\u0000\u0000\u0156\u075e\u0001\u0000\u0000\u0000\u0158\u0775\u0001"+
		"\u0000\u0000\u0000\u015a\u078c\u0001\u0000\u0000\u0000\u015c\u078e\u0001"+
		"\u0000\u0000\u0000\u015e\u0790\u0001\u0000\u0000\u0000\u0160\u0792\u0001"+
		"\u0000\u0000\u0000\u0162\u07a7\u0001\u0000\u0000\u0000\u0164\u07b2\u0001"+
		"\u0000\u0000\u0000\u0166\u07b8\u0001\u0000\u0000\u0000\u0168\u07c1\u0001"+
		"\u0000\u0000\u0000\u016a\u07c7\u0001\u0000\u0000\u0000\u016c\u07c9\u0001"+
		"\u0000\u0000\u0000\u016e\u07d6\u0001\u0000\u0000\u0000\u0170\u07ed\u0001"+
		"\u0000\u0000\u0000\u0172\u07f9\u0001\u0000\u0000\u0000\u0174\u0805\u0001"+
		"\u0000\u0000\u0000\u0176\u0811\u0001\u0000\u0000\u0000\u0178\u081a\u0001"+
		"\u0000\u0000\u0000\u017a\u081c\u0001\u0000\u0000\u0000\u017c\u082d\u0001"+
		"\u0000\u0000\u0000\u017e\u083a\u0001\u0000\u0000\u0000\u0180\u083e\u0001"+
		"\u0000\u0000\u0000\u0182\u0852\u0001\u0000\u0000\u0000\u0184\u0855\u0001"+
		"\u0000\u0000\u0000\u0186\u085b\u0001\u0000\u0000\u0000\u0188\u085f\u0001"+
		"\u0000\u0000\u0000\u018a\u087f\u0001\u0000\u0000\u0000\u018c\u0887\u0001"+
		"\u0000\u0000\u0000\u018e\u088c\u0001\u0000\u0000\u0000\u0190\u089f\u0001"+
		"\u0000\u0000\u0000\u0192\u08a6\u0001\u0000\u0000\u0000\u0194\u08ab\u0001"+
		"\u0000\u0000\u0000\u0196\u08b8\u0001\u0000\u0000\u0000\u0198\u08ca\u0001"+
		"\u0000\u0000\u0000\u019a\u08d3\u0001\u0000\u0000\u0000\u019c\u08d7\u0001"+
		"\u0000\u0000\u0000\u019e\u08db\u0001\u0000\u0000\u0000\u01a0\u08eb\u0001"+
		"\u0000\u0000\u0000\u01a2\u08ef\u0001\u0000\u0000\u0000\u01a4\u08f4\u0001"+
		"\u0000\u0000\u0000\u01a6\u092a\u0001\u0000\u0000\u0000\u01a8\u0932\u0001"+
		"\u0000\u0000\u0000\u01aa\u0934\u0001\u0000\u0000\u0000\u01ac\u0945\u0001"+
		"\u0000\u0000\u0000\u01ae\u0951\u0001\u0000\u0000\u0000\u01b0\u095d\u0001"+
		"\u0000\u0000\u0000\u01b2\u0967\u0001\u0000\u0000\u0000\u01b4\u096e\u0001"+
		"\u0000\u0000\u0000\u01b6\u0975\u0001\u0000\u0000\u0000\u01b8\u0982\u0001"+
		"\u0000\u0000\u0000\u01ba\u0986\u0001\u0000\u0000\u0000\u01bc\u098b\u0001"+
		"\u0000\u0000\u0000\u01be\u0993\u0001\u0000\u0000\u0000\u01c0\u09b2\u0001"+
		"\u0000\u0000\u0000\u01c2\u09b4\u0001\u0000\u0000\u0000\u01c4\u09e5\u0001"+
		"\u0000\u0000\u0000\u01c6\u09f4\u0001\u0000\u0000\u0000\u01c8\u09f8\u0001"+
		"\u0000\u0000\u0000\u01ca\u09fa\u0001\u0000\u0000\u0000\u01cc\u09fc\u0001"+
		"\u0000\u0000\u0000\u01ce\u09fe\u0001\u0000\u0000\u0000\u01d0\u0a00\u0001"+
		"\u0000\u0000\u0000\u01d2\u0a02\u0001\u0000\u0000\u0000\u01d4\u0a06\u0001"+
		"\u0000\u0000\u0000\u01d6\u0a0f\u0001\u0000\u0000\u0000\u01d8\u0a1d\u0001"+
		"\u0000\u0000\u0000\u01da\u0a3a\u0001\u0000\u0000\u0000\u01dc\u0a44\u0001"+
		"\u0000\u0000\u0000\u01de\u0a49\u0001\u0000\u0000\u0000\u01e0\u0a4b\u0001"+
		"\u0000\u0000\u0000\u01e2\u0a55\u0001\u0000\u0000\u0000\u01e4\u0a5c\u0001"+
		"\u0000\u0000\u0000\u01e6\u0a60\u0001\u0000\u0000\u0000\u01e8\u0a65\u0001"+
		"\u0000\u0000\u0000\u01ea\u0a6d\u0001\u0000\u0000\u0000\u01ec\u0a6f\u0001"+
		"\u0000\u0000\u0000\u01ee\u0a7a\u0001\u0000\u0000\u0000\u01f0\u0a82\u0001"+
		"\u0000\u0000\u0000\u01f2\u01f3\u0003\u0002\u0001\u0000\u01f3\u01f4\u0005"+
		"\u0000\u0000\u0001\u01f4\u0001\u0001\u0000\u0000\u0000\u01f5\u01fa\u0003"+
		"\u0004\u0002\u0000\u01f6\u01fa\u0003(\u0014\u0000\u01f7\u01fa\u00030\u0018"+
		"\u0000\u01f8\u01fa\u00032\u0019\u0000\u01f9\u01f5\u0001\u0000\u0000\u0000"+
		"\u01f9\u01f6\u0001\u0000\u0000\u0000\u01f9\u01f7\u0001\u0000\u0000\u0000"+
		"\u01f9\u01f8\u0001\u0000\u0000\u0000\u01fa\u0003\u0001\u0000\u0000\u0000"+
		"\u01fb\u01fc\u0003\u0006\u0003\u0000\u01fc\u0005\u0001\u0000\u0000\u0000"+
		"\u01fd\u01ff\u0003\b\u0004\u0000\u01fe\u01fd\u0001\u0000\u0000\u0000\u01fe"+
		"\u01ff\u0001\u0000\u0000\u0000\u01ff\u0200\u0001\u0000\u0000\u0000\u0200"+
		"\u0206\u0003\u0016\u000b\u0000\u0201\u0202\u0003p8\u0000\u0202\u0203\u0003"+
		"\u0016\u000b\u0000\u0203\u0205\u0001\u0000\u0000\u0000\u0204\u0201\u0001"+
		"\u0000\u0000\u0000\u0205\u0208\u0001\u0000\u0000\u0000\u0206\u0204\u0001"+
		"\u0000\u0000\u0000\u0206\u0207\u0001\u0000\u0000\u0000\u0207\u0007\u0001"+
		"\u0000\u0000\u0000\u0208\u0206\u0001\u0000\u0000\u0000\u0209\u020a\u0005"+
		"\u00d9\u0000\u0000\u020a\u020f\u0003\n\u0005\u0000\u020b\u020c\u0005\u0001"+
		"\u0000\u0000\u020c\u020e\u0003\n\u0005\u0000\u020d\u020b\u0001\u0000\u0000"+
		"\u0000\u020e\u0211\u0001\u0000\u0000\u0000\u020f\u020d\u0001\u0000\u0000"+
		"\u0000\u020f\u0210\u0001\u0000\u0000\u0000\u0210\t\u0001\u0000\u0000\u0000"+
		"\u0211\u020f\u0001\u0000\u0000\u0000\u0212\u0213\u0003\u01f0\u00f8\u0000"+
		"\u0213\u0218\u0005#\u0000\u0000\u0214\u0216\u0005\u0098\u0000\u0000\u0215"+
		"\u0214\u0001\u0000\u0000\u0000\u0215\u0216\u0001\u0000\u0000\u0000\u0216"+
		"\u0217\u0001\u0000\u0000\u0000\u0217\u0219\u0005\u0086\u0000\u0000\u0218"+
		"\u0215\u0001\u0000\u0000\u0000\u0218\u0219\u0001\u0000\u0000\u0000\u0219"+
		"\u021a\u0001\u0000\u0000\u0000\u021a\u021b\u0005\u0002\u0000\u0000\u021b"+
		"\u021c\u0003\u0006\u0003\u0000\u021c\u021e\u0005\u0003\u0000\u0000\u021d"+
		"\u021f\u0003\f\u0006\u0000\u021e\u021d\u0001\u0000\u0000\u0000\u021e\u021f"+
		"\u0001\u0000\u0000\u0000\u021f\u0221\u0001\u0000\u0000\u0000\u0220\u0222"+
		"\u0003\u0012\t\u0000\u0221\u0220\u0001\u0000\u0000\u0000\u0221\u0222\u0001"+
		"\u0000\u0000\u0000\u0222\u000b\u0001\u0000\u0000\u0000\u0223\u0224\u0005"+
		"\u00b9\u0000\u0000\u0224\u0225\u0007\u0000\u0000\u0000\u0225\u0226\u0005"+
		"U\u0000\u0000\u0226\u0227\u0005)\u0000\u0000\u0227\u0228\u0003\u000e\u0007"+
		"\u0000\u0228\u0229\u0005\u00bc\u0000\u0000\u0229\u022a\u0003\u01f0\u00f8"+
		"\u0000\u022a\r\u0001\u0000\u0000\u0000\u022b\u0230\u0003\u0010\b\u0000"+
		"\u022c\u022d\u0005\u0001\u0000\u0000\u022d\u022f\u0003\u0010\b\u0000\u022e"+
		"\u022c\u0001\u0000\u0000\u0000\u022f\u0232\u0001\u0000\u0000\u0000\u0230"+
		"\u022e\u0001\u0000\u0000\u0000\u0230\u0231\u0001\u0000\u0000\u0000\u0231"+
		"\u000f\u0001\u0000\u0000\u0000\u0232\u0230\u0001\u0000\u0000\u0000\u0233"+
		"\u0235\u0003\u01f0\u00f8\u0000\u0234\u0236\u0003H$\u0000\u0235\u0234\u0001"+
		"\u0000\u0000\u0000\u0235\u0236\u0001\u0000\u0000\u0000\u0236\u0238\u0001"+
		"\u0000\u0000\u0000\u0237\u0239\u0003J%\u0000\u0238\u0237\u0001\u0000\u0000"+
		"\u0000\u0238\u0239\u0001\u0000\u0000\u0000\u0239\u0011\u0001\u0000\u0000"+
		"\u0000\u023a\u023b\u0005;\u0000\u0000\u023b\u023c\u0003\u0014\n\u0000"+
		"\u023c\u023d\u0005\u00bc\u0000\u0000\u023d\u0243\u0003\u01f0\u00f8\u0000"+
		"\u023e\u023f\u0005\u00c7\u0000\u0000\u023f\u0240\u0003r9\u0000\u0240\u0241"+
		"\u0005?\u0000\u0000\u0241\u0242\u0003r9\u0000\u0242\u0244\u0001\u0000"+
		"\u0000\u0000\u0243\u023e\u0001\u0000\u0000\u0000\u0243\u0244\u0001\u0000"+
		"\u0000\u0000\u0244\u0247\u0001\u0000\u0000\u0000\u0245\u0246\u0005\u00d3"+
		"\u0000\u0000\u0246\u0248\u0003\u01f0\u00f8\u0000\u0247\u0245\u0001\u0000"+
		"\u0000\u0000\u0247\u0248\u0001\u0000\u0000\u0000\u0248\u0013\u0001\u0000"+
		"\u0000\u0000\u0249\u024e\u0003\u01f0\u00f8\u0000\u024a\u024b\u0005\u0001"+
		"\u0000\u0000\u024b\u024d\u0003\u01f0\u00f8\u0000\u024c\u024a\u0001\u0000"+
		"\u0000\u0000\u024d\u0250\u0001\u0000\u0000\u0000\u024e\u024c\u0001\u0000"+
		"\u0000\u0000\u024e\u024f\u0001\u0000\u0000\u0000\u024f\u0015\u0001\u0000"+
		"\u0000\u0000\u0250\u024e\u0001\u0000\u0000\u0000\u0251\u0257\u0003\u0018"+
		"\f\u0000\u0252\u0253\u0005\u0002\u0000\u0000\u0253\u0254\u0003\u0006\u0003"+
		"\u0000\u0254\u0255\u0005\u0003\u0000\u0000\u0255\u0257\u0001\u0000\u0000"+
		"\u0000\u0256\u0251\u0001\u0000\u0000\u0000\u0256\u0252\u0001\u0000\u0000"+
		"\u0000\u0257\u0259\u0001\u0000\u0000\u0000\u0258\u025a\u0003\u001a\r\u0000"+
		"\u0259\u0258\u0001\u0000\u0000\u0000\u0259\u025a\u0001\u0000\u0000\u0000"+
		"\u025a\u025c\u0001\u0000\u0000\u0000\u025b\u025d\u0003L&\u0000\u025c\u025b"+
		"\u0001\u0000\u0000\u0000\u025c\u025d\u0001\u0000\u0000\u0000\u025d\u025f"+
		"\u0001\u0000\u0000\u0000\u025e\u0260\u0003N\'\u0000\u025f\u025e\u0001"+
		"\u0000\u0000\u0000\u025f\u0260\u0001\u0000\u0000\u0000\u0260\u0262\u0001"+
		"\u0000\u0000\u0000\u0261\u0263\u0003P(\u0000\u0262\u0261\u0001\u0000\u0000"+
		"\u0000\u0262\u0263\u0001\u0000\u0000\u0000\u0263\u0017\u0001\u0000\u0000"+
		"\u0000\u0264\u0266\u0003T*\u0000\u0265\u0267\u0003\u001c\u000e\u0000\u0266"+
		"\u0265\u0001\u0000\u0000\u0000\u0266\u0267\u0001\u0000\u0000\u0000\u0267"+
		"\u0269\u0001\u0000\u0000\u0000\u0268\u026a\u0003`0\u0000\u0269\u0268\u0001"+
		"\u0000\u0000\u0000\u0269\u026a\u0001\u0000\u0000\u0000\u026a\u026c\u0001"+
		"\u0000\u0000\u0000\u026b\u026d\u0003j5\u0000\u026c\u026b\u0001\u0000\u0000"+
		"\u0000\u026c\u026d\u0001\u0000\u0000\u0000\u026d\u026f\u0001\u0000\u0000"+
		"\u0000\u026e\u0270\u0003n7\u0000\u026f\u026e\u0001\u0000\u0000\u0000\u026f"+
		"\u0270\u0001\u0000\u0000\u0000\u0270\u027f\u0001\u0000\u0000\u0000\u0271"+
		"\u0273\u0003\u001c\u000e\u0000\u0272\u0274\u0003`0\u0000\u0273\u0272\u0001"+
		"\u0000\u0000\u0000\u0273\u0274\u0001\u0000\u0000\u0000\u0274\u0276\u0001"+
		"\u0000\u0000\u0000\u0275\u0277\u0003j5\u0000\u0276\u0275\u0001\u0000\u0000"+
		"\u0000\u0276\u0277\u0001\u0000\u0000\u0000\u0277\u0279\u0001\u0000\u0000"+
		"\u0000\u0278\u027a\u0003n7\u0000\u0279\u0278\u0001\u0000\u0000\u0000\u0279"+
		"\u027a\u0001\u0000\u0000\u0000\u027a\u027c\u0001\u0000\u0000\u0000\u027b"+
		"\u027d\u0003T*\u0000\u027c\u027b\u0001\u0000\u0000\u0000\u027c\u027d\u0001"+
		"\u0000\u0000\u0000\u027d\u027f\u0001\u0000\u0000\u0000\u027e\u0264\u0001"+
		"\u0000\u0000\u0000\u027e\u0271\u0001\u0000\u0000\u0000\u027f\u0019\u0001"+
		"\u0000\u0000\u0000\u0280\u0281\u0003l6\u0000\u0281\u001b\u0001\u0000\u0000"+
		"\u0000\u0282\u0283\u0005Y\u0000\u0000\u0283\u0288\u0003\u001e\u000f\u0000"+
		"\u0284\u0285\u0005\u0001\u0000\u0000\u0285\u0287\u0003\u001e\u000f\u0000"+
		"\u0286\u0284\u0001\u0000\u0000\u0000\u0287\u028a\u0001\u0000\u0000\u0000"+
		"\u0288\u0286\u0001\u0000\u0000\u0000\u0288\u0289\u0001\u0000\u0000\u0000"+
		"\u0289\u001d\u0001\u0000\u0000\u0000\u028a\u0288\u0001\u0000\u0000\u0000"+
		"\u028b\u028f\u0003\"\u0011\u0000\u028c\u028e\u0003 \u0010\u0000\u028d"+
		"\u028c\u0001\u0000\u0000\u0000\u028e\u0291\u0001\u0000\u0000\u0000\u028f"+
		"\u028d\u0001\u0000\u0000\u0000\u028f\u0290\u0001\u0000\u0000\u0000\u0290"+
		"\u001f\u0001\u0000\u0000\u0000\u0291\u028f\u0001\u0000\u0000\u0000\u0292"+
		"\u0296\u0003$\u0012\u0000\u0293\u0296\u0003d2\u0000\u0294\u0296\u0003"+
		"h4\u0000\u0295\u0292\u0001\u0000\u0000\u0000\u0295\u0293\u0001\u0000\u0000"+
		"\u0000\u0295\u0294\u0001\u0000\u0000\u0000\u0296!\u0001\u0000\u0000\u0000"+
		"\u0297\u0299\u0003\u01ec\u00f6\u0000\u0298\u029a\u0003\u01e8\u00f4\u0000"+
		"\u0299\u0298\u0001\u0000\u0000\u0000\u0299\u029a\u0001\u0000\u0000\u0000"+
		"\u029a\u02a9\u0001\u0000\u0000\u0000\u029b\u029d\u0005z\u0000\u0000\u029c"+
		"\u029b\u0001\u0000\u0000\u0000\u029c\u029d\u0001\u0000\u0000\u0000\u029d"+
		"\u029e\u0001\u0000\u0000\u0000\u029e\u029f\u0005\u0002\u0000\u0000\u029f"+
		"\u02a0\u0003R)\u0000\u02a0\u02a2\u0005\u0003\u0000\u0000\u02a1\u02a3\u0003"+
		"\u01e8\u00f4\u0000\u02a2\u02a1\u0001\u0000\u0000\u0000\u02a2\u02a3\u0001"+
		"\u0000\u0000\u0000\u02a3\u02a9\u0001\u0000\u0000\u0000\u02a4\u02a6\u0003"+
		"\u00f4z\u0000\u02a5\u02a7\u0003\u01e8\u00f4\u0000\u02a6\u02a5\u0001\u0000"+
		"\u0000\u0000\u02a6\u02a7\u0001\u0000\u0000\u0000\u02a7\u02a9\u0001\u0000"+
		"\u0000\u0000\u02a8\u0297\u0001\u0000\u0000\u0000\u02a8\u029c\u0001\u0000"+
		"\u0000\u0000\u02a8\u02a4\u0001\u0000\u0000\u0000\u02a9#\u0001\u0000\u0000"+
		"\u0000\u02aa\u02ab\u0003b1\u0000\u02ab\u02ad\u0005m\u0000\u0000\u02ac"+
		"\u02ae\u0005S\u0000\u0000\u02ad\u02ac\u0001\u0000\u0000\u0000\u02ad\u02ae"+
		"\u0001\u0000\u0000\u0000\u02ae\u02af\u0001\u0000\u0000\u0000\u02af\u02b1"+
		"\u0003&\u0013\u0000\u02b0\u02b2\u0003f3\u0000\u02b1\u02b0\u0001\u0000"+
		"\u0000\u0000\u02b1\u02b2\u0001\u0000\u0000\u0000\u02b2%\u0001\u0000\u0000"+
		"\u0000\u02b3\u02b5\u0003\u00c8d\u0000\u02b4\u02b6\u0003\u01e8\u00f4\u0000"+
		"\u02b5\u02b4\u0001\u0000\u0000\u0000\u02b5\u02b6\u0001\u0000\u0000\u0000"+
		"\u02b6\u02c8\u0001\u0000\u0000\u0000\u02b7\u02b9\u0005z\u0000\u0000\u02b8"+
		"\u02b7\u0001\u0000\u0000\u0000\u02b8\u02b9\u0001\u0000\u0000\u0000\u02b9"+
		"\u02ba\u0001\u0000\u0000\u0000\u02ba\u02bb\u0005\u0002\u0000\u0000\u02bb"+
		"\u02bc\u0003R)\u0000\u02bc\u02be\u0005\u0003\u0000\u0000\u02bd\u02bf\u0003"+
		"\u01e8\u00f4\u0000\u02be\u02bd\u0001\u0000\u0000\u0000\u02be\u02bf\u0001"+
		"\u0000\u0000\u0000\u02bf\u02c8\u0001\u0000\u0000\u0000\u02c0\u02c2\u0005"+
		"z\u0000\u0000\u02c1\u02c0\u0001\u0000\u0000\u0000\u02c1\u02c2\u0001\u0000"+
		"\u0000\u0000\u02c2\u02c3\u0001\u0000\u0000\u0000\u02c3\u02c5\u0003\u00f4"+
		"z\u0000\u02c4\u02c6\u0003\u01e8\u00f4\u0000\u02c5\u02c4\u0001\u0000\u0000"+
		"\u0000\u02c5\u02c6\u0001\u0000\u0000\u0000\u02c6\u02c8\u0001\u0000\u0000"+
		"\u0000\u02c7\u02b3\u0001\u0000\u0000\u0000\u02c7\u02b8\u0001\u0000\u0000"+
		"\u0000\u02c7\u02c1\u0001\u0000\u0000\u0000\u02c8\'\u0001\u0000\u0000\u0000"+
		"\u02c9\u02cb\u0005\u00d2\u0000\u0000\u02ca\u02cc\u0005\u001b\u0000\u0000"+
		"\u02cb\u02ca\u0001\u0000\u0000\u0000\u02cb\u02cc\u0001\u0000\u0000\u0000"+
		"\u02cc\u02cd\u0001\u0000\u0000\u0000\u02cd\u02ce\u0003*\u0015\u0000\u02ce"+
		"\u02d0\u0003,\u0016\u0000\u02cf\u02d1\u0003`0\u0000\u02d0\u02cf\u0001"+
		"\u0000\u0000\u0000\u02d0\u02d1\u0001\u0000\u0000\u0000\u02d1)\u0001\u0000"+
		"\u0000\u0000\u02d2\u02d4\u0003\u01ec\u00f6\u0000\u02d3\u02d5\u0003\u01e8"+
		"\u00f4\u0000\u02d4\u02d3\u0001\u0000\u0000\u0000\u02d4\u02d5\u0001\u0000"+
		"\u0000\u0000\u02d5+\u0001\u0000\u0000\u0000\u02d6\u02d7\u0005\u00bc\u0000"+
		"\u0000\u02d7\u02dc\u0003.\u0017\u0000\u02d8\u02d9\u0005\u0001\u0000\u0000"+
		"\u02d9\u02db\u0003.\u0017\u0000\u02da\u02d8\u0001\u0000\u0000\u0000\u02db"+
		"\u02de\u0001\u0000\u0000\u0000\u02dc\u02da\u0001\u0000\u0000\u0000\u02dc"+
		"\u02dd\u0001\u0000\u0000\u0000\u02dd-\u0001\u0000\u0000\u0000\u02de\u02dc"+
		"\u0001\u0000\u0000\u0000\u02df\u02e0\u0003\u00ceg\u0000\u02e0\u02e1\u0005"+
		"\u0004\u0000\u0000\u02e1\u02e2\u0003\u01c6\u00e3\u0000\u02e2/\u0001\u0000"+
		"\u0000\u0000\u02e3\u02e5\u0005@\u0000\u0000\u02e4\u02e6\u0005Y\u0000\u0000"+
		"\u02e5\u02e4\u0001\u0000\u0000\u0000\u02e5\u02e6\u0001\u0000\u0000\u0000"+
		"\u02e6\u02e7\u0001\u0000\u0000\u0000\u02e7\u02e9\u0003*\u0015\u0000\u02e8"+
		"\u02ea\u0003`0\u0000\u02e9\u02e8\u0001\u0000\u0000\u0000\u02e9\u02ea\u0001"+
		"\u0000\u0000\u0000\u02ea1\u0001\u0000\u0000\u0000\u02eb\u02ed\u0005g\u0000"+
		"\u0000\u02ec\u02ee\u0005k\u0000\u0000\u02ed\u02ec\u0001\u0000\u0000\u0000"+
		"\u02ed\u02ee\u0001\u0000\u0000\u0000\u02ee\u02ef\u0001\u0000\u0000\u0000"+
		"\u02ef\u02f0\u0003*\u0015\u0000\u02f0\u02f3\u00034\u001a\u0000\u02f1\u02f4"+
		"\u0003\u0006\u0003\u0000\u02f2\u02f4\u00036\u001b\u0000\u02f3\u02f1\u0001"+
		"\u0000\u0000\u0000\u02f3\u02f2\u0001\u0000\u0000\u0000\u02f4\u02f6\u0001"+
		"\u0000\u0000\u0000\u02f5\u02f7\u0003:\u001d\u0000\u02f6\u02f5\u0001\u0000"+
		"\u0000\u0000\u02f6\u02f7\u0001\u0000\u0000\u0000\u02f73\u0001\u0000\u0000"+
		"\u0000\u02f8\u02f9\u0005\u0002\u0000\u0000\u02f9\u02fe\u0003\u00ceg\u0000"+
		"\u02fa\u02fb\u0005\u0001\u0000\u0000\u02fb\u02fd\u0003\u00ceg\u0000\u02fc"+
		"\u02fa\u0001\u0000\u0000\u0000\u02fd\u0300\u0001\u0000\u0000\u0000\u02fe"+
		"\u02fc\u0001\u0000\u0000\u0000\u02fe\u02ff\u0001\u0000\u0000\u0000\u02ff"+
		"\u0301\u0001\u0000\u0000\u0000\u0300\u02fe\u0001\u0000\u0000\u0000\u0301"+
		"\u0302\u0005\u0003\u0000\u0000\u03025\u0001\u0000\u0000\u0000\u0303\u0304"+
		"\u0005\u00d5\u0000\u0000\u0304\u0309\u00038\u001c\u0000\u0305\u0306\u0005"+
		"\u0001\u0000\u0000\u0306\u0308\u00038\u001c\u0000\u0307\u0305\u0001\u0000"+
		"\u0000\u0000\u0308\u030b\u0001\u0000\u0000\u0000\u0309\u0307\u0001\u0000"+
		"\u0000\u0000\u0309\u030a\u0001\u0000\u0000\u0000\u030a7\u0001\u0000\u0000"+
		"\u0000\u030b\u0309\u0001\u0000\u0000\u0000\u030c\u030d\u0005\u0002\u0000"+
		"\u0000\u030d\u0312\u0003\u00c4b\u0000\u030e\u030f\u0005\u0001\u0000\u0000"+
		"\u030f\u0311\u0003\u00c4b\u0000\u0310\u030e\u0001\u0000\u0000\u0000\u0311"+
		"\u0314\u0001\u0000\u0000\u0000\u0312\u0310\u0001\u0000\u0000\u0000\u0312"+
		"\u0313\u0001\u0000\u0000\u0000\u0313\u0315\u0001\u0000\u0000\u0000\u0314"+
		"\u0312\u0001\u0000\u0000\u0000\u0315\u0316\u0005\u0003\u0000\u0000\u0316"+
		"9\u0001\u0000\u0000\u0000\u0317\u0318\u0005\u009f\u0000\u0000\u0318\u031a"+
		"\u00050\u0000\u0000\u0319\u031b\u0003<\u001e\u0000\u031a\u0319\u0001\u0000"+
		"\u0000\u0000\u031a\u031b\u0001\u0000\u0000\u0000\u031b\u031c\u0001\u0000"+
		"\u0000\u0000\u031c\u031d\u0005D\u0000\u0000\u031d\u031e\u0003>\u001f\u0000"+
		"\u031e;\u0001\u0000\u0000\u0000\u031f\u0320\u0005\u009f\u0000\u0000\u0320"+
		"\u0321\u00051\u0000\u0000\u0321\u032e\u0003\u01f0\u00f8\u0000\u0322\u0323"+
		"\u0005\u0002\u0000\u0000\u0323\u0328\u0003\u00ceg\u0000\u0324\u0325\u0005"+
		"\u0001\u0000\u0000\u0325\u0327\u0003\u00ceg\u0000\u0326\u0324\u0001\u0000"+
		"\u0000\u0000\u0327\u032a\u0001\u0000\u0000\u0000\u0328\u0326\u0001\u0000"+
		"\u0000\u0000\u0328\u0329\u0001\u0000\u0000\u0000\u0329\u032b\u0001\u0000"+
		"\u0000\u0000\u032a\u0328\u0001\u0000\u0000\u0000\u032b\u032c\u0005\u0003"+
		"\u0000\u0000\u032c\u032e\u0001\u0000\u0000\u0000\u032d\u031f\u0001\u0000"+
		"\u0000\u0000\u032d\u0322\u0001\u0000\u0000\u0000\u032e=\u0001\u0000\u0000"+
		"\u0000\u032f\u0336\u0005\u0099\u0000\u0000\u0330\u0331\u0005\u00d2\u0000"+
		"\u0000\u0331\u0333\u0003,\u0016\u0000\u0332\u0334\u0003`0\u0000\u0333"+
		"\u0332\u0001\u0000\u0000\u0000\u0333\u0334\u0001\u0000\u0000\u0000\u0334"+
		"\u0336\u0001\u0000\u0000\u0000\u0335\u032f\u0001\u0000\u0000\u0000\u0335"+
		"\u0330\u0001\u0000\u0000\u0000\u0336?\u0001\u0000\u0000\u0000\u0337\u0338"+
		"\u0005\u0094\u0000\u0000\u0338\u0339\u0003\u01de\u00ef\u0000\u0339\u033a"+
		"\u0005\u0002\u0000\u0000\u033a\u033b\u0003\u01e0\u00f0\u0000\u033b\u033c"+
		"\u0005\u0003\u0000\u0000\u033cA\u0001\u0000\u0000\u0000\u033d\u0341\u0003"+
		"\u01f0\u00f8\u0000\u033e\u0341\u0005\u00ed\u0000\u0000\u033f\u0341\u0003"+
		"\u00c4b\u0000\u0340\u033d\u0001\u0000\u0000\u0000\u0340\u033e\u0001\u0000"+
		"\u0000\u0000\u0340\u033f\u0001\u0000\u0000\u0000\u0341C\u0001\u0000\u0000"+
		"\u0000\u0342\u0344\u0003F#\u0000\u0343\u0345\u0003H$\u0000\u0344\u0343"+
		"\u0001\u0000\u0000\u0000\u0344\u0345\u0001\u0000\u0000\u0000\u0345\u0347"+
		"\u0001\u0000\u0000\u0000\u0346\u0348\u0003J%\u0000\u0347\u0346\u0001\u0000"+
		"\u0000\u0000\u0347\u0348\u0001\u0000\u0000\u0000\u0348E\u0001\u0000\u0000"+
		"\u0000\u0349\u034d\u0003\u01f0\u00f8\u0000\u034a\u034d\u0005\u00ed\u0000"+
		"\u0000\u034b\u034d\u0003\u00c4b\u0000\u034c\u0349\u0001\u0000\u0000\u0000"+
		"\u034c\u034a\u0001\u0000\u0000\u0000\u034c\u034b\u0001\u0000\u0000\u0000"+
		"\u034dG\u0001\u0000\u0000\u0000\u034e\u034f\u0007\u0001\u0000\u0000\u034f"+
		"I\u0001\u0000\u0000\u0000\u0350\u0351\u0005\u009a\u0000\u0000\u0351\u0352"+
		"\u0007\u0002\u0000\u0000\u0352K\u0001\u0000\u0000\u0000\u0353\u0354\u0005"+
		"~\u0000\u0000\u0354\u0355\u0003\u01e4\u00f2\u0000\u0355M\u0001\u0000\u0000"+
		"\u0000\u0356\u0357\u0005\u009d\u0000\u0000\u0357\u0359\u0003\u01e4\u00f2"+
		"\u0000\u0358\u035a\u0007\u0003\u0000\u0000\u0359\u0358\u0001\u0000\u0000"+
		"\u0000\u0359\u035a\u0001\u0000\u0000\u0000\u035aO\u0001\u0000\u0000\u0000"+
		"\u035b\u035c\u0005S\u0000\u0000\u035c\u0361\u0007\u0004\u0000\u0000\u035d"+
		"\u0362\u0003\u01e4\u00f2\u0000\u035e\u035f\u0003\u01e6\u00f3\u0000\u035f"+
		"\u0360\u0005\u0005\u0000\u0000\u0360\u0362\u0001\u0000\u0000\u0000\u0361"+
		"\u035d\u0001\u0000\u0000\u0000\u0361\u035e\u0001\u0000\u0000\u0000\u0362"+
		"\u0363\u0001\u0000\u0000\u0000\u0363\u0367\u0007\u0003\u0000\u0000\u0364"+
		"\u0368\u0005\u00a0\u0000\u0000\u0365\u0366\u0005\u00d9\u0000\u0000\u0366"+
		"\u0368\u0005\u00c2\u0000\u0000\u0367\u0364\u0001\u0000\u0000\u0000\u0367"+
		"\u0365\u0001\u0000\u0000\u0000\u0368Q\u0001\u0000\u0000\u0000\u0369\u036a"+
		"\u0003\u0006\u0003\u0000\u036aS\u0001\u0000\u0000\u0000\u036b\u036d\u0005"+
		"\u00bb\u0000\u0000\u036c\u036e\u0005C\u0000\u0000\u036d\u036c\u0001\u0000"+
		"\u0000\u0000\u036d\u036e\u0001\u0000\u0000\u0000\u036e\u036f\u0001\u0000"+
		"\u0000\u0000\u036f\u0370\u0003V+\u0000\u0370U\u0001\u0000\u0000\u0000"+
		"\u0371\u0376\u0003X,\u0000\u0372\u0373\u0005\u0001\u0000\u0000\u0373\u0375"+
		"\u0003X,\u0000\u0374\u0372\u0001\u0000\u0000\u0000\u0375\u0378\u0001\u0000"+
		"\u0000\u0000\u0376\u0374\u0001\u0000\u0000\u0000\u0376\u0377\u0001\u0000"+
		"\u0000\u0000\u0377W\u0001\u0000\u0000\u0000\u0378\u0376\u0001\u0000\u0000"+
		"\u0000\u0379\u037b\u0003Z-\u0000\u037a\u037c\u0003\u01e8\u00f4\u0000\u037b"+
		"\u037a\u0001\u0000\u0000\u0000\u037b\u037c\u0001\u0000\u0000\u0000\u037c"+
		"Y\u0001\u0000\u0000\u0000\u037d\u0382\u0003@ \u0000\u037e\u0382\u0003"+
		"\\.\u0000\u037f\u0382\u0003^/\u0000\u0380\u0382\u0003\u01c6\u00e3\u0000"+
		"\u0381\u037d\u0001\u0000\u0000\u0000\u0381\u037e\u0001\u0000\u0000\u0000"+
		"\u0381\u037f\u0001\u0000\u0000\u0000\u0381\u0380\u0001\u0000\u0000\u0000"+
		"\u0382[\u0001\u0000\u0000\u0000\u0383\u0384\u0005J\u0000\u0000\u0384\u0385"+
		"\u0005\u0002\u0000\u0000\u0385\u0386\u0003\u00c8d\u0000\u0386\u0387\u0005"+
		"\u0003\u0000\u0000\u0387]\u0001\u0000\u0000\u0000\u0388\u0389\u0005\u009b"+
		"\u0000\u0000\u0389\u038a\u0005\u0002\u0000\u0000\u038a\u038b\u0003\u01f0"+
		"\u00f8\u0000\u038b\u038c\u0005\u0003\u0000\u0000\u038c_\u0001\u0000\u0000"+
		"\u0000\u038d\u038e\u0005\u00d8\u0000\u0000\u038e\u0393\u0003\u01c4\u00e2"+
		"\u0000\u038f\u0390\u0005\u0001\u0000\u0000\u0390\u0392\u0003\u01c4\u00e2"+
		"\u0000\u0391\u038f\u0001\u0000\u0000\u0000\u0392\u0395\u0001\u0000\u0000"+
		"\u0000\u0393\u0391\u0001\u0000\u0000\u0000\u0393\u0394\u0001\u0000\u0000"+
		"\u0000\u0394a\u0001\u0000\u0000\u0000\u0395\u0393\u0001\u0000\u0000\u0000"+
		"\u0396\u0398\u0005f\u0000\u0000\u0397\u0396\u0001\u0000\u0000\u0000\u0397"+
		"\u0398\u0001\u0000\u0000\u0000\u0398\u03a1\u0001\u0000\u0000\u0000\u0399"+
		"\u039b\u0007\u0005\u0000\u0000\u039a\u0399\u0001\u0000\u0000\u0000\u039a"+
		"\u039b\u0001\u0000\u0000\u0000\u039b\u039d\u0001\u0000\u0000\u0000\u039c"+
		"\u039e\u0005\u00a5\u0000\u0000\u039d\u039c\u0001\u0000\u0000\u0000\u039d"+
		"\u039e\u0001\u0000\u0000\u0000\u039e\u03a1\u0001\u0000\u0000\u0000\u039f"+
		"\u03a1\u00054\u0000\u0000\u03a0\u0397\u0001\u0000\u0000\u0000\u03a0\u039a"+
		"\u0001\u0000\u0000\u0000\u03a0\u039f\u0001\u0000\u0000\u0000\u03a1c\u0001"+
		"\u0000\u0000\u0000\u03a2\u03a3\u00054\u0000\u0000\u03a3\u03a4\u0005m\u0000"+
		"\u0000\u03a4\u03a6\u0003\u01ec\u00f6\u0000\u03a5\u03a7\u0003\u01e8\u00f4"+
		"\u0000\u03a6\u03a5\u0001\u0000\u0000\u0000\u03a6\u03a7\u0001\u0000\u0000"+
		"\u0000\u03a7e\u0001\u0000\u0000\u0000\u03a8\u03a9\u0007\u0006\u0000\u0000"+
		"\u03a9\u03aa\u0003\u01c4\u00e2\u0000\u03aag\u0001\u0000\u0000\u0000\u03ab"+
		"\u03ac\u0005\u0001\u0000\u0000\u03ac\u03ad\u0005b\u0000\u0000\u03ad\u03ae"+
		"\u0005\u0002\u0000\u0000\u03ae\u03af\u0003\u00c8d\u0000\u03af\u03b1\u0005"+
		"\u0003\u0000\u0000\u03b0\u03b2\u0003\u01e8\u00f4\u0000\u03b1\u03b0\u0001"+
		"\u0000\u0000\u0000\u03b1\u03b2\u0001\u0000\u0000\u0000\u03b2i\u0001\u0000"+
		"\u0000\u0000\u03b3\u03b4\u0005\\\u0000\u0000\u03b4\u03b5\u0005)\u0000"+
		"\u0000\u03b5\u03ba\u0003B!\u0000\u03b6\u03b7\u0005\u0001\u0000\u0000\u03b7"+
		"\u03b9\u0003B!\u0000\u03b8\u03b6\u0001\u0000\u0000\u0000\u03b9\u03bc\u0001"+
		"\u0000\u0000\u0000\u03ba\u03b8\u0001\u0000\u0000\u0000\u03ba\u03bb\u0001"+
		"\u0000\u0000\u0000\u03bbk\u0001\u0000\u0000\u0000\u03bc\u03ba\u0001\u0000"+
		"\u0000\u0000\u03bd\u03be\u0005\u00a2\u0000\u0000\u03be\u03bf\u0005)\u0000"+
		"\u0000\u03bf\u03c4\u0003D\"\u0000\u03c0\u03c1\u0005\u0001\u0000\u0000"+
		"\u03c1\u03c3\u0003D\"\u0000\u03c2\u03c0\u0001\u0000\u0000\u0000\u03c3"+
		"\u03c6\u0001\u0000\u0000\u0000\u03c4\u03c2\u0001\u0000\u0000\u0000\u03c4"+
		"\u03c5\u0001\u0000\u0000\u0000\u03c5m\u0001\u0000\u0000\u0000\u03c6\u03c4"+
		"\u0001\u0000\u0000\u0000\u03c7\u03c8\u0005^\u0000\u0000\u03c8\u03cd\u0003"+
		"\u01c4\u00e2\u0000\u03c9\u03ca\u0005\u0001\u0000\u0000\u03ca\u03cc\u0003"+
		"\u01c4\u00e2\u0000\u03cb\u03c9\u0001\u0000\u0000\u0000\u03cc\u03cf\u0001"+
		"\u0000\u0000\u0000\u03cd\u03cb\u0001\u0000\u0000\u0000\u03cd\u03ce\u0001"+
		"\u0000\u0000\u0000\u03ceo\u0001\u0000\u0000\u0000\u03cf\u03cd\u0001\u0000"+
		"\u0000\u0000\u03d0\u03d2\u0005\u00d0\u0000\u0000\u03d1\u03d3\u0005\u001f"+
		"\u0000\u0000\u03d2\u03d1\u0001\u0000\u0000\u0000\u03d2\u03d3\u0001\u0000"+
		"\u0000\u0000\u03d3\u03dd\u0001\u0000\u0000\u0000\u03d4\u03d6\u0005i\u0000"+
		"\u0000\u03d5\u03d7\u0005\u001f\u0000\u0000\u03d6\u03d5\u0001\u0000\u0000"+
		"\u0000\u03d6\u03d7\u0001\u0000\u0000\u0000\u03d7\u03dd\u0001\u0000\u0000"+
		"\u0000\u03d8\u03da\u0005O\u0000\u0000\u03d9\u03db\u0005\u001f\u0000\u0000"+
		"\u03da\u03d9\u0001\u0000\u0000\u0000\u03da\u03db\u0001\u0000\u0000\u0000"+
		"\u03db\u03dd\u0001\u0000\u0000\u0000\u03dc\u03d0\u0001\u0000\u0000\u0000"+
		"\u03dc\u03d4\u0001\u0000\u0000\u0000\u03dc\u03d8\u0001\u0000\u0000\u0000"+
		"\u03ddq\u0001\u0000\u0000\u0000\u03de\u03e8\u0005\u00eb\u0000\u0000\u03df"+
		"\u03e8\u0005\u00ec\u0000\u0000\u03e0\u03e8\u0005\u00e8\u0000\u0000\u03e1"+
		"\u03e8\u0003t:\u0000\u03e2\u03e8\u0003v;\u0000\u03e3\u03e8\u0003\u00c0"+
		"`\u0000\u03e4\u03e8\u0003\u00c2a\u0000\u03e5\u03e8\u0003\u0096K\u0000"+
		"\u03e6\u03e8\u0003\u0098L\u0000\u03e7\u03de\u0001\u0000\u0000\u0000\u03e7"+
		"\u03df\u0001\u0000\u0000\u0000\u03e7\u03e0\u0001\u0000\u0000\u0000\u03e7"+
		"\u03e1\u0001\u0000\u0000\u0000\u03e7\u03e2\u0001\u0000\u0000\u0000\u03e7"+
		"\u03e3\u0001\u0000\u0000\u0000\u03e7\u03e4\u0001\u0000\u0000\u0000\u03e7"+
		"\u03e5\u0001\u0000\u0000\u0000\u03e7\u03e6\u0001\u0000\u0000\u0000\u03e8"+
		"s\u0001\u0000\u0000\u0000\u03e9\u03ea\u0007\u0007\u0000\u0000\u03eau\u0001"+
		"\u0000\u0000\u0000\u03eb\u03ec\u0007\b\u0000\u0000\u03ecw\u0001\u0000"+
		"\u0000\u0000\u03ed\u03f1\u0003z=\u0000\u03ee\u03f1\u0003|>\u0000\u03ef"+
		"\u03f1\u0003~?\u0000\u03f0\u03ed\u0001\u0000\u0000\u0000\u03f0\u03ee\u0001"+
		"\u0000\u0000\u0000\u03f0\u03ef\u0001\u0000\u0000\u0000\u03f1y\u0001\u0000"+
		"\u0000\u0000\u03f2\u03f3\u0005\u0002\u0000\u0000\u03f3\u03f4\u0003\u0086"+
		"C\u0000\u03f4\u03f5\u0005\u0003\u0000\u0000\u03f5\u03fc\u0001\u0000\u0000"+
		"\u0000\u03f6\u03f8\u0005\u0081\u0000\u0000\u03f7\u03f6\u0001\u0000\u0000"+
		"\u0000\u03f7\u03f8\u0001\u0000\u0000\u0000\u03f8\u03f9\u0001\u0000\u0000"+
		"\u0000\u03f9\u03fa\u0005=\u0000\u0000\u03fa\u03fc\u0003\u0086C\u0000\u03fb"+
		"\u03f2\u0001\u0000\u0000\u0000\u03fb\u03f7\u0001\u0000\u0000\u0000\u03fc"+
		"{\u0001\u0000\u0000\u0000\u03fd\u03fe\u0005\u0002\u0000\u0000\u03fe\u03ff"+
		"\u0003\u0088D\u0000\u03ff\u0400\u0005\u0003\u0000\u0000\u0400\u0407\u0001"+
		"\u0000\u0000\u0000\u0401\u0403\u0005\u00e7\u0000\u0000\u0402\u0401\u0001"+
		"\u0000\u0000\u0000\u0402\u0403\u0001\u0000\u0000\u0000\u0403\u0404\u0001"+
		"\u0000\u0000\u0000\u0404\u0405\u0005=\u0000\u0000\u0405\u0407\u0003\u0088"+
		"D\u0000\u0406\u03fd\u0001\u0000\u0000\u0000\u0406\u0402\u0001\u0000\u0000"+
		"\u0000\u0407}\u0001\u0000\u0000\u0000\u0408\u0409\u0005\u0002\u0000\u0000"+
		"\u0409\u040a\u0003\u008aE\u0000\u040a\u040b\u0005\u0003\u0000\u0000\u040b"+
		"\u0412\u0001\u0000\u0000\u0000\u040c\u040e\u0005\u009d\u0000\u0000\u040d"+
		"\u040c\u0001\u0000\u0000\u0000\u040d\u040e\u0001\u0000\u0000\u0000\u040e"+
		"\u040f\u0001\u0000\u0000\u0000\u040f\u0410\u0005=\u0000\u0000\u0410\u0412"+
		"\u0003\u008cF\u0000\u0411\u0408\u0001\u0000\u0000\u0000\u0411\u040d\u0001"+
		"\u0000\u0000\u0000\u0412\u007f\u0001\u0000\u0000\u0000\u0413\u0414\u0005"+
		"\u0002\u0000\u0000\u0414\u0415\u0003\u009eO\u0000\u0415\u0416\u0005\u0003"+
		"\u0000\u0000\u0416\u041d\u0001\u0000\u0000\u0000\u0417\u0419\u0005\u0081"+
		"\u0000\u0000\u0418\u0417\u0001\u0000\u0000\u0000\u0418\u0419\u0001\u0000"+
		"\u0000\u0000\u0419\u041a\u0001\u0000\u0000\u0000\u041a\u041b\u0005<\u0000"+
		"\u0000\u041b\u041d\u0003\u009eO\u0000\u041c\u0413\u0001\u0000\u0000\u0000"+
		"\u041c\u0418\u0001\u0000\u0000\u0000\u041d\u0081\u0001\u0000\u0000\u0000"+
		"\u041e\u041f\u0005\u0002\u0000\u0000\u041f\u0420\u0003\u00a0P\u0000\u0420"+
		"\u0421\u0005\u0003\u0000\u0000\u0421\u0428\u0001\u0000\u0000\u0000\u0422"+
		"\u0424\u0005\u0081\u0000\u0000\u0423\u0422\u0001\u0000\u0000\u0000\u0423"+
		"\u0424\u0001\u0000\u0000\u0000\u0424\u0425\u0001\u0000\u0000\u0000\u0425"+
		"\u0426\u0005\u00c3\u0000\u0000\u0426\u0428\u0003\u00a0P\u0000\u0427\u041e"+
		"\u0001\u0000\u0000\u0000\u0427\u0423\u0001\u0000\u0000\u0000\u0428\u0083"+
		"\u0001\u0000\u0000\u0000\u0429\u042d\u0003\u0086C\u0000\u042a\u042d\u0003"+
		"\u0088D\u0000\u042b\u042d\u0003\u008aE\u0000\u042c\u0429\u0001\u0000\u0000"+
		"\u0000\u042c\u042a\u0001\u0000\u0000\u0000\u042c\u042b\u0001\u0000\u0000"+
		"\u0000\u042d\u0085\u0001\u0000\u0000\u0000\u042e\u042f\u0003\u009eO\u0000"+
		"\u042f\u0430\u0003\u00a0P\u0000\u0430\u0087\u0001\u0000\u0000\u0000\u0431"+
		"\u0432\u0003\u009eO\u0000\u0432\u0433\u0003\u00a0P\u0000\u0433\u0434\u0003"+
		"\u00b2Y\u0000\u0434\u0089\u0001\u0000\u0000\u0000\u0435\u0436\u0003\u009e"+
		"O\u0000\u0436\u0437\u0003\u00a0P\u0000\u0437\u0438\u0003\u00a2Q\u0000"+
		"\u0438\u008b\u0001\u0000\u0000\u0000\u0439\u043a\u0003\u009eO\u0000\u043a"+
		"\u043b\u0003\u00a0P\u0000\u043b\u043c\u0003\u00a4R\u0000\u043c\u008d\u0001"+
		"\u0000\u0000\u0000\u043d\u0440\u0005\u00f5\u0000\u0000\u043e\u0441\u0003"+
		"\u0084B\u0000\u043f\u0441\u0003\u0094J\u0000\u0440\u043e\u0001\u0000\u0000"+
		"\u0000\u0440\u043f\u0001\u0000\u0000\u0000\u0441\u0442\u0001\u0000\u0000"+
		"\u0000\u0442\u0443\u0005\u0006\u0000\u0000\u0443\u008f\u0001\u0000\u0000"+
		"\u0000\u0444\u0447\u0005\u00f6\u0000\u0000\u0445\u0448\u0003\u009eO\u0000"+
		"\u0446\u0448\u0003\u0094J\u0000\u0447\u0445\u0001\u0000\u0000\u0000\u0447"+
		"\u0446\u0001\u0000\u0000\u0000\u0448\u0449\u0001\u0000\u0000\u0000\u0449"+
		"\u044a\u0005\u0006\u0000\u0000\u044a\u0091\u0001\u0000\u0000\u0000\u044b"+
		"\u044e\u0005\u00f7\u0000\u0000\u044c\u044f\u0003\u00a0P\u0000\u044d\u044f"+
		"\u0003\u0094J\u0000\u044e\u044c\u0001\u0000\u0000\u0000\u044e\u044d\u0001"+
		"\u0000\u0000\u0000\u044f\u0450\u0001\u0000\u0000\u0000\u0450\u0451\u0005"+
		"\u0006\u0000\u0000\u0451\u0093\u0001\u0000\u0000\u0000\u0452\u0453\u0005"+
		"\u00eb\u0000\u0000\u0453\u0095\u0001\u0000\u0000\u0000\u0454\u045d\u0005"+
		"\u0007\u0000\u0000\u0455\u045a\u0003\u00c4b\u0000\u0456\u0457\u0005\u0001"+
		"\u0000\u0000\u0457\u0459\u0003\u00c4b\u0000\u0458\u0456\u0001\u0000\u0000"+
		"\u0000\u0459\u045c\u0001\u0000\u0000\u0000\u045a\u0458\u0001\u0000\u0000"+
		"\u0000\u045a\u045b\u0001\u0000\u0000\u0000\u045b\u045e\u0001\u0000\u0000"+
		"\u0000\u045c\u045a\u0001\u0000\u0000\u0000\u045d\u0455\u0001\u0000\u0000"+
		"\u0000\u045d\u045e\u0001\u0000\u0000\u0000\u045e\u045f\u0001\u0000\u0000"+
		"\u0000\u045f\u0460\u0005\b\u0000\u0000\u0460\u0097\u0001\u0000\u0000\u0000"+
		"\u0461\u0462\u0005\u0002\u0000\u0000\u0462\u0463\u0003\u009aM\u0000\u0463"+
		"\u0464\u0005\t\u0000\u0000\u0464\u0465\u0003\u009cN\u0000\u0465\u0466"+
		"\u0005\u0003\u0000\u0000\u0466\u0099\u0001\u0000\u0000\u0000\u0467\u0468"+
		"\u0005\u00eb\u0000\u0000\u0468\u009b\u0001\u0000\u0000\u0000\u0469\u046a"+
		"\u0005\u00eb\u0000\u0000\u046a\u009d\u0001\u0000\u0000\u0000\u046b\u046c"+
		"\u0003\u00a6S\u0000\u046c\u046d\u0005\u00f9\u0000\u0000\u046d\u046e\u0003"+
		"\u00a8T\u0000\u046e\u046f\u0005\u00f9\u0000\u0000\u046f\u0470\u0003\u00aa"+
		"U\u0000\u0470\u009f\u0001\u0000\u0000\u0000\u0471\u0472\u0003\u00acV\u0000"+
		"\u0472\u0473\u0005\t\u0000\u0000\u0473\u0476\u0003\u00aeW\u0000\u0474"+
		"\u0475\u0005\t\u0000\u0000\u0475\u0477\u0003\u00b0X\u0000\u0476\u0474"+
		"\u0001\u0000\u0000\u0000\u0476\u0477\u0001\u0000\u0000\u0000\u0477\u00a1"+
		"\u0001\u0000\u0000\u0000\u0478\u0479\u0007\t\u0000\u0000\u0479\u047c\u0003"+
		"\u00acV\u0000\u047a\u047b\u0005\t\u0000\u0000\u047b\u047d\u0003\u00ae"+
		"W\u0000\u047c\u047a\u0001\u0000\u0000\u0000\u047c\u047d\u0001\u0000\u0000"+
		"\u0000\u047d\u00a3\u0001\u0000\u0000\u0000\u047e\u047f\u0007\t\u0000\u0000"+
		"\u047f\u0480\u0003\u00acV\u0000\u0480\u0481\u0005\t\u0000\u0000\u0481"+
		"\u0482\u0003\u00aeW\u0000\u0482\u00a5\u0001\u0000\u0000\u0000\u0483\u0484"+
		"\u0005\u00ed\u0000\u0000\u0484\u00a7\u0001\u0000\u0000\u0000\u0485\u0486"+
		"\u0005\u00ed\u0000\u0000\u0486\u00a9\u0001\u0000\u0000\u0000\u0487\u0488"+
		"\u0005\u00ed\u0000\u0000\u0488\u00ab\u0001\u0000\u0000\u0000\u0489\u048a"+
		"\u0005\u00ed\u0000\u0000\u048a\u00ad\u0001\u0000\u0000\u0000\u048b\u048c"+
		"\u0005\u00ed\u0000\u0000\u048c\u00af\u0001\u0000\u0000\u0000\u048d\u048e"+
		"\u0007\n\u0000\u0000\u048e\u00b1\u0001\u0000\u0000\u0000\u048f\u0492\u0005"+
		"\u00fa\u0000\u0000\u0490\u0491\u0005\n\u0000\u0000\u0491\u0493\u0005\u00fa"+
		"\u0000\u0000\u0492\u0490\u0001\u0000\u0000\u0000\u0492\u0493\u0001\u0000"+
		"\u0000\u0000\u0493\u0496\u0001\u0000\u0000\u0000\u0494\u0496\u0005\u00eb"+
		"\u0000\u0000\u0495\u048f\u0001\u0000\u0000\u0000\u0495\u0494\u0001\u0000"+
		"\u0000\u0000\u0496\u00b3\u0001\u0000\u0000\u0000\u0497\u049d\u0003\u00b6"+
		"[\u0000\u0498\u049d\u0003\u00b8\\\u0000\u0499\u049d\u0003\u00ba]\u0000"+
		"\u049a\u049d\u0003\u00bc^\u0000\u049b\u049d\u0003\u00be_\u0000\u049c\u0497"+
		"\u0001\u0000\u0000\u0000\u049c\u0498\u0001\u0000\u0000\u0000\u049c\u0499"+
		"\u0001\u0000\u0000\u0000\u049c\u049a\u0001\u0000\u0000\u0000\u049c\u049b"+
		"\u0001\u0000\u0000\u0000\u049d\u00b5\u0001\u0000\u0000\u0000\u049e\u049f"+
		"\u0007\u000b\u0000\u0000\u049f\u00b7\u0001\u0000\u0000\u0000\u04a0\u04a1"+
		"\u0005>\u0000\u0000\u04a1\u04a2\u0005\u009c\u0000\u0000\u04a2\u04aa\u0005"+
		"\u0091\u0000\u0000\u04a3\u04a4\u0005>\u0000\u0000\u04a4\u04a5\u0005\u009c"+
		"\u0000\u0000\u04a5\u04aa\u0005\u00d6\u0000\u0000\u04a6\u04a7\u0005>\u0000"+
		"\u0000\u04a7\u04a8\u0005\u009c\u0000\u0000\u04a8\u04aa\u0005\u00e6\u0000"+
		"\u0000\u04a9\u04a0\u0001\u0000\u0000\u0000\u04a9\u04a3\u0001\u0000\u0000"+
		"\u0000\u04a9\u04a6\u0001\u0000\u0000\u0000\u04aa\u00b9\u0001\u0000\u0000"+
		"\u0000\u04ab\u04ac\u0005\u00d6\u0000\u0000\u04ac\u04ad\u0005\u009c\u0000"+
		"\u0000\u04ad\u04b2\u0005\u0091\u0000\u0000\u04ae\u04af\u0005\u00d6\u0000"+
		"\u0000\u04af\u04b0\u0005\u009c\u0000\u0000\u04b0\u04b2\u0005\u00e6\u0000"+
		"\u0000\u04b1\u04ab\u0001\u0000\u0000\u0000\u04b1\u04ae\u0001\u0000\u0000"+
		"\u0000\u04b2\u00bb\u0001\u0000\u0000\u0000\u04b3\u04b5\u0005\u009d\u0000"+
		"\u0000\u04b4\u04b6\u0007\f\u0000\u0000\u04b5\u04b4\u0001\u0000\u0000\u0000"+
		"\u04b5\u04b6\u0001\u0000\u0000\u0000\u04b6\u04ba\u0001\u0000\u0000\u0000"+
		"\u04b7\u04ba\u0005\u00c5\u0000\u0000\u04b8\u04ba\u0005\u00c6\u0000\u0000"+
		"\u04b9\u04b3\u0001\u0000\u0000\u0000\u04b9\u04b7\u0001\u0000\u0000\u0000"+
		"\u04b9\u04b8\u0001\u0000\u0000\u0000\u04ba\u00bd\u0001\u0000\u0000\u0000"+
		"\u04bb\u04bc\u0007\r\u0000\u0000\u04bc\u00bf\u0001\u0000\u0000\u0000\u04bd"+
		"\u04c9\u0005\u00f4\u0000\u0000\u04be\u04bf\u0005\u000b\u0000\u0000\u04bf"+
		"\u04c4\u0005\u00f3\u0000\u0000\u04c0\u04c1\u0005\u0001\u0000\u0000\u04c1"+
		"\u04c3\u0005\u00f3\u0000\u0000\u04c2\u04c0\u0001\u0000\u0000\u0000\u04c3"+
		"\u04c6\u0001\u0000\u0000\u0000\u04c4\u04c2\u0001\u0000\u0000\u0000\u04c4"+
		"\u04c5\u0001\u0000\u0000\u0000\u04c5\u04c7\u0001\u0000\u0000\u0000\u04c6"+
		"\u04c4\u0001\u0000\u0000\u0000\u04c7\u04c9\u0005\u0006\u0000\u0000\u04c8"+
		"\u04bd\u0001\u0000\u0000\u0000\u04c8\u04be\u0001\u0000\u0000\u0000\u04c9"+
		"\u00c1\u0001\u0000\u0000\u0000\u04ca\u04d1\u0003x<\u0000\u04cb\u04d1\u0003"+
		"\u0080@\u0000\u04cc\u04d1\u0003\u0082A\u0000\u04cd\u04d1\u0003\u008eG"+
		"\u0000\u04ce\u04d1\u0003\u0090H\u0000\u04cf\u04d1\u0003\u0092I\u0000\u04d0"+
		"\u04ca\u0001\u0000\u0000\u0000\u04d0\u04cb\u0001\u0000\u0000\u0000\u04d0"+
		"\u04cc\u0001\u0000\u0000\u0000\u04d0\u04cd\u0001\u0000\u0000\u0000\u04d0"+
		"\u04ce\u0001\u0000\u0000\u0000\u04d0\u04cf\u0001\u0000\u0000\u0000\u04d1"+
		"\u00c3\u0001\u0000\u0000\u0000\u04d2\u04d3\u0006b\uffff\uffff\u0000\u04d3"+
		"\u04d4\u0005\u0002\u0000\u0000\u04d4\u04d5\u0003\u00c4b\u0000\u04d5\u04d6"+
		"\u0005\u0003\u0000\u0000\u04d6\u04f4\u0001\u0000\u0000\u0000\u04d7\u04d8"+
		"\u0005\u0002\u0000\u0000\u04d8\u04db\u0003\u01c6\u00e3\u0000\u04d9\u04da"+
		"\u0005\u0001\u0000\u0000\u04da\u04dc\u0003\u01c6\u00e3\u0000\u04db\u04d9"+
		"\u0001\u0000\u0000\u0000\u04dc\u04dd\u0001\u0000\u0000\u0000\u04dd\u04db"+
		"\u0001\u0000\u0000\u0000\u04dd\u04de\u0001\u0000\u0000\u0000\u04de\u04df"+
		"\u0001\u0000\u0000\u0000\u04df\u04e0\u0005\u0003\u0000\u0000\u04e0\u04f4"+
		"\u0001\u0000\u0000\u0000\u04e1\u04e2\u0005\u0002\u0000\u0000\u04e2\u04e3"+
		"\u0003R)\u0000\u04e3\u04e4\u0005\u0003\u0000\u0000\u04e4\u04f4\u0001\u0000"+
		"\u0000\u0000\u04e5\u04f4\u0003\u00c6c\u0000\u04e6\u04e7\u0007\t\u0000"+
		"\u0000\u04e7\u04f4\u0003v;\u0000\u04e8\u04e9\u0007\t\u0000\u0000\u04e9"+
		"\u04f4\u0003\u00c4b\t\u04ea\u04eb\u0005>\u0000\u0000\u04eb\u04ec\u0005"+
		"\u009c\u0000\u0000\u04ec\u04f4\u0005\u00d6\u0000\u0000\u04ed\u04ee\u0005"+
		">\u0000\u0000\u04ee\u04ef\u0005\u009c\u0000\u0000\u04ef\u04f4\u0005\u0091"+
		"\u0000\u0000\u04f0\u04f1\u0005\u00d6\u0000\u0000\u04f1\u04f2\u0005\u009c"+
		"\u0000\u0000\u04f2\u04f4\u0005\u00e6\u0000\u0000\u04f3\u04d2\u0001\u0000"+
		"\u0000\u0000\u04f3\u04d7\u0001\u0000\u0000\u0000\u04f3\u04e1\u0001\u0000"+
		"\u0000\u0000\u04f3\u04e5\u0001\u0000\u0000\u0000\u04f3\u04e6\u0001\u0000"+
		"\u0000\u0000\u04f3\u04e8\u0001\u0000\u0000\u0000\u04f3\u04ea\u0001\u0000"+
		"\u0000\u0000\u04f3\u04ed\u0001\u0000\u0000\u0000\u04f3\u04f0\u0001\u0000"+
		"\u0000\u0000\u04f4\u0505\u0001\u0000\u0000\u0000\u04f5\u04f6\n\u0006\u0000"+
		"\u0000\u04f6\u04f7\u0007\u000e\u0000\u0000\u04f7\u0504\u0003\u00c4b\u0007"+
		"\u04f8\u04f9\n\u0005\u0000\u0000\u04f9\u04fa\u0007\t\u0000\u0000\u04fa"+
		"\u0504\u0003\u00c4b\u0006\u04fb\u04fc\n\u0004\u0000\u0000\u04fc\u04fd"+
		"\u0005\f\u0000\u0000\u04fd\u0504\u0003\u00c4b\u0005\u04fe\u04ff\n\b\u0000"+
		"\u0000\u04ff\u0504\u0003\u00b6[\u0000\u0500\u0501\n\u0007\u0000\u0000"+
		"\u0501\u0502\u0005)\u0000\u0000\u0502\u0504\u0003\u00b6[\u0000\u0503\u04f5"+
		"\u0001\u0000\u0000\u0000\u0503\u04f8\u0001\u0000\u0000\u0000\u0503\u04fb"+
		"\u0001\u0000\u0000\u0000\u0503\u04fe\u0001\u0000\u0000\u0000\u0503\u0500"+
		"\u0001\u0000\u0000\u0000\u0504\u0507\u0001\u0000\u0000\u0000\u0505\u0503"+
		"\u0001\u0000\u0000\u0000\u0505\u0506\u0001\u0000\u0000\u0000\u0506\u00c5"+
		"\u0001\u0000\u0000\u0000\u0507\u0505\u0001\u0000\u0000\u0000\u0508\u0516"+
		"\u0003\u00e8t\u0000\u0509\u0516\u0003r9\u0000\u050a\u0516\u0003\u01ea"+
		"\u00f5\u0000\u050b\u0516\u0003\u00d4j\u0000\u050c\u0516\u0003\u00d6k\u0000"+
		"\u050d\u0516\u0003\u00d8l\u0000\u050e\u0516\u0003\u00dam\u0000\u050f\u0511"+
		"\u0003\u00dcn\u0000\u0510\u0512\u0003\u00d2i\u0000\u0511\u0510\u0001\u0000"+
		"\u0000\u0000\u0511\u0512\u0001\u0000\u0000\u0000\u0512\u0516\u0001\u0000"+
		"\u0000\u0000\u0513\u0516\u0003\u00f2y\u0000\u0514\u0516\u0003\u00cae\u0000"+
		"\u0515\u0508\u0001\u0000\u0000\u0000\u0515\u0509\u0001\u0000\u0000\u0000"+
		"\u0515\u050a\u0001\u0000\u0000\u0000\u0515\u050b\u0001\u0000\u0000\u0000"+
		"\u0515\u050c\u0001\u0000\u0000\u0000\u0515\u050d\u0001\u0000\u0000\u0000"+
		"\u0515\u050e\u0001\u0000\u0000\u0000\u0515\u050f\u0001\u0000\u0000\u0000"+
		"\u0515\u0513\u0001\u0000\u0000\u0000\u0515\u0514\u0001\u0000\u0000\u0000"+
		"\u0516\u00c7\u0001\u0000\u0000\u0000\u0517\u0519\u0003\u00dcn\u0000\u0518"+
		"\u051a\u0003\u00d2i\u0000\u0519\u0518\u0001\u0000\u0000\u0000\u0519\u051a"+
		"\u0001\u0000\u0000\u0000\u051a\u051d\u0001\u0000\u0000\u0000\u051b\u051d"+
		"\u0003\u00cae\u0000\u051c\u0517\u0001\u0000\u0000\u0000\u051c\u051b\u0001"+
		"\u0000\u0000\u0000\u051d\u00c9\u0001\u0000\u0000\u0000\u051e\u0520\u0003"+
		"\u00ceg\u0000\u051f\u0521\u0003\u00ccf\u0000\u0520\u051f\u0001\u0000\u0000"+
		"\u0000\u0520\u0521\u0001\u0000\u0000\u0000\u0521\u00cb\u0001\u0000\u0000"+
		"\u0000\u0522\u0523\u0005\u0007\u0000\u0000\u0523\u0524\u0003\u00c4b\u0000"+
		"\u0524\u0527\u0005\b\u0000\u0000\u0525\u0526\u0005\r\u0000\u0000\u0526"+
		"\u0528\u0003\u00cae\u0000\u0527\u0525\u0001\u0000\u0000\u0000\u0527\u0528"+
		"\u0001\u0000\u0000\u0000\u0528\u00cd\u0001\u0000\u0000\u0000\u0529\u052d"+
		"\u0003\u01f0\u00f8\u0000\u052a\u052c\u0003\u00d0h\u0000\u052b\u052a\u0001"+
		"\u0000\u0000\u0000\u052c\u052f\u0001\u0000\u0000\u0000\u052d\u052b\u0001"+
		"\u0000\u0000\u0000\u052d\u052e\u0001\u0000\u0000\u0000\u052e\u00cf\u0001"+
		"\u0000\u0000\u0000\u052f\u052d\u0001\u0000\u0000\u0000\u0530\u0531\u0005"+
		"\r\u0000\u0000\u0531\u0532\u0003\u01f0\u00f8\u0000\u0532\u00d1\u0001\u0000"+
		"\u0000\u0000\u0533\u0534\u0005\r\u0000\u0000\u0534\u0535\u0003\u00ceg"+
		"\u0000\u0535\u00d3\u0001\u0000\u0000\u0000\u0536\u0537\u0005\u00cd\u0000"+
		"\u0000\u0537\u053a\u0005\u0002\u0000\u0000\u0538\u053b\u0003\u00c8d\u0000"+
		"\u0539\u053b\u0003\u01ea\u00f5\u0000\u053a\u0538\u0001\u0000\u0000\u0000"+
		"\u053a\u0539\u0001\u0000\u0000\u0000\u053b\u053c\u0001\u0000\u0000\u0000"+
		"\u053c\u053d\u0005\u0003\u0000\u0000\u053d\u00d5\u0001\u0000\u0000\u0000"+
		"\u053e\u053f\u0005\u0019\u0000\u0000\u053f\u0540\u0005\u0002\u0000\u0000"+
		"\u0540\u0541\u0003\u00c8d\u0000\u0541\u0543\u0005\u0003\u0000\u0000\u0542"+
		"\u0544\u0003\u00d2i\u0000\u0543\u0542\u0001\u0000\u0000\u0000\u0543\u0544"+
		"\u0001\u0000\u0000\u0000\u0544\u00d7\u0001\u0000\u0000\u0000\u0545\u0546"+
		"\u0005\u001a\u0000\u0000\u0546\u0547\u0005\u0002\u0000\u0000\u0547\u0548"+
		"\u0003\u00c8d\u0000\u0548\u0549\u0005\u0003\u0000\u0000\u0549\u00d9\u0001"+
		"\u0000\u0000\u0000\u054a\u054b\u0005\u001c\u0000\u0000\u054b\u054c\u0005"+
		"\u0002\u0000\u0000\u054c\u054d\u0003\u00c8d\u0000\u054d\u054f\u0005\u0003"+
		"\u0000\u0000\u054e\u0550\u0003\u00d2i\u0000\u054f\u054e\u0001\u0000\u0000"+
		"\u0000\u054f\u0550\u0001\u0000\u0000\u0000\u0550\u00db\u0001\u0000\u0000"+
		"\u0000\u0551\u0567\u0003\u00e0p\u0000\u0552\u0567\u0003\u00e2q\u0000\u0553"+
		"\u0567\u0003\u00e4r\u0000\u0554\u0555\u0003\u00ceg\u0000\u0555\u0556\u0003"+
		"\u00ccf\u0000\u0556\u0567\u0001\u0000\u0000\u0000\u0557\u0558\u0003\u00ce"+
		"g\u0000\u0558\u0559\u0003\u00deo\u0000\u0559\u0567\u0001\u0000\u0000\u0000"+
		"\u055a\u0567\u0003\u00e6s\u0000\u055b\u055c\u0003\u00f2y\u0000\u055c\u055d"+
		"\u0003\u00d2i\u0000\u055d\u0567\u0001\u0000\u0000\u0000\u055e\u055f\u0003"+
		"\u00f2y\u0000\u055f\u0561\u0003\u00ccf\u0000\u0560\u0562\u0003\u00d2i"+
		"\u0000\u0561\u0560\u0001\u0000\u0000\u0000\u0561\u0562\u0001\u0000\u0000"+
		"\u0000\u0562\u0567\u0001\u0000\u0000\u0000\u0563\u0564\u0003\u00f2y\u0000"+
		"\u0564\u0565\u0003\u00deo\u0000\u0565\u0567\u0001\u0000\u0000\u0000\u0566"+
		"\u0551\u0001\u0000\u0000\u0000\u0566\u0552\u0001\u0000\u0000\u0000\u0566"+
		"\u0553\u0001\u0000\u0000\u0000\u0566\u0554\u0001\u0000\u0000\u0000\u0566"+
		"\u0557\u0001\u0000\u0000\u0000\u0566\u055a\u0001\u0000\u0000\u0000\u0566"+
		"\u055b\u0001\u0000\u0000\u0000\u0566\u055e\u0001\u0000\u0000\u0000\u0566"+
		"\u0563\u0001\u0000\u0000\u0000\u0567\u00dd\u0001\u0000\u0000\u0000\u0568"+
		"\u0569\u0005\u0007\u0000\u0000\u0569\u056a\u0003\u00c4b\u0000\u056a\u056b"+
		"\u0005\t\u0000\u0000\u056b\u056c\u0003\u00c4b\u0000\u056c\u056d\u0005"+
		"\b\u0000\u0000\u056d\u00df\u0001\u0000\u0000\u0000\u056e\u056f\u0005\u00c9"+
		"\u0000\u0000\u056f\u0570\u0005\u0002\u0000\u0000\u0570\u0571\u0003\u00c8"+
		"d\u0000\u0571\u0572\u0005#\u0000\u0000\u0572\u0573\u0003\u00ceg\u0000"+
		"\u0573\u0575\u0005\u0003\u0000\u0000\u0574\u0576\u0003\u00d2i\u0000\u0575"+
		"\u0574\u0001\u0000\u0000\u0000\u0575\u0576\u0001\u0000\u0000\u0000\u0576"+
		"\u00e1\u0001\u0000\u0000\u0000\u0577\u0578\u0003\u01cc\u00e6\u0000\u0578"+
		"\u0579\u0005\u0002\u0000\u0000\u0579\u057a\u0003\u00c8d\u0000\u057a\u057c"+
		"\u0005\u0003\u0000\u0000\u057b\u057d\u0003\u00d2i\u0000\u057c\u057b\u0001"+
		"\u0000\u0000\u0000\u057c\u057d\u0001\u0000\u0000\u0000\u057d\u00e3\u0001"+
		"\u0000\u0000\u0000\u057e\u057f\u0003\u01ce\u00e7\u0000\u057f\u0580\u0005"+
		"\u0002\u0000\u0000\u0580\u0581\u0003\u00c8d\u0000\u0581\u0583\u0005\u0003"+
		"\u0000\u0000\u0582\u0584\u0003\u00d2i\u0000\u0583\u0582\u0001\u0000\u0000"+
		"\u0000\u0583\u0584\u0001\u0000\u0000\u0000\u0584\u00e5\u0001\u0000\u0000"+
		"\u0000\u0585\u0586\u0005\u001d\u0000\u0000\u0586\u0587\u0005\u0002\u0000"+
		"\u0000\u0587\u0588\u0003\u00c8d\u0000\u0588\u0589\u0005\u0003\u0000\u0000"+
		"\u0589\u00e7\u0001\u0000\u0000\u0000\u058a\u058d\u0003\u00eau\u0000\u058b"+
		"\u058d\u0003\u00ecv\u0000\u058c\u058a\u0001\u0000\u0000\u0000\u058c\u058b"+
		"\u0001\u0000\u0000\u0000\u058d\u00e9\u0001\u0000\u0000\u0000\u058e\u058f"+
		"\u0005*\u0000\u0000\u058f\u0591\u0003\u01c6\u00e3\u0000\u0590\u0592\u0003"+
		"\u00eew\u0000\u0591\u0590\u0001\u0000\u0000\u0000\u0592\u0593\u0001\u0000"+
		"\u0000\u0000\u0593\u0591\u0001\u0000\u0000\u0000\u0593\u0594\u0001\u0000"+
		"\u0000\u0000\u0594\u0597\u0001\u0000\u0000\u0000\u0595\u0596\u0005G\u0000"+
		"\u0000\u0596\u0598\u0003\u01c6\u00e3\u0000\u0597\u0595\u0001\u0000\u0000"+
		"\u0000\u0597\u0598\u0001\u0000\u0000\u0000\u0598\u0599\u0001\u0000\u0000"+
		"\u0000\u0599\u059a\u0005I\u0000\u0000\u059a\u00eb\u0001\u0000\u0000\u0000"+
		"\u059b\u059d\u0005*\u0000\u0000\u059c\u059e\u0003\u00f0x\u0000\u059d\u059c"+
		"\u0001\u0000\u0000\u0000\u059e\u059f\u0001\u0000\u0000\u0000\u059f\u059d"+
		"\u0001\u0000\u0000\u0000\u059f\u05a0\u0001\u0000\u0000\u0000\u05a0\u05a3"+
		"\u0001\u0000\u0000\u0000\u05a1\u05a2\u0005G\u0000\u0000\u05a2\u05a4\u0003"+
		"\u01c6\u00e3\u0000\u05a3\u05a1\u0001\u0000\u0000\u0000\u05a3\u05a4\u0001"+
		"\u0000\u0000\u0000\u05a4\u05a5\u0001\u0000\u0000\u0000\u05a5\u05a6\u0005"+
		"I\u0000\u0000\u05a6\u00ed\u0001\u0000\u0000\u0000\u05a7\u05a8\u0005\u00d7"+
		"\u0000\u0000\u05a8\u05a9\u0003\u00c4b\u0000\u05a9\u05aa\u0005\u00c1\u0000"+
		"\u0000\u05aa\u05ab\u0003\u01c6\u00e3\u0000\u05ab\u00ef\u0001\u0000\u0000"+
		"\u0000\u05ac\u05ad\u0005\u00d7\u0000\u0000\u05ad\u05ae\u0003\u01c4\u00e2"+
		"\u0000\u05ae\u05af\u0005\u00c1\u0000\u0000\u05af\u05b0\u0003\u01c6\u00e3"+
		"\u0000\u05b0\u00f1\u0001\u0000\u0000\u0000\u05b1\u05bc\u0003\u00f8|\u0000"+
		"\u05b2\u05bc\u0003\u0156\u00ab\u0000\u05b3\u05bc\u0003\u0150\u00a8\u0000"+
		"\u05b4\u05bc\u0003\u0152\u00a9\u0000\u05b5\u05bc\u0003\u0154\u00aa\u0000"+
		"\u05b6\u05bc\u0003\u0144\u00a2\u0000\u05b7\u05bc\u0003\u0148\u00a4\u0000"+
		"\u05b8\u05bc\u0003\u0178\u00bc\u0000\u05b9\u05bc\u0003\u01a8\u00d4\u0000"+
		"\u05ba\u05bc\u0003\u014a\u00a5\u0000\u05bb\u05b1\u0001\u0000\u0000\u0000"+
		"\u05bb\u05b2\u0001\u0000\u0000\u0000\u05bb\u05b3\u0001\u0000\u0000\u0000"+
		"\u05bb\u05b4\u0001\u0000\u0000\u0000\u05bb\u05b5\u0001\u0000\u0000\u0000"+
		"\u05bb\u05b6\u0001\u0000\u0000\u0000\u05bb\u05b7\u0001\u0000\u0000\u0000"+
		"\u05bb\u05b8\u0001\u0000\u0000\u0000\u05bb\u05b9\u0001\u0000\u0000\u0000"+
		"\u05bb\u05ba\u0001\u0000\u0000\u0000\u05bc\u00f3\u0001\u0000\u0000\u0000"+
		"\u05bd\u05c1\u0003\u00f6{\u0000\u05be\u05c1\u0003\u019e\u00cf\u0000\u05bf"+
		"\u05c1\u0003\u01bc\u00de\u0000\u05c0\u05bd\u0001\u0000\u0000\u0000\u05c0"+
		"\u05be\u0001\u0000\u0000\u0000\u05c0\u05bf\u0001\u0000\u0000\u0000\u05c1"+
		"\u00f5\u0001\u0000\u0000\u0000\u05c2\u05c3\u0003\u01f0\u00f8\u0000\u05c3"+
		"\u05c5\u0005\u0002\u0000\u0000\u05c4\u05c6\u0003\u014e\u00a7\u0000\u05c5"+
		"\u05c4\u0001\u0000\u0000\u0000\u05c5\u05c6\u0001\u0000\u0000\u0000\u05c6"+
		"\u05c7\u0001\u0000\u0000\u0000\u05c7\u05c8\u0005\u0003\u0000\u0000\u05c8"+
		"\u00f7\u0001\u0000\u0000\u0000\u05c9\u05df\u0003\u00fa}\u0000\u05ca\u05df"+
		"\u0003\u00e0p\u0000\u05cb\u05df\u0003\u0140\u00a0\u0000\u05cc\u05df\u0003"+
		"\u0142\u00a1\u0000\u05cd\u05df\u0003\u0134\u009a\u0000\u05ce\u05df\u0003"+
		"\u0138\u009c\u0000\u05cf\u05df\u0003\u0100\u0080\u0000\u05d0\u05df\u0003"+
		"\u011a\u008d\u0000\u05d1\u05df\u0003\u0106\u0083\u0000\u05d2\u05df\u0003"+
		"\u010c\u0086\u0000\u05d3\u05df\u0003\u0114\u008a\u0000\u05d4\u05df\u0003"+
		"\u0124\u0092\u0000\u05d5\u05df\u0003\u0126\u0093\u0000\u05d6\u05df\u0003"+
		"\u0128\u0094\u0000\u05d7\u05df\u0003\u012a\u0095\u0000\u05d8\u05df\u0003"+
		"\u0130\u0098\u0000\u05d9\u05df\u0003\u0132\u0099\u0000\u05da\u05df\u0003"+
		"\u012c\u0096\u0000\u05db\u05df\u0003\u012e\u0097\u0000\u05dc\u05df\u0003"+
		"\u013a\u009d\u0000\u05dd\u05df\u0003\u013c\u009e\u0000\u05de\u05c9\u0001"+
		"\u0000\u0000\u0000\u05de\u05ca\u0001\u0000\u0000\u0000\u05de\u05cb\u0001"+
		"\u0000\u0000\u0000\u05de\u05cc\u0001\u0000\u0000\u0000\u05de\u05cd\u0001"+
		"\u0000\u0000\u0000\u05de\u05ce\u0001\u0000\u0000\u0000\u05de\u05cf\u0001"+
		"\u0000\u0000\u0000\u05de\u05d0\u0001\u0000\u0000\u0000\u05de\u05d1\u0001"+
		"\u0000\u0000\u0000\u05de\u05d2\u0001\u0000\u0000\u0000\u05de\u05d3\u0001"+
		"\u0000\u0000\u0000\u05de\u05d4\u0001\u0000\u0000\u0000\u05de\u05d5\u0001"+
		"\u0000\u0000\u0000\u05de\u05d6\u0001\u0000\u0000\u0000\u05de\u05d7\u0001"+
		"\u0000\u0000\u0000\u05de\u05d8\u0001\u0000\u0000\u0000\u05de\u05d9\u0001"+
		"\u0000\u0000\u0000\u05de\u05da\u0001\u0000\u0000\u0000\u05de\u05db\u0001"+
		"\u0000\u0000\u0000\u05de\u05dc\u0001\u0000\u0000\u0000\u05de\u05dd\u0001"+
		"\u0000\u0000\u0000\u05df\u00f9\u0001\u0000\u0000\u0000\u05e0\u05e1\u0005"+
		"+\u0000\u0000\u05e1\u05e2\u0005\u0002\u0000\u0000\u05e2\u05e3\u0003\u00c4"+
		"b\u0000\u05e3\u05e4\u0005#\u0000\u0000\u05e4\u05e5\u0003\u00fc~\u0000"+
		"\u05e5\u05e6\u0005\u0003\u0000\u0000\u05e6\u00fb\u0001\u0000\u0000\u0000"+
		"\u05e7\u05ef\u0003\u00fe\u007f\u0000\u05e8\u05e9\u0005\u0002\u0000\u0000"+
		"\u05e9\u05ec\u0005\u00ed\u0000\u0000\u05ea\u05eb\u0005\u0001\u0000\u0000"+
		"\u05eb\u05ed\u0005\u00ed\u0000\u0000\u05ec\u05ea\u0001\u0000\u0000\u0000"+
		"\u05ec\u05ed\u0001\u0000\u0000\u0000\u05ed\u05ee\u0001\u0000\u0000\u0000"+
		"\u05ee\u05f0\u0005\u0003\u0000\u0000\u05ef\u05e8\u0001\u0000\u0000\u0000"+
		"\u05ef\u05f0\u0001\u0000\u0000\u0000\u05f0\u00fd\u0001\u0000\u0000\u0000"+
		"\u05f1\u05f2\u0003\u01f0\u00f8\u0000\u05f2\u05f3\u0006\u007f\uffff\uffff"+
		"\u0000\u05f3\u05fa\u0001\u0000\u0000\u0000\u05f4\u05f5\u0005\r\u0000\u0000"+
		"\u05f5\u05f6\u0003\u01f0\u00f8\u0000\u05f6\u05f7\u0006\u007f\uffff\uffff"+
		"\u0000\u05f7\u05f9\u0001\u0000\u0000\u0000\u05f8\u05f4\u0001\u0000\u0000"+
		"\u0000\u05f9\u05fc\u0001\u0000\u0000\u0000\u05fa\u05f8\u0001\u0000\u0000"+
		"\u0000\u05fa\u05fb\u0001\u0000\u0000\u0000\u05fb\u00ff\u0001\u0000\u0000"+
		"\u0000\u05fc\u05fa\u0001\u0000\u0000\u0000\u05fd\u05fe\u0005\u00bf\u0000"+
		"\u0000\u05fe\u05ff\u0005\u0002\u0000\u0000\u05ff\u0600\u0003\u00c4b\u0000"+
		"\u0600\u0601\u0005\u0001\u0000\u0000\u0601\u0604\u0003\u0102\u0081\u0000"+
		"\u0602\u0603\u0005\u0001\u0000\u0000\u0603\u0605\u0003\u0104\u0082\u0000"+
		"\u0604\u0602\u0001\u0000\u0000\u0000\u0604\u0605\u0001\u0000\u0000\u0000"+
		"\u0605\u0606\u0001\u0000\u0000\u0000\u0606\u0607\u0005\u0003\u0000\u0000"+
		"\u0607\u0614\u0001\u0000\u0000\u0000\u0608\u0609\u0005\u00bf\u0000\u0000"+
		"\u0609\u060a\u0005\u0002\u0000\u0000\u060a\u060b\u0003\u00c4b\u0000\u060b"+
		"\u060c\u0005Y\u0000\u0000\u060c\u060f\u0003\u0102\u0081\u0000\u060d\u060e"+
		"\u0005W\u0000\u0000\u060e\u0610\u0003\u0104\u0082\u0000\u060f\u060d\u0001"+
		"\u0000\u0000\u0000\u060f\u0610\u0001\u0000\u0000\u0000\u0610\u0611\u0001"+
		"\u0000\u0000\u0000\u0611\u0612\u0005\u0003\u0000\u0000\u0612\u0614\u0001"+
		"\u0000\u0000\u0000\u0613\u05fd\u0001\u0000\u0000\u0000\u0613\u0608\u0001"+
		"\u0000\u0000\u0000\u0614\u0101\u0001\u0000\u0000\u0000\u0615\u0616\u0003"+
		"\u00c4b\u0000\u0616\u0103\u0001\u0000\u0000\u0000\u0617\u0618\u0003\u00c4"+
		"b\u0000\u0618\u0105\u0001\u0000\u0000\u0000\u0619\u061a\u0005\u00ca\u0000"+
		"\u0000\u061a\u061c\u0005\u0002\u0000\u0000\u061b\u061d\u0003\u0108\u0084"+
		"\u0000\u061c\u061b\u0001\u0000\u0000\u0000\u061c\u061d\u0001\u0000\u0000"+
		"\u0000\u061d\u061f\u0001\u0000\u0000\u0000\u061e\u0620\u0003\u010a\u0085"+
		"\u0000\u061f\u061e\u0001\u0000\u0000\u0000\u061f\u0620\u0001\u0000\u0000"+
		"\u0000\u0620\u0622\u0001\u0000\u0000\u0000\u0621\u0623\u0005Y\u0000\u0000"+
		"\u0622\u0621\u0001\u0000\u0000\u0000\u0622\u0623\u0001\u0000\u0000\u0000"+
		"\u0623\u0624\u0001\u0000\u0000\u0000\u0624\u0625\u0003\u00c4b\u0000\u0625"+
		"\u0626\u0005\u0003\u0000\u0000\u0626\u0107\u0001\u0000\u0000\u0000\u0627"+
		"\u0628\u0007\u000f\u0000\u0000\u0628\u0109\u0001\u0000\u0000\u0000\u0629"+
		"\u062c\u0005\u00eb\u0000\u0000\u062a\u062c\u0003\u01ea\u00f5\u0000\u062b"+
		"\u0629\u0001\u0000\u0000\u0000\u062b\u062a\u0001\u0000\u0000\u0000\u062c"+
		"\u010b\u0001\u0000\u0000\u0000\u062d\u062e\u0005\u00a9\u0000\u0000\u062e"+
		"\u062f\u0005\u0002\u0000\u0000\u062f\u0630\u0003\u00c4b\u0000\u0630\u0631"+
		"\u0005\u00d9\u0000\u0000\u0631\u0632\u0003\u0112\u0089\u0000\u0632\u0634"+
		"\u0003\u010e\u0087\u0000\u0633\u0635\u0003\u0110\u0088\u0000\u0634\u0633"+
		"\u0001\u0000\u0000\u0000\u0634\u0635\u0001\u0000\u0000\u0000\u0635\u0636"+
		"\u0001\u0000\u0000\u0000\u0636\u0637\u0005\u0003\u0000\u0000\u0637\u010d"+
		"\u0001\u0000\u0000\u0000\u0638\u0639\u0007\u0010\u0000\u0000\u0639\u010f"+
		"\u0001\u0000\u0000\u0000\u063a\u063b\u0005\u00eb\u0000\u0000\u063b\u0111"+
		"\u0001\u0000\u0000\u0000\u063c\u063d\u0003\u00c4b\u0000\u063d\u0113\u0001"+
		"\u0000\u0000\u0000\u063e\u063f\u0005\u00af\u0000\u0000\u063f\u0640\u0005"+
		"\u0002\u0000\u0000\u0640\u0641\u0003\u0116\u008b\u0000\u0641\u0642\u0005"+
		"b\u0000\u0000\u0642\u0643\u0003\u0118\u008c\u0000\u0643\u0644\u0005\u0003"+
		"\u0000\u0000\u0644\u0115\u0001\u0000\u0000\u0000\u0645\u0646\u0003\u00c4"+
		"b\u0000\u0646\u0117\u0001\u0000\u0000\u0000\u0647\u0648\u0003\u00c4b\u0000"+
		"\u0648\u0119\u0001\u0000\u0000\u0000\u0649\u064a\u0005\u00a8\u0000\u0000"+
		"\u064a\u064b\u0005\u0002\u0000\u0000\u064b\u064c\u0003\u011c\u008e\u0000"+
		"\u064c\u064d\u0005\u00ae\u0000\u0000\u064d\u064e\u0003\u011e\u008f\u0000"+
		"\u064e\u064f\u0005Y\u0000\u0000\u064f\u0652\u0003\u0120\u0090\u0000\u0650"+
		"\u0651\u0005W\u0000\u0000\u0651\u0653\u0003\u0122\u0091\u0000\u0652\u0650"+
		"\u0001\u0000\u0000\u0000\u0652\u0653\u0001\u0000\u0000\u0000\u0653\u0654"+
		"\u0001\u0000\u0000\u0000\u0654\u0655\u0005\u0003\u0000\u0000\u0655\u011b"+
		"\u0001\u0000\u0000\u0000\u0656\u0657\u0003\u00c4b\u0000\u0657\u011d\u0001"+
		"\u0000\u0000\u0000\u0658\u0659\u0003\u00c4b\u0000\u0659\u011f\u0001\u0000"+
		"\u0000\u0000\u065a\u065b\u0003\u00c4b\u0000\u065b\u0121\u0001\u0000\u0000"+
		"\u0000\u065c\u065d\u0003\u00c4b\u0000\u065d\u0123\u0001\u0000\u0000\u0000"+
		"\u065e\u0661\u00057\u0000\u0000\u065f\u0660\u0005\u0002\u0000\u0000\u0660"+
		"\u0662\u0005\u0003\u0000\u0000\u0661\u065f\u0001\u0000\u0000\u0000\u0661"+
		"\u0662\u0001\u0000\u0000\u0000\u0662\u0666\u0001\u0000\u0000\u0000\u0663"+
		"\u0664\u00056\u0000\u0000\u0664\u0666\u0005<\u0000\u0000\u0665\u065e\u0001"+
		"\u0000\u0000\u0000\u0665\u0663\u0001\u0000\u0000\u0000\u0666\u0125\u0001"+
		"\u0000\u0000\u0000\u0667\u066a\u00059\u0000\u0000\u0668\u0669\u0005\u0002"+
		"\u0000\u0000\u0669\u066b\u0005\u0003\u0000\u0000\u066a\u0668\u0001\u0000"+
		"\u0000\u0000\u066a\u066b\u0001\u0000\u0000\u0000\u066b\u066f\u0001\u0000"+
		"\u0000\u0000\u066c\u066d\u00056\u0000\u0000\u066d\u066f\u0005\u00c3\u0000"+
		"\u0000\u066e\u0667\u0001\u0000\u0000\u0000\u066e\u066c\u0001\u0000\u0000"+
		"\u0000\u066f\u0127\u0001\u0000\u0000\u0000\u0670\u0673\u0005:\u0000\u0000"+
		"\u0671\u0672\u0005\u0002\u0000\u0000\u0672\u0674\u0005\u0003\u0000\u0000"+
		"\u0673\u0671\u0001\u0000\u0000\u0000\u0673\u0674\u0001\u0000\u0000\u0000"+
		"\u0674\u0678\u0001\u0000\u0000\u0000\u0675\u0676\u00056\u0000\u0000\u0676"+
		"\u0678\u0005\u00c4\u0000\u0000\u0677\u0670\u0001\u0000\u0000\u0000\u0677"+
		"\u0675\u0001\u0000\u0000\u0000\u0678\u0129\u0001\u0000\u0000\u0000\u0679"+
		"\u067c\u00058\u0000\u0000\u067a\u067b\u0005\u0002\u0000\u0000\u067b\u067d"+
		"\u0005\u0003\u0000\u0000\u067c\u067a\u0001\u0000\u0000\u0000\u067c\u067d"+
		"\u0001\u0000\u0000\u0000\u067d\u0680\u0001\u0000\u0000\u0000\u067e\u0680"+
		"\u0005h\u0000\u0000\u067f\u0679\u0001\u0000\u0000\u0000\u067f\u067e\u0001"+
		"\u0000\u0000\u0000\u0680\u012b\u0001\u0000\u0000\u0000\u0681\u0684\u0005"+
		"\u0083\u0000\u0000\u0682\u0683\u0005\u0002\u0000\u0000\u0683\u0685\u0005"+
		"\u0003\u0000\u0000\u0684\u0682\u0001\u0000\u0000\u0000\u0684\u0685\u0001"+
		"\u0000\u0000\u0000\u0685\u0689\u0001\u0000\u0000\u0000\u0686\u0687\u0005"+
		"\u0081\u0000\u0000\u0687\u0689\u0005=\u0000\u0000\u0688\u0681\u0001\u0000"+
		"\u0000\u0000\u0688\u0686\u0001\u0000\u0000\u0000\u0689\u012d\u0001\u0000"+
		"\u0000\u0000\u068a\u068d\u0005\u009e\u0000\u0000\u068b\u068c\u0005\u0002"+
		"\u0000\u0000\u068c\u068e\u0005\u0003\u0000\u0000\u068d\u068b\u0001\u0000"+
		"\u0000\u0000\u068d\u068e\u0001\u0000\u0000\u0000\u068e\u0692\u0001\u0000"+
		"\u0000\u0000\u068f\u0690\u0005\u009d\u0000\u0000\u0690\u0692\u0005=\u0000"+
		"\u0000\u0691\u068a\u0001\u0000\u0000\u0000\u0691\u068f\u0001\u0000\u0000"+
		"\u0000\u0692\u012f\u0001\u0000\u0000\u0000\u0693\u0696\u0005\u0082\u0000"+
		"\u0000\u0694\u0695\u0005\u0002\u0000\u0000\u0695\u0697\u0005\u0003\u0000"+
		"\u0000\u0696\u0694\u0001\u0000\u0000\u0000\u0696\u0697\u0001\u0000\u0000"+
		"\u0000\u0697\u069b\u0001\u0000\u0000\u0000\u0698\u0699\u0005\u0081\u0000"+
		"\u0000\u0699\u069b\u0005<\u0000\u0000\u069a\u0693\u0001\u0000\u0000\u0000"+
		"\u069a\u0698\u0001\u0000\u0000\u0000\u069b\u0131\u0001\u0000\u0000\u0000"+
		"\u069c\u069f\u0005\u0084\u0000\u0000\u069d\u069e\u0005\u0002\u0000\u0000"+
		"\u069e\u06a0\u0005\u0003\u0000\u0000\u069f\u069d\u0001\u0000\u0000\u0000"+
		"\u069f\u06a0\u0001\u0000\u0000\u0000\u06a0\u06a4\u0001\u0000\u0000\u0000"+
		"\u06a1\u06a2\u0005\u0081\u0000\u0000\u06a2\u06a4\u0005\u00c3\u0000\u0000"+
		"\u06a3\u069c\u0001\u0000\u0000\u0000\u06a3\u06a1\u0001\u0000\u0000\u0000"+
		"\u06a4\u0133\u0001\u0000\u0000\u0000\u06a5\u06a6\u0005X\u0000\u0000\u06a6"+
		"\u06a7\u0005\u0002\u0000\u0000\u06a7\u06a8\u0003\u00c4b\u0000\u06a8\u06a9"+
		"\u0005#\u0000\u0000\u06a9\u06aa\u0003\u013e\u009f\u0000\u06aa\u06ab\u0005"+
		"\u0003\u0000\u0000\u06ab\u0135\u0001\u0000\u0000\u0000\u06ac\u06ad\u0003"+
		"\u00ceg\u0000\u06ad\u0137\u0001\u0000\u0000\u0000\u06ae\u06af\u0005,\u0000"+
		"\u0000\u06af\u06b0\u0005\u0002\u0000\u0000\u06b0\u06b1\u0003\u00c4b\u0000"+
		"\u06b1\u06b2\u0005#\u0000\u0000\u06b2\u06b3\u0003\u0136\u009b\u0000\u06b3"+
		"\u06b4\u0005\u0003\u0000\u0000\u06b4\u0139\u0001\u0000\u0000\u0000\u06b5"+
		"\u06b6\u00055\u0000\u0000\u06b6\u06b7\u0005\u0002\u0000\u0000\u06b7\u06bc"+
		"\u0003\u01c6\u00e3\u0000\u06b8\u06b9\u0005\u0001\u0000\u0000\u06b9\u06bb"+
		"\u0003\u01c6\u00e3\u0000\u06ba\u06b8\u0001\u0000\u0000\u0000\u06bb\u06be"+
		"\u0001\u0000\u0000\u0000\u06bc\u06ba\u0001\u0000\u0000\u0000\u06bc\u06bd"+
		"\u0001\u0000\u0000\u0000\u06bd\u06bf\u0001\u0000\u0000\u0000\u06be\u06bc"+
		"\u0001\u0000\u0000\u0000\u06bf\u06c0\u0005\u0003\u0000\u0000\u06c0\u013b"+
		"\u0001\u0000\u0000\u0000\u06c1\u06c2\u0005\u00b6\u0000\u0000\u06c2\u06c3"+
		"\u0005\u0002\u0000\u0000\u06c3\u06c8\u0003\u01c6\u00e3\u0000\u06c4\u06c5"+
		"\u0005\u0001\u0000\u0000\u06c5\u06c7\u0003\u01c6\u00e3\u0000\u06c6\u06c4"+
		"\u0001\u0000\u0000\u0000\u06c7\u06ca\u0001\u0000\u0000\u0000\u06c8\u06c6"+
		"\u0001\u0000\u0000\u0000\u06c8\u06c9\u0001\u0000\u0000\u0000\u06c9\u06cb"+
		"\u0001\u0000\u0000\u0000\u06ca\u06c8\u0001\u0000\u0000\u0000\u06cb\u06cc"+
		"\u0005\u0003\u0000\u0000\u06cc\u013d\u0001\u0000\u0000\u0000\u06cd\u06ce"+
		"\u0005\u00eb\u0000\u0000\u06ce\u013f\u0001\u0000\u0000\u0000\u06cf\u06d0"+
		"\u0005R\u0000\u0000\u06d0\u06d1\u0005\u0002\u0000\u0000\u06d1\u06d2\u0003"+
		"\u00b4Z\u0000\u06d2\u06d3\u0005Y\u0000\u0000\u06d3\u06d4\u0003\u00c4b"+
		"\u0000\u06d4\u06d5\u0005\u0003\u0000\u0000\u06d5\u06dc\u0001\u0000\u0000"+
		"\u0000\u06d6\u06d7\u0003\u00b6[\u0000\u06d7\u06d8\u0005\u0002\u0000\u0000"+
		"\u06d8\u06d9\u0003\u00c4b\u0000\u06d9\u06da\u0005\u0003\u0000\u0000\u06da"+
		"\u06dc\u0001\u0000\u0000\u0000\u06db\u06cf\u0001\u0000\u0000\u0000\u06db"+
		"\u06d6\u0001\u0000\u0000\u0000\u06dc\u0141\u0001\u0000\u0000\u0000\u06dd"+
		"\u06de\u0007\u0011\u0000\u0000\u06de\u06df\u0005\u0002\u0000\u0000\u06df"+
		"\u06e5\u0003\u00c4b\u0000\u06e0\u06e3\u0005\u0001\u0000\u0000\u06e1\u06e4"+
		"\u0003\u00b6[\u0000\u06e2\u06e4\u0003\u00c4b\u0000\u06e3\u06e1\u0001\u0000"+
		"\u0000\u0000\u06e3\u06e2\u0001\u0000\u0000\u0000\u06e4\u06e6\u0001\u0000"+
		"\u0000\u0000\u06e5\u06e0\u0001\u0000\u0000\u0000\u06e5\u06e6\u0001\u0000"+
		"\u0000\u0000\u06e6\u06e7\u0001\u0000\u0000\u0000\u06e7\u06e8\u0005\u0003"+
		"\u0000\u0000\u06e8\u0143\u0001\u0000\u0000\u0000\u06e9\u06ea\u0005[\u0000"+
		"\u0000\u06ea\u06eb\u0005\u0002\u0000\u0000\u06eb\u06ee\u0003\u0146\u00a3"+
		"\u0000\u06ec\u06ed\u0005#\u0000\u0000\u06ed\u06ef\u0003\u00fc~\u0000\u06ee"+
		"\u06ec\u0001\u0000\u0000\u0000\u06ee\u06ef\u0001\u0000\u0000\u0000\u06ef"+
		"\u06f2\u0001\u0000\u0000\u0000\u06f0\u06f1\u0005\u0001\u0000\u0000\u06f1"+
		"\u06f3\u0003\u014e\u00a7\u0000\u06f2\u06f0\u0001\u0000\u0000\u0000\u06f2"+
		"\u06f3\u0001\u0000\u0000\u0000\u06f3\u06f4\u0001\u0000\u0000\u0000\u06f4"+
		"\u06f5\u0005\u0003\u0000\u0000\u06f5\u0145\u0001\u0000\u0000\u0000\u06f6"+
		"\u06f9\u0005\u00eb\u0000\u0000\u06f7\u06f9\u0003\u01f0\u00f8\u0000\u06f8"+
		"\u06f6\u0001\u0000\u0000\u0000\u06f8\u06f7\u0001\u0000\u0000\u0000\u06f9"+
		"\u0147\u0001\u0000\u0000\u0000\u06fa\u06fb\u0005-\u0000\u0000\u06fb\u06fc"+
		"\u0005\u0002\u0000\u0000\u06fc\u06fd\u0003\u00c8d\u0000\u06fd\u06fe\u0005"+
		"\r\u0000\u0000\u06fe\u0701\u0003\u0146\u00a3\u0000\u06ff\u0700\u0005#"+
		"\u0000\u0000\u0700\u0702\u0003\u00fc~\u0000\u0701\u06ff\u0001\u0000\u0000"+
		"\u0000\u0701\u0702\u0001\u0000\u0000\u0000\u0702\u0703\u0001\u0000\u0000"+
		"\u0000\u0703\u0704\u0005\u0003\u0000\u0000\u0704\u0149\u0001\u0000\u0000"+
		"\u0000\u0705\u0706\u0003\u014c\u00a6\u0000\u0706\u0709\u0005\u0002\u0000"+
		"\u0000\u0707\u070a\u0003\u014e\u00a7\u0000\u0708\u070a\u0005\u0018\u0000"+
		"\u0000\u0709\u0707\u0001\u0000\u0000\u0000\u0709\u0708\u0001\u0000\u0000"+
		"\u0000\u0709\u070a\u0001\u0000\u0000\u0000\u070a\u070b\u0001\u0000\u0000"+
		"\u0000\u070b\u070d\u0005\u0003\u0000\u0000\u070c\u070e\u0003\u00d2i\u0000"+
		"\u070d\u070c\u0001\u0000\u0000\u0000\u070d\u070e\u0001\u0000\u0000\u0000"+
		"\u070e\u0710\u0001\u0000\u0000\u0000\u070f\u0711\u0003\u016a\u00b5\u0000"+
		"\u0710\u070f\u0001\u0000\u0000\u0000\u0710\u0711\u0001\u0000\u0000\u0000"+
		"\u0711\u0713\u0001\u0000\u0000\u0000\u0712\u0714\u0003\u0168\u00b4\u0000"+
		"\u0713\u0712\u0001\u0000\u0000\u0000\u0713\u0714\u0001\u0000\u0000\u0000"+
		"\u0714\u0716\u0001\u0000\u0000\u0000\u0715\u0717\u0003\u0164\u00b2\u0000"+
		"\u0716\u0715\u0001\u0000\u0000\u0000\u0716\u0717\u0001\u0000\u0000\u0000"+
		"\u0717\u0719\u0001\u0000\u0000\u0000\u0718\u071a\u0003\u0166\u00b3\u0000"+
		"\u0719\u0718\u0001\u0000\u0000\u0000\u0719\u071a\u0001\u0000\u0000\u0000"+
		"\u071a\u071c\u0001\u0000\u0000\u0000\u071b\u071d\u0003\u016c\u00b6\u0000"+
		"\u071c\u071b\u0001\u0000\u0000\u0000\u071c\u071d\u0001\u0000\u0000\u0000"+
		"\u071d\u014b\u0001\u0000\u0000\u0000\u071e\u071f\u0003\u00ceg\u0000\u071f"+
		"\u014d\u0001\u0000\u0000\u0000\u0720\u0725\u0005C\u0000\u0000\u0721\u0722"+
		"\u0003\u00b6[\u0000\u0722\u0723\u0005\u0001\u0000\u0000\u0723\u0725\u0001"+
		"\u0000\u0000\u0000\u0724\u0720\u0001\u0000\u0000\u0000\u0724\u0721\u0001"+
		"\u0000\u0000\u0000\u0724\u0725\u0001\u0000\u0000\u0000\u0725\u0726\u0001"+
		"\u0000\u0000\u0000\u0726\u072b\u0003\u01c6\u00e3\u0000\u0727\u0728\u0005"+
		"\u0001\u0000\u0000\u0728\u072a\u0003\u01c6\u00e3\u0000\u0729\u0727\u0001"+
		"\u0000\u0000\u0000\u072a\u072d\u0001\u0000\u0000\u0000\u072b\u0729\u0001"+
		"\u0000\u0000\u0000\u072b\u072c\u0001\u0000\u0000\u0000\u072c\u014f\u0001"+
		"\u0000\u0000\u0000\u072d\u072b\u0001\u0000\u0000\u0000\u072e\u072f\u0005"+
		"\u00bd\u0000\u0000\u072f\u0730\u0005\u0002\u0000\u0000\u0730\u0731\u0003"+
		"\u00c8d\u0000\u0731\u0732\u0005\u0003\u0000\u0000\u0732\u0151\u0001\u0000"+
		"\u0000\u0000\u0733\u0734\u0007\u0012\u0000\u0000\u0734\u0735\u0005\u0002"+
		"\u0000\u0000\u0735\u0736\u0003\u01ca\u00e5\u0000\u0736\u0737\u0005\u0002"+
		"\u0000\u0000\u0737\u0738\u0003\u00c8d\u0000\u0738\u0739\u0005\u0003\u0000"+
		"\u0000\u0739\u073a\u0005\u0003\u0000\u0000\u073a\u074e\u0001\u0000\u0000"+
		"\u0000\u073b\u073c\u0007\u0012\u0000\u0000\u073c\u073d\u0005\u0002\u0000"+
		"\u0000\u073d\u073e\u0003\u01d0\u00e8\u0000\u073e\u073f\u0005\u0002\u0000"+
		"\u0000\u073f\u0740\u0003\u00c8d\u0000\u0740\u0741\u0005\u0003\u0000\u0000"+
		"\u0741\u0742\u0005\u0003\u0000\u0000\u0742\u074e\u0001\u0000\u0000\u0000"+
		"\u0743\u0744\u0007\u0013\u0000\u0000\u0744\u0745\u0005\u0002\u0000\u0000"+
		"\u0745\u0746\u0003\u00c8d\u0000\u0746\u0747\u0005\u0003\u0000\u0000\u0747"+
		"\u074e\u0001\u0000\u0000\u0000\u0748\u0749\u0007\u0014\u0000\u0000\u0749"+
		"\u074a\u0005\u0002\u0000\u0000\u074a\u074b\u0003\u00c8d\u0000\u074b\u074c"+
		"\u0005\u0003\u0000\u0000\u074c\u074e\u0001\u0000\u0000\u0000\u074d\u0733"+
		"\u0001\u0000\u0000\u0000\u074d\u073b\u0001\u0000\u0000\u0000\u074d\u0743"+
		"\u0001\u0000\u0000\u0000\u074d\u0748\u0001\u0000\u0000\u0000\u074e\u0153"+
		"\u0001\u0000\u0000\u0000\u074f\u0750\u0003\u01ca\u00e5\u0000\u0750\u0751"+
		"\u0005\u0002\u0000\u0000\u0751\u0752\u0003\u00c8d\u0000\u0752\u0753\u0005"+
		"\u0003\u0000\u0000\u0753\u075a\u0001\u0000\u0000\u0000\u0754\u0755\u0003"+
		"\u01d0\u00e8\u0000\u0755\u0756\u0005\u0002\u0000\u0000\u0756\u0757\u0003"+
		"\u00c8d\u0000\u0757\u0758\u0005\u0003\u0000\u0000\u0758\u075a\u0001\u0000"+
		"\u0000\u0000\u0759\u074f\u0001\u0000\u0000\u0000\u0759\u0754\u0001\u0000"+
		"\u0000\u0000\u075a\u0155\u0001\u0000\u0000\u0000\u075b\u075f\u0003\u0158"+
		"\u00ac\u0000\u075c\u075f\u0003\u015a\u00ad\u0000\u075d\u075f\u0003\u0160"+
		"\u00b0\u0000\u075e\u075b\u0001\u0000\u0000\u0000\u075e\u075c\u0001\u0000"+
		"\u0000\u0000\u075e\u075d\u0001\u0000\u0000\u0000\u075f\u0157\u0001\u0000"+
		"\u0000\u0000\u0760\u0761\u0003\u015c\u00ae\u0000\u0761\u0762\u0005\u0002"+
		"\u0000\u0000\u0762\u0763\u0003\u01c4\u00e2\u0000\u0763\u0765\u0005\u0003"+
		"\u0000\u0000\u0764\u0766\u0003\u0166\u00b3\u0000\u0765\u0764\u0001\u0000"+
		"\u0000\u0000\u0765\u0766\u0001\u0000\u0000\u0000\u0766\u0768\u0001\u0000"+
		"\u0000\u0000\u0767\u0769\u0003\u016c\u00b6\u0000\u0768\u0767\u0001\u0000"+
		"\u0000\u0000\u0768\u0769\u0001\u0000\u0000\u0000\u0769\u0776\u0001\u0000"+
		"\u0000\u0000\u076a\u076b\u0003\u015c\u00ae\u0000\u076b\u076c\u0005\u0002"+
		"\u0000\u0000\u076c\u076d\u0003R)\u0000\u076d\u076e\u0005\u0003\u0000\u0000"+
		"\u076e\u0776\u0001\u0000\u0000\u0000\u076f\u0770\u0003\u015c\u00ae\u0000"+
		"\u0770\u0771\u0003\u01c8\u00e4\u0000\u0771\u0772\u0005\u0002\u0000\u0000"+
		"\u0772\u0773\u0003\u00ceg\u0000\u0773\u0774\u0005\u0003\u0000\u0000\u0774"+
		"\u0776\u0001\u0000\u0000\u0000\u0775\u0760\u0001\u0000\u0000\u0000\u0775"+
		"\u076a\u0001\u0000\u0000\u0000\u0775\u076f\u0001\u0000\u0000\u0000\u0776"+
		"\u0159\u0001\u0000\u0000\u0000\u0777\u0778\u0003\u015e\u00af\u0000\u0778"+
		"\u0779\u0005\u0002\u0000\u0000\u0779\u077a\u0003\u01c4\u00e2\u0000\u077a"+
		"\u077c\u0005\u0003\u0000\u0000\u077b\u077d\u0003\u0166\u00b3\u0000\u077c"+
		"\u077b\u0001\u0000\u0000\u0000\u077c\u077d\u0001\u0000\u0000\u0000\u077d"+
		"\u077f\u0001\u0000\u0000\u0000\u077e\u0780\u0003\u016c\u00b6\u0000\u077f"+
		"\u077e\u0001\u0000\u0000\u0000\u077f\u0780\u0001\u0000\u0000\u0000\u0780"+
		"\u078d\u0001\u0000\u0000\u0000\u0781\u0782\u0003\u015e\u00af\u0000\u0782"+
		"\u0783\u0005\u0002\u0000\u0000\u0783\u0784\u0003R)\u0000\u0784\u0785\u0005"+
		"\u0003\u0000\u0000\u0785\u078d\u0001\u0000\u0000\u0000\u0786\u0787\u0003"+
		"\u015e\u00af\u0000\u0787\u0788\u0003\u01c8\u00e4\u0000\u0788\u0789\u0005"+
		"\u0002\u0000\u0000\u0789\u078a\u0003\u00ceg\u0000\u078a\u078b\u0005\u0003"+
		"\u0000\u0000\u078b\u078d\u0001\u0000\u0000\u0000\u078c\u0777\u0001\u0000"+
		"\u0000\u0000\u078c\u0781\u0001\u0000\u0000\u0000\u078c\u0786\u0001\u0000"+
		"\u0000\u0000\u078d\u015b\u0001\u0000\u0000\u0000\u078e\u078f\u0007\u0015"+
		"\u0000\u0000\u078f\u015d\u0001\u0000\u0000\u0000\u0790\u0791\u0007\u0016"+
		"\u0000\u0000\u0791\u015f\u0001\u0000\u0000\u0000\u0792\u0793\u0005\u0080"+
		"\u0000\u0000\u0793\u0795\u0005\u0002\u0000\u0000\u0794\u0796\u0005C\u0000"+
		"\u0000\u0795\u0794\u0001\u0000\u0000\u0000\u0795\u0796\u0001\u0000\u0000"+
		"\u0000\u0796\u0797\u0001\u0000\u0000\u0000\u0797\u0798\u0003\u01c6\u00e3"+
		"\u0000\u0798\u0799\u0005\u0001\u0000\u0000\u0799\u079b\u0003\u01c6\u00e3"+
		"\u0000\u079a\u079c\u0003\u0162\u00b1\u0000\u079b\u079a\u0001\u0000\u0000"+
		"\u0000\u079b\u079c\u0001\u0000\u0000\u0000\u079c\u079d\u0001\u0000\u0000"+
		"\u0000\u079d\u079f\u0005\u0003\u0000\u0000\u079e\u07a0\u0003\u0164\u00b2"+
		"\u0000\u079f\u079e\u0001\u0000\u0000\u0000\u079f\u07a0\u0001\u0000\u0000"+
		"\u0000\u07a0\u07a2\u0001\u0000\u0000\u0000\u07a1\u07a3\u0003\u0166\u00b3"+
		"\u0000\u07a2\u07a1\u0001\u0000\u0000\u0000\u07a2\u07a3\u0001\u0000\u0000"+
		"\u0000\u07a3\u07a5\u0001\u0000\u0000\u0000\u07a4\u07a6\u0003\u016c\u00b6"+
		"\u0000\u07a5\u07a4\u0001\u0000\u0000\u0000\u07a5\u07a6\u0001\u0000\u0000"+
		"\u0000\u07a6\u0161\u0001\u0000\u0000\u0000\u07a7\u07a8\u0005\u009f\u0000"+
		"\u0000\u07a8\u07b0\u0005\u00a7\u0000\u0000\u07a9\u07b1\u0005L\u0000\u0000"+
		"\u07aa\u07ac\u0005\u00cc\u0000\u0000\u07ab\u07ad\u0003\u00c4b\u0000\u07ac"+
		"\u07ab\u0001\u0000\u0000\u0000\u07ac\u07ad\u0001\u0000\u0000\u0000\u07ad"+
		"\u07ae\u0001\u0000\u0000\u0000\u07ae\u07af\u0007\u0017\u0000\u0000\u07af"+
		"\u07b1\u00053\u0000\u0000\u07b0\u07a9\u0001\u0000\u0000\u0000\u07b0\u07aa"+
		"\u0001\u0000\u0000\u0000\u07b1\u0163\u0001\u0000\u0000\u0000\u07b2\u07b3"+
		"\u0005\u00da\u0000\u0000\u07b3\u07b4\u0005\\\u0000\u0000\u07b4\u07b5\u0005"+
		"\u0002\u0000\u0000\u07b5\u07b6\u0003l6\u0000\u07b6\u07b7\u0005\u0003\u0000"+
		"\u0000\u07b7\u0165\u0001\u0000\u0000\u0000\u07b8\u07b9\u0005T\u0000\u0000"+
		"\u07b9\u07ba\u0005\u0002\u0000\u0000\u07ba\u07bb\u0003`0\u0000\u07bb\u07bc"+
		"\u0005\u0003\u0000\u0000\u07bc\u0167\u0001\u0000\u0000\u0000\u07bd\u07be"+
		"\u0005\u00b3\u0000\u0000\u07be\u07c2\u0005\u009a\u0000\u0000\u07bf\u07c0"+
		"\u0005`\u0000\u0000\u07c0\u07c2\u0005\u009a\u0000\u0000\u07c1\u07bd\u0001"+
		"\u0000\u0000\u0000\u07c1\u07bf\u0001\u0000\u0000\u0000\u07c2\u0169\u0001"+
		"\u0000\u0000\u0000\u07c3\u07c4\u0005Y\u0000\u0000\u07c4\u07c8\u0005U\u0000"+
		"\u0000\u07c5\u07c6\u0005Y\u0000\u0000\u07c6\u07c8\u0005y\u0000\u0000\u07c7"+
		"\u07c3\u0001\u0000\u0000\u0000\u07c7\u07c5\u0001\u0000\u0000\u0000\u07c8"+
		"\u016b\u0001\u0000\u0000\u0000\u07c9\u07ca\u0005\u00a6\u0000\u0000\u07ca"+
		"\u07cc\u0005\u0002\u0000\u0000\u07cb\u07cd\u0003\u016e\u00b7\u0000\u07cc"+
		"\u07cb\u0001\u0000\u0000\u0000\u07cc\u07cd\u0001\u0000\u0000\u0000\u07cd"+
		"\u07cf\u0001\u0000\u0000\u0000\u07ce\u07d0\u0003l6\u0000\u07cf\u07ce\u0001"+
		"\u0000\u0000\u0000\u07cf\u07d0\u0001\u0000\u0000\u0000\u07d0\u07d2\u0001"+
		"\u0000\u0000\u0000\u07d1\u07d3\u0003\u0170\u00b8\u0000\u07d2\u07d1\u0001"+
		"\u0000\u0000\u0000\u07d2\u07d3\u0001\u0000\u0000\u0000\u07d3\u07d4\u0001"+
		"\u0000\u0000\u0000\u07d4\u07d5\u0005\u0003\u0000\u0000\u07d5\u016d\u0001"+
		"\u0000\u0000\u0000\u07d6\u07d7\u0005\u00ab\u0000\u0000\u07d7\u07d8\u0005"+
		")\u0000\u0000\u07d8\u07dd\u0003\u00c4b\u0000\u07d9\u07da\u0005\u0001\u0000"+
		"\u0000\u07da\u07dc\u0003\u00c4b\u0000\u07db\u07d9\u0001\u0000\u0000\u0000"+
		"\u07dc\u07df\u0001\u0000\u0000\u0000\u07dd\u07db\u0001\u0000\u0000\u0000"+
		"\u07dd\u07de\u0001\u0000\u0000\u0000\u07de\u016f\u0001\u0000\u0000\u0000"+
		"\u07df\u07dd\u0001\u0000\u0000\u0000\u07e0\u07e1\u0007\u0018\u0000\u0000"+
		"\u07e1\u07e3\u0003\u0172\u00b9\u0000\u07e2\u07e4\u0003\u0176\u00bb\u0000"+
		"\u07e3\u07e2\u0001\u0000\u0000\u0000\u07e3\u07e4\u0001\u0000\u0000\u0000"+
		"\u07e4\u07ee\u0001\u0000\u0000\u0000\u07e5\u07e6\u0007\u0018\u0000\u0000"+
		"\u07e6\u07e7\u0005&\u0000\u0000\u07e7\u07e8\u0003\u0172\u00b9\u0000\u07e8"+
		"\u07e9\u0005 \u0000\u0000\u07e9\u07eb\u0003\u0174\u00ba\u0000\u07ea\u07ec"+
		"\u0003\u0176\u00bb\u0000\u07eb\u07ea\u0001\u0000\u0000\u0000\u07eb\u07ec"+
		"\u0001\u0000\u0000\u0000\u07ec\u07ee\u0001\u0000\u0000\u0000\u07ed\u07e0"+
		"\u0001\u0000\u0000\u0000\u07ed\u07e5\u0001\u0000\u0000\u0000\u07ee\u0171"+
		"\u0001\u0000\u0000\u0000\u07ef\u07f0\u00056\u0000\u0000\u07f0\u07fa\u0005"+
		"\u00b7\u0000\u0000\u07f1\u07f2\u0005\u00ce\u0000\u0000\u07f2\u07fa\u0005"+
		"\u00b0\u0000\u0000\u07f3\u07f4\u0003\u00c4b\u0000\u07f4\u07f5\u0005\u00b0"+
		"\u0000\u0000\u07f5\u07fa\u0001\u0000\u0000\u0000\u07f6\u07f7\u0003\u00c4"+
		"b\u0000\u07f7\u07f8\u0005V\u0000\u0000\u07f8\u07fa\u0001\u0000\u0000\u0000"+
		"\u07f9\u07ef\u0001\u0000\u0000\u0000\u07f9\u07f1\u0001\u0000\u0000\u0000"+
		"\u07f9\u07f3\u0001\u0000\u0000\u0000\u07f9\u07f6\u0001\u0000\u0000\u0000"+
		"\u07fa\u0173\u0001\u0000\u0000\u0000\u07fb\u07fc\u00056\u0000\u0000\u07fc"+
		"\u0806\u0005\u00b7\u0000\u0000\u07fd\u07fe\u0005\u00ce\u0000\u0000\u07fe"+
		"\u0806\u0005V\u0000\u0000\u07ff\u0800\u0003\u00c4b\u0000\u0800\u0801\u0005"+
		"\u00b0\u0000\u0000\u0801\u0806\u0001\u0000\u0000\u0000\u0802\u0803\u0003"+
		"\u00c4b\u0000\u0803\u0804\u0005V\u0000\u0000\u0804\u0806\u0001\u0000\u0000"+
		"\u0000\u0805\u07fb\u0001\u0000\u0000\u0000\u0805\u07fd\u0001\u0000\u0000"+
		"\u0000\u0805\u07ff\u0001\u0000\u0000\u0000\u0805\u0802\u0001\u0000\u0000"+
		"\u0000\u0806\u0175\u0001\u0000\u0000\u0000\u0807\u0808\u0005P\u0000\u0000"+
		"\u0808\u0809\u00056\u0000\u0000\u0809\u0812\u0005\u00b7\u0000\u0000\u080a"+
		"\u080b\u0005P\u0000\u0000\u080b\u0812\u0005\\\u0000\u0000\u080c\u080d"+
		"\u0005P\u0000\u0000\u080d\u0812\u0005\u00c2\u0000\u0000\u080e\u080f\u0005"+
		"P\u0000\u0000\u080f\u0810\u0005\u0097\u0000\u0000\u0810\u0812\u0005\u00a4"+
		"\u0000\u0000\u0811\u0807\u0001\u0000\u0000\u0000\u0811\u080a\u0001\u0000"+
		"\u0000\u0000\u0811\u080c\u0001\u0000\u0000\u0000\u0811\u080e\u0001\u0000"+
		"\u0000\u0000\u0812\u0177\u0001\u0000\u0000\u0000\u0813\u081b\u0003\u017a"+
		"\u00bd\u0000\u0814\u081b\u0003\u017c\u00be\u0000\u0815\u081b\u0003\u0180"+
		"\u00c0\u0000\u0816\u081b\u0003\u0188\u00c4\u0000\u0817\u081b\u0003\u018e"+
		"\u00c7\u0000\u0818\u081b\u0003\u0194\u00ca\u0000\u0819\u081b\u0003\u0196"+
		"\u00cb\u0000\u081a\u0813\u0001\u0000\u0000\u0000\u081a\u0814\u0001\u0000"+
		"\u0000\u0000\u081a\u0815\u0001\u0000\u0000\u0000\u081a\u0816\u0001\u0000"+
		"\u0000\u0000\u081a\u0817\u0001\u0000\u0000\u0000\u081a\u0818\u0001\u0000"+
		"\u0000\u0000\u081a\u0819\u0001\u0000\u0000\u0000\u081b\u0179\u0001\u0000"+
		"\u0000\u0000\u081c\u081d\u0005o\u0000\u0000\u081d\u0829\u0005\u0002\u0000"+
		"\u0000\u081e\u0823\u0003\u01c6\u00e3\u0000\u081f\u0820\u0005\u0001\u0000"+
		"\u0000\u0820\u0822\u0003\u01c6\u00e3\u0000\u0821\u081f\u0001\u0000\u0000"+
		"\u0000\u0822\u0825\u0001\u0000\u0000\u0000\u0823\u0821\u0001\u0000\u0000"+
		"\u0000\u0823\u0824\u0001\u0000\u0000\u0000\u0824\u0827\u0001\u0000\u0000"+
		"\u0000\u0825\u0823\u0001\u0000\u0000\u0000\u0826\u0828\u0003\u019a\u00cd"+
		"\u0000\u0827\u0826\u0001\u0000\u0000\u0000\u0827\u0828\u0001\u0000\u0000"+
		"\u0000\u0828\u082a\u0001\u0000\u0000\u0000\u0829\u081e\u0001\u0000\u0000"+
		"\u0000\u0829\u082a\u0001\u0000\u0000\u0000\u082a\u082b\u0001\u0000\u0000"+
		"\u0000\u082b\u082c\u0005\u0003\u0000\u0000\u082c\u017b\u0001\u0000\u0000"+
		"\u0000\u082d\u082e\u0005q\u0000\u0000\u082e\u082f\u0005\u0002\u0000\u0000"+
		"\u082f\u0830\u0003\u00c4b\u0000\u0830\u0831\u0005\u0001\u0000\u0000\u0831"+
		"\u0833\u0003\u00c4b\u0000\u0832\u0834\u0003\u0198\u00cc\u0000\u0833\u0832"+
		"\u0001\u0000\u0000\u0000\u0833\u0834\u0001\u0000\u0000\u0000\u0834\u0836"+
		"\u0001\u0000\u0000\u0000\u0835\u0837\u0003\u017e\u00bf\u0000\u0836\u0835"+
		"\u0001\u0000\u0000\u0000\u0836\u0837\u0001\u0000\u0000\u0000\u0837\u0838"+
		"\u0001\u0000\u0000\u0000\u0838\u0839\u0005\u0003\u0000\u0000\u0839\u017d"+
		"\u0001\u0000\u0000\u0000\u083a\u083b\u0007\u0019\u0000\u0000\u083b\u083c"+
		"\u0005\u009f\u0000\u0000\u083c\u083d\u0005L\u0000\u0000\u083d\u017f\u0001"+
		"\u0000\u0000\u0000\u083e\u083f\u0005r\u0000\u0000\u083f\u0841\u0005\u0002"+
		"\u0000\u0000\u0840\u0842\u0003\u0182\u00c1\u0000\u0841\u0840\u0001\u0000"+
		"\u0000\u0000\u0841\u0842\u0001\u0000\u0000\u0000\u0842\u0847\u0001\u0000"+
		"\u0000\u0000\u0843\u0844\u0005\u0001\u0000\u0000\u0844\u0846\u0003\u0182"+
		"\u00c1\u0000\u0845\u0843\u0001\u0000\u0000\u0000\u0846\u0849\u0001\u0000"+
		"\u0000\u0000\u0847\u0845\u0001\u0000\u0000\u0000\u0847\u0848\u0001\u0000"+
		"\u0000\u0000\u0848\u084b\u0001\u0000\u0000\u0000\u0849\u0847\u0001\u0000"+
		"\u0000\u0000\u084a\u084c\u0003\u019a\u00cd\u0000\u084b\u084a\u0001\u0000"+
		"\u0000\u0000\u084b\u084c\u0001\u0000\u0000\u0000\u084c\u084d\u0001\u0000"+
		"\u0000\u0000\u084d\u084e\u0005\u0003\u0000\u0000\u084e\u0181\u0001\u0000"+
		"\u0000\u0000\u084f\u0853\u0003\u01c6\u00e3\u0000\u0850\u0853\u0003\u0184"+
		"\u00c2\u0000\u0851\u0853\u0003\u0186\u00c3\u0000\u0852\u084f\u0001\u0000"+
		"\u0000\u0000\u0852\u0850\u0001\u0000\u0000\u0000\u0852\u0851\u0001\u0000"+
		"\u0000\u0000\u0853\u0183\u0001\u0000\u0000\u0000\u0854\u0856\u0005w\u0000"+
		"\u0000\u0855\u0854\u0001\u0000\u0000\u0000\u0855\u0856\u0001\u0000\u0000"+
		"\u0000\u0856\u0857\u0001\u0000\u0000\u0000\u0857\u0858\u0003\u01c6\u00e3"+
		"\u0000\u0858\u0859\u0005\u00d4\u0000\u0000\u0859\u085a\u0003\u01c6\u00e3"+
		"\u0000\u085a\u0185\u0001\u0000\u0000\u0000\u085b\u085c\u0003\u01c6\u00e3"+
		"\u0000\u085c\u085d\u0005\t\u0000\u0000\u085d\u085e\u0003\u01c6\u00e3\u0000"+
		"\u085e\u0187\u0001\u0000\u0000\u0000\u085f\u0860\u0005t\u0000\u0000\u0860"+
		"\u0861\u0005\u0002\u0000\u0000\u0861\u0862\u0003\u00c4b\u0000\u0862\u0863"+
		"\u0005\u0001\u0000\u0000\u0863\u0865\u0003\u00c4b\u0000\u0864\u0866\u0003"+
		"\u0198\u00cc\u0000\u0865\u0864\u0001\u0000\u0000\u0000\u0865\u0866\u0001"+
		"\u0000\u0000\u0000\u0866\u0868\u0001\u0000\u0000\u0000\u0867\u0869\u0003"+
		"\u018a\u00c5\u0000\u0868\u0867\u0001\u0000\u0000\u0000\u0868\u0869\u0001"+
		"\u0000\u0000\u0000\u0869\u086b\u0001\u0000\u0000\u0000\u086a\u086c\u0003"+
		"\u018c\u00c6\u0000\u086b\u086a\u0001\u0000\u0000\u0000\u086b\u086c\u0001"+
		"\u0000\u0000\u0000\u086c\u086e\u0001\u0000\u0000\u0000\u086d\u086f\u0003"+
		"\u018c\u00c6\u0000\u086e\u086d\u0001\u0000\u0000\u0000\u086e\u086f\u0001"+
		"\u0000\u0000\u0000\u086f\u0870\u0001\u0000\u0000\u0000\u0870\u0871\u0005"+
		"\u0003\u0000\u0000\u0871\u0189\u0001\u0000\u0000\u0000\u0872\u0874\u0005"+
		"\u00d9\u0000\u0000\u0873\u0875\u0007\u001a\u0000\u0000\u0874\u0873\u0001"+
		"\u0000\u0000\u0000\u0874\u0875\u0001\u0000\u0000\u0000\u0875\u0877\u0001"+
		"\u0000\u0000\u0000\u0876\u0878\u0005\"\u0000\u0000\u0877\u0876\u0001\u0000"+
		"\u0000\u0000\u0877\u0878\u0001\u0000\u0000\u0000\u0878\u0879\u0001\u0000"+
		"\u0000\u0000\u0879\u0880\u0005\u00dc\u0000\u0000\u087a\u087c\u0005\u00db"+
		"\u0000\u0000\u087b\u087d\u0005\"\u0000\u0000\u087c\u087b\u0001\u0000\u0000"+
		"\u0000\u087c\u087d\u0001\u0000\u0000\u0000\u087d\u087e\u0001\u0000\u0000"+
		"\u0000\u087e\u0880\u0005\u00dc\u0000\u0000\u087f\u0872\u0001\u0000\u0000"+
		"\u0000\u087f\u087a\u0001\u0000\u0000\u0000\u0880\u018b\u0001\u0000\u0000"+
		"\u0000\u0881\u0888\u0005L\u0000\u0000\u0882\u0888\u0005\u00e8\u0000\u0000"+
		"\u0883\u0885\u0005H\u0000\u0000\u0884\u0886\u0007\u001b\u0000\u0000\u0885"+
		"\u0884\u0001\u0000\u0000\u0000\u0885\u0886\u0001\u0000\u0000\u0000\u0886"+
		"\u0888\u0001\u0000\u0000\u0000\u0887\u0881\u0001\u0000\u0000\u0000\u0887"+
		"\u0882\u0001\u0000\u0000\u0000\u0887\u0883\u0001\u0000\u0000\u0000\u0888"+
		"\u0889\u0001\u0000\u0000\u0000\u0889\u088a\u0005\u009f\u0000\u0000\u088a"+
		"\u088b\u0007\u001c\u0000\u0000\u088b\u018d\u0001\u0000\u0000\u0000\u088c"+
		"\u088d\u0005v\u0000\u0000\u088d\u088e\u0005\u0002\u0000\u0000\u088e\u088f"+
		"\u0003\u00c4b\u0000\u088f\u0890\u0005\u0001\u0000\u0000\u0890\u0892\u0003"+
		"\u00c4b\u0000\u0891\u0893\u0003\u0198\u00cc\u0000\u0892\u0891\u0001\u0000"+
		"\u0000\u0000\u0892\u0893\u0001\u0000\u0000\u0000\u0893\u0895\u0001\u0000"+
		"\u0000\u0000\u0894\u0896\u0003\u0190\u00c8\u0000\u0895\u0894\u0001\u0000"+
		"\u0000\u0000\u0895\u0896\u0001\u0000\u0000\u0000\u0896\u0898\u0001\u0000"+
		"\u0000\u0000\u0897\u0899\u0003\u0192\u00c9\u0000\u0898\u0897\u0001\u0000"+
		"\u0000\u0000\u0898\u0899\u0001\u0000\u0000\u0000\u0899\u089b\u0001\u0000"+
		"\u0000\u0000\u089a\u089c\u0003\u0192\u00c9\u0000\u089b\u089a\u0001\u0000"+
		"\u0000\u0000\u089b\u089c\u0001\u0000\u0000\u0000\u089c\u089d\u0001\u0000"+
		"\u0000\u0000\u089d\u089e\u0005\u0003\u0000\u0000\u089e\u018f\u0001\u0000"+
		"\u0000\u0000\u089f\u08a0\u0005\u00b4\u0000\u0000\u08a0\u08a1\u0003\u00fc"+
		"~\u0000\u08a1\u0191\u0001\u0000\u0000\u0000\u08a2\u08a7\u0005L\u0000\u0000"+
		"\u08a3\u08a7\u0005\u00e8\u0000\u0000\u08a4\u08a5\u0005?\u0000\u0000\u08a5"+
		"\u08a7\u0003\u00c4b\u0000\u08a6\u08a2\u0001\u0000\u0000\u0000\u08a6\u08a3"+
		"\u0001\u0000\u0000\u0000\u08a6\u08a4\u0001\u0000\u0000\u0000\u08a7\u08a8"+
		"\u0001\u0000\u0000\u0000\u08a8\u08a9\u0005\u009f\u0000\u0000\u08a9\u08aa"+
		"\u0007\u001c\u0000\u0000\u08aa\u0193\u0001\u0000\u0000\u0000\u08ab\u08ac"+
		"\u0005p\u0000\u0000\u08ac\u08ad\u0005\u0002\u0000\u0000\u08ad\u08af\u0003"+
		"\u01c6\u00e3\u0000\u08ae\u08b0\u0003\u019a\u00cd\u0000\u08af\u08ae\u0001"+
		"\u0000\u0000\u0000\u08af\u08b0\u0001\u0000\u0000\u0000\u08b0\u08b2\u0001"+
		"\u0000\u0000\u0000\u08b1\u08b3\u0003l6\u0000\u08b2\u08b1\u0001\u0000\u0000"+
		"\u0000\u08b2\u08b3\u0001\u0000\u0000\u0000\u08b3\u08b4\u0001\u0000\u0000"+
		"\u0000\u08b4\u08b6\u0005\u0003\u0000\u0000\u08b5\u08b7\u0003\u0166\u00b3"+
		"\u0000\u08b6\u08b5\u0001\u0000\u0000\u0000\u08b6\u08b7\u0001\u0000\u0000"+
		"\u0000\u08b7\u0195\u0001\u0000\u0000\u0000\u08b8\u08b9\u0005s\u0000\u0000"+
		"\u08b9\u08bb\u0005\u0002\u0000\u0000\u08ba\u08bc\u0005w\u0000\u0000\u08bb"+
		"\u08ba\u0001\u0000\u0000\u0000\u08bb\u08bc\u0001\u0000\u0000\u0000\u08bc"+
		"\u08bd\u0001\u0000\u0000\u0000\u08bd\u08be\u0003\u01c6\u00e3\u0000\u08be"+
		"\u08bf\u0007\u001d\u0000\u0000\u08bf\u08c1\u0003\u01c6\u00e3\u0000\u08c0"+
		"\u08c2\u0003\u019a\u00cd\u0000\u08c1\u08c0\u0001\u0000\u0000\u0000\u08c1"+
		"\u08c2\u0001\u0000\u0000\u0000\u08c2\u08c4\u0001\u0000\u0000\u0000\u08c3"+
		"\u08c5\u0003\u019c\u00ce\u0000\u08c4\u08c3\u0001\u0000\u0000\u0000\u08c4"+
		"\u08c5\u0001\u0000\u0000\u0000\u08c5\u08c6\u0001\u0000\u0000\u0000\u08c6"+
		"\u08c8\u0005\u0003\u0000\u0000\u08c7\u08c9\u0003\u0166\u00b3\u0000\u08c8"+
		"\u08c7\u0001\u0000\u0000\u0000\u08c8\u08c9\u0001\u0000\u0000\u0000\u08c9"+
		"\u0197\u0001\u0000\u0000\u0000\u08ca\u08cb\u0005\u00ac\u0000\u0000\u08cb"+
		"\u08d0\u0003\u01b8\u00dc\u0000\u08cc\u08cd\u0005\u0001\u0000\u0000\u08cd"+
		"\u08cf\u0003\u01b8\u00dc\u0000\u08ce\u08cc\u0001\u0000\u0000\u0000\u08cf"+
		"\u08d2\u0001\u0000\u0000\u0000\u08d0\u08ce\u0001\u0000\u0000\u0000\u08d0"+
		"\u08d1\u0001\u0000\u0000\u0000\u08d1\u0199\u0001\u0000\u0000\u0000\u08d2"+
		"\u08d0\u0001\u0000\u0000\u0000\u08d3\u08d4\u0007\u001e\u0000\u0000\u08d4"+
		"\u08d5\u0005\u009f\u0000\u0000\u08d5\u08d6\u0005\u00e8\u0000\u0000\u08d6"+
		"\u019b\u0001\u0000\u0000\u0000\u08d7\u08d8\u0007\u0017\u0000\u0000\u08d8"+
		"\u08d9\u0005\u00d1\u0000\u0000\u08d9\u08da\u0005x\u0000\u0000\u08da\u019d"+
		"\u0001\u0000\u0000\u0000\u08db\u08dc\u0005u\u0000\u0000\u08dc\u08dd\u0005"+
		"\u0002\u0000\u0000\u08dd\u08e0\u0003\u00c4b\u0000\u08de\u08df\u0005\u0001"+
		"\u0000\u0000\u08df\u08e1\u0003\u00c4b\u0000\u08e0\u08de\u0001\u0000\u0000"+
		"\u0000\u08e0\u08e1\u0001\u0000\u0000\u0000\u08e1\u08e3\u0001\u0000\u0000"+
		"\u0000\u08e2\u08e4\u0003\u0198\u00cc\u0000\u08e3\u08e2\u0001\u0000\u0000"+
		"\u0000\u08e3\u08e4\u0001\u0000\u0000\u0000\u08e4\u08e5\u0001\u0000\u0000"+
		"\u0000\u08e5\u08e7\u0003\u01a2\u00d1\u0000\u08e6\u08e8\u0003\u01a0\u00d0"+
		"\u0000\u08e7\u08e6\u0001\u0000\u0000\u0000\u08e7\u08e8\u0001\u0000\u0000"+
		"\u0000\u08e8\u08e9\u0001\u0000\u0000\u0000\u08e9\u08ea\u0005\u0003\u0000"+
		"\u0000\u08ea\u019f\u0001\u0000\u0000\u0000\u08eb\u08ec\u0007\u001f\u0000"+
		"\u0000\u08ec\u08ed\u0005\u009f\u0000\u0000\u08ed\u08ee\u0005L\u0000\u0000"+
		"\u08ee\u01a1\u0001\u0000\u0000\u0000\u08ef\u08f0\u0005.\u0000\u0000\u08f0"+
		"\u08f1\u0005\u0002\u0000\u0000\u08f1\u08f2\u0003\u01a4\u00d2\u0000\u08f2"+
		"\u08f3\u0005\u0003\u0000\u0000\u08f3\u01a3\u0001\u0000\u0000\u0000\u08f4"+
		"\u08f9\u0003\u01a6\u00d3\u0000\u08f5\u08f6\u0005\u0001\u0000\u0000\u08f6"+
		"\u08f8\u0003\u01a6\u00d3\u0000\u08f7\u08f5\u0001\u0000\u0000\u0000\u08f8"+
		"\u08fb\u0001\u0000\u0000\u0000\u08f9\u08f7\u0001\u0000\u0000\u0000\u08f9"+
		"\u08fa\u0001\u0000\u0000\u0000\u08fa\u01a5\u0001\u0000\u0000\u0000\u08fb"+
		"\u08f9\u0001\u0000\u0000\u0000\u08fc\u08fe\u0005\u0095\u0000\u0000\u08fd"+
		"\u08ff\u0005\u00aa\u0000\u0000\u08fe\u08fd\u0001\u0000\u0000\u0000\u08fe"+
		"\u08ff\u0001\u0000\u0000\u0000\u08ff\u0900\u0001\u0000\u0000\u0000\u0900"+
		"\u0901\u0005\u00eb\u0000\u0000\u0901\u092b\u0003\u01a2\u00d1\u0000\u0902"+
		"\u0903\u0003\u01f0\u00f8\u0000\u0903\u0905\u0005n\u0000\u0000\u0904\u0906"+
		"\u0003\u018a\u00c5\u0000\u0905\u0904\u0001\u0000\u0000\u0000\u0905\u0906"+
		"\u0001\u0000\u0000\u0000\u0906\u0909\u0001\u0000\u0000\u0000\u0907\u0908"+
		"\u0005\u00aa\u0000\u0000\u0908\u090a\u0005\u00eb\u0000\u0000\u0909\u0907"+
		"\u0001\u0000\u0000\u0000\u0909\u090a\u0001\u0000\u0000\u0000\u090a\u090c"+
		"\u0001\u0000\u0000\u0000\u090b\u090d\u0003\u018c\u00c6\u0000\u090c\u090b"+
		"\u0001\u0000\u0000\u0000\u090c\u090d\u0001\u0000\u0000\u0000\u090d\u090f"+
		"\u0001\u0000\u0000\u0000\u090e\u0910\u0003\u018c\u00c6\u0000\u090f\u090e"+
		"\u0001\u0000\u0000\u0000\u090f\u0910\u0001\u0000\u0000\u0000\u0910\u092b"+
		"\u0001\u0000\u0000\u0000\u0911\u0912\u0003\u01f0\u00f8\u0000\u0912\u0913"+
		"\u0005W\u0000\u0000\u0913\u0914\u0005\u00a3\u0000\u0000\u0914\u092b\u0001"+
		"\u0000\u0000\u0000\u0915\u0916\u0003\u01f0\u00f8\u0000\u0916\u0919\u0005"+
		"Q\u0000\u0000\u0917\u0918\u0005\u00aa\u0000\u0000\u0918\u091a\u0005\u00eb"+
		"\u0000\u0000\u0919\u0917\u0001\u0000\u0000\u0000\u0919\u091a\u0001\u0000"+
		"\u0000\u0000\u091a\u091c\u0001\u0000\u0000\u0000\u091b\u091d\u0003\u017e"+
		"\u00bf\u0000\u091c\u091b\u0001\u0000\u0000\u0000\u091c\u091d\u0001\u0000"+
		"\u0000\u0000\u091d\u092b\u0001\u0000\u0000\u0000\u091e\u091f\u0003\u01f0"+
		"\u00f8\u0000\u091f\u0922\u0003\u00fc~\u0000\u0920\u0921\u0005\u00aa\u0000"+
		"\u0000\u0921\u0923\u0005\u00eb\u0000\u0000\u0922\u0920\u0001\u0000\u0000"+
		"\u0000\u0922\u0923\u0001\u0000\u0000\u0000\u0923\u0925\u0001\u0000\u0000"+
		"\u0000\u0924\u0926\u0003\u0192\u00c9\u0000\u0925\u0924\u0001\u0000\u0000"+
		"\u0000\u0925\u0926\u0001\u0000\u0000\u0000\u0926\u0928\u0001\u0000\u0000"+
		"\u0000\u0927\u0929\u0003\u0192\u00c9\u0000\u0928\u0927\u0001\u0000\u0000"+
		"\u0000\u0928\u0929\u0001\u0000\u0000\u0000\u0929\u092b\u0001\u0000\u0000"+
		"\u0000\u092a\u08fc\u0001\u0000\u0000\u0000\u092a\u0902\u0001\u0000\u0000"+
		"\u0000\u092a\u0911\u0001\u0000\u0000\u0000\u092a\u0915\u0001\u0000\u0000"+
		"\u0000\u092a\u091e\u0001\u0000\u0000\u0000\u092b\u01a7\u0001\u0000\u0000"+
		"\u0000\u092c\u0933\u0003\u01aa\u00d5\u0000\u092d\u0933\u0003\u01ae\u00d7"+
		"\u0000\u092e\u0933\u0003\u01b0\u00d8\u0000\u092f\u0933\u0003\u01b2\u00d9"+
		"\u0000\u0930\u0933\u0003\u01b4\u00da\u0000\u0931\u0933\u0003\u01b6\u00db"+
		"\u0000\u0932\u092c\u0001\u0000\u0000\u0000\u0932\u092d\u0001\u0000\u0000"+
		"\u0000\u0932\u092e\u0001\u0000\u0000\u0000\u0932\u092f\u0001\u0000\u0000"+
		"\u0000\u0932\u0930\u0001\u0000\u0000\u0000\u0932\u0931\u0001\u0000\u0000"+
		"\u0000\u0933\u01a9\u0001\u0000\u0000\u0000\u0934\u0935\u0005\u00e0\u0000"+
		"\u0000\u0935\u0936\u0005\u0002\u0000\u0000\u0936\u0937\u0005\u0092\u0000"+
		"\u0000\u0937\u093a\u0003\u01f0\u00f8\u0000\u0938\u0939\u0005\u0001\u0000"+
		"\u0000\u0939\u093b\u0003\u01ac\u00d6\u0000\u093a\u0938\u0001\u0000\u0000"+
		"\u0000\u093a\u093b\u0001\u0000\u0000\u0000\u093b\u0940\u0001\u0000\u0000"+
		"\u0000\u093c\u093d\u0005\u0001\u0000\u0000\u093d\u093f\u0003\u01c6\u00e3"+
		"\u0000\u093e\u093c\u0001\u0000\u0000\u0000\u093f\u0942\u0001\u0000\u0000"+
		"\u0000\u0940\u093e\u0001\u0000\u0000\u0000\u0940\u0941\u0001\u0000\u0000"+
		"\u0000\u0941\u0943\u0001\u0000\u0000\u0000\u0942\u0940\u0001\u0000\u0000"+
		"\u0000\u0943\u0944\u0005\u0003\u0000\u0000\u0944\u01ab\u0001\u0000\u0000"+
		"\u0000\u0945\u0946\u0005\u00df\u0000\u0000\u0946\u0947\u0005\u0002\u0000"+
		"\u0000\u0947\u094c\u0003\u01b8\u00dc\u0000\u0948\u0949\u0005\u0001\u0000"+
		"\u0000\u0949\u094b\u0003\u01b8\u00dc\u0000\u094a\u0948\u0001\u0000\u0000"+
		"\u0000\u094b\u094e\u0001\u0000\u0000\u0000\u094c\u094a\u0001\u0000\u0000"+
		"\u0000\u094c\u094d\u0001\u0000\u0000\u0000\u094d\u094f\u0001\u0000\u0000"+
		"\u0000\u094e\u094c\u0001\u0000\u0000\u0000\u094f\u0950\u0005\u0003\u0000"+
		"\u0000\u0950\u01ad\u0001\u0000\u0000\u0000\u0951\u0952\u0005\u00e2\u0000"+
		"\u0000\u0952\u0953\u0005\u0002\u0000\u0000\u0953\u0958\u0003\u01ba\u00dd"+
		"\u0000\u0954\u0955\u0005\u0001\u0000\u0000\u0955\u0957\u0003\u01ba\u00dd"+
		"\u0000\u0956\u0954\u0001\u0000\u0000\u0000\u0957\u095a\u0001\u0000\u0000"+
		"\u0000\u0958\u0956\u0001\u0000\u0000\u0000\u0958\u0959\u0001\u0000\u0000"+
		"\u0000\u0959\u095b\u0001\u0000\u0000\u0000\u095a\u0958\u0001\u0000\u0000"+
		"\u0000\u095b\u095c\u0005\u0003\u0000\u0000\u095c\u01af\u0001\u0000\u0000"+
		"\u0000\u095d\u095e\u0005\u00e3\u0000\u0000\u095e\u095f\u0005\u0002\u0000"+
		"\u0000\u095f\u0960\u0005\u0092\u0000\u0000\u0960\u0963\u0003\u01f0\u00f8"+
		"\u0000\u0961\u0962\u0005\u0001\u0000\u0000\u0962\u0964\u0003\u00c4b\u0000"+
		"\u0963\u0961\u0001\u0000\u0000\u0000\u0963\u0964\u0001\u0000\u0000\u0000"+
		"\u0964\u0965\u0001\u0000\u0000\u0000\u0965\u0966\u0005\u0003\u0000\u0000"+
		"\u0966\u01b1\u0001\u0000\u0000\u0000\u0967\u0968\u0005\u00e4\u0000\u0000"+
		"\u0968\u0969\u0005\u0002\u0000\u0000\u0969\u096a\u0003\u00c4b\u0000\u096a"+
		"\u096b\u0005\u00ac\u0000\u0000\u096b\u096c\u0003\u00c4b\u0000\u096c\u096d"+
		"\u0005\u0003\u0000\u0000\u096d\u01b3\u0001\u0000\u0000\u0000\u096e\u096f"+
		"\u0005\u00e1\u0000\u0000\u096f\u0970\u0005\u0002\u0000\u0000\u0970\u0971"+
		"\u0003\u00c4b\u0000\u0971\u0972\u0005\u00ac\u0000\u0000\u0972\u0973\u0003"+
		"\u00c4b\u0000\u0973\u0974\u0005\u0003\u0000\u0000\u0974\u01b5\u0001\u0000"+
		"\u0000\u0000\u0975\u0976\u0005\u00de\u0000\u0000\u0976\u0977\u0005\u0002"+
		"\u0000\u0000\u0977\u0979\u0003\u00c4b\u0000\u0978\u097a\u0003l6\u0000"+
		"\u0979\u0978\u0001\u0000\u0000\u0000\u0979\u097a\u0001\u0000\u0000\u0000"+
		"\u097a\u097b\u0001\u0000\u0000\u0000\u097b\u097d\u0005\u0003\u0000\u0000"+
		"\u097c\u097e\u0003\u0166\u00b3\u0000\u097d\u097c\u0001\u0000\u0000\u0000"+
		"\u097d\u097e\u0001\u0000\u0000\u0000\u097e\u0980\u0001\u0000\u0000\u0000"+
		"\u097f\u0981\u0003\u016c\u00b6\u0000\u0980\u097f\u0001\u0000\u0000\u0000"+
		"\u0980\u0981\u0001\u0000\u0000\u0000\u0981\u01b7\u0001\u0000\u0000\u0000"+
		"\u0982\u0983\u0003\u01c6\u00e3\u0000\u0983\u0984\u0005#\u0000\u0000\u0984"+
		"\u0985\u0003\u01f0\u00f8\u0000\u0985\u01b9\u0001\u0000\u0000\u0000\u0986"+
		"\u0989\u0003\u01c6\u00e3\u0000\u0987\u0988\u0005#\u0000\u0000\u0988\u098a"+
		"\u0003\u01f0\u00f8\u0000\u0989\u0987\u0001\u0000\u0000\u0000\u0989\u098a"+
		"\u0001\u0000\u0000\u0000\u098a\u01bb\u0001\u0000\u0000\u0000\u098b\u098c"+
		"\u0005\u00e5\u0000\u0000\u098c\u098d\u0005\u0002\u0000\u0000\u098d\u098e"+
		"\u0003\u00c4b\u0000\u098e\u098f\u0005\u00ac\u0000\u0000\u098f\u0990\u0003"+
		"\u00c4b\u0000\u0990\u0991\u0003\u01be\u00df\u0000\u0991\u0992\u0005\u0003"+
		"\u0000\u0000\u0992\u01bd\u0001\u0000\u0000\u0000\u0993\u0994\u0005.\u0000"+
		"\u0000\u0994\u0999\u0003\u01c0\u00e0\u0000\u0995\u0996\u0005\u0001\u0000"+
		"\u0000\u0996\u0998\u0003\u01c0\u00e0\u0000\u0997\u0995\u0001\u0000\u0000"+
		"\u0000\u0998\u099b\u0001\u0000\u0000";
	private static final String _serializedATNSegment1 =
		"\u0000\u0999\u0997\u0001\u0000\u0000\u0000\u0999\u099a\u0001\u0000\u0000"+
		"\u0000\u099a\u01bf\u0001\u0000\u0000\u0000\u099b\u0999\u0001\u0000\u0000"+
		"\u0000\u099c\u099d\u0003\u01f0\u00f8\u0000\u099d\u09a0\u0005\u00dd\u0000"+
		"\u0000\u099e\u099f\u0005\u00aa\u0000\u0000\u099f\u09a1\u0005\u00eb\u0000"+
		"\u0000\u09a0\u099e\u0001\u0000\u0000\u0000\u09a0\u09a1\u0001\u0000\u0000"+
		"\u0000\u09a1\u09a3\u0001\u0000\u0000\u0000\u09a2\u09a4\u0003\u01c2\u00e1"+
		"\u0000\u09a3\u09a2\u0001\u0000\u0000\u0000\u09a3\u09a4\u0001\u0000\u0000"+
		"\u0000\u09a4\u09b3\u0001\u0000\u0000\u0000\u09a5\u09a6\u0003\u01f0\u00f8"+
		"\u0000\u09a6\u09a7\u0005W\u0000\u0000\u09a7\u09a8\u0005\u00a3\u0000\u0000"+
		"\u09a8\u09b3\u0001\u0000\u0000\u0000\u09a9\u09aa\u0003\u01f0\u00f8\u0000"+
		"\u09aa\u09ad\u0003\u00fc~\u0000\u09ab\u09ac\u0005\u00aa\u0000\u0000\u09ac"+
		"\u09ae\u0005\u00eb\u0000\u0000\u09ad\u09ab\u0001\u0000\u0000\u0000\u09ad"+
		"\u09ae\u0001\u0000\u0000\u0000\u09ae\u09b0\u0001\u0000\u0000\u0000\u09af"+
		"\u09b1\u0003\u01c2\u00e1\u0000\u09b0\u09af\u0001\u0000\u0000\u0000\u09b0"+
		"\u09b1\u0001\u0000\u0000\u0000\u09b1\u09b3\u0001\u0000\u0000\u0000\u09b2"+
		"\u099c\u0001\u0000\u0000\u0000\u09b2\u09a5\u0001\u0000\u0000\u0000\u09b2"+
		"\u09a9\u0001\u0000\u0000\u0000\u09b3\u01c1\u0001\u0000\u0000\u0000\u09b4"+
		"\u09b5\u0005?\u0000\u0000\u09b5\u09b6\u0003\u00c4b\u0000\u09b6\u01c3\u0001"+
		"\u0000\u0000\u0000\u09b7\u09b8\u0006\u00e2\uffff\uffff\u0000\u09b8\u09b9"+
		"\u0005\u0002\u0000\u0000\u09b9\u09ba\u0003\u01c4\u00e2\u0000\u09ba\u09bb"+
		"\u0005\u0003\u0000\u0000\u09bb\u09e6\u0001\u0000\u0000\u0000\u09bc\u09bd"+
		"\u0003\u00c4b\u0000\u09bd\u09bf\u0005l\u0000\u0000\u09be\u09c0\u0005\u0098"+
		"\u0000\u0000\u09bf\u09be\u0001\u0000\u0000\u0000\u09bf\u09c0\u0001\u0000"+
		"\u0000\u0000\u09c0\u09c1\u0001\u0000\u0000\u0000\u09c1\u09c2\u0007 \u0000"+
		"\u0000\u09c2\u09e6\u0001\u0000\u0000\u0000\u09c3\u09c4\u0003\u00c4b\u0000"+
		"\u09c4\u09c6\u0005l\u0000\u0000\u09c5\u09c7\u0005\u0098\u0000\u0000\u09c6"+
		"\u09c5\u0001\u0000\u0000\u0000\u09c6\u09c7\u0001\u0000\u0000\u0000\u09c7"+
		"\u09c8\u0001\u0000\u0000\u0000\u09c8\u09c9\u0005C\u0000\u0000\u09c9\u09ca"+
		"\u0005Y\u0000\u0000\u09ca\u09cb\u0003\u00c4b\u0000\u09cb\u09e6\u0001\u0000"+
		"\u0000\u0000\u09cc\u09ce\u0003\u00c4b\u0000\u09cd\u09cf\u0005\u0098\u0000"+
		"\u0000\u09ce\u09cd\u0001\u0000\u0000\u0000\u09ce\u09cf\u0001\u0000\u0000"+
		"\u0000\u09cf\u09d0\u0001\u0000\u0000\u0000\u09d0\u09d2\u0005\u008a\u0000"+
		"\u0000\u09d1\u09d3\u0005\u009c\u0000\u0000\u09d2\u09d1\u0001\u0000\u0000"+
		"\u0000\u09d2\u09d3\u0001\u0000\u0000\u0000\u09d3\u09d4\u0001\u0000\u0000"+
		"\u0000\u09d4\u09d5\u0003\u00c8d\u0000\u09d5\u09e6\u0001\u0000\u0000\u0000"+
		"\u09d6\u09e6\u0003\u01d8\u00ec\u0000\u09d7\u09e6\u0003\u01d4\u00ea\u0000"+
		"\u09d8\u09da\u0003\u00c4b\u0000\u09d9\u09db\u0005\u0098\u0000\u0000\u09da"+
		"\u09d9\u0001\u0000\u0000\u0000\u09da\u09db\u0001\u0000\u0000\u0000\u09db"+
		"\u09dc\u0001\u0000\u0000\u0000\u09dc\u09dd\u0007!\u0000\u0000\u09dd\u09de"+
		"\u0003\u00c4b\u0000\u09de\u09e6\u0001\u0000\u0000\u0000\u09df\u09e6\u0003"+
		"\u01d2\u00e9\u0000\u09e0\u09e6\u0003\u01d6\u00eb\u0000\u09e1\u09e6\u0003"+
		"\u01dc\u00ee\u0000\u09e2\u09e3\u0005\u0098\u0000\u0000\u09e3\u09e6\u0003"+
		"\u01c4\u00e2\u0004\u09e4\u09e6\u0003\u00c4b\u0000\u09e5\u09b7\u0001\u0000"+
		"\u0000\u0000\u09e5\u09bc\u0001\u0000\u0000\u0000\u09e5\u09c3\u0001\u0000"+
		"\u0000\u0000\u09e5\u09cc\u0001\u0000\u0000\u0000\u09e5\u09d6\u0001\u0000"+
		"\u0000\u0000\u09e5\u09d7\u0001\u0000\u0000\u0000\u09e5\u09d8\u0001\u0000"+
		"\u0000\u0000\u09e5\u09df\u0001\u0000\u0000\u0000\u09e5\u09e0\u0001\u0000"+
		"\u0000\u0000\u09e5\u09e1\u0001\u0000\u0000\u0000\u09e5\u09e2\u0001\u0000"+
		"\u0000\u0000\u09e5\u09e4\u0001\u0000\u0000\u0000\u09e6\u09ef\u0001\u0000"+
		"\u0000\u0000\u09e7\u09e8\n\u0003\u0000\u0000\u09e8\u09e9\u0005 \u0000"+
		"\u0000\u09e9\u09ee\u0003\u01c4\u00e2\u0004\u09ea\u09eb\n\u0002\u0000\u0000"+
		"\u09eb\u09ec\u0005\u00a1\u0000\u0000\u09ec\u09ee\u0003\u01c4\u00e2\u0003"+
		"\u09ed\u09e7\u0001\u0000\u0000\u0000\u09ed\u09ea\u0001\u0000\u0000\u0000"+
		"\u09ee\u09f1\u0001\u0000\u0000\u0000\u09ef\u09ed\u0001\u0000\u0000\u0000"+
		"\u09ef\u09f0\u0001\u0000\u0000\u0000\u09f0\u01c5\u0001\u0000\u0000\u0000"+
		"\u09f1\u09ef\u0001\u0000\u0000\u0000\u09f2\u09f5\u0003\u00c4b\u0000\u09f3"+
		"\u09f5\u0003\u01c4\u00e2\u0000\u09f4\u09f2\u0001\u0000\u0000\u0000\u09f4"+
		"\u09f3\u0001\u0000\u0000\u0000\u09f5\u01c7\u0001\u0000\u0000\u0000\u09f6"+
		"\u09f9\u0003\u01ca\u00e5\u0000\u09f7\u09f9\u0003\u01d0\u00e8\u0000\u09f8"+
		"\u09f6\u0001\u0000\u0000\u0000\u09f8\u09f7\u0001\u0000\u0000\u0000\u09f9"+
		"\u01c9\u0001\u0000\u0000\u0000\u09fa\u09fb\u0007\"\u0000\u0000\u09fb\u01cb"+
		"\u0001\u0000\u0000\u0000\u09fc\u09fd\u0007#\u0000\u0000\u09fd\u01cd\u0001"+
		"\u0000\u0000\u0000\u09fe\u09ff\u0007$\u0000\u0000\u09ff\u01cf\u0001\u0000"+
		"\u0000\u0000\u0a00\u0a01\u0007%\u0000\u0000\u0a01\u01d1\u0001\u0000\u0000"+
		"\u0000\u0a02\u0a03\u0003\u00c4b\u0000\u0a03\u0a04\u0007&\u0000\u0000\u0a04"+
		"\u0a05\u0003\u00c4b\u0000\u0a05\u01d3\u0001\u0000\u0000\u0000\u0a06\u0a08"+
		"\u0003\u00c4b\u0000\u0a07\u0a09\u0005\u0098\u0000\u0000\u0a08\u0a07\u0001"+
		"\u0000\u0000\u0000\u0a08\u0a09\u0001\u0000\u0000\u0000\u0a09\u0a0a\u0001"+
		"\u0000\u0000\u0000\u0a0a\u0a0b\u0005&\u0000\u0000\u0a0b\u0a0c\u0003\u00c4"+
		"b\u0000\u0a0c\u0a0d\u0005 \u0000\u0000\u0a0d\u0a0e\u0003\u00c4b\u0000"+
		"\u0a0e\u01d5\u0001\u0000\u0000\u0000\u0a0f\u0a11\u0003\u00c4b\u0000\u0a10"+
		"\u0a12\u0005\u0098\u0000\u0000\u0a11\u0a10\u0001\u0000\u0000\u0000\u0a11"+
		"\u0a12\u0001\u0000\u0000\u0000\u0a12\u0a13\u0001\u0000\u0000\u0000\u0a13"+
		"\u0a14\u0007\'\u0000\u0000\u0a14\u0a1b\u0003\u00c4b\u0000\u0a15\u0a19"+
		"\u0005M\u0000\u0000\u0a16\u0a1a\u0005\u00eb\u0000\u0000\u0a17\u0a1a\u0005"+
		"\u00ec\u0000\u0000\u0a18\u0a1a\u0003\u01ea\u00f5\u0000\u0a19\u0a16\u0001"+
		"\u0000\u0000\u0000\u0a19\u0a17\u0001\u0000\u0000\u0000\u0a19\u0a18\u0001"+
		"\u0000\u0000\u0000\u0a1a\u0a1c\u0001\u0000\u0000\u0000\u0a1b\u0a15\u0001"+
		"\u0000\u0000\u0000\u0a1b\u0a1c\u0001\u0000\u0000\u0000\u0a1c\u01d7\u0001"+
		"\u0000\u0000\u0000\u0a1d\u0a1f\u0003\u00c4b\u0000\u0a1e\u0a20\u0005\u0098"+
		"\u0000\u0000\u0a1f\u0a1e\u0001\u0000\u0000\u0000\u0a1f\u0a20\u0001\u0000"+
		"\u0000\u0000\u0a20\u0a21\u0001\u0000\u0000\u0000\u0a21\u0a22\u0005b\u0000"+
		"\u0000\u0a22\u0a23\u0003\u01da\u00ed\u0000\u0a23\u01d9\u0001\u0000\u0000"+
		"\u0000\u0a24\u0a25\u0007(\u0000\u0000\u0a25\u0a26\u0005\u0002\u0000\u0000"+
		"\u0a26\u0a27\u0003\u00ceg\u0000\u0a27\u0a28\u0005\u0003\u0000\u0000\u0a28"+
		"\u0a3b\u0001\u0000\u0000\u0000\u0a29\u0a2a\u0005\u0002\u0000\u0000\u0a2a"+
		"\u0a2b\u0003R)\u0000\u0a2b\u0a2c\u0005\u0003\u0000\u0000\u0a2c\u0a3b\u0001"+
		"\u0000\u0000\u0000\u0a2d\u0a3b\u0003\u01ea\u00f5\u0000\u0a2e\u0a37\u0005"+
		"\u0002\u0000\u0000\u0a2f\u0a34\u0003\u01c6\u00e3\u0000\u0a30\u0a31\u0005"+
		"\u0001\u0000\u0000\u0a31\u0a33\u0003\u01c6\u00e3\u0000\u0a32\u0a30\u0001"+
		"\u0000\u0000\u0000\u0a33\u0a36\u0001\u0000\u0000\u0000\u0a34\u0a32\u0001"+
		"\u0000\u0000\u0000\u0a34\u0a35\u0001\u0000\u0000\u0000\u0a35\u0a38\u0001"+
		"\u0000\u0000\u0000\u0a36\u0a34\u0001\u0000\u0000\u0000\u0a37\u0a2f\u0001"+
		"\u0000\u0000\u0000\u0a37\u0a38\u0001\u0000\u0000\u0000\u0a38\u0a39\u0001"+
		"\u0000\u0000\u0000\u0a39\u0a3b\u0005\u0003\u0000\u0000\u0a3a\u0a24\u0001"+
		"\u0000\u0000\u0000\u0a3a\u0a29\u0001\u0000\u0000\u0000\u0a3a\u0a2d\u0001"+
		"\u0000\u0000\u0000\u0a3a\u0a2e\u0001\u0000\u0000\u0000\u0a3b\u01db\u0001"+
		"\u0000\u0000\u0000\u0a3c\u0a3d\u0005Q\u0000\u0000\u0a3d\u0a3e\u0007(\u0000"+
		"\u0000\u0a3e\u0a3f\u0005\u0002\u0000\u0000\u0a3f\u0a40\u0003\u00ceg\u0000"+
		"\u0a40\u0a41\u0005\u0003\u0000\u0000\u0a41\u0a45\u0001\u0000\u0000\u0000"+
		"\u0a42\u0a43\u0005Q\u0000\u0000\u0a43\u0a45\u0003\u00c4b\u0000\u0a44\u0a3c"+
		"\u0001\u0000\u0000\u0000\u0a44\u0a42\u0001\u0000\u0000\u0000\u0a45\u01dd"+
		"\u0001\u0000\u0000\u0000\u0a46\u0a4a\u0005\u007f\u0000\u0000\u0a47\u0a4a"+
		"\u0005\u0085\u0000\u0000\u0a48\u0a4a\u0003\u00ceg\u0000\u0a49\u0a46\u0001"+
		"\u0000\u0000\u0000\u0a49\u0a47\u0001\u0000\u0000\u0000\u0a49\u0a48\u0001"+
		"\u0000\u0000\u0000\u0a4a\u01df\u0001\u0000\u0000\u0000\u0a4b\u0a50\u0003"+
		"\u01e2\u00f1\u0000\u0a4c\u0a4d\u0005\u0001\u0000\u0000\u0a4d\u0a4f\u0003"+
		"\u01e2\u00f1\u0000\u0a4e\u0a4c\u0001\u0000\u0000\u0000\u0a4f\u0a52\u0001"+
		"\u0000\u0000\u0000\u0a50\u0a4e\u0001\u0000\u0000\u0000\u0a50\u0a51\u0001"+
		"\u0000\u0000\u0000\u0a51\u01e1\u0001\u0000\u0000\u0000\u0a52\u0a50\u0001"+
		"\u0000\u0000\u0000\u0a53\u0a56\u0003\u01c6\u00e3\u0000\u0a54\u0a56\u0003"+
		"@ \u0000\u0a55\u0a53\u0001\u0000\u0000\u0000\u0a55\u0a54\u0001\u0000\u0000"+
		"\u0000\u0a56\u0a58\u0001\u0000\u0000\u0000\u0a57\u0a59\u0003\u01e8\u00f4"+
		"\u0000\u0a58\u0a57\u0001\u0000\u0000\u0000\u0a58\u0a59\u0001\u0000\u0000"+
		"\u0000\u0a59\u01e3\u0001\u0000\u0000\u0000\u0a5a\u0a5d\u0003\u01ea\u00f5"+
		"\u0000\u0a5b\u0a5d\u0005\u00ed\u0000\u0000\u0a5c\u0a5a\u0001\u0000\u0000"+
		"\u0000\u0a5c\u0a5b\u0001\u0000\u0000\u0000\u0a5d\u01e5\u0001\u0000\u0000"+
		"\u0000\u0a5e\u0a61\u0003\u01ea\u00f5\u0000\u0a5f\u0a61\u0003v;\u0000\u0a60"+
		"\u0a5e\u0001\u0000\u0000\u0000\u0a60\u0a5f\u0001\u0000\u0000\u0000\u0a61"+
		"\u01e7\u0001\u0000\u0000\u0000\u0a62\u0a63\u0005#\u0000\u0000\u0a63\u0a66"+
		"\u0003\u01f0\u00f8\u0000\u0a64\u0a66\u0003\u01ee\u00f7\u0000\u0a65\u0a62"+
		"\u0001\u0000\u0000\u0000\u0a65\u0a64\u0001\u0000\u0000\u0000\u0a66\u01e9"+
		"\u0001\u0000\u0000\u0000\u0a67\u0a68\u0005\t\u0000\u0000\u0a68\u0a6e\u0003"+
		"\u01f0\u00f8\u0000\u0a69\u0a6b\u0005\u0015\u0000\u0000\u0a6a\u0a6c\u0005"+
		"\u00ed\u0000\u0000\u0a6b\u0a6a\u0001\u0000\u0000\u0000\u0a6b\u0a6c\u0001"+
		"\u0000\u0000\u0000\u0a6c\u0a6e\u0001\u0000\u0000\u0000\u0a6d\u0a67\u0001"+
		"\u0000\u0000\u0000\u0a6d\u0a69\u0001\u0000\u0000\u0000\u0a6e\u01eb\u0001"+
		"\u0000\u0000\u0000\u0a6f\u0a74\u0003\u01f0\u00f8\u0000\u0a70\u0a71\u0005"+
		"\r\u0000\u0000\u0a71\u0a73\u0003\u01f0\u00f8\u0000\u0a72\u0a70\u0001\u0000"+
		"\u0000\u0000\u0a73\u0a76\u0001\u0000\u0000\u0000\u0a74\u0a72\u0001\u0000"+
		"\u0000\u0000\u0a74\u0a75\u0001\u0000\u0000\u0000\u0a75\u01ed\u0001\u0000"+
		"\u0000\u0000\u0a76\u0a74\u0001\u0000\u0000\u0000\u0a77\u0a7b\u0005\u00fa"+
		"\u0000\u0000\u0a78\u0a7b\u0005\u00fb\u0000\u0000\u0a79\u0a7b\u0007)\u0000"+
		"\u0000\u0a7a\u0a77\u0001\u0000\u0000\u0000\u0a7a\u0a78\u0001\u0000\u0000"+
		"\u0000\u0a7a\u0a79\u0001\u0000\u0000\u0000\u0a7b\u01ef\u0001\u0000\u0000"+
		"\u0000\u0a7c\u0a83\u0003\u01ee\u00f7\u0000\u0a7d\u0a83\u0005Z\u0000\u0000"+
		"\u0a7e\u0a83\u0005f\u0000\u0000\u0a7f\u0a83\u0005|\u0000\u0000\u0a80\u0a83"+
		"\u0005\u00a5\u0000\u0000\u0a81\u0a83\u0005\u00b5\u0000\u0000\u0a82\u0a7c"+
		"\u0001\u0000\u0000\u0000\u0a82\u0a7d\u0001\u0000\u0000\u0000\u0a82\u0a7e"+
		"\u0001\u0000\u0000\u0000\u0a82\u0a7f\u0001\u0000\u0000\u0000\u0a82\u0a80"+
		"\u0001\u0000\u0000\u0000\u0a82\u0a81\u0001\u0000\u0000\u0000\u0a83\u01f1"+
		"\u0001\u0000\u0000\u0000\u013a\u01f9\u01fe\u0206\u020f\u0215\u0218\u021e"+
		"\u0221\u0230\u0235\u0238\u0243\u0247\u024e\u0256\u0259\u025c\u025f\u0262"+
		"\u0266\u0269\u026c\u026f\u0273\u0276\u0279\u027c\u027e\u0288\u028f\u0295"+
		"\u0299\u029c\u02a2\u02a6\u02a8\u02ad\u02b1\u02b5\u02b8\u02be\u02c1\u02c5"+
		"\u02c7\u02cb\u02d0\u02d4\u02dc\u02e5\u02e9\u02ed\u02f3\u02f6\u02fe\u0309"+
		"\u0312\u031a\u0328\u032d\u0333\u0335\u0340\u0344\u0347\u034c\u0359\u0361"+
		"\u0367\u036d\u0376\u037b\u0381\u0393\u0397\u039a\u039d\u03a0\u03a6\u03b1"+
		"\u03ba\u03c4\u03cd\u03d2\u03d6\u03da\u03dc\u03e7\u03f0\u03f7\u03fb\u0402"+
		"\u0406\u040d\u0411\u0418\u041c\u0423\u0427\u042c\u0440\u0447\u044e\u045a"+
		"\u045d\u0476\u047c\u0492\u0495\u049c\u04a9\u04b1\u04b5\u04b9\u04c4\u04c8"+
		"\u04d0\u04dd\u04f3\u0503\u0505\u0511\u0515\u0519\u051c\u0520\u0527\u052d"+
		"\u053a\u0543\u054f\u0561\u0566\u0575\u057c\u0583\u058c\u0593\u0597\u059f"+
		"\u05a3\u05bb\u05c0\u05c5\u05de\u05ec\u05ef\u05fa\u0604\u060f\u0613\u061c"+
		"\u061f\u0622\u062b\u0634\u0652\u0661\u0665\u066a\u066e\u0673\u0677\u067c"+
		"\u067f\u0684\u0688\u068d\u0691\u0696\u069a\u069f\u06a3\u06bc\u06c8\u06db"+
		"\u06e3\u06e5\u06ee\u06f2\u06f8\u0701\u0709\u070d\u0710\u0713\u0716\u0719"+
		"\u071c\u0724\u072b\u074d\u0759\u075e\u0765\u0768\u0775\u077c\u077f\u078c"+
		"\u0795\u079b\u079f\u07a2\u07a5\u07ac\u07b0\u07c1\u07c7\u07cc\u07cf\u07d2"+
		"\u07dd\u07e3\u07eb\u07ed\u07f9\u0805\u0811\u081a\u0823\u0827\u0829\u0833"+
		"\u0836\u0841\u0847\u084b\u0852\u0855\u0865\u0868\u086b\u086e\u0874\u0877"+
		"\u087c\u087f\u0885\u0887\u0892\u0895\u0898\u089b\u08a6\u08af\u08b2\u08b6"+
		"\u08bb\u08c1\u08c4\u08c8\u08d0\u08e0\u08e3\u08e7\u08f9\u08fe\u0905\u0909"+
		"\u090c\u090f\u0919\u091c\u0922\u0925\u0928\u092a\u0932\u093a\u0940\u094c"+
		"\u0958\u0963\u0979\u097d\u0980\u0989\u0999\u09a0\u09a3\u09ad\u09b0\u09b2"+
		"\u09bf\u09c6\u09ce\u09d2\u09da\u09e5\u09ed\u09ef\u09f4\u09f8\u0a08\u0a11"+
		"\u0a19\u0a1b\u0a1f\u0a34\u0a37\u0a3a\u0a44\u0a49\u0a50\u0a55\u0a58\u0a5c"+
		"\u0a60\u0a65\u0a6b\u0a6d\u0a74\u0a7a\u0a82";
	public static final String _serializedATN = Utils.join(
		new String[] {
			_serializedATNSegment0,
			_serializedATNSegment1
		},
		""
	);
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}